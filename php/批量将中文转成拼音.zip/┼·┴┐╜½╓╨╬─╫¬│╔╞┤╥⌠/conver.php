<?php
require_once('pinyin_table.php');
require_once('inc_pinyin.php');

$conn = mysql_connect("localhost","root","zhangconghe");
mysql_set_charset('utf8');
mysql_select_db('newcard');


$sql1 ="SELECT id,gname FROM `game_info`";
$result1 = mysql_query($sql1);
while($rows1 = mysql_fetch_assoc($result1)){
    $id = $rows1['id'];
    $str = iconv('utf-8','gb2312',$rows1['gname']);
    echo '<hr>';
    echo $str;
    $first_char = getInitialCN($str);   //ȡ������ĸ
    $first_char = strtoupper($first_char);
    $first_char = iconv('gb2312','utf-8',$first_char);
    $first_char = ord($first_char);     //����ĸת��ascii��
    echo $first_char;

    $sql = "update game_info set firstchar = '{$first_char}' where id = '{$id}';";
    echo $sql."<br>";
    var_dump(mysql_query($sql));
}

?>
