<?php
include 'securityCode.class.php';
echo SecurityCode::Draw(4, 4, 98, 27, 10, 0, 20, 'vcode');
die();

//session_start();
//$vc = new ValidateCode();
//$vc->doimg();
//$_SESSION['vcode'] = $vc->getCode();
