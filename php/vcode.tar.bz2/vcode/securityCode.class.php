<?PHP
//ini_set('display_errors', 1);
//error_reporting(E_ALL | E_STRICT);
/**
  说明: 验证码生成类,支持生成Gif图片验证码(带噪点，干扰线，网格，随机色背景，随机自定义字体，倾斜，Gif动画）

  服务端：
  echo SecurityCode::Draw(4, 1, 120, 30, 5, 10, 100, "secode");
  die();
  调用: <img src="/getcode.php?mod=code" onclick="this.src='/getcode.php?mod=code&r='+Math.round(Math.random(0)*1000)">

  验证:
  $reqCode = strtolower(isset($_REQUEST["secode"]) ? $_REQUEST["secode"] : "");  //请求的验证码
  $sessionCode = strtolower(isset($_SESSION["secode"]) ? $_SESSION["secode"] : ""); //会话生成的验证码
  if($reqCode != $sessionCode){
  echo "安全验证码错误！";
  die();
  }
 */

// echo SecurityCode::Draw(4, 15, 100, 27, 10, 2, 100, "secode");

class SecurityCode {
        private static $debug = 0;
        private static $code = '';
        private static $chars = 'abcdefghkmnprstuvwxyzABCDEFGHKMNPRSTUVWXYZ23456789';

        private static $textGap = 20;
        private static $textMargin = 5;

        private static $fontFilePath = 'font/'; //相对地本代码文件的位置
        private static $fontFileName = array('DejaVuSansMono.ttf', 'consola.ttf', 'inconsolata.ttf', 'monaco.ttf');
//        private static $fontSize = 14; // 字体大小

        private static $imgHeader = 'GIF89a'; //GIF header 6 bytes   
        private static $BUF = array();
        private static $LOP = 0;
        private static $DIS = 2;
        private static $COL = -1;
        private static $IMG = -1;

        /**
          生成GIF图片验证
          @param int $L 验证码长度
          @param int $F 生成Gif图的帧数
          @param int $W 宽度
          @param int $H 高度
          @param int $mixCnt 干扰线数
          @param int $lineGap 网格线间隔
          @param int $noisyCnt 澡点数
          @param int $sName 验证码Session名称
         */
        public static function Draw($L = 4, $F = 1, $W = 150, $H = 30, $mixCnt = 2, $lineGap = 0, $noisyCnt = 10, $sName = "vcode") {
                ob_start();
                ob_clean();

                for ($i = 0; $i < $L; $i++) {
                        self::$code .= substr(self::$chars, mt_rand(0, strlen(self::$chars) - 1), 1);
                }

                if (!isset($_SESSION)){
                        session_start();
                }

                $_SESSION[$sName] = strtolower(self::$code);

                //生成一个多帧的GIF动画
                for ($i = 0; $i < $F; $i++) {
                        $bgRGB = array(mt_rand(157, 255), mt_rand(157, 255), mt_rand(157, 255));
                        $img = imagecreate($W, $H);

                        //背景色
                        $bgColor = imagecolorallocate($img, $bgRGB[0], $bgRGB[1], $bgRGB[2]);
                        imagecolortransparent($img, $bgColor);
                        unset($bgColor);

                        //添加噪点
                        $maxNoisy = rand(0, $noisyCnt);
                        $noisyColor = imagecolorallocate($img, mt_rand(0, 156), mt_rand(0, 156), mt_rand(0, 156));
                        for ($k = 0; $k <= $maxNoisy; $k++) {
                                imagesetpixel($img, rand(0, $W), rand(0, $H), $noisyColor);
                        }

                        //添加网格
                        if ($lineGap > 0) {
                                for ($m = 0; $m < ($W / $lineGap); $m++) { //竖线
                                        imageline($img, $m * $lineGap, 0, $m * $lineGap, $H, $noisyColor);
                                }
                                for ($n = 0; $n < ($H / $lineGap); $n++) { //横线
                                        imageline($img, 0, $n * $lineGap, $W, $n * $lineGap, $noisyColor);
                                }
                        }
                        unset($noisyColor);

                        // 添加干扰线
                        for ($k = 0; $k < $mixCnt; $k++) {
                                $wr = mt_rand(0, $W);
                                $hr = mt_rand(0, $W);
                                $lineColor = imagecolorallocate($img, mt_rand(0, 156), mt_rand(0, 156), rand(0, 156));
                                imagearc($img, $W - floor($wr / 2), floor($hr / 2), $wr, $hr, rand(90, 180), rand(180, 270), $lineColor);
                                unset($lineColor);
                                unset($wr, $hr);
                        }

                        //第一帧忽略文字
                        //if ($i != 0 || $F <= 1) {
                                for ($j = 0; $j < $L; $j++) {
                                        $fontColor = imagecolorallocate($img, mt_rand(0, 156), mt_rand(0, 156), mt_rand(0, 156));
                                        $fontFile = self::$fontFilePath . self::$fontFileName[rand(0, count(self::$fontFileName) - 1)];
                                        if (!file_exists($fontFile)){
                                                imagestring($img, 4, self::$textMargin + $j * self::$textGap, ($H - rand($H / 2, $H)), self::$code[$j], $fontColor);
                                        } else{
                                                imagettftext($img, rand(14, 16), mt_rand(-15, 15), self::$textMargin + $j * self::$textGap, ($H - rand(7, 10)), $fontColor, $fontFile, self::$code[$j]);
                                        }
                                }
                                unset($fontColor);
                        //}

                        imagegif($img);
                        imagedestroy($img);
                        $imdata[] = ob_get_contents();
                        ob_clean();
                }
                unset($W, $H, $B);
                /*
                   if (self::$debug) {
                   echo $_SESSION['code'];
                   echo '<pre>', var_dump($imdata), '</pre>';
                   die();
                   }
                 */
                header('Content-type:image/gif');
                return self::createGif($imdata, 24);
                unset($imdata);
        }

        private static function createGif($gifSrc, $gifDly = 24, $gifLop = 0, $gifDis = 0, $gifRed = 0, $gifGrn = 0, $gifBlu = 0, $gifMod = 'bin') {
                if (!is_array($gifSrc)) {
                        throw New Exception('Error:' . __LINE__ . ',Does not supported function for only one image!!');
                        die();
                }
                self::$LOP = ($gifLop > -1) ? $gifLop : 0;
                self::$DIS = ($gifDis > -1) ? (($gifDis < 3) ? $gifDis : 3) : 2;
                self::$COL = ($gifRed > -1 && $gifGrn > -1 && $gifBlu > -1) ? ($gifRed | ($gifGrn << 8) | ($gifBlu << 16)) : -1;
                for ($i = 0, $srcCnt = count($gifSrc); $i < $srcCnt; $i++) {
                        if (strtolower($gifMod) == 'url') {
                                self::$BUF[] = fread(fopen($gifSrc[$i], 'rb'), filesize($gifSrc[$i]));
                        } else if (strtolower($gifMod) == 'bin') {
                                self::$BUF[] = $gifSrc[$i];
                        } else {
                                throw New Exception('Error:' . __LINE__ . ',Unintelligible flag (' . $gifMod . ')!');
                                die();
                        }

                        if (!(substr(self::$BUF[$i], 0, 6) == 'GIF87a' Or Substr(self::$BUF[$i], 0, 6) == 'GIF89a')) {
                                throw New Exception('Error:' . __LINE__ . ',Source ' . $i . ' is not a GIF image!');
                                die();
                        }
                        for ($j = (13 + 3 * (2 << (ord(self::$BUF[$i]{10}) & 0x07))), $k = TRUE; $k; $j++) {
                                switch (self::$BUF[$i]{$j}) {
                                        case '!':
                                                if ((substr(self::$BUF[$i], ($j + 3), 8)) == 'NETSCAPE') {
                                                        throw New Exception('Error:' . __LINE__ . ',Could not make animation from animated GIF source (' . ($i + 1) . ')!');
                                                        die();
                                                }
                                                break;
                                        case ';':
                                                $k = FALSE;
                                                break;
                                }
                        }
                }
                self::addHeader();
                for ($i = 0, $bufCnt = count(self::$BUF); $i < $bufCnt; $i++) {
                        self::addFrames($i, $gifDly);
                }
                self::$imgHeader .= ';';
                return (self::$imgHeader);
        }

        private static function addHeader() {
                $i = 0;
                if (ord(self::$BUF[0]{10}) & 0x80) {
                        $i = 3 * (2 << (ord(self::$BUF[0]{10}) & 0x07));
                        self::$imgHeader .= substr(self::$BUF[0], 6, 7);
                        self::$imgHeader .= substr(self::$BUF[0], 13, $i);
                        self::$imgHeader .= "!\377\13NETSCAPE2.0\3\1" . chr(self::$LOP & 0xFF) . chr((self::$LOP >> 8) & 0xFF) . "\0";
                }
                unset($i);
        }

        private static function addFrames($i, $d) {
                $L_str = 13 + 3 * (2 << (ord(self::$BUF[$i]{10}) & 0x07));
                $L_end = strlen(self::$BUF[$i]) - $L_str - 1;
                $L_tmp = substr(self::$BUF[$i], $L_str, $L_end);
                $G_len = 2 << (ord(self::$BUF[0]{10}) & 0x07);
                $L_len = 2 << (ord(self::$BUF[$i]{10}) & 0x07);
                $G_rgb = substr(self::$BUF[0], 13, 3 * (2 << (ord(self::$BUF[0]{10}) & 0x07)));
                $L_rgb = substr(self::$BUF[$i], 13, 3 * (2 << (ord(self::$BUF[$i]{10}) & 0x07)));
                $L_ext = "!\xF9\x04" . chr((self::$DIS << 2) + 0) . chr(($d >> 0) & 0xFF) . chr(($d >> 8) & 0xFF) . "\x0\x0";
                if (self::$COL > -1 && ord(self::$BUF[$i]{10}) & 0x80) {
                        for ($j = 0; $j < (2 << (ord(self::$BUF[$i]{10}) & 0x07)); $j++) {
                                if (ord($L_rgb{3 * $j + 0}) == (self::$COL >> 0) & 0xFF && ord($L_rgb{3 * $j + 1}) == (self::$COL >> 8) & 0xFF && ord($L_rgb{3 * $j + 2}) == (self::$COL >> 16) & 0xFF) {
                                        $L_ext = "!\xF9\x04" . chr((self::$DIS << 2) + 1) . chr(($d >> 0) & 0xFF) . chr(($d >> 8) & 0xFF) . chr($j) . "\x0";
                                        break;
                                }
                        }
                }
                switch ($L_tmp{0}) {
                        case '!':
                                $L_img = substr($L_tmp, 8, 10);
                                $L_tmp = substr($L_tmp, 18, strlen($L_tmp) - 18);
                                break;
                        case ',':
                                $L_img = substr($L_tmp, 0, 10);
                                $L_tmp = substr($L_tmp, 10, strlen($L_tmp) - 10);
                                break;
                }
                if (ord(self::$BUF[$i]{10}) & 0x80 && self::$IMG > -1) {
                        if ($G_len == $L_len) {
                                if (self::compare($G_rgb, $L_rgb, $G_len)) {
                                        self::$imgHeader .= ($L_ext . $L_img . $L_tmp);
                                } else {
                                        $byte = ord($L_img{9});
                                        $byte |= 0x80;
                                        $byte &= 0xF8;
                                        $byte |= (ord(self::$BUF[0]{10}) & 0x07);
                                        $L_img{9} = chr($byte);
                                        self::$imgHeader .= ($L_ext . $L_img . $L_rgb . $L_tmp);
                                }
                        } else {
                                $byte = ord($L_img{9});
                                $byte |= 0x80;
                                $byte &= 0xF8;
                                $byte |= (ord(self::$BUF[$i]{10}) & 0x07);
                                $L_img{9} = chr($byte);
                                self::$imgHeader .= ($L_ext . $L_img . $L_rgb . $L_tmp);
                        }
                } else {
                        self::$imgHeader .= ($L_ext . $L_img . $L_tmp);
                }
                self::$IMG = 1;
        }

        private static function compare($G_Block, $L_Block, $Len) {
                for ($i = 0; $i < $Len; $i++) {
                        if ($G_Block{3 * $i + 0} != $L_Block{3 * $i + 0} || $G_Block{3 * $i + 1} != $L_Block{3 * $i + 1} || $G_Block{3 * $i + 2} != $L_Block{3 * $i + 2}) {
                                return (0);
                        }
                }
                return (1);
        }

}
