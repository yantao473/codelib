<?php
/**
 * filename : createlist.php
 * description : 
 * date : 2012-11-19
 * @category sina
 * @package application
 * @subpackage /program/application
 * @author Liu Chang <liuchang5@staff.sina.com.cn>
 * @copyright 2012(C) http://iask.sina.com.cn
 * @version 1.0
 */

include_once("apiconf.php");

class createlist extends webApp{
 	static private $input;
	function __construct(){
		self::$input = array(
			'app' => '', 
			'key_num' => 3,
			'key_size' => '',
			'key_type' => '',
			'value_size' => 0,
			'format' => 0
		);//format 0 json 1 serialize
	}
	
	private function checkinput()
	{
		$app_arr = array('plist','alist','vlist');
		self::$input['app'] = $_REQUEST['app'];
		if(!in_array(self::$input['app'], $app_arr)){
			$this->error(4000);
		}
		self::$input['key_num'] = (isset($_REQUEST['key_num']) && is_numeric($_REQUEST['key_num']))?intval($_REQUEST['key_num']):3;
		self::$input['key_size'] = $_REQUEST['key_size']; //4 or 8
		self::$input['key_type'] = $_REQUEST['key_type']; //char int
		self::$input['value_size'] = isset($_REQUEST['value_size'])?intval($_REQUEST['value_size']):128;
		self::$input['format'] = intval($_REQUEST['format']);
	}
	
	private function createlistid($v,&$tableid){
		//获取新表的ID
		$id = new IdServer();
		//$tableint = $id->get('tableint');
		//$tablechar = $id->get('tablechar');
		$tableint = 65536;
		//更新keybtree，此表用来维护所有的BDB表结构
		$keys[0] = BDB_INFO_TABLEID; //keybtree表ID
		$keys[1] = $tableint; //keybtee的key为 新表的ID
		$tableid = $tableint;
		$info = serialize($v);
		$u = new upbdb();
		//更新本地
		if (!$u->updata('keybtree', $keys, $info))
			return false;
		//写入远程队列
		if (!self::bdbqueue(1, 'keybtree', $keys, $info))
			return false;
		return true;
	}
	
	//写入远程队列
	private function bdbqueue($unitebdb, $t, $key, $data)
	{
		$tool = new tools();
		$url = QDOMAIN."/send_queue.php";
		$post_data = array();
		$post_data['unitebdb'] = $unitebdb;
		$post_data['t'] = $t;
		$post_data['key'] = $key;
		$post_data['data'] = $data;
		$str = serialize($post_data);
		$res='';
		return $tool->curl_set($url , 'post', array('data'=>$str), $res);
	}
	//错误对应
	function error($v){
		if (self::$input['format'] === 0){
			return $this->error_num($v);
		}
		global $g_error_app;
		$json_array = array('error_num'=>$v);
		$json_array['error'] = $g_error_app[$v];
		echo serialize($json_array);
		exit;
	}
	/*主函数
	 *
	 *
	 */
	function main(){
		//检查输入参数
		self::checkinput();
		$lkey = array();
		$lkey[0] = array(4,'int');
		$key_size_arr = explode(',', self::$input['key_size']);
		$key_type_arr = explode(',', self::$input['key_type']);
		$keysize = 4;
		for($i=0;$i<self::$input['key_num'];$i++){
			if(!isset($key_size_arr["$i"]) || !isset($key_type_arr["$i"]))
				$this->error(4011);
			if($key_type_arr["$i"]!="int" && $key_type_arr["$i"]!="char")
				$this->error(4011);
			if($key_type_arr["$i"]=='int' && !is_numeric($key_size_arr["$i"]))
				$this->error(4002);
			$lkey[] = array($key_size_arr["$i"],$key_type_arr["$i"]);
			$keysize += intval($key_size_arr["$i"]);
		}
		//生成表结构数组
		$table = array();
		$table['t'] = self::$input['app'];
		$table['lkey'] = $lkey;
		if(self::$input['app']=='alist'){
			$table['ikey']=0;
		}else{
			$table['ikey']=1;
		}
		$table['lvalue'] = self::$input['value_size'];
		$tableid=0;
		if(!self::createlistid($table,$tableid))
			$this->error(4005);
		$data = array();
		$data['type'] = 1; //索引类型，1 btree, 2 hash
		$data['islist'] = 1; //是否列表类型， 0 非列表， 1 列表， 2 计数器类型(按int来设计)
		$data['universal'] = 1; //是否通用类型 0 普通（默认）， 1 通用表
		$data['listindextable'] = 0; //是否key创建辅助索引表 0 无 1 辅助表  2 主表（重复更新）3 主表（重复不更新）
		$data['pagesize'] = (self::$input['app']=='plist')?4096:((self::$input['app']=='vlist')?4096:16384); //页大小
		$data['tableid'] = $tableid; //应用id 普通表值为0，通用表有值
		$data['listindexaddr'] = 0; //key不进入排序值偏移
		$data['listindexsize'] = 0; //key不进入排序值长度
		$data['keysize'] = $keysize; //key大小，不固定大小的为0
		$data['datasize'] = self::$input['value_size']; //value长度，不固定大小为0
		$data['datablocksize'] = 0; //value块大小，不固定块大小为0
		$data['datablockuniquesize'] = 0; //value块无重复关键字大小，从头开始计算(访客) 0 无限制
		$data['datablockuindexsize'] = 0; //块排序大小，按字典顺序
		$bdb = new bdbdb();
		//本地
		if(!$bdb->createtableid($tableid, $data))
			$this->error(4012);
		//写入远程队列
		if (!self::bdbqueue(3, '', $tableid, $data))
			$this->error(4012);

		$tableinfo = array();
		$tableinfo['tableid'] = $tableid;
		array_shift($lkey);
		$tableinfo['keys'] = $lkey;
		$tableinfo['value_size'] = $data['datasize'];
		if (self::$input['format'] === 0){
			echo json_encode(array('result'=>true,'tableinfo'=>$tableinfo));
		}else{
			echo serialize(array('result'=>true,'tableinfo'=>$tableinfo));
		}
	}
}
$app = new createlist();
$app->run();
