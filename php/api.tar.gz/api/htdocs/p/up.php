<?php
/**
 * @fn              修改/添加 bdb通用接口
 * @author          haiyang
 * @copyright       新浪研发
 * @link            /p/up.php
 * @date            2012-06-25
 */

include_once("apiconf.php");



class up extends webApp{
	static private $input;
	function __construct(){
		self::$input = array('tableid'=>0,'key'=>'','value'=>'','secondid'=>'','format'=>0);//format 0 json 1 serialize
	}
	
	private function checkinput()
	{
		self::$input['tableid'] = intval($_REQUEST['tableid']);
		if (self::$input['tableid'] == 0 || self::$input['tableid'] == 7)
			$this->error(4000);
		if (!isset($_REQUEST['key']))
			$this->error(4001);
		self::$input['key'] = $_REQUEST['key'];
		self::$input['secondid'] = ((isset($_REQUEST['secondid']) && is_numeric($_REQUEST['secondid']))?intval($_REQUEST['secondid']):'');
		self::$input['value'] = (isset($_REQUEST['value'])?$_REQUEST['value']:'');
		self::$input['format'] = intval($_REQUEST['format']);
	}
	//写入远程队列
	private function bdbqueue($t, $key, $data)
	{
		$tool = new tools();
		$url = QDOMAIN."/send_queue.php";
		$post_data = array();
		$post_data['unitebdb'] = 1;
		$post_data['t'] = $t;
		$post_data['key'] = $key;
		$post_data['data'] = $data;
		$str = serialize($post_data);
		return $tool->curl_set($url , 'post', array('data'=>$str), $res);
	}
	//错误对应
	function error($v){
		if (self::$input['format'] === 0){
			return $this->error_num($v);
		}
		global $g_error_app;
		$json_array = array('error_num'=>$v);
		$json_array['error'] = $g_error_app[$v];
		echo serialize($json_array);
		exit;
	}
	/*主函数
	 *
	 *
	 */
	function main(){
		//检查输入参数
		self::checkinput();
		//$u = new upbdb();
		$bdb = new bdbdb();
		if (!$bdb->gettableconf(self::$input['tableid'], $tarray))
			$this->error(4000);
		$keys = array();
		$keys[0] = self::$input['tableid'];
		if (self::$input['secondid'] !== '')
			$keys[1] = self::$input['secondid'];
		if (is_array(self::$input['key'])){
			foreach (self::$input['key'] as $v)
			{
				$keys[] = $v;
			}
		}else{
			$keys[] = self::$input['key'];
		}
		foreach ($tarray['lkey'] as $k => $v)
		{
			if (!isset($keys["$k"]))
				$this->error(4003);
			if ($v[1] === 'int' && !is_numeric($keys["$k"]))
				$this->error(4002);
		}
		$info = self::$input['value'];
		if ($tarray['flag'] == 'array'){
			if (!is_array(self::$input['value'])){
				if (self::$input['format'] === 0){
					$info = json_decode(self::$input['value'], true);
				}else{
					$info = unserialize(self::$input['value']);
				}
			}
			if (!is_array($info))
				$this->error(4004);
		}else if ($tarray['flag'] == 'int'){
			if (count($tarray['v']) !== count($info))
				$this->error(4004);
		}
		//更新
		$u= new bdb();

	// write some up log.
	//	file_put_contents('/usr/home/xingyue/set.log','KEYS:'. var_export($keys,true) . "\n info : " . 
	//		var_export($info,true)
	//	 ,FILE_APPEND);

		if (false===$u->set($keys, array($info)))
		//if (!$u->updata($tarray['t'], $keys, $info))
			$this->error(4005);
		//入远程队列
		if (!self::bdbqueue($tarray['t'], $keys, $info))
			$this->error(4005);
		if (self::$input['format'] === 0){
			echo json_encode(array('result'=>true));
		}else{
			echo serialize(array('result'=>true));
		}
	}
}
$app = new up();
$app->run();
?>
