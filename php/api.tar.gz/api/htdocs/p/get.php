<?php
/**
 * @fn              获取 bdb通用接口
 * @author          haiyang
 * @copyright       新浪研发
 * @link            /p/get.php
 * @date            2012-06-25
 */
include_once("apiconf.php");
class get extends webApp{
	static private $input;
	function __construct(){
		self::$input = array('tableid'=>0,'key'=>'','secondid'=>'','format'=>0);//format 0 json 1 serialize 2 json_rawurlencode（可用于gbk输出json格式）
	}
	
	private function checkinput()
	{
		self::$input['tableid'] = intval($_REQUEST['tableid']);
		if (self::$input['tableid'] == 0)
			$this->error(4000);
		if (!isset($_REQUEST['key']))
			$this->error(4001);
		self::$input['key'] = $_REQUEST['key'];
		self::$input['secondid'] = ((isset($_REQUEST['secondid']) && is_numeric($_REQUEST['secondid']))?intval($_REQUEST['secondid']):'');
		self::$input['format'] = intval($_REQUEST['format']);
	}
	
	//错误对应
	function error($v){
		if (self::$input['format'] === 0){
			return $this->error_num($v);
		}
		global $g_error_app;
		$json_array = array('error_num'=>$v);
		$json_array['error'] = $g_error_app[$v];
		echo serialize($json_array);
		exit;
	}
	function my_encode(&$v, &$k)
	{
		$v = rawurlencode($v);
		$k = rawurlencode($k);
	}
	/*主函数
	 *
	 *
	 */
	function main(){
		//检查输入参数
		self::checkinput();
		//$g = new getbdb();
		$bdb = new bdbdb();
		if (!$bdb->gettableconf(self::$input['tableid'], $tarray))
			$this->error(4000);
		$keys = array();
		$tmpkey = array();
		$multi = 0;
		$tmpkey[0] = self::$input['tableid'];
		if (self::$input['secondid'] !== '')
			$tmpkey[1] = self::$input['secondid'];
		if (is_array(self::$input['key'])){
			$count = count($tarray['lkey']);
			$i = 0;
			if (($count -1) == count($tmpkey)){//获取多个
				$multi = 1;
				foreach (self::$input['key'] as $v)
				{
					$keys[$i] = $tmpkey;
					$keys[$i][] = $v;
					$i++;
				}
			}else if(is_array(self::$input['key'][0])){
				$multi = 1;
				foreach (self::$input['key'] as $v)
				{
					$keys[$i] = $tmpkey;
					foreach ($v as $v1)
					{
						$keys[$i][] = $v1;
					}
					$i++;
				}
			}else{ 
				$keys = $tmpkey;
				foreach (self::$input['key'] as $v)
				{
					$keys[] = $v;
				}
			}
		}else{
			$keys = $tmpkey;
			$keys[] = self::$input['key'];
		}
	
		$g = new bdb();	
//get some get log
 //file_put_contents('/usr/home/xingyue/gets.log','keys:'. var_export($keys,true) . "\n"
//           ,FILE_APPEND);


		//获取
		//if (!$g->gets($tarray['t'], $keys, $data))
		if (false === ($data=$g->get($keys, false)))
			$this->error(4007);
		if ($multi == 0){
			list(,$data) = each($data);
		}
		switch(self::$input['format'])
		{
			case 1:
				echo serialize($data);
				break;
			case 2:
				array_walk_recursive($data, array($this, "my_encode"));
				echo json_encode($data);
				break;
			default:
				echo json_encode($data);
				break;
		}
	}
}
$app = new get();
$app->run();
?>
