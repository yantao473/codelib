<?php
/**
 * @fn              检查key是否存在 bdb通用接口
 * @author          haiyang
 * @copyright       新浪研发
 * @link            /p/checklist.php
 * @date            2012-06-25
 */
include_once("apiconf.php");

class checklist extends webApp{
	static private $input;
	function __construct(){
		self::$input = array('tableid'=>0,'key'=>'', 'findkeys'=>'','isvalue'=> 0,'secondid'=>'','format'=>0);//format 0 json 1 serialize
	}
	
	private function checkinput()
	{
		self::$input['tableid'] = intval($_REQUEST['tableid']);
		if (self::$input['tableid'] == 0)
			$this->error(4000);
		if (!isset($_REQUEST['key']))
			$this->error(4001);
		if (!isset($_REQUEST['findkeys']))
			$this->error(4001);
		self::$input['key'] = $_REQUEST['key'];
		self::$input['findkeys'] = $_REQUEST['findkeys'];
		self::$input['isvalue'] = (intval($_REQUEST['isvalue']) != 1?true:false);
		self::$input['secondid'] = ((isset($_REQUEST['secondid']) && is_numeric($_REQUEST['secondid']))?intval($_REQUEST['secondid']):'');
		self::$input['format'] = intval($_REQUEST['format']);
	}
	//错误对应
	function error($v){
		if (self::$input['format'] === 0){
			return $this->error_num($v);
		}
		global $g_error_app;
		$json_array = array('error_num'=>$v);
		$json_array['error'] = $g_error_app[$v];
		echo serialize($json_array);
		exit;
	}
	
	/*主函数
	 *
	 *
	 */
	function main(){
		//检查输入参数
		self::checkinput();
		$g = new getbdb();
		$bdb = new bdbdb();
		if (!$bdb->gettableconf(self::$input['tableid'], $tarray))
			$this->error(4000);
		$keys = array();
		$keys[0] = self::$input['tableid'];
		if (self::$input['secondid'] !== '')
			$keys[1] = self::$input['secondid'];
		if (is_array(self::$input['key'])){
			foreach (self::$input['key'] as $v)
			{
				$keys[] = $v;
			}
		}else{
			$keys[] = self::$input['key'];
		}
		foreach ($tarray['lkey'] as $k => $v)
		{
			if (!isset($keys["$k"]))
				break;
			if (is_numeric($v) && !is_numeric($keys["$k"]))
				$this->error(4002);
		}
		
		//获取
		if (!$g->getlistkey($tarray['t'], $keys, self::$input['findkeys'], $data, self::$input['isvalue']))
			$this->error(4007);
		if (self::$input['format'] === 0){
			echo json_encode($data);
		}else{
			echo serialize($data);
		}
	}
}
$app = new checklist();
$app->run();
?>