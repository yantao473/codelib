<?php
exit();
error_reporting(E_ALL | E_STRICT);
include_once("apiconf.php");
$keys = array(10,1,2,3);
$info = array(9,7,8);
$u= new bdb();
$r = $u->set($keys, array($info));
$m = $u->get($keys,$data);
var_dump($m);
