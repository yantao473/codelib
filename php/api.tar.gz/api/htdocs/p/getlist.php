<?php
/**
 * @fn              修改/添加 bdb通用接口
 * @author          haiyang
 * @copyright       新浪研发
 * @link            /p/getlist.php
 * @date            2012-06-25
 */
include_once("apiconf.php");

class getlist extends webApp{
	static private $input;
	function __construct(){
		self::$input = array('tableid'=>0,'key'=>'','start'=>'','num'=>'','order'=>0,'secondid'=>'','format'=>0);//format 0 json 1 serialize
	}
	
	private function checkinput()
	{
		self::$input['tableid'] = intval($_REQUEST['tableid']);
		if (self::$input['tableid'] == 0)
			$this->error(4000);
		if (!isset($_REQUEST['key']))
			$this->error(4001);
		self::$input['key'] = $_REQUEST['key'];
		self::$input['start'] = intval($_REQUEST['start']);
		self::$input['num'] = intval($_REQUEST['num']);
		self::$input['order'] = (intval($_REQUEST['order']) != 1?0:1);
		self::$input['secondid'] = ((isset($_REQUEST['secondid']) && is_numeric($_REQUEST['secondid']))?intval($_REQUEST['secondid']):'');
		self::$input['format'] = intval($_REQUEST['format']);
		if (self::$input['num'] > 200){
			if (self::$input['tableid'] > 10000)
			$this->error(4006);
		}
	}
	//错误对应
	function error($v){
		if (self::$input['format'] === 0){
			return $this->error_num($v);
		}
		global $g_error_app;
		$json_array = array('error_num'=>$v);
		$json_array['error'] = $g_error_app[$v];
		echo serialize($json_array);
		exit;
	}
	
	/*主函数
	 *
	 *
	 */
	function main(){
		//检查输入参数
		self::checkinput();
		//$g = new getbdb();
		$bdb = new bdbdb();
		if (!$bdb->gettableconf(self::$input['tableid'], $tarray))
			$this->error(4000);
		$keys = array();
		$keys[0] = self::$input['tableid'];
		if (self::$input['secondid'] !== '')
			$keys[1] = self::$input['secondid'];
		if ($tarray['t'] !== 'alist'){
			if (is_array(self::$input['key'])){
				foreach (self::$input['key'] as $v)
				{
					$keys[] = $v;
				}
			}else{
				$keys[] = self::$input['key'];
			}
		}
		foreach ($tarray['lkey'] as $k => $v)
		{
			if (!isset($keys["$k"]))
				break;
			if ($v[1] === 'int' && !is_numeric($keys["$k"]))
				$this->error(4002);
		}
		$g = new bdb();	
		//获取
		//if (!$g->lists($tarray['t'], $keys, self::$input['start'], self::$input['num'], $data, self::$input['order']))
		if (false === ($data=$g->getlist($keys, self::$input['start'], self::$input['num'], self::$input['order'])))
			$this->error(4007);
		if (self::$input['format'] === 0){
			echo json_encode($data);
		}else{
			echo serialize($data);
		}
	}
}
$app = new getlist();
$app->run();
?>
