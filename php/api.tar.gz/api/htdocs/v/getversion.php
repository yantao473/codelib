<?php
/**
 * 获取版本信息
 *
 * @package     version
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
*/
include_once("apiconf.php");

class Version extends webApp
{
	private $tools_obj;
	
	public function __construct() 
	{
		$this->tools_obj = new Tools();
		$this->fname = ROOT_DIR . '/data/version_code.data';
	}
	
	public function main() 
	{
		$this->_check_params();
		if($this->g_para['get_version'] == 'weibo_ask') {
			$this->get_version();
			die();
		}
	}

	/**
	 * 获取参数
	 * 
	 * @param :
	 * @return :
	*/
	private function _check_params()
	{
		$this->g_para['get_version']	= $_POST['get_version'] ? $_POST['get_version'] : 0;
	}

	private function get_version() {
		if(file_exists($this->fname)) {
			$s_ver = trim(file_get_contents($this->fname));
			echo $s_ver;
		}
	}
}
$app = new Version();
$app->run();
?>
