<?php
/**
 * 感兴趣的人和话题
 */
class Getinterest extends Webapp {
	public $getbdb_obj;
	function __construct() {
        $this->getbdb_obj = new GetBdb;		
	}
    function main(){
        $uid = isset($_REQUEST['uid'])?$_REQUEST['uid']:0;
        $type = isset($_REQUEST['type'])?$_REQUEST['type']:'';
        if(in_array($type,array('user','tag'),true)){
            if(!empty($uid)){
                $res = $this->getbdb_obj->gets('interest',$uid,$data);
                echo json_encode($data["$type"]);
            }else{
                $this->error_num(2902);
            }    
        }else{
            $this->error_num(2901);
        }
      
    }
}
$app = new Getinterest;
$app->run();

?>