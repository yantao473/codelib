<?php
/**
 * 用户中心
 *
 * @package     User
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
*/
include_once("apiconf.php");

class Register extends webApp
{
	private $err_msg;
	private $err_code;
	private $g_error_app;

	public function __construct() 
	{
		global $g_error_app;
		$this->g_error_app = $g_error_app;
		$this->tools_obj = new Tools();
		$this->user_obj = new Login_UserMan();
	}
	
	public function main() 
	{
		$this->_check_params();
		$para_stat = $this->_check_params_legal();
		if(!$para_stat)
		{
			$this->error_num($this->err_code);
			die();
		}
		$flag = $this->do_platform();
		if(!$flag)
		{
			$this->error_num($this->err_code);
			die();
		}
		echo json_encode(array('result'=>'success'));
	}

	/**
	 * 获取参数
	 * 
	 * @param :
	 * @return :
	*/
	private function _check_params()
	{
		$this->g_para['uid']		= $_REQUEST['uid'];
		$this->g_para['login']		= $_REQUEST['login'];
		$this->g_para['nick']		= $_REQUEST['nick'];
		$this->g_para['gender']		= is_numeric($_REQUEST['gender']) ? $_REQUEST['gender'] : 0;
		$this->g_para['ag']		= intval($_REQUEST['ag']);
		$this->g_para['status']		= $_REQUEST['status'] ? $_REQUEST['status'] : 0;
		$this->g_para['picture']	= $_REQUEST['picture'] ? $_REQUEST['picture'] : 0;
		$this->g_para['ip']			= $_REQUEST['ip'];
		$this->g_para['app']		= $_REQUEST['app'];
		$this->g_para['ctime']		= !empty($_REQUEST['ctime']) ? $_REQUEST['ctime'] : date('Y-m-d H:i:s');
		$this->g_para['notice_set']	= !empty($_REQUEST['notice_set']) ? $_REQUEST['notice_set'] : 0 ;
		$this->g_para['invite_set']	= !empty($_REQUEST['invite_set']) ? $_REQUEST['invite_set'] : 1 ;	// 1 所有人都可以邀请我回答问题
		$this->g_para['invite_nums']= !empty($_REQUEST['invite_nums'])? $_REQUEST['invite_nums']: 6 ;
		$this->g_para['description']= $_REQUEST['description'];
		//首次登录首页标志
		 $this->g_para['index_first_login'] =  0;
	}

	/**
	 * 检查参数合法性
	 * 
	 * @param :
	 * @return : bool
	*/
	private function _check_params_legal()
	{
	    // 判断用户id
        if(!$this->_check_empty($this->g_para['uid']))
        {
	        $this->err_code = 2001;
            return false;
        }
        elseif(!$this->_check_num($this->g_para['uid'])) {
	        $this->err_code = 2002;
            return false;
        }

	    // 判断注册邮箱
        if(!$this->_check_empty($this->g_para['login']))
        {
	        $this->err_code = 2015;
            return false;
        }

	    // 判断昵称
        if(!$this->_check_empty($this->g_para['nick']))
        {
	        $this->err_code = 2017;
            return false;
        }
/*
	    // 判断用户组别
        if(!$this->_check_empty($this->g_para['ag']))
        {
	        $this->err_code = 2019;
            return false;
        }
        elseif(!$this->_check_num($this->g_para['ag'])) {
	        $this->err_code = 2020;
            	return false;
        }
*/

	    // 判断应用
        if(!$this->_check_empty($this->g_para['app']))
        {
	        $this->err_code = 2005;
            return false;
        }
        elseif(!$this->_check_num($this->g_para['app'])) {
	        $this->err_code = 2006;
            return false;
        }
		return true;
	}

	/**
	 * 注册用户
	 * 
	 * @param :
	 * @return : bool
	*/
	private function do_platform()
	{
		$acols = array(
			'uid'			=> $this->g_para['uid'],
			'login'			=> $this->g_para['login'],
			'nick'			=> $this->g_para['nick'],
			'gender'		=> $this->g_para['gender'],
			'ag'			=> $this->g_para['ag'],
			'status'		=> $this->g_para['status'],
			'picture'		=> $this->g_para['picture'],
			'ip'			=> $this->g_para['ip'],
			'app'			=> $this->g_para['app'],
			'ctime'			=> $this->g_para['ctime'],
			'notice_set'	=> $this->g_para['notice_set'],
			'invite_set'	=> $this->g_para['invite_set'],
			'invite_nums'	=> $this->g_para['invite_nums'],
			'description'	=> $this->g_para['description'],
			'data_append'  => json_encode( array( 'index_first_login'=> $this->g_para['index_first_login']) ),
		);
		if(!$this->user_obj->reg_local($acols,$err)) 
		{
			$this->err_code = 2203;
			return false;
		}
		$this->send_to_bdb();
		return true;
	}

	function send_to_bdb()
	{
		$acols = array(
			'0'			=> EVENT_USER_REGISTER,
			'uid'			=> $this->g_para['uid'],
			'login'			=> $this->g_para['login'],
			'nick'			=> $this->g_para['nick'],
			'gender'		=> $this->g_para['gender'],
			'ag'			=> $this->g_para['ag'],
			'status'		=> $this->g_para['status'],
			'picture'		=> $this->g_para['picture'],
			'ip'			=> $this->g_para['ip'],
			'app'			=> $this->g_para['app'],
			'ctime'			=> $this->g_para['ctime'],
			'notice_set'	=> $this->g_para['notice_set'],
			'invite_set'	=> $this->g_para['invite_set'],
			'invite_nums'	=> $this->g_para['invite_nums'],
			'description'	=> $this->g_para['description'],
			'data_append'  => json_encode( array( 'index_first_login'=> $this->g_para['index_first_login']) ),
		);
		//$this->tools_obj->queue_send('user',$acols);
		$url = QDOMAIN . "/send_queue.php";
		$this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($acols)) , $queue_result);
		
		if(!$queue_result) {
			sleep(1);
			$this->tools_obj->curl_set($url , 'POST' , $acols , $queue_result);
			if(!$queue_result) {
				return false;
			}
		}
		return true;
	}

    private function _check_empty($v) {
	    if(empty($v)) {
			return false;
        }
        else{
	        return true;
        }
    }
 
    private function _check_num($v) {
	    if(!preg_match('~^[0-9]+$~is',$v)) {
	        return false;
        }
        else {
 	       return true;
        }
    }


	/**
	 * 验证用户是否存在
	 *
	 * @param
	 * @return boll
	*/
	function _check_user_exists() {
	    $aconf = array(
		    'login' => $this->g_para['login'],
	    );
	    if($this->user_obj->get_user_detail($aconf , $data)) {
			if($data[0]['login'] == $this->g_para['login']) {
		            $this->err_code = 2016;
					return false ;
	            }
	        }
			else {
		        $this->err_code = 2201;
	            return false;
	        }
	   return true;
	}

	/**
	 * 验证用户是否存在
	 *
	 * @param
	 * @return boll
	*/
	function _check_nick_exists() {
	    $aconf = array(
		    'nick' => $this->g_para['nick'],
	    );
	    if($this->user_obj->get_user_detail($aconf , $data)) {
			if($data[0]['nick'] == $this->g_para['nick']) {
		            $this->err_code = 2018;
					return false ;
	            }
	        }
			else {
		        $this->err_code = 2201;
	            return false;
	        }
	   return true;
	}
}
$app = new Register();
$app->run();
?>
