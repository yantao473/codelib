<?php
/**
 * 用户中心
 *
 * @package     User
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
 * @update time xianghui 2012/09/11
*/

include_once("apiconf.php");

class upuser extends webApp implements Platform_Api{
        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

	public function __construct() 
	{
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();

	}

        function _init_param(){
                $this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;           
                $this->g_para['uid'] = floatval($_REQUEST['uid']);           
		$this->g_para['nick'] = $_REQUEST['nick'];
		$this->g_para['status']	= $_REQUEST['status'];
		$this->g_para['picture'] = $_REQUEST['picture'];
		$this->g_para['description'] = $_REQUEST['description'];
		$this->g_para['notice_set'] = $_REQUEST['notice_set'];
		$this->g_para['invite_set'] = $_REQUEST['invite_set'];
		$this->g_para['invite_nums'] = $_REQUEST['invite_nums'];
                //没有帮助标志暂时放到dataappend
                $this->g_para['nohelpflag'] = $_REQUEST['nohelpflag'];
		//修改首次登录首页标志字段
		$this->g_para['index_first_login'] = isset( $_REQUEST['index_first_login'] ) ? floatval($_REQUEST['index_first_login']) : 0;
		//申请专家时的话题，数组形式
		$this->g_para['be_good_at'] =  $_REQUEST['be_good_at']; //array
        }                                                                                                  
                                                                                                           
        function _check_param(){                                                                           
                if(empty($this->g_para['uid'])){                                                           
                        $this->error_num(2508);                                                            
                }                                                                                          
        }                                                                                                  
                                                                                                           
        function _init_class(){                                                                            
		$this->tools_obj = new Tools();
		$this->user_obj = new Login_UserMan();
		$this->log_obj = new LOGS();
        }       
                  
        function _init_api_config(){                                                                       
                $this->api_name = 'upuser';                                                                 
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
                if(empty($this->api_config)) {                                                             
                        $this->error_num(3001);                                                            
                }                                                                                          
        }   

	
	function main() 
	{
		$flag = $this->_check_login();
		if(!$flag)
		{
			$this->error_num($this->err_code);
			die();
		}
		$flag = $this->do_platform();
		if(!$flag)
		{
			$this->error_num($this->err_code);
			die();
		}
		$this->run_api_event();
		echo json_encode(array('result'=>'success'));
	}
	
	/**
	 * 更新用户信息
	 * 
	 * @param :
	 * @return : bool
	*/
	private function do_platform()
	{
		$acols = array();
		if($this->g_para['nick'])
		{
			$acols['nick'] = $this->g_para['nick'];
			#$user_edit_log = $acols['nick'];
		}
		if($this->g_para['status'] != '')
		{
			$acols['status'] = $this->g_para['status'];
		}
		if($this->g_para['picture'])
		{
			$acols['picture'] = $this->g_para['picture'];
			#$user_edit_log .= $acols['picture'];
		}
		if(isset($this->g_para['description']))
		{
			$acols['description'] = $this->g_para['description'];
			#$user_edit_log .= $acols['description'];
		}
		if(isset($this->g_para['notice_set']))
		{
			$acols['notice_set'] = $this->g_para['notice_set'];
		}
		if(isset($this->g_para['invite_set']))
		{
			$acols['invite_set'] = $this->g_para['invite_set'];
		}
		if($this->g_para['invite_nums'])
		{
			$acols['invite_nums'] = $this->g_para['invite_nums'];
		}
		if($this->g_para['app'])
		{
			$acols['app'] = $this->g_para['app'];
		}
		//data_append
                $flag = $this->user_obj->get_user_detail_bdb($this->g_para['uid'],$data);
		$tmp_data_append = json_decode($data['data_append'],true);
		
		if($this->g_para['nohelpflag'])
		{
			$tmp_data_append["iszdflag"] = $this->g_para['nohelpflag'];
		}
		//首次登录首页标志
		if(isset($this->g_para['index_first_login']))
		{
			$tmp_data_append["index_first_login"] = $this->g_para['index_first_login'];
		}
		//张晗那边不需要判断这个字段为空 
		#if(isset($this->g_para['be_good_at'])){
			$tmp_data_append["be_good_at"] = $this->g_para['be_good_at'];
		#}
		if(!empty( $tmp_data_append)){
			$acols['data_append'] = json_encode($tmp_data_append);
		}
		$flag = $this->user_obj->update_user_detail($this->g_para['uid'],$acols,$data);
		if(!$flag)
		{
			$this->err_code = 2004;
			return false;
		}
		$this->update_bdb($acols);
		/*
		if($user_edit_log) {
			// 调日志类 添加用户修改用户信息的动态
			$flag = $this->log_obj->add_logs($this->g_para['uid'],$this->g_para['uid'],EVENT_USER_UPDATE,$user_edit_log,date('Y-m-d H:i:s'));
			if(!$flag)
			{
				$this->err_code = 2004;
				return false;
			}
		}
		*/
		return true;
	}

	/**
	 * 更bdb
	 *
	 * @param
	 * @return bool 
	*/
	private function update_bdb($acols) {
		$acols[0]	= EVENT_USER_UPDATE;
		$acols['uid']	= $this->g_para['uid'];
		$acols['etime']	= date('Y-m-d H:i:s');
		$url = QDOMAIN."/send_queue.php";
                $queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($acols)) , $queue);
		//$this->tools_obj->queue_send('user',$acols);
		return true;
	}

	private function _check_login() {
		return true;		// 一期不做登陆判断
		$flag = $this->login_obj->check_sso_cookie($err_code,$userinfo);
		if(!$flag)
		{
			$this->err_code = 6;
			$this->err_msg = $this->g_error_app[6];
			return false;
		}
		return true;
	}

        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$app = new upuser();
$app->run();
?>
