<?php
/**
 * 用户中心
 *
 * @package     User
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
*/
include_once("apiconf.php");

class UserActList extends webApp
{
	private $err_code;
	private $err_msg;
	private $g_error_app;

	public function __construct() 
	{
		global $g_error_app;
		$this->g_error_app = $g_error_app;
		$this->tools_obj = new Tools();
		$this->bdb_obj	= new GetBdb();
	}
	
	public function main() 
	{
		$this->_check_params();
		$para_stat = $this->_check_params_legal();
		if(!$para_stat)
		{
			$this->error_num($this->err_code);
			die();
		}
		$flag = $this->do_platform($callback);
		if(!$flag)
		{
			$this->error_num($this->err_code);
			die();
		}
		echo $callback;
	}

	/**
	 * 获取参数
	 * 
	 * @param :
	 * @return :
	*/
	private function _check_params()
	{
		$this->g_para['uid']		= $_REQUEST['uid'];
		$this->g_para['type']		= $_REQUEST['type'];	// uq问过,um问他,ua答过,ue编辑
		$this->g_para['start']		= $_REQUEST['start'] ? $_REQUEST['start'] : 0;
		$this->g_para['num']		= isset($_REQUEST['num']) ? $_REQUEST['num'] : 10;
		$this->g_para['app']		= $_REQUEST['app'];
		$this->g_para['order']		= $_REQUEST['order'];
                //图片显示控制标志                                                                         
                $this->g_para['imgflag'] = isset($_REQUEST['imgflag']) ? floatval($_REQUEST['imgflag']) : 0;
	}

	/**
	 * 检查参数合法性
	 * 
	 * @param :
	 * @return : bool
	*/
	private function _check_params_legal()
	{
		// 判断对象id
		if(!$this->_check_empty($this->g_para['uid']))
		{
			$this->err_code = 2001;
			return false;
		}
		elseif(!$this->_check_num($this->g_para['uid'])) {
			$this->err_code = 2002;
			return false;
		}

		// 判断类型id
		if(!$this->_check_empty($this->g_para['type']))
		{
			$this->err_code = 2007;
			return false;
		}
		elseif($this->_check_num($this->g_para['type'])) {
			$this->err_code = 2021;
			return false;
		}

		if(!$this->_check_num($this->g_para['num'])) {
			$this->err_code = 2011;
			return false;
		}

		return true;
	}

	/**
	 * 更新用户信息
	 * 
	 * @param :
	 * @return : bool
	*/
	private function do_platform(&$callback)
	{
		$flag = $this->get_act_list($data);
		if(!$flag) 
		{
			$this->err_code = 2202;
			return false;
		}
		$callback = json_encode($data);
		return true;
	}

	private function get_act_list(&$data)
	{
		// 问他 
		if($this->g_para['type'] == 'um') {
			$this->get_um_list($data);
		}
		// 问过
		if($this->g_para['type'] == 'uq') {
			$this->get_uq_list($data);
		}
		// 答过
		if($this->g_para['type'] == 'ua') {
			$this->get_ua_list($data);
		}
		// 编辑
		if($this->g_para['type'] == 'ue') {
			$this->get_ue_list($data);
		}
		// 被赞同的人
		if($this->g_para['type'] == 'uqv') {
			$this->get_uqv_list($data);
		}
		
		return true;
	}
	
	private function get_ue_list(&$ue_info)
	{
		$flag = $this->bdb_obj->lists($this->g_para['type'], $this->g_para['uid'], $this->g_para['start'], $this->g_para['num'], $data, $this->g_para['order']);	
		if(!$flag)
		{
			$this->err_code = 2202;
			return false;
		}
		$total = $data['total'];
		$num = $data['num'];
		unset($data['total'] , $data['num']);
		//print_R($data);die();
		if($total > 0)
		{
			foreach($data as $k => $v)
		    {
				// qid 数组
		        $v['keys'][1] = date('Y-m-d H:i:s',$v['keys'][1]);
				$info = array_merge($v['data'],$v['keys']);
				
				// 获取用户详细信息
		        if(!empty($v['data']['uid'])) {
			        $this->bdb_obj->gets('user',array($v['data']['uid']) , $udata);
					$info['user_info'] = $udata[$v['data']['uid']];
				}
		        
		        unset($msg);
				
				switch($info['type']) 
				{
					case 30 :					// 修改个人用户信息
						$msg = $msg ? $msg : '修改了昵称、描述';
						$info['msg'] = $msg;
						break;
					case 33 :
						$msg = $msg ? $msg : '修改了个人头像';
						$old_pic = $this->image_obj->getlogo($info['oid'],'uc');
						$new_pic = $this->image_obj->getlogo($info['pid'],'uc');
						$udata['old_pic'] = $old_pic;
						$udata['new_pic'] = $new_pic;
						$info['msg'] = $msg;
						break;
					case 1:
						$msg = $msg ? $msg : '添加了问题';
						if(!empty($info['oid'])) {
							$this->bdb_obj->gets('question',array($info['oid']), $qinfo);
						}
						$info['question_info'] = $qinfo[$info['oid']];
						$info['msg'] = $msg;
						break;
					case 7 :                                        // 添加答案
					    $msg = $msg ? $msg : '添加了答案';
					case 8 :                                        // 删除答案
					    $msg = $msg ? $msg : '删除了答案';
					case 9 :                                        // 添加答案
					    $msg = $msg ? $msg : '更新了答案';
					case 10 :                                        // 删除答案
					    $msg = $msg ? $msg : '恢复了答案';
					case 29 :                                       // 恢复答案
					    $msg = $msg ? $msg : '对问题描述进行了更新';
						if(!empty($info['oid'])) {
							$this->bdb_obj->gets('question',array($info['oid']), $qinfo);
						}
						$info['question_info'] = $qinfo[$info['oid']];
						$info['msg'] = $msg;
						break;
					case 5:                                     // 问题话题添加
						$msg = $msg ? $msg : '为问题添加了话题';
						if(!empty($info['oid'])) {
							$this->bdb_obj->gets('question',array($info['oid']), $qinfo);
						}
						$info['question_info'] = $qinfo[$info['oid']];
					case 6:                                     // 问题话题删除
						$msg = $msg ? $msg : '为问题删除了话题';
						if(!empty($info['oid'])) {
							$this->bdb_obj->gets('question',array($info['oid']), $qinfo);
						}
						$info['question_info'] = $qinfo[$info['oid']];
					case 21:                                        // 父话题添加
					    $msg = $msg ? $msg : '为话题添加了父话题';
					case 22:                                        // 父话题删除
					    $msg = $msg ? $msg : '为话题移除了父话题';
					case 23:                                        // 子话题添加
					    $msg = $msg ? $msg : '为话题添加了子话题';
					case 24:                                        // 子话题删除
					    $msg = $msg ? $msg : '为话题移除了子话题';
					case 32:                                        // 创建话题
					    $msg = $msg ? $msg : '创建了话题';
						$info['msg'] = $msg;
						break;
					case 28 :                                       // 修改问题标题信息
					    $msg = $msg ? $msg : '修改了问题标题';
						$info['msg'] = $msg;
						break;
					case 31:
					    $msg = $msg ? $msg : '用户成功注册';
						$info['msg'] = $msg;
						break;
				}
				$ue_info[] = $info;
			}
			$ue_info['total'] = $total;
		}
		return true;
	}
	
   /*
    * 答过
    *
    * @param: &array , array
    * @return: bool
   */
   private function get_ua_list(&$ua_info) {
	   // 根据uid获取回答列表
		$flag = $this->bdb_obj->lists($this->g_para['type'], $this->g_para['uid'], $this->g_para['start'], $this->g_para['num'], $data, $this->g_para['order']);	
		//print_r($data);die();
		if(!$flag)
		{
			$this->err_code = 2202;
			return false;
		}
		$total = $data['total'];
        $num = $data['num'];
        unset($data['total'] , $data['num']);
        if($total > 0) 
		{
	        foreach($data as $k => $v) 
			{
				if(!empty($v['keys']))
                {
					list($uid, $stime, $qid) = $v['keys'];
                	$ids[] = $qid;
            	}
			}
			
			foreach($data as $k => $v)
			{
	            list($uid, $stime, $qid) = $v['keys'];
                // 取问题id
				$answerid = $v['data'];
				// 取问题信息
                $this->bdb_obj->gets('question', array($qid), $qdata);
               	$qdata = $qdata[$qid];
                
				$this->bdb_obj->gets('answer',$answerid, $ansdata);
                
				if(!empty($ansdata)) {
                                                //deal图片显示  暂时 start
                                                if(empty($this->g_para['imgflag'])){
                                                        //默认过滤图片
                                                $apreg = '~\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
                                                $ansdata['answer'] = preg_replace_callback(
                                                        $apreg,
                                                        function($match){
                                                        return "";
                                                },
                                                $ansdata['answer']
                                                );
                                                }
                                                //end


                	$ansdata['questionid'] = $qdata['questionid'];
                   	$ansdata['qtitle'] = $qdata['title'];
                   	$ansdata['gz'] = $qdata['gz'];
                   	$ansdata['qnick'] = $qudata['nick'];
                   	$ansdata['quid'] = $qudata['uid'];
                   	$ua_info[] = $ansdata;
				}
			}
			$ua_info['total'] = $total;
		}
		return true;
	}

	/*
	 * 问过
	 *
	 * @param: &array
	 * @return: bool
	*/
	private function get_uq_list(&$uq_info) {
		$flag = $this->bdb_obj->lists($this->g_para['type'], $this->g_para['uid'], $this->g_para['start'], $this->g_para['num'], $data, $this->g_para['order']);	
		//print_r($data);die();
		if(!$flag)
		{
			$this->err_code = 2202;
			return false;
		}
        
		$total = $data['total'];
        	$num = $data['num'];
        	unset($data['total'] , $data['num']);
        	if($total > 0) 
		{
	        	foreach($data as $k => $v) 
			{
				if(!empty($v['keys']))
                		{
					list($uid, $stime, $qid) = $v['keys'];
                			$ids[] = $qid;
            			}
			}
			
            		foreach($data as $k => $v)
			{
	            		list($uid, $stime, $qid) = $v['keys'];
                		// 取谁问的
				$fromuid = $v['data'];
				// 取问题信息
                		$this->bdb_obj->gets('question', array($qid), $qdata);
               			$qdata = $qdata[$qid];
                
				if(!empty($qdata)) 
				{
	                		$qdata['atotal'] = $qdata['atotal'] ? $qdata['atotal'] : 0 ;
					$uq_info[] = $qdata;
                		}
			}
			$uq_info['total'] = $total;
		}
		return true;
	}


	/*
	 * 问他
	 *
	 * @param: &array
	 * @return: bool
	*/
	private function get_um_list(&$um_info)
	{
		$flag = $this->bdb_obj->lists($this->g_para['type'], $this->g_para['uid'], $this->g_para['start'], $this->g_para['num'], $data, $this->g_para['order']);	
		//echo "um \n";print_r($data);die();
		if(!$flag)
		{
			$this->err_code = 2202;
			return false;
		}
        $total = $data['total'];
        $num = $data['num'];
        unset($data['num'] , $data['total']);
        if($total > 0) 
		{
	        foreach($data as $k => $v) 
			{
				if(!empty($v['keys']))
                {
					list($uid, $stime, $qid) = $v['keys'];
                	$ids[] = $qid;
            	}
			}
			
			foreach($data as $k => $v) 
			{
	            list($uid, $stime, $qid) = $v['keys'];
                // 取谁问的
				$fromuid = $v['data'];
				// 取问题信息
                $this->bdb_obj->gets('question', array($qid), $qdata);
               	$qdata = $qdata[$qid];

                if(!empty($qdata))
				{
	                // 获取提问者详细信息
	                $this->bdb_obj->gets('user', $fromuid, $udata);
                    $qdata['nick'] = $udata['nick'];
                    $um_info[] = $qdata;
                }
            }
			$um_info['total'] = $total;
		}
		return true;
	}

	private function _check_empty($v) {
		if(empty($v)) {
			return false;
		}
		else{
			return true;
		}
	}
 
     private function _check_num($v) {
        if(!preg_match('~^[0-9]+$~is',$v)) {
             return false;
        }
        else {
            return true;
        }
     }
	
	/*
	 * 被赞同
	 *
	 * @param: &array
	 * @return: bool
	*/
	private function get_uqv_list(&$u_info)
	{
		$flag = $this->bdb_obj->lists($this->g_para['type'], $this->g_para['uid'], $this->g_para['start'], $this->g_para['num'], $data, $this->g_para['order']);	
		//echo "um \n";print_r($data);die();
		if(!$flag)
		{
			$this->err_code = 2202;
			return false;
		}
        $total = $data['total'];
        $num = $data['num'];
        unset($data['num'] , $data['total']);
        if($total > 0) 
		{
	        foreach($data as $k => $v) 
			{
				if(!empty($v['keys']))
                {
					$qid = $v['data'];
                	$this->bdb_obj->gets('question', array($qid), $qdata);
               		$qdata = $qdata[$qid];
					list($uid, $stime, $vuid) = $v['keys'];
	            	$this->bdb_obj->gets('user', $vuid, $udata);
                	$u_info[] = array(
									'uid' => $udata['uid'],
                					'nick' => $udata['nick'],
									'time' => date('Y-m-d H:i:s',$stime),
									'title' => $qdata['title'],
									'qid' => $qid,
								);
            	}
			}
			$u_info['total'] = $total;
		}
		return true;
	}
}
$app = new UserActList();
$app->run();
?>
