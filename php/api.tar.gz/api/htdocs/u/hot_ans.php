<?php
/**
 * 回答列表
 *
 * @package     User
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
*/
include_once("apiconf.php");

class HotAns extends webApp
{
	private $err_code;
	private $err_msg;
	private $g_error_app;
	private $tools_obj;
	
	public function __construct() 
	{
		global $g_error_app;
		$this->g_error_app = $g_error_app;
		$this->tools_obj = new Tools();
		$this->q_obj = new Login_QMan();
		$this->bdb_obj  = new GetBdb();
	}
	
	public function main() 
	{
		$this->_check_params();

		$this->prepare_data();

	}

	/**
	 * 获取参数
	 * 
	 * @param :
	 * @return :
	*/
	private function _check_params()
	{
		# $this->g_para['time']	= $_REQUEST['time'] ? $_REQUEST['time'] : '';
		//$this->g_para['time'] = date('Y-m-d');
	}

	private function prepare_data() {
		# $h = date('H');
		//$h = 12;
		#if($h == 12) {	// 每天中午12点 查昨天一天的回答 从赞同最多的回答开始排序
			$this->create_data();
		#}
		#$this->read_data($json_str);
		#echo $json_str;
	}
	
	private function read_data(&$json_str) {
		
		$flag = $this->bdb_obj->gets('hotanswer', strtotime($this->g_para['time']) , $data);	
		
		if(!empty($data['list'])) {
			foreach($data['list'] as $k => $inf) {
				$qids[] = $inf['questionid'];
				//$aids[] = $inf['answerid'];
			}
			
			$this->bdb_obj->gets('detail', $qids, $qdata);
			//print_r($qdata);die();
			//$this->bdb_obj->gets('answer', $aids, $adata);
			//print_r($adata);die();
			
			foreach($data['list'] as $k => $inf) {
				$data['list'][$k]['qinfo'] = $qdata[$inf['questionid']];
				//$data['list'][$k]['ainfo'] = $adata[$inf['answerid']];
			}
		}
		$json_str = json_encode($data);
	}

	private function create_data() {
		$this->q_obj->get_ans_top_list($data);
		# $this->send_to_bdb($data);
		echo json_encode($data);
		return true;
	}

	function send_to_bdb($data)
	{
		$acols = array(
		    '0'			=> EVENT_INDEX_HOT_ANSWER,
	        'ctime'		=> date('Y-m-d'),
			'list'		=> $data,
	    );
	    $this->tools_obj->queue_send('question_queue',$acols);
	}
}
$app = new HotAns();
$app->run();
?>
