<?php
/**
 * 批量获取话题信息
 * @update  xianghui@staff.sina.com.cn
 * 20120907
 */
require_once("apiconf.php");

class GetBatchTags extends webApp  implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();

	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['syncid'] = isset($_REQUEST['syncid']) ? floatval($_REQUEST['syncid']) : 1;
		//多个tids,以半角逗号分开
		$this->g_para['tid_str'] =  $_REQUEST['tid_str'];
		//多个tags,以半角逗号分开
		$this->g_para['tag_str'] =  $_REQUEST['tag_str'];
		//话题广场需要话题描述，如果descflag = 1 表示需要desc，如果descflag = 0 表示不需要desc
		$this->g_para['descflag'] = isset($_REQUEST['descflag']) ? floatval($_REQUEST['descflag']) : 0;
	}                                                                                                  
	function _check_param(){                                                                           
		if(isset($this->g_para['tid_str']) && empty($this->g_para['tid_str'])){
			$this->error_num(2505);
		}
		if(isset($this->g_para['tag_str']) && empty($this->g_para['tag_str'])){
			$this->error_num(2124);
		}
	}                                                                                                  
	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;                                                                  
		$this->follow_obj = new Follow($this->g_para , $this->g_result);                                             
	}                                                                                                  
	function _init_api_config(){                                                                       
		$this->api_name = 'getbatchtags';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 

	function main(){
		$this->get_batch_tags();
	}
	function get_batch_tags(){
		$arr = array();
		if(!empty($this->g_para['tid_str'])){
			$tids = @explode(",",$this->g_para['tid_str']);
			$tids_arr = array();
			if(!empty($tids)){
				foreach($tids as $v){
					if(!empty($v)){
						$tids_arr[] = floatval($v);
					}
				}
			}

			$res = $this->tag_obj->get_batch_tagid($tids_arr, $tag_info);
		}
		elseif(!empty($this->g_para['tag_str'])){
			$tids_arr = array();
			$tags = @explode(",",$this->g_para['tag_str']);
			$tags_arr = array();
			if(!empty($tags)){
				foreach($tags as $v){
					if(!empty($v)){
						$tags_arr[] = trim($v);
					}
				}
			}
			//先获取话题ID
			$res = @$this->tag_obj->gettag($tags_arr, $tag_id_info);
			if(!empty($tag_id_info)){
				foreach($tag_id_info as $k => $v){
					$tids_arr[] = $v;
				}
			}
			//通过话题ID数组 获取话题信息
			$res = $this->tag_obj->get_batch_tagid($tids_arr, $tag_info);
		}

		$data = array();
			foreach($tag_info as $k => $v){
				if(empty($k)){
					continue;
				}
				$arr["$k"]['tid'] = $v['tid'];
				$arr["$k"]['name'] = $v['name'];
				$arr["$k"]['showflag'] = $v['showflag'];
				if( $this->g_para['descflag'] == 1){
					$arr["$k"]['desc'] = $v['description'];	
				}
			}
			$data = array('result'=>true,'data'=>$arr);

		$this->run_api_event();
		echo json_encode($data);

	}
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}
}
$app = new GetBatchTags;
$app->run();
?>
