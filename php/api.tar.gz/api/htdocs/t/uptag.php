<?php
/**
 * 修改话题
 * @update  xianghui@staff.sina.com.cn
 * @date 2012-08-28
 */
require_once('apiconf.php');

class Uptag extends webApp  implements Platform_Api{

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['tid'] = isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : "";
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : 0;
		$this->g_para['showflag'] = isset($_REQUEST['showflag']) ? floatval($_REQUEST['showflag']) : 0;
		$this->g_para['status'] = $_REQUEST['status'];
		$this->g_para['image'] = isset($_REQUEST['image']) ? $_REQUEST['image'] : 0;
		$this->g_para['desc'] =  $_REQUEST['desc'];
		$this->g_para['tname'] = isset($_REQUEST['tname']) ? $_REQUEST['tname'] : "";                                                $this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;           
		$this->g_para['utime'] = isset($_REQUEST['utime']) ? htmlspecialchars($_REQUEST['utime']) : date("Y-m-d H:i:s");
		$this->g_para['nolog'] = isset($_REQUEST['nolog']) ? floatval($_REQUEST['nolog']) : 0; // 1表后台过来的	
		$this->g_para['deltname'] = isset($_REQUEST['deltname']) ? $_REQUEST['deltname'] : ""; // 1表示要删除没用的话题	
	}                                                                                                  

	function _check_param(){                                                                           
	}                                                                                                  

	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;                                                                  
	}   

	/*                                                                                                 
	 * 初始化接口功能                                                                                   
	 */                                                                                                 
	function _init_api_config() {                                                                      
		$this->api_name = 'uptag';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 

	function main() {
		$this->deal_update_tag();
	}
	function deal_update_tag(){

		if(!empty($this->g_para['tname']) && empty($this->g_para['tid'])){
			$tname = mysql_escape_string($this->g_para['tname']);
			$t_res = $this->tag_obj->gettag($tname,$tid);
		}else if(!empty($this->g_para['tid'])){
			$tid = $this->g_para['tid'];
		}else{
			$tid = 0;
		}
		$this->g_para['logids_array'] = array();

/*
		if(empty($tid) || empty($this->g_para['uid'])){
			$this->error_num(2501);
		}
		if(!empty($this->g_para['image'])){
			$image = mysql_escape_string($_REQUEST['image']);
		}
*/
		if(isset($this->g_para['desc'])){
			$desc = mysql_escape_string($this->g_para['desc']);
			 $this->g_para['utime'] = date("Y-m-d H:i:s");
			$res['d'] = $this->tag_obj->uptag_desc($tid, $desc, $this->g_para['utime'], $this->g_para['uid'],0,$desc_logid,$this->g_para['nolog']);
			$this->g_para['logids_array'][] = $desc_logid;
			if(!$res['d']){
				$this->error_num(2512);
				exit;
			}
		}

		//修改话题名称
		//同时删除修改之前的话题名称
		if(!empty( $this->g_para['tname']) && !empty($this->g_para['tid']) && !empty($this->g_para['deltname'])){
			$result = $this->tag_obj->uptag_tname($tid,  $this->g_para['tname'], $this->g_para['utime'], $this->g_para['uid'],$this->g_para['deltname']);
			if(!$result){
				$this->error_num(2512);
				exit;
			}
	
		}

		if(!empty($this->g_para['image'])) {
			$image = mysql_escape_string($this->g_para['image']);
			//$utime = $this->tag_obj->log_addns($utime,1);                
#$this->utime = date('Y-m-d H:i:s' , strtotime($this->utime) + 1);
			 $this->g_para['utime'] = date("Y-m-d H:i:s");
			$res['i'] = $this->tag_obj->uptag_image($tid, $image, $this->g_para['utime'], $this->g_para['uid'],$img_logid,$this->g_para['nolog']);
			$this->g_para['logids_array'][]  = $img_logid;
			if(!$res['i']){
				$this->error_num(2513);
				exit;
			}
		}

		// 更新话题 隐藏 显示 状态
		if(isset($this->g_para['showflag'])){
			//$utime = $this->tag_obj->log_addns($utime,1);    
#$this->utime = date('Y-m-d H:i:s' , strtotime($this->utime) + 1);
			$res['sh'] = $this->tag_obj->uptag_showflag($tid,$this->g_para['showflag'],$this->g_para['utime'],$this->g_para['uid'],$this->g_para['nolog']);
			if(!$res['sh']){
				$this->error_num(2514);
				exit;
			}                
		}

		// 锁定话题&&解锁话题
		if(isset($this->g_para['status']) && @in_array($this->g_para['status'],array(0,1))){
			//$utime = $this->tag_obj->log_addns($utime,1);  
#$this->utime = date('Y-m-d H:i:s' , strtotime($this->utime) + 1);
			$res['st'] = $this->tag_obj->uptag_status($tid,$this->g_para['status'],$this->g_para['utime'],$this->g_para['uid']); 
			if(!$res['st']){
				$this->error_num(2515);
				exit;
			}                
		}

		$r_res['res'] = true; 
		if(isset($res['i']) && $res['i']){
			$r_res['src'] = $res['i']; //图片地址
		}
		$r_res['logids'] = $this->g_para['logids_array'];
		$this->run_api_event();
		echo json_encode($r_res);
		exit;

	}
	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}



}
$app = new Uptag;
$app->run();
?>
