<?php
/**
 * 批量白名单
 * @update  xianghui@staff.sina.com.cn
 * 20121209
 */
require_once("apiconf.php");

class GetWhitelist extends webApp  implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();

	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		//一个或者多个tids,多个以半角逗号分开
		$this->g_para['tid_str'] =  isset($_REQUEST['tid_str']) ? trim($_REQUEST['tid_str']) : '';
		$this->filename = '/data0/weibo/data/grassroots_expert_words.txt';
	}                                                                                                  
	function _check_param(){
                if(empty($this->g_para['app'])) {
                        $this->error_num(3000);                                                                   
                }                                                                    
		if( empty($this->g_para['tid_str'])){
			$this->error_num(2505);
		}
	}                                                                                                  
	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->memc = new mcevent;                                                             
	}                                                                                                  
	function _init_api_config(){                                                                       
		$this->api_name = 'getwhitelist';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 

	function main(){
		$this->get_tid_uids();
	}
	function get_tid_uids(){
		$arr = array();
		if(!empty($this->g_para['tid_str'])){
			$tids = @explode(",",$this->g_para['tid_str']);
			$tids_arr = array();
			if(!empty($tids)){
				foreach($tids as $v){
					if(!empty($v)){
						$tids_arr[] = floatval($v);
					}
				}
			}
			//读取 MC
			$arr = $this->get_mc_data($tids_arr);
			#$arr = array();
			//读取文件
			if(empty($arr)){
				$data = $this->get_file_data($this->filename);
				if(!empty($data)){
					foreach($tids_arr as $tid){
						if(!empty($data[$tid])){
							$arr[$tid] = $data[$tid];
						}else{
							$arr[$tid] = array();
						}
					}
				}
				#print_r($arr);
			}
		}

		$this->run_api_event();
		echo json_encode($arr);

	}
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}

        function get_mc_data($arr) {
		$tmp_arr = array();
		if(!empty( $arr )){
			foreach ( $arr as $v ){
				$res = $this->memc->get("mc_whitelist_".$v);
				if(!$res){
					$tmp_arr[$v] = array();
				}else{
                			$tmp_arr[$v] = $res;
				}
			} 
		}
                return $tmp_arr;
        }

        function get_file_data($file){
                if(!file_exists($file)){
                        touch($file);
                }
                $data = file_get_contents($file);
                $data = json_decode($data,true);
                return $data;
        }

}
$app = new GetWhitelist;
$app->run();
?>
