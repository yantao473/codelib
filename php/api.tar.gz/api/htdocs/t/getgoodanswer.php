<?php
/***
 * 获取话题页优秀回答者   统计知识
 * @by tingting18
 * @update xianghui 2012-09-10 
 */
require_once("apiconf.php");

class Getgoodanswer extends webApp  implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
	}

        function _init_param(){
                $this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
                $this->g_para['tid'] = isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : "";                                        
        }    
                                                                                              
        function _check_param(){                                                                           
		if(empty($this->g_para['tid'])){
			$this->error_num(2518);
		}
        }                                                                                                  
        function _init_class(){                                                                            
                $this->tools_obj= new Tools();                                                             
		$this->stat_obj = new Stat;
		$this->getbdb_obj = new GetBdb;
                //$this->tag_obj = new Tag;                                                                  
        }                                                                                                  
        function _init_api_config(){                                                                       
                $this->api_name = 'getgoodanswer';                                                                 
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
                if(empty($this->api_config)) {                                                             
                        $this->error_num(3001);                                                            
                }                                                                                          
        }    

	function main(){
		$this->get_good_answer();
	}
	function get_good_answer(){
		if(!empty($this->g_para['tid'])){
			$good_answer = $this->stat_obj->get_tag_ask($this->g_para['tid'],'canswer');
			$this->run_api_event();
			echo json_encode($good_answer);
			exit;            
		}
	}   

        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }
 
}
$app = new Getgoodanswer;
$app->main();
?>
