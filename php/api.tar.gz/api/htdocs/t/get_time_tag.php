<?php
/**
 * 获取所有话题
 * 20120720
 */
require_once('apiconf.php');
class tag{
    public $rpcdb_obj,$tag_obj,$getbdb_obj,$queue_obj;
    function __construct() {
        $this->rpcdb_obj = new RpcDb;
	$this->gettime   = $_REQUEST['time'] ;
    }
    function main(){
        //得到所有话题id       
	$time = date("Y-m-d H:i:s",$this->gettime);
        $tags = $this->getall_tagid($time);
	if(!empty($tags)){
		$date = date("Y-m-d H:i:s",strtotime("-2 days"));
		$tags['time'] = strtotime($date);	
	}
	echo json_encode($tags);
    } 
    
    /**
     * 获得所有话题id
     */
    function getall_tagid($time){
        $sql = "SELECT tid,name FROM tag where ctime > '$time' ";
        $dbname = 'question';
        $res = $this->rpcdb_obj->read($dbname,$sql, $data);
        return $data; 
    }
    
}
$app = new tag;
$app->main();
?>

