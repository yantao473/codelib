<?php
/**
 * 修改话题经验
 * @update : xianghui@staff.sina.com.cn
 * @date : 20120827
 */
require_once('apiconf.php');

class Upexp extends webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function _init_param(){
		$this->g_para['tid'] = isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : "";                     
		$this->g_para['content'] = isset($_REQUEST['content']) ? $_REQUEST['content'] : "";                     
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : 0;           
		$this->g_para['tname'] = $_REQUEST['tname'];
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;           
	}                                                                                                  

	function _check_param(){                                                                           
		if(empty($this->g_para['uid']) ){                            
			$this->error_num(2510);
		}                                                                                          
	}                                                                                                  

	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;                                                                  
	}       
	/*                                                                                                 
	 * 初始化接口功能                                                                                   
	 */                                                                                                 
	function _init_api_config() {                                                                      
		$this->api_name = 'upexp';                                                                
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 

	function main(){
		$this->deal_tag();

	}
	
	function deal_tag(){
		if(!empty($this->g_para['tname'])){
			$t_res = $this->tag_obj->gettag( $this->g_para['tname'] ,$tid);
		}else if(!empty( $this->g_para['tid'])){
			$tid =  $this->g_para['tid'];
		}
		//删除话题经验(删除mysql中content为''的字段，为了和bdb保持一致) 
		$utime = date("Y-m-d H:i:s");
		if(empty($this->g_para['content'])){
			$res['res'] = $this->tag_obj->delexp($tid, $this->g_para['uid'], $this->g_para['content'], $utime); 
		}else{
			$e_res = $this->tag_obj->getexp($this->g_para['uid'],$tid,0,20, $taginfo);
			$ishave = $this->tag_obj->getexpdb($this->g_para['uid'],$tid);
			if($e_res && isset($taginfo["$tid"]) && $ishave){//update
				$res['res'] = $this->tag_obj->upexp($tid, $this->g_para['uid'], $this->g_para['content'], $utime); 
			}else{//add
				$res['res'] = $this->tag_obj->addexp($tid, $this->g_para['uid'],$this->g_para['content'], $utime); 
			}  
		}
		$this->run_api_event(); 
		echo json_encode($res);
		exit;

	}
        /*
         * 调用接口功能订制列表
         */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$app = new Upexp;
$app->run();
?>
