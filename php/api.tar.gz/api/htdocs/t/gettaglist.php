<?php
/**
 * 获取话题列表（包括话题下的所有问题及已采纳的问题）
 */
require_once("apiconf.php");
class Gettaglist extends webApp  implements Platform_Api {
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['tid'] =  isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : 0;
		$this->g_para['tname'] = isset($_REQUEST['tname']) ? trim($_REQUEST['tname']) : "";
		$this->g_para['flag'] = isset($_REQUEST['flag']) ? floatval($_REQUEST['flag']) : 0;         
		$this->g_para['type'] = isset($_REQUEST['type']) ? trim($_REQUEST['type']) : "";              
		$this->g_para['start'] = isset($_REQUEST['start'])?$_REQUEST['start']:0;
		$this->g_para['num'] = isset($_REQUEST['num'])?$_REQUEST['num']:20;                                
	}                                                                                                  
	function _check_param(){                                                                           

	}                                                                                                  
	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;                                                                  
		$this->getbdb_obj = new GetBdb;                                                            
	}                                                                                                  
	function _init_api_config(){                                                                       
		$this->api_name = 'gettaglog';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	}  

	function main(){
		$this->gettaglist();
	}
	function gettaglist(){
		if(!empty( $this->g_para['tname'])){
			$t_res = $this->tag_obj->gettagid( $this->g_para['tname'] ,$tid );
		}else if(!empty( $this->g_para['tid'])){
			$tid =  $this->g_para['tid'];
		}

		if(in_array( $this->g_para['type'],array('tk','tq'),true)){
			if(empty($tid)){
				$this->error_num(2517);
			}
			$qinfo = $this->tag_obj->gettaglist( $this->g_para['type'],$tid, $this->g_para['start'], $this->g_para['num']);                
			if(!is_array($qinfo)){
				$this->error_num(2516);
			}
			if($this->g_para['flag'] == 0){ // 不返回详细信息
				foreach($qinfo as $k => $v){
					if(is_numeric($k)){
						$qid = $v['keys'][2];  
						$qlist['list']["$qid"]['data'] = $v['data'];
						$qlist['list']["$qid"]['tid'] = $v['keys'][0];
						$qlist['list']["$qid"]['time'] = $v['keys'][1]; 
						$qlist['list']["$qid"]['qid'] = $v['keys'][2];                                
					}else{
						$qlist[$k] = $v;
					}
				}
			}else if($this->g_para['flag'] == 1){ //返回详细信息
				foreach($qinfo as $key => $v){
					if(is_numeric($key)){
						$qlist['list'][$key]['data'] = $v['data'];                
						$qlist['list'][$key]['tid'] = $v['keys'][0];
						$qlist['list'][$key]['time'] = $v['keys'][1];                           
						$q_res = $this->getbdb_obj->gets("detail", $v['keys'][2], $q_info);
						$qlist['list'][$key]['qid'] = $q_info['questionid'];
						$qlist['list'][$key]['title'] = $q_info['title'];                            
						if(isset($q_info['atotal']) && isset($q_info['a'])){
							//add by guoxianghui
							if(!empty($q_info['a'])) {
								foreach($q_info['a'] as $aid => $ainfo) {
									if($ainfo['showflag'] == 1) {
										$q_info['atotal']--;
									}
								}
							}
							$qlist['list'][$key]['atotal'] = $q_info['atotal'] < 0 ? 0 : $q_info['atotal'];				
							// end
							//$qlist['list'][$key]['atotal'] = $q_info['atotal'];
							$ansow = $q_info['a'];
							//显示在所有问答上的回答
							$qlist['list'][$key]['answer'] =  $ansow[$v['data']]['answer']; 
							$qlist['list'][$key]['aid'] =  $ansow[$v['data']]['answerid']; 
							$qlist['list'][$key]['a']['answerid'] =  $ansow[$v['data']]['answerid'];

							/****************for 已采纳的问题****************/
							//提问题uid
							$qlist['list'][$key]['uid'] =  $q_info['uid'];    
							foreach($ansow as $ak => $av){
								// 已采纳标志                                    
								if( $this->g_para['type'] == 'tk') // 取的是话题下已解决问题
								{
									if(!isset($ansow["$ak"]['status']) || $ansow["$ak"]['status'] == 0) {
										continue;
									}
								}
								$qlist['list'][$key]["a"]['adopt'] = isset($ansow["$ak"]['status'])?$ansow["$ak"]['status']:0;
								// 被采纳了，就需要对应的回答内容
								if($qlist['list'][$key]['a']["adopt"]){
									$qlist['list'][$key]['a']["answer"] =  $ansow["$ak"]['answer'];
									$qlist['list'][$key]['a']["answerid"] =  $ansow["$ak"]['answerid'];
								}else{

								}
								//回答问题用户id
								$qlist['list'][$key]['a']['uid'] = $ansow["$ak"]['uid'];
								//获取回答问题用户对应的话题经验
								$t_res = $this->tag_obj->getexp($qlist['list'][$key]['a']['uid'],$tid,0,20, $taginfo);
								$qlist['list'][$key]['a']['exp'] = isset($taginfo["$tid"])?$taginfo["$tid"]:'';
								//赞同 数
								$qlist['list'][$key]['a']['agree'] = isset($ansow["$ak"][2])?count($ansow["$ak"][2]):0;
							} //foreach end

							//回答相关的都先取出来
							//$qlist['list'][$key]['a'] = $q_info['a'];
						}

					}else{
						$qlist[$key] = $v;
					}                        
				} //foreach  end                        
			}


			$this->run_api_event();                
			echo json_encode($qlist);
		}else{
			$this->error_num(2507);
		}           

	}
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}
}
$app = new  Gettaglist;
$app->run();

?>
