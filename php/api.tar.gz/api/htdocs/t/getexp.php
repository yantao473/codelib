<?php
/**
 * 获取话题经验
 * @update  xianghui@staff.sina.com.cn
 * 20120910
 */
require_once('apiconf.php');

class Getexp extends webApp  implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();

	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : 0;
		$this->g_para['tid'] = isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : "";
		$this->g_para['tids'] = isset($_REQUEST['tids']) ? $_REQUEST['tids'] : "";
		$this->g_para['tname'] = isset($_REQUEST['tname']) ? trim($_REQUEST['tname']) : "";        
		$this->g_para['start'] = isset($_REQUEST['start']) ? intval($_REQUEST['start']) : 0;
		$this->g_para['num'] = isset($_REQUEST['num']) ? intval($_REQUEST['num']) : 20;
	}    

	function _check_param(){                                                                           
		if(empty($this->g_para['uid'])){
			$this->error_num(2508);
		}
	}

	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;                                                                  
	}

	function _init_api_config(){                                                                       
		$this->api_name = 'getexp';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	}   

	function main(){
		$this->get_exp();
	}

	function get_exp(){
		if(!empty( $this->g_para['tname'])){
			$t_res = $this->tag_obj->gettagid( $this->g_para['tid'],$tid);
		}else if(!empty($this->g_para['tid'])){
			$tid = $this->g_para['tid'];
		}else if(!empty($this->g_para['tids'])){ //多个
			$tids = $this->g_para['tids'];
		}else{
			$tid = 0;
		}

		if(!empty($tid)){
			$res = $this->tag_obj->getexp($this->g_para['uid'],$tid,$this->g_para['start'] ,$this->g_para['num'] ,$data);
		}else if(isset($tids)){
			$tid_a = explode(",",$tids);
			if(is_array($tid_a)){
				foreach($tid_a as $k => $v){
							$res = $this->tag_obj->getexp($this->g_para['uid'],$v,$this->g_para['start'] ,$this->g_para['num'] ,$data);                        
							}//foreach end                    
							}else{
							$data = '';
							}
							}else{
							$res = $this->tag_obj->getexp( $this->g_para['uid'],0,$this->g_para['start'],$this->g_para['num'],$data);
							}
							$this->run_api_event();
							echo json_encode($data); 
							exit; 

							}

							function run_api_event() {
							$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
							if(!empty($cmd)) {
							if(eval($cmd) === FALSE) {
								$this->error_num(3002);
							}
							}
							}

}
$app = new Getexp;
$app->run();
?>
