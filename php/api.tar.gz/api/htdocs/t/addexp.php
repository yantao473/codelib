<?php
/**
 * 添加话题经验
 * @author : tingting
 * @update : xianghui@staff.sina.com.cn
 * @date : 20120827
 */

require_once('apiconf.php');

class  Addexp extends webApp implements Platform_Api{

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function _init_param(){
		$this->g_para['tid'] = isset($_REQUEST['tid']) ? $_REQUEST['tid'] : 0;
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : 0;
		$this->g_para['content'] = isset($_REQUEST['content']) ? $_REQUEST['content'] : "";        
		$this->g_para['ctime'] = isset($_REQUEST['ctime']) ? $_REQUEST['ctime'] : date("Y-m-d H:i:s");
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;    
	}                                                                                                  

	function _check_param(){                                                                           
		if(empty($this->g_para['uid']) || empty($this->g_para['tid'])){              
			$this->error_num(2504);
		}                                                                                          
	}                                                                                                  

	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;
	} 

	/*                                                                                                 
	 * 初始化接口功能                                                                                   
	 */                                                                                                 
	function _init_api_config() {                                                                      
		$this->api_name = 'addexp';                                                           
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	}  


	function main(){
		$res = $this->tag_obj->getexp($this->g_para['uid'],$this->g_para['tid'],0,20,$taginfo);
		$ishave = $this->tag_obj->getexpdb($g_para['uid'],$this->g_para['tid']);
		$this->run_api_event();    
		if($res && isset($taginfo["$tid"]) && $ishave){
			$u_res['res'] = $this->tag_obj->upexp($this->g_para['tid'], $this->g_para['uid'], $this->g_para['content'], $this->g_para['ctime']);
			echo json_encode($u_res);
		}else{
			if(!empty($content)){
				$u_res['res'] = $this->tag_obj->addexp($this->g_para['tid'],$this->g_para['uid'],$this->g_para['content'],$this->g_para['ctime']);
				echo json_encode($u_res);
			}else{ //由于bdb不存空信息，所以不用往数据库里插入content为空的信息故而不做任何操作
				$u_res['res'] = true;
				echo json_encode($u_res);                    
			}                
		}
	}
	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}

}
$app = new Addexp;
$app->run();
?>
