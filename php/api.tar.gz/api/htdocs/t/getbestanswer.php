<?php
/***
 * 获取话题页最佳回答   统计知识
 * @by tingting18
 *update by guoxianghui 20120224 
 *update by guoxianghui 20120315 
 *update by guoxianghui 20120910 
 */
require_once("apiconf.php");

class Getbestanswer extends webApp  implements Platform_Api  {
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['tid'] =  isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : "";
	}

	function _check_param(){                                                                           

	}

	function _init_class(){                                                                            
		$this->stat_obj = new Stat;
		$this->getbdb_obj = new GetBdb;
		$this->tools_obj= new Tools();                                                             
	}                     

	function _init_api_config(){                                                                       
		$this->api_name = 'getbestanswer';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 


	function main(){
		$this->get_best_answer();
	}

	function get_best_answer(){
		if(empty($this->g_para['tid'])){
			$this->error_num(2518);
		}
		$bdb_data = $this->stat_obj->get_tag_ask( $this->g_para['tid'],"vanswer");
		$res = array();
		$res['res'] = "";
		
		if(!empty($bdb_data)){
			$tmp_array = array();
			$dis_arr = array();
			foreach($bdb_data as $k=>$v){
				if(empty($v['qid'])){
					continue;
				}
				if(@!array_key_exists($v['qid'],$dis_arr)){
					$qids_arr[] = $v['qid'];
					$aids_arr[] = $v['aid'];
					$dis_arr[$v['qid']] = $v['aid'];     //add by zhanghua2 添加qid对应的 aid
				}
			}
			$q_info = $this->getbdb_obj->gets('detail', $qids_arr , $q_data);
			//重组
			foreach ($q_data as $k=>$v){
				$qid = $v['questionid'];
				$get_array[$v['questionid']]['questionid'] = $v['questionid'];
				$get_array[$v['questionid']]['title'] = $v['title'];
				$get_array[$v['questionid']]['uid'] = $v['uid'];
				$get_array[$v['questionid']]['atotal'] = $v['atotal'];
				$get_array[$v['questionid']]['tag'] = $v['tag'];
				$get_array[$v['questionid']]['a'][$dis_arr[$qid]] = $v['a'][$dis_arr[$qid]];  // 直接获取对应的答案
			}
			$res['res'] = $get_array;
		}
		$this->run_api_event();
		echo json_encode($res);
		exit;
	}

	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}


}
$app = new Getbestanswer;
$app->run();
?>
