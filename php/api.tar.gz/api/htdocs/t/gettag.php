<?php
/**
 * 获取话题信息
 * @update  xianghui@staff.sina.com.cn
 * 20120907
 */
require_once("apiconf.php");

class Gettag extends webApp  implements Platform_Api {

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

	function __construct() {
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['tid'] =  floatval($_REQUEST['tid']);
		$this->g_para['tname'] = isset($_REQUEST['tname']) ? trim($_REQUEST['tname']) : "";
	}
	function _check_param(){
	
	}
	function _init_class(){
		$this->tools_obj= new Tools();
		$this->tag_obj = new Tag;
		$this->follow_obj = new Follow($this->g_para , $this->g_result);
	}
	function _init_api_config(){
		$this->api_name = 'gettag';                                                                 
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
                if(empty($this->api_config)) {                                                             
                        $this->error_num(3001);                                                            
                }  
	}
	function main(){
		$this->get_tag();	
	}
	
	function get_tag(){
		if(!empty($this->g_para['tname'])){
			if(!is_array($this->g_para['tname'])){
				$t_res = $this->tag_obj->gettag($this->g_para['tname'],$tid);
			}else{
				$t_res = $this->tag_obj->gettag($this->g_para['tname'],$tid_arr);
			}
		}else if(isset($this->g_para['tid'])){
			$tid = $this->g_para['tid'];
		}
		$start = $num = 0;
		if($tid){
			$t_res = $this->tag_obj->gettagid($tid,$tag_info);
			if(!empty($tag_info)) {
				//add 关注人个数 start   guoxianghui
				$follow = $this->follow_obj->getfollowlist('gto' , $tid , $start , $num);
				$tag_info['gz_num'] = $follow['total'];
				//add 关注人个数 end 
				//话题下问题个数 start       
				$tag_questions = $this->tag_obj->gettaglist('tq',$tid,$start,$num);
				$tag_info['qtotal'] = $tag_questions['total'];
				if(empty($tag_info['imageid'])){
					$tag_info['image'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default100100.jpg';
					$tag_info['image_a'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default5050.jpg';
					$tag_info['image_b'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default100100.jpg';
				}
			}
			$this->run_api_event();
			//话题下问题个数 end 
			echo  json_encode($tag_info);
		}else if(!empty($tid_arr)){

			foreach($tid_arr as $name=>$tid){
			
				if(!empty($tid)){
					$t_res = $this->tag_obj->gettagid($tid,$tag_info);
					if(!empty($tag_info)) {
						//add 关注人个数 start   guoxianghui
						$follow = $this->follow_obj->getfollowlist('gto' , $tid , $start , $num);
						$tag_info['gz_num'] = $follow['total'];
						//add 关注人个数 end 
						//话题下问题个数 start       
						$tag_questions = $this->tag_obj->gettaglist('tq',$tid,$start,$num);
						$tag_info['qtotal'] = $tag_questions['total'];


						if(empty($tag_info['imageid'])){
							$tag_info['image'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default100100.jpg';
							$tag_info['image_a'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default5050.jpg';
							$tag_info['image_b'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default100100.jpg';
						}
						$tname_arr[$name] = $tag_info;
				}
			}else{
				$tname_arr[$name] = "";	
			}
			}
			//话题下问题个数 end 
			$this->run_api_event();
			echo  json_encode($tname_arr);
		}else{
			$this->error_num(2501);
		}

	}
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$app = new Gettag;
$app->run();

?>
