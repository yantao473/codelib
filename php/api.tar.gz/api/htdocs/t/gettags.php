<?php
/**
 * 批量获取话题信息
 * @update  xianghui@staff.sina.com.cn
 * 20120907
 */
require_once("apiconf.php");

class Gettags extends webApp  implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();

	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['tid_str'] =  isset($_REQUEST['tid_str']) ? $_REQUEST['tid_str'] : '';
	}                                                                                                  
	function _check_param(){                                                                           

	}                                                                                                  
	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;                                                                  
		$this->follow_obj = new Follow($this->g_para , $this->g_result);                                             
	}                                                                                                  
	function _init_api_config(){                                                                       
		$this->api_name = 'gettags';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 

	function main(){
		$this->get_batch_tags();
	}
	function get_batch_tags(){
		$tids = explode(",",$this->g_para['tid_str']);
		if(empty($tids)){
			$this->error_num(2505);
		}
		if(count($tids) >= 20){
			$this->error_num(2506);    
		}
		foreach($tids as $key=>$v){
			if(empty($v) || !is_numeric($v)){
				$this->error_num(2502);
			}
			$res = $this->tag_obj->gettagid($v, $tag_info["$v"]);                    
			if(!empty($tag_info["$v"])) {
				//add 关注人个数 start   guoxianghui
				$start = $num = 0;                                                 
				$follow = $this->follow_obj->getfollowlist('gto' , $v , $start , $num);
				$tag_info["$v"]['gz_num'] = $follow['total'];
				//add 关注人个数 end 
				//话题下问题个数 start       
				$tag_questions = $this->tag_obj->gettaglist('tq',$v,$start,$num);
				$tag_info["$v"]['qtotal'] = $tag_questions['total'];	
				//话题下问题个数 end
			}

		}
		//修改默认图片
		foreach($tag_info as $k => $v){
			if(!empty($v)) {
				if(empty($v['imageid'])){
					$tag_info[$k]['image'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default100100.jpg';
					$tag_info[$k]['image_a'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default5050.jpg';
					$tag_info[$k]['image_b'] = 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default100100.jpg';
				}
			}
		}
		$this->run_api_event();
		echo json_encode($tag_info);

	}
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}
}
$app = new Gettags;
$app->run();
?>
