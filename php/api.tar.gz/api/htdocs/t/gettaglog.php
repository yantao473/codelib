<?php
/**
 * 获取话题日志
 * @update  xianghui@staff.sina.com.cn
 * 20120907
 */
require_once("apiconf.php");

class Gettaglog extends webApp  implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['tid'] =  isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : 0;
		$this->g_para['tname'] = isset($_REQUEST['tname']) ? trim($_REQUEST['tname']) : "";        
		$this->g_para['start'] = isset($_REQUEST['start']) ? trim($_REQUEST['start']) : 0;        
		$this->g_para['num'] = isset($_REQUEST['num']) ? trim($_REQUEST['num']) : 20;        
	}                                                                                                  
	function _check_param(){                                                                           

	}                                                                                                  
	function _init_class(){                                                                            
		$this->tools_obj= new Tools();                                                             
		$this->tag_obj = new Tag;                                                                  
		$this->getbdb_obj = new GetBdb;
	}                                                                                                  
	function _init_api_config(){                                                                       
		$this->api_name = 'gettaglog';                                                                 
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 

	function main(){
		$this->gettaglog();
	}
	function gettaglog(){
		if(!empty($this->g_para['tname'])){
			$t_res = $this->tag_obj->gettag( $this->g_para['tname'] , $tid );
		}else{
			$tid = $this->g_para['tid'];
		}
		if(empty($tid)){
			$this->error_num(2509);
		}
			$log = $this->tag_obj->gettaglog($tid, $this->g_para['start'], $this->g_para['num']);
			if(is_array($log) && !empty($log)){
				foreach($log as $key=>$v){
					if(is_numeric($key)){
						$logs['tlog'][$key]['tid'] = $log[$key]['data']['oid']; //$tid
						$t_res = $this->tag_obj->gettagid($logs['tlog'][$key]['tid'], $tag_info);
						$logs['tlog'][$key]['tname'] = $tag_info['tname'];
						$logs['tlog'][$key]['uid'] = $log[$key]['data']['uid'];
						$u_res = $this->getbdb_obj->gets("user", $logs['tlog'][$key]['uid'], $user_info);   
						$logs['tlog'][$key]['nick']= isset($user_info['nick'])?$user_info['nick']:''; 
						$logs['tlog'][$key]['type'] = $log[$key]['data']['type'];
						if($logs['tlog'][$key]['type'] != 42){
							$logs['tlog'][$key]['content'] = $log[$key]['data']['content'];
						}
						if ($logs['tlog'][$key]['type'] == 42){ //话题图片进行了修改,分隔图片id
							$image = explode("|",$log[$key]['data']['content']);
							$logs['tlog'][$key]['image_old'] = $image[0];
							$logs['tlog'][$key]['image_new'] = $image[1];
						}

						$logs['tlog'][$key]['ctime'] = $log[$key]['data']['ctime'];
					}else{
						$logs[$key] = $log[$key];
					}                    
				}
			}else{
				$logs['tlog'] = $log;
			}   
			$this->run_api_event();             
			echo json_encode($logs); 
			exit;

	}
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$app = new Gettaglog;
$app->run();
?>
