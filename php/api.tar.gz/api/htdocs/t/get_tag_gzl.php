<?php
/**
 * 获取话题的关注者列表
 *
 * @package     TAG
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2012/02/01 14:29:00
 @ @update guoxianghui 2012-09-10
*/
include_once("apiconf.php");

class TagGzList extends webApp  implements Platform_Api
{

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;
	
	public function __construct() 
	{
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();

	}

        function _init_param(){
                $this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
                $this->g_para['tid'] = isset($_REQUEST['tid']) ? floatval($_REQUEST['tid']) : "" ;
		$this->g_para['start'] = isset($_REQUEST['start']) ? intval($_REQUEST['start']) : 0;        
                $this->g_para['num'] = isset($_REQUEST['num']) ? intval($_REQUEST['num']) : 20;        
        }                                                                                                  
        function _check_param(){                                                                           
        	if(!$this->_check_empty($this->g_para['tid']))
        	{
			$this->err_code = 2108;
			$this->error_num($this->err_code);
			die();
        	}
		return true;
        }      
                                                                                            
        function _init_class(){  
                                                                          
		$this->tools_obj = new Tools();
		$this->tag_obj = new Tag();
		$this->getbdb_obj = new GetBdb();
        }       
                                                                                           
        function _init_api_config(){                                                                       
                $this->api_name = 'get_tag_gzl';                                                                 
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
                if(empty($this->api_config)) {                                                             
                        $this->error_num(3001);                                                            
                }                                                                                          
        } 

	
	public function main() 
	{
		$flag = $this->do_platform($callback);
		if(!$flag)
		{
			$this->error_num($this->err_code);
			die();
		}
  		$this->run_api_event();
		echo $callback;
	}

        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }


	/**
	 * 更新用户信息
	 * 
	 * @param :
	 * @return : bool
	*/
	private function do_platform(&$callback)
	{
		$flag = $this->getbdb_obj->lists("gto", $this->g_para['tid'], $this->g_para['start'], $this->g_para['num'], $data);
		if(!$flag) 
		{
			$this->err_code = 2302;
			return false;
		}
		if(!empty($data))
		{
			$gzl = array();
			$gzl['total'] = $data['total'];
			unset($data['total'],$data['num']);
			foreach($data as $key => $val)
			{
				$gzl['ulist'][] = $val['keys'][2];
			}
		}
		$callback = json_encode($gzl);
		return true;
	}

     private function _check_empty($v) {
         if(empty($v)) {
            return false;
         }
         else{
             return true;
         }
     }
 
}
$app = new TagGzList();
$app->run();
?>
