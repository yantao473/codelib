<?php
/**
 * 获取搜索结果
 * @author: xianghui@staff.sina.com.cn
 * @date : 2012-08-27
 */
require_once("apiconf.php");

class Getsearch extends webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['type'] = isset($_REQUEST['type']) ? floatval($_REQUEST['type']) : '';
		$this->g_para['key'] = isset($_REQUEST['key']) ? $_REQUEST['key'] : '';
		$this->g_para['start'] = isset($_REQUEST['start']) ? floatval($_REQUEST['start']) : 0;
		$this->g_para['num'] = isset($_REQUEST['num']) ? floatval($_REQUEST['num']) : 8;
	}

	//type 1 表示问题 2表示话题 3表示综合
	function _check_param(){
		if(!in_array($this->g_para['type'],array(1,2,3))){
			$this->error_num(2601);
		}
		if(empty($this->g_para['key'])){
			$this->error_num(2602);
		}	
	}

	function _init_class(){
		$this->tools_obj= new Tools();
		$this->search_obj = new search();
	}
	/*                                                                                                 
	 * 初始化接口功能                                                                                   
	 */                                                                                                 
	function _init_api_config() {                                                                      
		$this->api_name = 'getsearch';                                                           
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 
	function main(){
		$this->deal_search();
	}

	function deal_search(){
		// 1问题，2话题，3话题和问题
		if($this->g_para['type'] == 1){
			$title1 = $this->g_para['key'];
		}else if($this->g_para['type'] == 2){
			$title2 = $this->g_para['key'];
		}else if($this->g_para['type'] == 3){
			$title1 = $title2 = $this->g_para['key'];
		}
		$arr = array(
			'title1'=>$this->g_para['key'],
			'title2'=>$this->g_para['key'],
			'source'=>$this->g_para['type'],
		);
		$res = $this->search_obj->get($arr, $this->g_para['start'], $this->g_para['num'], $data);
		$search_info['total'] = $data['m2']; //返回总数
		$search_info['num'] = $data['m']; //返回当前个数
		if(!empty($data['result'])){
			foreach($data['result'] as $key=>$v){
				if(!empty($v['title'])){
					$ids = explode("_",$v['id']);
					 $search_info['result'][$key]['id'] = $ids[0];
					 $search_info['result'][$key]['title'] = $v['title'];
					 $search_info['result'][$key]['type'] = $v['source_id'];
					 $search_info['result'][$key]['uid'] = $v['uid'];
					 $search_info['result'][$key]['SortV'] = $v['SortV'];
					 $search_info['result'][$key]['ctime'] = $v['ctime'];
					 $search_info['result'][$key]['title_len'] = $v['title_len']; 	
					 $search_info['result'][$key]['num1'] = $v['num1']; 	
					 $search_info['result'][$key]['num2'] = $v['num2']; 	

				}

			}
		}else{
			$search_info['result'] = $data['result'];
		}       
		$this->run_api_event();    
		echo json_encode($search_info);

	}
        /*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$app = new Getsearch;
$app->run();
?>
