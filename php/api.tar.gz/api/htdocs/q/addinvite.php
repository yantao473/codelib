<?php
/**
 * @fn              添加邀请回答接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @link            /q/addinvite.php
 * @date            2011-11-03
 * @date            2012-07-31
 */

include_once("apiconf.php");

class addInvite extends webApp implements Platform_Api {
        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        private $APP;
	
	public $g_para;
        public $g_result;

	function  __construct(){
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
	}

	function _init_param() { 
		$this->g_para['app']	= isset($_REQUEST['app'])? floatval($_REQUEST['app']): 1; 
		$this->g_para['uid']	= isset($_REQUEST['uid'])? floatval($_REQUEST['uid']): ''; 
		$this->g_para['touid']	= isset($_REQUEST['touid']) ? floatval($_REQUEST['touid']):'';         
		$this->g_para['questionid'] = isset($_REQUEST['questionid']) ? floatval($_REQUEST['questionid']):'';
		$this->g_para['ctime']	= isset($_REQUEST['ctime']) ? floatval($_REQUEST['ctime']):date("Y-m-d H:i:s");

                //微什么项目处理逻辑标识                                                                          
                $this->g_para['syncid']         = isset($_REQUEST['syncid'])    ? floatval($_REQUEST['syncid']) : 1;
                //来源  首页邀请专家   牛人浮层邀请  最终页下面的邀请
		$this->g_para['from']         = isset($_REQUEST['from']) ? trim($_REQUEST['from']) : '';
		$this->g_para['callback_type']         = isset($_REQUEST['callback_type']) ? floatval($_REQUEST['callback_type']) : '';
	}

	function _check_param() {
                if($this->g_para['app'] == 2 ){  //知识人项目                                                     
                        if($this->g_para['syncid'] == 1){                                                         
                                $this->APP = 1; //知识人数据导入微什么项目的情况                                  
                        }                                                                                         
                        else{                                                                                     
                                $this->APP = 2; //知识人                                                          
                        }                                                                                         
                }                                                                                                 
                elseif($this->g_para['app'] == 1 && $this->g_para['syncid'] == 1){  //微什么web版本               
                        $this->APP = 1;                                                                           
                }                                                                                                 
                elseif($this->g_para['app'] == 3 && $this->g_para['syncid'] == 1){ //微什么手机wap版本            
                        $this->APP = 1;                                                                           
                }                                                                                                 
                                                                                                                  
                //项目应用与同步规则                                                                              
                if(empty($this->APP)) {                                                                           
                        $this->error_num(3003);                                                                   
                }       


                if(empty($this->g_para['questionid'])) {                                                          
                        $this->error_num(2111);                                                            
                }                                                                                          
                                                                                                           
                if(empty($this->g_para['uid'])) {                                                          
                        $this->error_num(2112);                                                            
                }                                                                                          

                if(empty($this->g_para['touid'])) {                                                        
                        $this->error_num(2104);
                }
                if($this->g_para['app'] == ZHISHI_APP_ID) {                                                
                        if(empty($this->g_para['questionid'])) {                                           
                                $this->error_num(2136);                                                    
                        }                                                                                  
                } 

	}

        function _init_class() {                                                                 
                if($this->APP == 1) {                                                   
                        $this->generate_server_id = new IdServer();                                        
			$this->g_para['inviteid'] = $this->generate_server_id->get("invite");
                }                                                                                          
                                                                                                           
                $this->tools_obj= new Tools();                                                             
                $this->api_obj = new Invite($this->g_para , $this->g_result);                            
        }

        function _init_api_config() {
                $this->api_name = 'invite';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->APP;
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        } 
	function main(){
		$this->add_invite();
	}

	function add_invite(){
		//mysql
		$arr =  array(
				'inviteid'=>$this->g_para['inviteid'],
				'inviter'=>$this->g_para['touid'],
				'uid'=>$this->g_para['uid'],
				'ctime'=>$this->g_para['ctime'],
				'questionid'=>$this->g_para['questionid'],
			     );
                $this->api_obj->send_mysql($arr , $rpcdb_result,1);                                          
                if(!$rpcdb_result){                                                                        
                        $this->error_num(2102);                                                            
                } 
		//发送BDB 
		$arr_bdb = array(
			0=>EVENT_QUESTION_INVITE,
			'inviteid'=>$this->g_para['inviteid'],
			'inviter'=>$this->g_para['touid'],
			'uid'=>$this->g_para['uid'],
			'ctime'=>$this->g_para['ctime'],
			'questionid'=>$this->g_para['questionid'],
			'from'=> $this->g_para['from'],
			'callback_type' => $this->g_para['callback_type'],
		);
                $this->api_obj->send_bdb($arr_bdb , $queue_result);                                            
                if(!$queue_result){                                                                        
                        $this->error_num(2102);                                                            
                }  
		$json_array = array('result'=>'true','inviteid'=>$this->g_para['inviteid']);
		//usleep(500000);
  		// 执行订制功能
		$this->run_api_event();
		echo json_encode($json_array);
	}
        function run_api_event() {                                                                         
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);                          
                if(!empty($cmd)) {                                                                         
                        if(eval($cmd) === FALSE) {                                                         
                                $this->error_num(3002);                                                    
                        }                                                                                  
                }                                                                                          
        } 
}
$exec = new addInvite();
$exec->run();
?>
