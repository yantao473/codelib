<?php
/**
 * @fn              获取话题相关问题接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-08-27
 */

include_once("apiconf.php");

class getRelateQuestion extends  webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['app'] = isset( $_REQUEST['app'] ) ? floatval( $_REQUEST['app']) : 1;
		$this->g_para['tids'] = $_REQUEST['tids'];
		$this->g_para['start'] = (isset($_REQUEST['start']) && !empty($_REQUEST['start']) )?$_REQUEST['start']:0;
		$this->g_para['num'] = (isset($_REQUEST['num'])&& !empty($_REQUEST['num']) )?$_REQUEST['num']:20;
		$this->g_para['tnames'] = $_REQUEST['tnames'];
	}

	function _check_param(){
		if(isset($this->g_para['tids']) && empty($this->g_para['tids'])){
			$this->error_num(2105);		
		}
		if(isset($this->g_para['tnames']) && empty($this->g_para['tnames'])){
			$this->error_num(2107);		
		}
	}

	function _init_class(){
		$this->tools_obj= new Tools();
		$this->gettag = new Tag();
		$this->bdb = new GetBdb();
	}

	/*                                                                                                 
	 * 初始化接口功能                                                                                   
	 */                                                                                                 
	function _init_api_config() {                                                                      
		$this->api_name = 'getrelate';                                                           
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	}

	function main(){
		$this->get_relate_question();
	}

	function get_relate_question(){
		//根据话题NAME 查询话题ID
		if(isset($this->g_para['tnames']) && !empty($this->g_para['tnames'])){
			//先去掉末尾，
			$tidname = trim($this->g_para['tnames'],",");

			if(strpos($tidname,",") !== false){
				//array
				$tidname = @explode(",",$tidname);
			}
			$arr_temp = array();
			$arr_rela = array();
			//如果NAMEs，获取IDS；如果NAME,获取ID
			$result_name_id = $this->bdb->gets("tag",$tidname,$get_data_tids);
			if(!is_array($get_data_tids)){
				$get_data_tids = array($get_data_tids);
			}
			//get tids
			$arrval = array_values($get_data_tids);
			if($result_name_id){
				$result = $this->bdb->gets("relate",$arrval,$data);
			}
			if(!empty($data)){
				$data = $this->get_relate_question_weight($data);
			}

			//get qids
			if(count($arrval) >0){
				$i = 0;
				$arrqids = array();
				//根据TID获取QID
				if(count($arrval) == 1){
					foreach($arrval as $v){
						if(!empty($v)){
							$arrqids = array_keys($data[$v]);	
						}
						$i++;
					}
				}else{

					foreach($arrval as $v){
						if(!empty($v) && !empty($data[$v])){
							foreach($data[$v] as $key=>$value){
								array_push($arrqids,$key);
							}
						}
						$i++;
					}

				}

			}	
			if(count($arrqids)>6){	
				$arrqids = array_slice($arrqids,0,6);
			}
			$result = $this->bdb->gets("question",$arrqids,$arr_relate);

			if(!$result){
				$this->error_num(2130);	
			}
			$array_question = array();
			$g = 0;
			foreach($arr_relate as $val){
				if($val['showflag'] == 0){
					$array_question[$g]['title'] = $val['title'];
					$array_question[$g]['questionid'] = $val['questionid'];
					$g++;
				}
			}

		}
		//id ids
		if(isset($this->g_para['tids']) && !empty($this->g_para['tids'])){

			//先去掉末尾，
			$tidname = trim($this->g_para['tids'],",");
			$get_data_tids = array();
			if(strpos($tidname,",") !== false){
				//array
				$get_data_tids = explode(",",$tidname);
			}else{
				$get_data_tids = array($tidname);
			}
			$arr_temp = array();
			$arr_rela = array();

			//get tids
			$arrval = array_values($get_data_tids);

			$result = $this->bdb->gets("relate",$arrval,$data);
			if(!empty($data)){
				$data = $this->get_relate_question_weight($data);
			}
			//var_export($data);
			//get qids
			if(count($arrval) >0){
				$i = 0;
				$arrqids = array();
				//根据TID获取QID
				if(count($arrval) == 1){
					foreach($arrval as $v){
						if(!empty($v)){
							$arrqids = @array_keys($data[$v]);	
						}
						$i++;
					}
				}else{

					foreach($arrval as $v){
						if(!empty($v) && !empty($data[$v])){
							foreach($data[$v] as $key=>$value){
								array_push($arrqids,$key);
							}
						}
						$i++;
					}

				}

			}
			if(count($arrqids)>6){	
				$arrqids = array_slice($arrqids,0,6);
			}
			$result = $this->bdb->gets("question",$arrqids,$arr_relate);

			if(!$result){
				$this->error_num(2130);	
			}
			$array_question = array();
			$g = 0;
			foreach($arr_relate as $val){
				if($val['showflag'] == 0){
					$array_question[$g]['title'] = $val['title'];
					$array_question[$g]['questionid'] = $val['questionid'];
					$g++;
				}
			}



		}
		$this->run_api_event();
		if(!empty($array_question)){
			echo json_encode($array_question);
		}else{
			$arr = array("result"=>false);
			echo json_encode($arr);
		}



	}
	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}


	function get_relate_question_weight($val){
		$data = array();
		foreach($val as $k => $v){
			if(!empty($v)){
				foreach($v as $key => $val){
					if($val != 0){
						$data[$k][$key] = $val;
					}	
				}
			}
		}
		return $data;
	}
}
$exec = new getRelateQuestion();
$exec->run();
?>
