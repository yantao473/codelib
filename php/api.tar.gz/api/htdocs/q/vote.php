<?php
/**
 * @fn              投票接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-08-24
 */

include_once("apiconf.php");

class dealVote extends webApp implements Platform_Api{

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        private $APP;

        public $g_para;
        public $g_result;

	function  __construct(){
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config(); 
	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : "";
		$this->g_para['questionid'] = isset($_REQUEST['questionid']) ? floatval($_REQUEST['questionid']) : "";
		$this->g_para['answerid'] = isset($_REQUEST['answerid']) ? floatval($_REQUEST['answerid']) : "";
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : "";
		$this->g_para['type'] = isset($_REQUEST['type']) ? floatval($_REQUEST['type']) : "";
		$this->g_para['ip'] = isset($_REQUEST['ip']) ? $_REQUEST['ip'] : "127.0.0.1";
		$this->g_para['time'] = isset($_REQUEST['ctime']) ? trim($_REQUEST['ctime']) : date("Y-m-d H:i:s");
		$this->g_para['cflag'] = isset($_REQUEST['cflag']) ? floatval($_REQUEST['cflag']) : 0;
                //微什么项目处理逻辑标识
                $this->g_para['syncid']         = isset($_REQUEST['syncid'])    ? floatval($_REQUEST['syncid']) : '';

	}

	function _check_param(){
               if($this->g_para['app'] == 2 ){  //知识人项目                                                      
                        if($this->g_para['syncid'] == 1){                                                         
                                $this->APP = 1; //知识人数据导入微什么项目的情况                                  
                        }                                                                                         
                        else{                                                                                     
                                $this->APP = 2; //知识人                                                          
                        }                                                                                         
                }                                                                                                 
                elseif($this->g_para['app'] == 1 && $this->g_para['syncid'] == 1){  //微什么web版本               
                        $this->APP = 1;                                                                           
                }                                                                                                 
                elseif($this->g_para['app'] == 3 && $this->g_para['syncid'] == 1){ //微什么手机wap版本            
                        $this->APP = 1;                                                                           
                }                                                                                                 
                                                                                                                  
                                                                                                                  
                //项目应用与同步规则                                                                              
                if(empty($this->APP)) {                                                                           
                        $this->error_num(3003);                                                                   
                }  
                if(empty($this->g_para['app'])) {
                        $this->error_num(3000);                                                                   
                } 

		if(isset($this->g_para['questionid']) && empty($this->g_para['questionid'])){
			$this->error_num(2111);		
		}
		if(isset($this->g_para['uid']) && empty($this->g_para['uid'])){
			$this->error_num(2112);		
		}
		if(isset($this->g_para['answerid']) && empty($this->g_para['answerid'])){
			$this->error_num(2131);		
		}
		if(isset($this->g_para['type']) && empty($this->g_para['type'])){
			$this->error_num(2134);		
		}
	}

	function _init_class(){
		$this->generate_server_id = new IdServer();
		$this->g_para['insert_id'] = $this->generate_server_id->get("vote");
		$this->tools_obj = new Tools();
		$this->un_obj = new unite;
		$this->api_obj = new Vote($this->g_para , $this->g_result);
	}

        /*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = 'vote';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->APP;
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }

	function main(){
		$this->deal_vote();
	}

	function deal_vote(){
		if($this->g_para['cflag'] == 0){
			//default
			$control_flag = true;
		}else if($this->g_para['cflag'] == 1){
			//没有取消赞成作用
			$control_flag = false;
		}

		if(!empty($this->g_para['answerid'])){
			$ip = ip2long($this->g_para['ip']);
			if( $this->g_para['type'] == 2 ){
				//入MYSQL
				$arr =  array(
						'voteid' => $this->g_para['insert_id'],
						'questionid' => $this->g_para['questionid'],
						'answerid' => $this->g_para['answerid'],
						'uid' => $this->g_para['uid'],
						'ctime' => $this->g_para['time'],
						'type' => 2,
						'ip' => $ip
					     );
                		$rpcdb_result = $this->api_obj->send_mysql($arr,1 , $data);                                          
				if( $data['errno'] != 1062  ){  // unique uid&&answerid
					if(!$rpcdb_result){
						$this->error_num(2102);
					}	
					//写BDB
					$arr_bdb = array( 
						0 => EVENT_VOTE_AGREE_ADD,
						'voteid' => $this->g_para['insert_id'],
						'questionid' => $this->g_para['questionid'],
						'answerid' => $this->g_para['answerid'],
						'uid' => $this->g_para['uid'],
						'ctime' => $this->g_para['time'],
						'type' => 2,
						'ip' => $ip
					);

				 	$this->api_obj->send_bdb($arr_bdb , $queue_result);
                			if(!$queue_result){
						$this->error_num(2102);
					} 	
					$json_array = array(
						'result'=>$rpcdb_result,
						'flag'=>'a',
						'uid'=>$this->g_para['uid'],
					);
					$this->run_api_event();
					echo json_encode($json_array);
					$this->api_obj->add_vote_feed();
					
					// 调用新的赞同存储接口
					$key = array($this->g_para['uid'] , $this->g_para['answerid']);
					$tableid = 19;
                        		$f = $this->un_obj->up($tableid , $key , time());

				}else if( $data['errno'] == 1062  && $control_flag   ){ 
					$sql = "delete from vote  
						where uid = $this->g_para['uid']
						and type = 2 
						and answerid = $this->g_para['answerid'] 
						and questionid = $this->g_para['questionid']  ";
				 	$result = $this->api_obj->send_mysql($sql ,2, $data);

					if(!$result){
						$this->error_num(2102);
					}	
					$arr_bdb = array(
						0=>EVENT_VOTE_AGREE_DEL,
						'answerid'=>$this->g_para['answerid'],
						'questionid'=>$this->g_para['questionid'],
						'uid'=>$this->g_para['uid'],
						'type'=> 2 , 
						'ctime'=>$this->g_para['time'],
					); 
                			$queue_result = $this->api_obj->send_bdb($arr_bdb , $data);

					if(!$queue_result){
						$this->error_num(2102);
					}	
					$arr = array(
						'result'=>$result,
						'flag'=>'d',
						'uid'=>$this->g_para['uid'],
					);
					$this->run_api_event();
						echo json_encode($arr);
				}
			}
		}
	}

        /*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$exec = new dealVote();
$exec->run();
?>
