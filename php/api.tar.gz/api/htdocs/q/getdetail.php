<?php
/**
 * @fn              获取问题详情接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2 
 * @link            /q/getdetail.php
 * @date            2011-11-02
 * @edit            2012-06-12
 */

include_once("apiconf.php");

class getDetail extends  webApp implements Platform_Api {

	private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        private $APP;


        public $g_para;
        public $g_result;

	function  __construct() { 
		$this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
		$this->sort_url = QUESTION_ANSWER_SORT;
	}

	/**
         *  获取参数
         **/
        function _init_param() {
		$this->g_para['app']		= isset($_REQUEST['app']) ? floatval($_REQUEST['app'])		: '';
		$this->g_para['questionid']	= isset($_REQUEST['questionid'])	? floatval($_REQUEST['questionid'])	: '';
        	$this->g_para['questionids']	= isset($_REQUEST['questionids'])	? trim($_REQUEST['questionids'])	: '';
		//图片显示控制标志
		$this->g_para['imgflag'] = isset($_REQUEST['imgflag']) ? floatval($_REQUEST['imgflag']) : 0;

		//手机需要
                $this->g_para['astart'] = isset($_REQUEST['astart']) ? trim($_REQUEST['astart'])        : "";
                $this->g_para['anum']   = isset($_REQUEST['anum'])? trim($_REQUEST['anum'])     : "";
                $this->g_para['uid'] = isset($_REQUEST['uid'])? floatval($_REQUEST['uid'])     : "";              
                //微什么项目处理逻辑标识                                                                          
                $this->g_para['syncid']         = isset($_REQUEST['syncid'])    ? floatval($_REQUEST['syncid']) : 1;
		$this->g_para['sort_answer']	= isset($_REQUEST['sort_answer']) ? floatval($_REQUEST['sort_answer'])		: 1;
	}

	/**
         *  判断参数合法性
         **/
        function _check_param() {
                if($this->g_para['app'] == 2 ){  //知识人项目                                                     
                        if($this->g_para['syncid'] == 1){                                                         
                                $this->APP = 1; //知识人数据导入微什么项目的情况                                  
                        }                                                                                         
                        else{                                                                                     
                                $this->APP = 2; //知识人                                                          
                        }                                                                                         
                }                                                                                                 
                elseif($this->g_para['app'] == 1 && $this->g_para['syncid'] == 1){  //微什么web版本               
                        $this->APP = 1;                                                                           
                }                                                                                                 
                elseif($this->g_para['app'] == 3 && $this->g_para['syncid'] == 1){ //微什么手机wap版本            
                        $this->APP = 1;                                                                           
                }                                                                                                 
                                                                                                                  
                                                                                                                  
                //项目应用与同步规则           
                if(empty($this->APP)) {                                                                           
                        $this->error_num(3003);                                                                   
                }      

		if(empty($this->g_para['questionid']) && empty($this->g_para['questionids'])){
			$this->error_num(2111);		
		}
		
		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}
	}
	
	/**
         *  初始化对象
         **/
        function _init_class() {
		$this->follow_obj	= new Follow($this->g_para , $this->g_result);
                $this->bdb_obj		= new GetBdb;
		$this->tools_obj	= new Tools;
	}

	/*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = $this->g_para['api_name'] = 'getdetail';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->APP;
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }
	
        /**
         * 主函数
         **/
	function main() {

		$this->get_question();
	}

	/**
         * 获取问题详情
         **/
	function get_question() {
		
		if(!empty($this->g_para['questionid'])) {
			$questionids = $this->g_para['questionid'];
		}
		elseif(!empty($this->g_para['questionids'])) {
			$questionids = $this->g_para['questionids'];
		}

		// 获取问题详细信息
		$qids = explode(',' , $questionids);
		$flag = $this->bdb_obj->gets("detail" , $qids , $data);
		if(!$flag) {
			$this->error_num(2130);
			die();
		}
		// 问题详细接口 增加取问题关注者总数
		if(!empty($data)) {
			if($this->APP == ZHISHI_APP_ID) {
				$this->g_para['type'] = 'gso';
			}
			elseif($this->APP == API_APP_ID) {
				$this->g_para['type'] = 'gqo';
			}
			foreach($data as $qid => $qinfo) {
				if(empty($qinfo)) {
					continue;
				}
				$this->g_para['start'] = $this->g_para['num'] = 0;
				$this->g_para['oid'] = $qid;
				$follow = $this->follow_obj->getfollowlist();
				$data[$qid]['gz_num'] = $follow['total'];
			}
		}

		//print_r($data);
		
		if($this->g_para['sort_answer'] == 1) {
                	// 取正军接口 得到回答排序
                	$post_data = array('qid' => $questionids );
                	$this->tools_obj->curl_set( $this->sort_url , "post" , $post_data , $json);
                	$tmp_sort = json_decode($json , true);
                	$aSort = array();
                	if(!empty($tmp_sort['data'])) {
                	        foreach($tmp_sort['data'] as $k => $v) {
                	                $qid = $v['qid'];
                	                $num = $v['num'];
                	                $aSort[$qid] = $v['answer'];
                	        }
                	}
		}
		
		//print_r($aSort);exit;

		// 过滤回答 去掉隐藏回答 取真正回答数 add by zhanghau2 2012-03-27
		if(!empty($data)) {
			foreach($data as $qid => $qinfo) {
				if(!empty($qinfo['a'])) {
					$tmp_answer = array();
					//if(empty($aSort[$qid])) {
					//	echo $qid . ',';//exit;
					//}
					// 如果需要排序，但是正军接口返回的数据为空的话 要做处理
					if($this->g_para['sort_answer'] == 1 && !empty($aSort[$qid])) {	
						foreach($aSort[$qid] as $k => $v) {
							//deal图片显示 如果不展示图片则去掉图片标签
							if(empty($this->g_para['imgflag'])) {
                						$preg = '~\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
                						$data[$qid]['a'][$aid]['answer'] = preg_replace($preg , '' , $a['answer']);
							}
							if(!empty($v['best_flag'])){
								if(!empty($qinfo['a'][$v['aid']]['data_append'])){
									$tmp_a_append = !is_array($qinfo['a'][$v['aid']]['data_append']) ? (unserialize($qinfo['a'][$v['aid']]['data_append']) === false ? array() : unserialize($qinfo['a'][$v['aid']]['data_append'])) : $qinfo['a'][$v['aid']]['data_append'];
									$tmp_a_append['best_flag'] = $v['best_flag'];
									$qinfo['a'][$v['aid']]['data_append'] = serialize($tmp_a_append);
								}else{
									$qinfo['a'][$v['aid']]['data_append'] = serialize(array('best_flag' => $v['best_flag']));
								}
							}
							// 设置折叠标签
							$qinfo['a'][$v['aid']]['be_fold'] = $v['be_fold'];
							$tmp_answer[$v['aid']] = $qinfo['a'][$v['aid']];
							
							// 判断回答是否隐藏 调整实际的回答数
							if($qinfo['a'][$v['aid']]['showflag'] == 1) {
								$data[$qid]['atotal']--;
							}
						}
						$data[$qid]['a'] = $tmp_answer;
					}
					else {
						foreach($qinfo['a'] as $aid => $ainfo) {
                                                	//deal图片显示  暂时 start
                                                	if(empty($this->g_para['imgflag'])){
                                                	        //默认过滤图片
                                                	        $preg = '~\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
                                                	        $data[$qid]['a'][$aid]['answer'] = preg_replace($preg , '' , $ainfo['answer']);
                                                	}
                                                	// 判断回答是否隐藏 调整实际的回答数
                                                	if($ainfo['showflag'] == 1) {
                                                	        $data[$qid]['atotal']--;
                                                	}
							$data[$qid]['a'][$aid]['be_fold'] = 0;
                                        	}
					}
					$data[$qid]['atotal'] = intval($data[$qid]['atotal']) <= 0 ? 0 : $data[$qid]['atotal'];
				}
			}
		}
		//print_r($data);exit;	
                // 执行订制功能
                $this->run_api_event();
	
		if(!empty($this->g_para['questionid'])) {
			echo json_encode($data[$this->g_para['questionid']]);
                }
                elseif(!empty($this->g_para['questionids'])) {
			echo json_encode($data);
                }
	}

	/*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$exec = new getDetail();
$exec->run();
?>
