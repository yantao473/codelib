<?php
/**
 * @fn              获取最新问题接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2 
 * @link            /q/getnewquestion.php
 * @date            2012-06-13
 */

include_once("apiconf.php");

class getNewQuestionList extends webApp implements Platform_Api {

	private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

	function  __construct() { 
		$this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
	}

	/**
         *  获取参数
         **/
        function _init_param() {
		$this->g_para['app']	= isset($_REQUEST['app'])	? floatval($_REQUEST['app'])	: "";
		$this->g_para['start']	= isset($_REQUEST['start'])	? $_REQUEST['start']		: 0;
                $this->g_para['num']	= isset($_REQUEST['num'])	? $_REQUEST['num']		: 20;
	}

	/**
         *  判断参数合法性
         **/
        function _check_param() {
		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}
	}
	
	/**
         *  初始化对象
         **/
        function _init_class() {
                $this->bdb_obj		= new GetBdb;
		$this->tools_obj	= new Tools;
	}

	/*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = 'getnewquestion';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }
	
        /**
         * 主函数
         **/
	function main() {

		$this->get_new_qlist();
	}

	/**
         * 获取最新问题列表
         **/
	function get_new_qlist() {
		
		$result = $this->bdb_obj->lists('lq' , '' , $this->g_para['start'] , $this->g_para['num'] , $data);
		if(empty($data)) {
			$this->error_num(2135);
			die();
		}
		if(!$result) {
			$this->error_num(2130);
			die();
		}
		
		$num = $data['num'];
		unset($data['total'] , $data['num']);
		if($num > 0) {
			foreach($data as $k => $v) {
				$qids[] = $v['keys'][1];
			}
			$this->bdb_obj->gets('detail' , $qids , $qdata);
		}
		echo json_encode($qdata);
		die();
	}

	/*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$exec = new getNewQuestionList();
$exec->run();
?>
