<?php
/**
 * @fn              获取热点问题接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-07-13
 */

include_once("apiconf.php");

class getHotans extends  webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : '';
		$this->g_para['start'] = isset($_REQUEST['start'])?intval($_REQUEST['start']):0;
		$this->g_para['num'] = isset($_REQUEST['num'])?intval($_REQUEST['num']):5;;
		$this->cfile = ROOT_DIR.'/data/hot_ans.txt';
	}

	function _check_param(){
		/*
		   if(isset($this->g_para['uid']) && empty($this->g_para['uid'])){
		   $this->error_num(2010);		
		   }
		 */
	}

	function _init_class(){
		$this->tools_obj= new Tools();                                                             
		$this->api_obj = new Question($this->g_para , $this->g_result);
	}

	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = 'gethotans';                                                           
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	}    

	function main(){
		$this->get_hotans();
	}
	function get_hotans(){
		if(file_exists($this->cfile)) {                                                            
			$fp = @fopen($this->cfile , 'r');
			flock($fp , LOCK_EX);                                                              
			$scon = fread($fp , @filesize($this->cfile));                                      
			flock($fp , LOCK_UN);                                                              
			fclose($fp);                                                                       
			$aID = json_decode(trim($scon) , true);
			$total = count($aID);
			$end = $this->g_para['start']*$this->g_para['num'] + $this->g_para['num'];

			//if($end <= $total ) {
			$start = $this->g_para['start']*$this->g_para['num'];
			for($i = $start; $i < $end ; $i++) { 
				$q_a_id[$aID[$i]['qid']] = $aID[$i]['aid'];
			}
			$qk = 0;
			foreach($q_a_id as $qid => $av){
				if(!empty($av)){
					$qids[$qk] = $qid;
					$aids[$qk] = $av;
					$q_a_id[$qk][$qid] = $av;
					$qk++;
				}
			}
			if(!empty($qids)) {     
				//$result = $this->bdb_obj->gets("detail" , $qids , $data);
				$this->g_para['questionid'] = $qids;
				$this->api_obj->get_question_detail($data);
				if(!empty($data)) {                                                                        					foreach($data as $qid => $qinfo) {                                                
					$data[$qid]['atotal'] = count($qinfo['a']);                         
					if(!empty($qinfo['a'])) { 
						$temp_arr = array();
						foreach($qinfo['a'] as $aid => $ainfo) {                     
							if($ainfo['showflag'] == 1) {                       
								$data[$qid]['atotal']--;                     
							}
							if( $aid == $q_a_id[$qid]){
								$temp_arr = $ainfo;
							}
						}
					}
					$data[$qid]['a'] = array();
					$data[$qid]['a'][$q_a_id[$qid]] = $temp_arr;

					$data[$qid]['atotal'] = $data[$qid]['atotal'] < 0 ? 0 : $data[$qid]['atotal'];
				}                                                                 
				}  


			}
			//}                                                                                  
		}      
		if(empty($data)){
			$this->error_num(2135);
		}
		$data['total'] = $total;
		$this->run_api_event();
		echo json_encode($data);

	}
	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}
}
$exec = new getHotans();
$exec->run();
?>
