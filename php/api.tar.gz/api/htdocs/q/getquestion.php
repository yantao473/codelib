<?php
/**
 * @fn              获取问题摘要接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-08-24
 */

include_once("apiconf.php");

class getQuestion extends webApp implements Platform_Api{

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

	function  __construct(){
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
    	}
	function _init_param(){
		$this->g_para['questionid'] = isset($_REQUEST['questionid']) ? floatval($_REQUEST['questionid']) : "";
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
	}

	function _check_param(){
		if(isset($this->g_para['questionid']) && empty($this->g_para['questionid'])){
			$this->error_num(2111);		
		}
	}

	function _init_class(){
                $this->tools_obj= new Tools();                                                             
                $this->api_obj = new Question($this->g_para , $this->g_result);
	}

        /*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = 'getquestion';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }
	
    	function main(){
		$this->get_question();
	}

	function get_question(){
		$result = $this->api_obj->get_question_baseinfo($data);
		if(!$result){
			$this->error_num(2130);	
		}
		if(!empty($data)){
			$this->run_api_event();
			echo json_encode($data);
		}else{
			$this->error_num(2135);
		}
	}
        /*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);                          
                if(!empty($cmd)) {                                                                         
                        if(eval($cmd) === FALSE) {                                                         
                                $this->error_num(3002);                                                    
                        }                                                                                  
                }                                                                                          
        }   

}
$exec = new getQuestion();
$exec->run();
?>
