<?php
/**
 * @fn              获取回答摘要接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-08-07
 */

include_once("apiconf.php");

class getAnswer extends  webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct(){ 
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['answerids'] = isset($_REQUEST['answerids']) ? $_REQUEST['answerids'] : "";
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']): 1;
		//图片显示控制标志                                                                         
		$this->g_para['imgflag'] = isset($_REQUEST['imgflag']) ? floatval($_REQUEST['imgflag']) : 0;	
	}

	function _check_param(){
		if(empty($this->g_para['answerids'])){
			$this->error_num(2131);
		}
	}

	function _init_class(){
		$this->tools_obj = new Tools();                                                            
		$this->api_obj = new Answer($this->g_para , $this->g_result);   
	}

	/*                                                                                                 
	 * 初始化接口功能                                                                                   
	 */                                                                                                 
	function _init_api_config() {                                                                      
		$this->api_name = 'getans';                                                                
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	} 

	function main(){
		$this->get_answer();
	}

	function get_answer(){
		if(strpos($this->g_para['answerids'],",") === false ){
			$this->g_para['answerid'] = $this->g_para['answerids'];
			$result = $this->api_obj->get_answer_detail();
			//$result = $this->bdb->gets("answer",$getids,$data);
			$get_info[$this->g_result['answer_info']['answerid']] = $this->g_result['answer_info'];
		}else{
			$this->g_para['answerid'] = explode(",",$this->g_para['answerids']);
			$result = $this->api_obj->get_answer_detail();
			//$result = $this->bdb->gets("answer",$getids,$data);
			foreach($this->g_para['answerid'] as $k=>$v){
				if(empty($v)){
					continue;
				}
				$get_info[$v] = $this->g_result['answer_info'][$v];
			}
		}
		//暂时加图片处理
		if(!empty($get_info)){
			foreach($get_info as $aid=>$ainfo){
				if(empty($this->g_para['imgflag'])){
					//默认过滤图片
					$apreg = '~\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
					$get_info[$aid]['answer'] = preg_replace_callback(
							$apreg,
							function($match){
							return "\n";
							},
							$ainfo['answer']
							);
				}
			}
		}
		if(!$result){
			$this->error_num(2102);
		}
		if(empty($this->g_result['answer_info'])){
			$this->error_num(2135);
		}
		$this->run_api_event(); 
		echo json_encode($get_info);

	}
	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}
}
$exec = new getAnswer();
$exec->run();
?>
