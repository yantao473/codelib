<?php
/**
 * @fn              添加回答接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version	    v2
 * @link            /q/addans.php
 * @date            2011-11-02
 * @edit     	    2012-06-12
 */

include_once("apiconf.php");

class addAnswer extends webApp implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	private $APP;

	public $g_para;
	public $g_result;

	function  __construct() { 
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		$this->g_para['app']		= isset($_REQUEST['app'])	? intval($_REQUEST['app'])	: '';
		$this->g_para['questionid']	= isset($_REQUEST['questionid'])? floatval($_REQUEST['questionid']) : '';
		$this->g_para['uid']		= isset($_REQUEST['uid'])	? floatval($_REQUEST['uid'])	: '';
		$this->g_para['owner']		= isset($_REQUEST['flag'])	? floatval($_REQUEST['flag'])	: 0;
		$this->g_para['answer']		= isset($_REQUEST['answer'])	? trim($_REQUEST['answer'])	: '';
		$this->g_para['refermate']	= isset($_REQUEST['refermate'])	? trim($_REQUEST['refermate'])	: '';
		$this->g_para['time']		= isset($_REQUEST['ctime'])	? trim($_REQUEST['ctime'])	: date("Y-m-d H:i:s");
		$this->g_para['imgtags']	= isset( $_REQUEST['imgtags'] ) ? $_REQUEST['imgtags'] : '';

		// zhishi
		$this->g_para['answerid']	= isset($_REQUEST['answerid'])	? floatval($_REQUEST['answerid'])	: '';
		$this->g_para['degree']         = isset($_REQUEST['degree'])	? intval($_REQUEST['degree'])   : 0;
		$this->g_para['remark']         = isset($_REQUEST['remark'])	? $_REQUEST['remark'] : '';
		$this->g_para['status']		= isset($_REQUEST['status'])	? intval($_REQUEST['status']) : 0;
		$this->g_para['auditflag']      = isset($_REQUEST['auditflag'])	? intval($_REQUEST['auditflag']): 'y';
		$this->g_para['showflag']       = isset($_REQUEST['showflag'])  ? intval($_REQUEST['showflag']) : 0;
		$this->g_para['warnflag']       = isset($_REQUEST['warnflag'])  ? intval($_REQUEST['warnflag']) : 'n';
		$this->g_para['path']           = isset($_REQUEST['path'])      ? trim($_REQUEST['path'])       : '';
		$this->g_para['filename']       = isset($_REQUEST['filename'])  ? trim($_REQUEST['filename'])   : '';
		$this->g_para['utime']          = isset($_REQUEST['utime'])     ? trim($_REQUEST['utime'])      : '';
		$this->g_para['ip']             = isset($_REQUEST['ip'])        ? trim($_REQUEST['ip'])         : '';
		$this->g_para['releasetype']    = isset($_REQUEST['releasetype']) ? intval($_REQUEST['releasetype']) : 0;
		$this->g_para['from']		= isset($_REQUEST['from'])	? trim($_REQUEST['from']) : 0;
		$this->g_para['nick']		= isset($_REQUEST['nick'])	? trim($_REQUEST['nick']) : '';
		$this->g_para['grade']		= isset($_REQUEST['grade'])	? trim($_REQUEST['grade']) : '';

                //微什么项目处理逻辑标识                                                                   
                $this->g_para['syncid']         = isset($_REQUEST['syncid'])    ? floatval($_REQUEST['syncid']) : 1;  
                //后台审核通过后，如果需要分享微博
		$this->g_para['c1']         = isset($_REQUEST['c1'])    ? trim($_REQUEST['c1']) : '';  
		$this->g_para['c2']         = isset($_REQUEST['c2'])    ? trim($_REQUEST['c2']) : '';  
                $this->g_para['sharewb']         = isset($_REQUEST['share'])    ? floatval($_REQUEST['share']) : '';  
        
        $this->g_para['wbinfo']         = isset($_REQUEST['wbinfo'])    ? trim($_REQUEST['wbinfo']) : '';  
                
        //微博接口OAuth2.0方式调用
		$this->g_para['token']  = isset($_REQUEST['token'])? trim($_REQUEST['token'])	: "";
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {

                if($this->g_para['app'] == 2 ){  //知识人项目                                              
                        if($this->g_para['syncid'] == 1){                                                  
                                $this->APP = 1; //知识人数据导入微什么项目的情况                           
                        }                                                                                  
                        else{
                                $this->APP = 2; //知识人                                                   
                        }
                }                                                                                          
                elseif($this->g_para['app'] == 1 && $this->g_para['syncid'] == 1){  //微什么web版本        
                        $this->APP = 1;                                                                    
                }                                                                                          
                elseif(($this->g_para['app'] == 3||$this->g_para['app'] == 6) && $this->g_para['syncid'] == 1){ //微什么手机wap版本 ios客户端     
                        $this->APP = 1;                                                                    
                }  

		//项目应用与同步规则                                                                       
                if(empty($this->APP)) {                                                                    
                        $this->error_num(3003);                                                            
                } 

		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}

		if(empty($this->g_para['questionid'])) {
			$this->error_num(2136);
		}

		if(empty($this->g_para['uid'])) {
			$this->error_num(2101);
		}

		if(empty($this->g_para['answer'])){
			$this->error_num(2113);
		}

		/*
		if($this->g_para['app'] == ZHISHI_APP_ID) {
			if(empty($this->g_para['answerid'])) {
				$this->error_num(2131);
			}
		}*/

	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {

		if($this->APP == 1) {
			$this->generate_server_id = new IdServer();
			$this->g_para['answerid'] = $this->generate_server_id->get('answer');
		}

		$this->tools_obj= new Tools();
		$this->api_obj = new Answer($this->g_para , $this->g_result);
	}


	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = $this->g_para['api_name'] = 'addans';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->APP;
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	/**
	 * 主函数
	 **/
	function main() {

		$this->add_answer();
	}

	/**
	 * 处理添加回答及其日志逻辑
	 **/	
	function add_answer() {

		// 判断用户是否已经回答过
		$res = $this->api_obj->check_if_answered();
		if(!$res) {
			$this->error_num(2102);
		}

		// 针对知识人 和 微问答 处理个性参数
		if($this->APP == API_APP_ID) {
			$data_append = array (
					'refermate'=>$this->g_para['refermate'],
					'imgtags' => $this->g_para['imgtags'],
					);
			//@todo 接口统一处理后删除此逻辑		
			if($this->g_para['app']==3||$this->g_para['app']==6){//wap端  ios客户端
				$this->g_para['answer'] = $this->tools_obj->deal_filter_link($this->g_para['answer'],$linkarr);
				$this->g_para['refermate'] = $this->tools_obj->deal_text_web($this->g_para['refermate'],2);
				$this->g_para['answer'] = $this->tools_obj->deal_text_web($this->g_para['answer'],5);
				$data_append = array (
										'refermate'=>$this->g_para['refermate']
								);
			}
			/*
			//添加判断是否被邀请标志start
				$invited_list = $this->api_obj->is_invited($this->g_para['questionid']);	
				if($invited_list['num'] > 0){
					unset($invited_list['num'],$invited_list['total']);
					$tmp_inv = array();
					foreach($invited_list as $val){
						if(!empty($val['keys'][2])){
							$tmp_inv[] = $val['keys'][2];
						}
					}
					if(@in_array($this->g_para['uid'],$tmp_inv)){
						$data_append['invite_flag'] = 1;
					}
				}
	
	
			//添加判断是否被邀请标志end
			*/

			$data_append_str = serialize($data_append);
		}
		elseif($this->APP  == ZHISHI_APP_ID) {

			$other_param_arr = array (
					'degree'	=> $this->g_para['degree'],
					'remark'	=> $this->g_para['remark'],
					'status'    => $this->g_para['status'],
					'auditflag'	=> $this->g_para['auditflag'],
					'warnflag'	=> $this->g_para['warnflag'],
					'path'		=> $this->g_para['path'],
					'filename'	=> $this->g_para['filename'],
					'refermate'	=> $this->g_para['refermate'],
					'releasetype'   => $this->g_para['releasetype'],
					'from'   => $this->g_para['from'],
					'nick'   => $this->g_para['nick'],
					'grade'   => $this->g_para['grade'],
					);
			$data_append_str = serialize($other_param_arr);

		}

		// 入mysql
		$arr =  array (
				'appid'		=> $this->g_para['app'], 	//表示数据所属的项目，保持与所传的值一致
				'answerid'	=> $this->g_para['answerid'],
				'answer'	=> $this->g_para['answer'],
				'showflag'	=> 0,
				'data_append'	=> $data_append_str,
				'uid'		=> $this->g_para['uid'],
				'ctime'		=> $this->g_para['time'],
				'owner'		=> $this->g_para['owner'],
				'utime'		=> $this->g_para['utime'],
				'ip'		=> ip2long($this->g_para['ip']),
				'questionid'	=> $this->g_para['questionid'],
			      );
		$this->api_obj->send_mysql($arr , $rpcdb_result);
		if(!$rpcdb_result){
			$this->error_num(2102);
		}

		//发送BDB
		$arr = array (
				'0'		=> EVENT_ANSWER_ADD,
				'answerid'	=> $this->g_para['answerid'],
				'appid'		=> $this->g_para['app'],
				'answer'	=> $this->g_para['answer'],
				'showflag'	=> 0,
				'data_append'	=> $data_append_str,
				'uid'		=> $this->g_para['uid'],
				'ctime'		=> $this->g_para['time'],
				'owner'		=> $this->g_para['owner'],
				'utime'		=> $this->g_para['utime'],
				'ip'		=> ip2long($this->g_para['ip']),
				'questionid'	=> $this->g_para['questionid'],
			     );

		$this->api_obj->send_bdb($arr , $queue_result);
		if(!$queue_result){
			$this->error_num(2102);
		}


		// 执行订制功能
		$this->run_api_event();

		$json_array = array('result' => 'true' , 'answerid' => $this->g_para['answerid'] , 'logids' => $this->g_result['logids_array']);
		echo json_encode($json_array);
	}

	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}

}
$exec = new addAnswer();
$exec->run();
?>
