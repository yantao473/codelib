<?php
/**
 * @fn              获取问题日志接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-08-27
 */

include_once("apiconf.php");

class getQuestionLog extends  webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['questionid'] = isset($_REQUEST['questionid']) ? floatval($_REQUEST['questionid']) : "";
		$this->g_gara['start'] = (isset($_REQUEST['start']) && !empty($_REQUEST['start']))?$_REQUEST['start']:0;
		$this->g_para['num'] = (isset($_REQUEST['num']) && !empty($_REQUEST['num']))?$_REQUEST['num']:20;
	}

	function _check_param(){
		if(isset($this->g_para['questionid']) && empty($this->g_para['questionid'])){
			$this->error_num(2111);		
		}
	}

	function _init_class(){
		$this->tools_obj= new Tools();
		$this->bdb = new GetBdb();
	}
	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = 'getquestionlog';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	function main(){
		$this->get_question_log();
	}

	function get_question_log(){

		$result = $this->bdb->lists("tqe",$this->g_para['questionid'],$this->g_gara['start'],$this->g_para['num'],$data);
		if(!$result){
			$this->error_num(2130);	
		}
		if(empty($data)){
			$this->error_num(2135);
		}
		$num = $data['num'];
		$total = $data['total'];
		$get_info = array();
		$get_info['num'] = $num;
		$get_info['total'] = $total;
		if($this->g_para['num'] < $num){
			$num = $this->g_para['num'];
		}
		for($i=0;$i< $num;$i++){
			if($data[$i]['data']['uid'] != 0){
				$this->bdb->gets('user',$data[$i]['data']['uid'],$d_user);
				$get_info[$i]['nick'] = !empty($d_user['nick'])?$d_user['nick']:"";
			}else{
				$get_info[$i]['nick'] = "";
			}
			$get_info[$i]['ctime'] = !empty($data[$i]['data']['ctime'])?$data[$i]['data']['ctime']:"";
			$get_info[$i]['oid'] = !empty($data[$i]['data']['oid'])?$data[$i]['data']['oid']:"";
			$get_info[$i]['uid'] = !empty($data[$i]['data']['uid'])?$data[$i]['data']['uid']:0;
			switch($data[$i]['data']['type']){
				case EVENT_QUESTION_ADD :
					$get_info[$i]['opration'] = "添加了问题:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_QUESTION_TITLE_UPDATE :
					$get_info[$i]['opration'] = "更新了问题标题:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_QUESTION_DESC_UPDATE :
					$get_info[$i]['opration'] = "更新了问题描述:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_QUESTION_LOCK :
					$get_info[$i]['opration'] = "锁定了问题:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_QUESTION_TAG_ADD :
					$get_info[$i]['opration'] = "添加了话题:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_QUESTION_TAG_DEL :
					$get_info[$i]['opration'] = "删除了话题:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_ANSWER_ADD :
					$get_info[$i]['opration'] = "添加了答案:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_ANSWER_DEL :
					$get_info[$i]['opration'] = "删除了答案:";
					//$get_info[$i]['content'] = $data[$i]['data']['content'];
					$get_info[$i]['content'] = "";
					break;
				case EVENT_ANSWER_UPDATE :
					$get_info[$i]['opration'] = "更新了答案:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_ANSWER_RECOVER :
					$get_info[$i]['opration'] = "恢复了答案:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
				case EVENT_QUESTION_ADOPT :
					$get_info[$i]['opration'] = "采纳了答案:";
					$get_info[$i]['content'] = $data[$i]['data']['content'];
					break;
			}
		}
		$this->run_api_event();	
		echo json_encode($get_info);
	}
	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}

}
$exec = new getQuestionLog();
$exec->run();
?>
