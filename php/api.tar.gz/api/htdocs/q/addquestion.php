<?php
/**
 * @fn              添加问题接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2
 * @link            /q/addquestion.php
 * @date            2012-06-07
 */

include_once("apiconf.php");

class addQuestion extends webApp implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	private $APP;

	public $g_para;
	public $g_result;

	function  __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		$this->g_para['uid']		= isset($_REQUEST['uid'])	? floatval($_REQUEST['uid'])	: '';
		//来源
		$this->g_para['app']		= isset($_REQUEST['app'])	? floatval($_REQUEST['app'])	: '';
		$this->g_para['owner']		= isset($_REQUEST['owner'])	? floatval($_REQUEST['owner']) 	: 0;	//0正常，1匿名提问，2团队提问
		$this->g_para['showflag']	= isset($_REQUEST['showflag'])	? floatval($_REQUEST['showflag']) : 0;	//0显示，1隐藏
		$this->g_para['touid']		= isset($_REQUEST['touid'])	? floatval($_REQUEST['touid'])	: 0;
		$this->g_para['title']		= isset($_REQUEST['title'])	? trim($_REQUEST['title']) 	: '';
		$this->g_para['desc']		= isset($_REQUEST['desc'])	? trim($_REQUEST['desc']) 	: '';
		$this->g_para['tag']		= isset($_REQUEST['tag'])	? trim($_REQUEST['tag']) 	: '';
		$this->g_para['time']		= isset($_REQUEST['ctime'])	? trim($_REQUEST['ctime']) 	: date("Y-m-d H:i:s");
		$this->g_para['status']		= isset($_REQUEST['status'])	? intval($_REQUEST['status'])	: 0;
                //后台审核回答标志 20120926 审核中1使用，审核了(通过与不通过)2后删除字段
                $this->g_para['auditaflag']        = isset( $_REQUEST['auditaflag'] ) ? $_REQUEST['auditaflag'] : '';

        //add share wb
		$this->g_para['sharewb']	= isset($_REQUEST['sharewb'])? floatval($_REQUEST['sharewb'])	: 0;
		$this->g_para['c1']         = isset($_REQUEST['c1'])    ? trim($_REQUEST['c1']) : '';
		$this->g_para['c2']         = isset($_REQUEST['c2'])    ? trim($_REQUEST['c2']) : '';
		//微博接口OAuth2.0方式调用
		$this->g_para['token']  = isset($_REQUEST['token'])? trim($_REQUEST['token'])	: "";


		// zhishi
		$this->g_para['limitday']	= isset($_REQUEST['limitday'])	? intval($_REQUEST['limitday']) : 0;
		$this->g_para['price']		= isset($_REQUEST['price'])	? intval($_REQUEST['price'])	: 0;
		//$this->g_para['degree']		= isset($_REQUEST['degree'])	? intval($_REQUEST['degree'])	: 0;
		$this->g_para['classid']	= isset($_REQUEST['classid'])	? intval($_REQUEST['classid'])	: 0;
		$this->g_para['grade']		= isset($_REQUEST['grade'])	? $_REQUEST['grade'] : '';
		$this->g_para['releasetype']	= isset($_REQUEST['releasetype']) ? intval($_REQUEST['releasetype'])	: 0;
		$this->g_para['nick']		= isset($_REQUEST['nick'])	? trim($_REQUEST['nick'])	: '';
		$this->g_para['ip']		= isset($_REQUEST['ip'])	? trim($_REQUEST['ip'])		: '';
		//$this->g_para['comments']	= isset($_REQUEST['comments'])	? trim($_REQUEST['comments'])	: '';
		$this->g_para['path']		= isset($_REQUEST['path'])	? trim($_REQUEST['path'])	: '';
		$this->g_para['filename']	= isset($_REQUEST['filename'])	? trim($_REQUEST['filename'])	: '';
		$this->g_para['append']		= isset($_REQUEST['append'])	? trim($_REQUEST['append'])	: '';
		$this->g_para['imageurl']	= isset($_REQUEST['imageurl'])	? trim($_REQUEST['imageurl'])	: '';

		$this->g_para['auditflag']	= isset($_REQUEST['auditflag'])	? trim($_REQUEST['auditflag'])	: 'y';
		$this->g_para['warnflag']	= isset($_REQUEST['warnflag'])	? trim($_REQUEST['warnflag'])	: '';
		$this->g_para['isfun']		= isset($_REQUEST['isfun'])	? trim($_REQUEST['isfun'])	: 'n';
		$this->g_para['iscream']	= isset($_REQUEST['iscream'])	? trim($_REQUEST['iscream'])	: 'n';
		$this->g_para['answerID']	= isset($_REQUEST['answerID'])	? trim($_REQUEST['answerID'])	: '';
		$this->g_para['entertime']	= isset($_REQUEST['entertime'])	? trim($_REQUEST['entertime'])	: '';
		$this->g_para['votetime']	= isset($_REQUEST['votetime'])	? trim($_REQUEST['votetime'])	: '';
		$this->g_para['votetotal']	= isset($_REQUEST['votetotal'])	? trim($_REQUEST['votetotal'])	: '0';
		$this->g_para['classidl1']	= isset($_REQUEST['classidl1'])	? trim($_REQUEST['classidl1'])	: '0';
		$this->g_para['classidl2']	= isset($_REQUEST['classidl2'])	? trim($_REQUEST['classidl2'])	: '0';
		$this->g_para['commend']	= isset($_REQUEST['commend'])	? trim($_REQUEST['commend'])	: 'n';
		$this->g_para['answer_nick']	= isset($_REQUEST['answer_nick'])	? trim($_REQUEST['answer_nick'])	: '';
		$this->g_para['answer_uid']	= isset($_REQUEST['answer_uid'])	? trim($_REQUEST['answer_uid'])	: '0';
		$this->g_para['isfilter']	= isset($_REQUEST['isfilter'])	? trim($_REQUEST['isfilter'])	: '0';
		$this->g_para['server']		= isset($_REQUEST['server'])	? trim($_REQUEST['server'])	: '';
		$this->g_para['prizetime']	= isset($_REQUEST['prizetime'])	? trim($_REQUEST['prizetime'])	: '';
		$this->g_para['appendtime']	= isset($_REQUEST['appendtime'])	? trim($_REQUEST['appendtime'])	: '';
		$this->g_para['mobile']		= isset($_REQUEST['mobile'])	? trim($_REQUEST['mobile'])	: '';
		$this->g_para['answerfrom']	= isset($_REQUEST['answerfrom'])	? trim($_REQUEST['answerfrom'])	: '';
		$this->g_para['iswonder']	= isset($_REQUEST['iswonder'])	? trim($_REQUEST['iswonder'])	: '0';
		$this->g_para['qfrom']		= isset($_REQUEST['qfrom'])	? trim($_REQUEST['qfrom'])	: '';
		$this->g_para['tonick']		= isset($_REQUEST['tonick'])	? trim($_REQUEST['tonick'])	: '';

		//微什么项目处理逻辑标识
		$this->g_para['syncid']		= isset($_REQUEST['syncid'])	? floatval($_REQUEST['syncid'])	: 1;
		//知识人有传过来的问题ID和微什么提问时如果有图片的时候也有QUESTIONID ，微什么在APP里生成的questionid
		$this->g_para['questionid']	= isset($_REQUEST['questionid'])? floatval($_REQUEST['questionid'])	: '';
		$this->g_para['imgtags']        = isset( $_REQUEST['imgtags'] ) ? $_REQUEST['imgtags'] : '';
		$this->g_para['img_link']        = isset( $_REQUEST['link'] ) ? $_REQUEST['link'] : '';
		$this->g_para['auto_follow']        = isset( $_REQUEST['auto_follow'] ) ? $_REQUEST['auto_follow'] : 0;
		$this->g_para['strip_tags']        = isset( $_REQUEST['strip_tags'] ) ? $_REQUEST['strip_tags'] : 0;
		$this->url = 'http://172.16.68.112/vask_filter/resys_vask_filter.php';
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {

		if($this->g_para['app'] == 2 ){  //知识人项目
			if($this->g_para['syncid'] == 1){
				$this->APP = 1; //知识人数据导入微什么项目的情况
			}
			else{
				$this->APP = 2; //知识人
			}
		}
		elseif($this->g_para['app'] == 1 && $this->g_para['syncid'] == 1){  //微什么web版本
			$this->APP = 1;
		}
		elseif(($this->g_para['app'] == 3||$this->g_para['app'] == 6) && $this->g_para['syncid'] == 1){ //微什么手机wap版本  ios客户端
			$this->APP = 1;
		}
		elseif($this->g_para['app'] == 4 && $this->g_para['syncid'] == 1) {
			$this->APP = 1;
		}
		elseif($this->g_para['app'] == 5 && $this->g_para['syncid'] == 1) {
			$this->APP = 1;
		}

		//项目应用与同步规则
		if(empty($this->APP)) {
			$this->error_num(3003);
		}

		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}

		if(empty($this->g_para['uid'])) {
			$this->error_num(2101);
		}

		if(empty($this->g_para['title'])) {
			$this->error_num(2103);
		}

		if($this->g_para['app'] == ZHISHI_APP_ID) {	//只判断知识人来源的问题ID，所以此处不用APP
			if(empty($this->g_para['questionid'])) {
				$this->error_num(2136);
			}
		}
	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {

		// 微什么要从发号器获取id ，由于提问时添加了图片的情况，会在app/addquestion.php里生成questionid，此时不用生成questionid
		if( ( $this->g_para['app'] == 1  && empty( $this->g_para['questionid'] ) ) ||  ($this->g_para['app'] == 2 &&  ($this->g_para['questionid'] < 30000000 )  ) ||($this->g_para['app'] == 3 )||($this->g_para['app'] == 6 ) || ($this->g_para['app'] == 4 ) ) {
			$this->generate_server_id = new IdServer();
			$this->g_para['questionid'] = $this->generate_server_id->get("question");
		}

		$this->tools_obj= new Tools();
		$this->api_obj = new Question($this->g_para , $this->g_result);
	}

	/*
	* 初始化接口功能
	*/
	function _init_api_config() {

		$this->api_name = 'addquestion';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->APP;
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	/**
	 * 主函数
	 **/
	function main() {

		$this->add_question();
	}

	function get_auto_tags(){
                $post_data = array(
                                'title' => $this->g_para['title'],
                                'desc'  => '',
                                );
                $post_data = array('question' => json_encode($post_data));

                $flag = $this->tools_obj->send_curl($this->url , 'post' , $post_data , $json);
                $res = json_decode($json , true);
                if($res['err_code'] == 0 && !empty($res['data'])) {
                        foreach($res['data'] as $k => $v) {
                                $result['data'][] = $v['word'];
                        }
		}
		return $result;

	}

	/**
	 * 处理添加问题及其日志逻辑
	 **/
	function add_question() {
		//调用自动添加话题接口START
		$auto_tags = $this->get_auto_tags();
		$strtags = '';
		if(!empty($auto_tags['data'])){
			$strtags = @implode(",",$auto_tags['data']);
		}
		//调用自动添加话题接口END

		if($this->g_para['strip_tags']) {
			$this->g_para['title'] = strip_tags($this->g_para['title']);
			$this->g_para['desc'] = strip_tags($this->g_para['desc']);
		}

		//@todo 接口统一处理后删除此逻辑
		if($this->g_para['app']==3||$this->g_para['app']==6){//wap端  ios客户端
			$this->g_para['title'] = preg_replace('~(#|＃)提问(#|＃)~is', "", $this->tools_obj->deal_text_web($this->g_para['title'],1));// 问题标题强制过滤点#提问#
			$this->g_para['desc'] = $this->tools_obj->deal_filter_link($this->g_para['desc'],$linkarr);
			$this->g_para['img_link']=isset( $linkarr ) ? $linkarr : '';
			$this->g_para['desc'] = $this->tools_obj->deal_text_web($this->g_para['desc'],5);
		}


		// 针对知识人 和 微问答 处理个性参数
		if($this->APP == API_APP_ID) {
			// 处理话题
                	if(!empty($this->g_para['tag'])) {
                	        $tags_array = $this->api_obj->deal_add_tags();
                	}
			else {
				$tags_array = array();
			}
			$other_param_arr = array(
					'syncid' =>  $this->g_para['syncid'],
			);
                        if(!empty($this->g_para['auditaflag']) && ($this->g_para['auditaflag'] == 1)){
                                $other_param_arr['auditlist'][$this->g_para['uid']] =  strtotime(date("Y-m-d H:i:s"));
                        }
                        if(!empty($this->g_para['auditaflag']) && ($this->g_para['auditaflag'] == 2)){
                                unset($other_param_arr['auditlist'][$this->g_para['uid']]);
                        }
			//图片标签处理
			if(!empty($this->g_para['imgtags'])){
				$other_param_arr['imgtags'] =  $this->g_para['imgtags'];
			}
			if(!empty($this->g_para['img_link'])){
				$other_param_arr['link'] =  $this->g_para['img_link'];
			}

			$data_append_str = json_encode($other_param_arr);
		}
		elseif( $this->APP == ZHISHI_APP_ID) {
			// 处理标签
			if(!empty($this->g_para['tag'])) {
				$tags_array = explode(',' , $this->g_para['tag']);
			}
			else {
				$tags_array = array();
			}
			// 处理其他参数
			$other_param_arr = array(
				'limitday'	=> $this->g_para['limitday'],
				'price'		=> $this->g_para['price'],
				//'degree'	=> $this->g_para['degree'],
				'auditflag'	=> $this->g_para['auditflag'],
				'warnflag'	=> $this->g_para['warnflag'],
				'isfun'		=> $this->g_para['isfun'],
				'iscream'	=> $this->g_para['iscream'],
				'answerID'	=> $this->g_para['answerID'],
				'entertime'	=> $this->g_para['entertime'],
				'votetime'	=> $this->g_para['votetime'],
				'votetotal'	=> $this->g_para['votetotal'],
				'classidl1'	=> $this->g_para['classidl1'],
				'classidl2'	=> $this->g_para['classidl2'],
				'commend'	=> $this->g_para['commend'],
				'answer_nick'	=> $this->g_para['answer_nick'],
				'answer_uid'	=> $this->g_para['answer_uid'],
				'isfilter'	=> $this->g_para['isfilter'],
				'server'	=> $this->g_para['server'],
				'prizetime'	=> $this->g_para['prizetime'],
				'appendtime'	=> $this->g_para['appendtime'],
				'mobile'	=> $this->g_para['mobile'],
				'answerfrom'	=> $this->g_para['answerfrom'],
				'iswonder'	=> $this->g_para['iswonder'],
				'qfrom'		=> $this->g_para['qfrom'],
				'tonick'		=> $this->g_para['tonick'],
				'nick'		=> $this->g_para['nick'],
				'comments'	=> $this->g_para['comments'],
				'path'		=> $this->g_para['path'],
				'filename'	=> $this->g_para['filename'],
				'imageurl'	=> $this->g_para['imageurl'],
				'append'	=> $this->g_para['append'],
				'releasetype'	=> $this->g_para['releasetype'],
				'grade'		=> $this->g_para['grade'],
				'syncid' 	=>  $this->g_para['syncid'],
			);
			$data_append_str = json_encode($other_param_arr);
		}


		// 入mysql
		$arr = array (
						'appid'		=> $this->g_para['app'],	//表示数据所属的项目，保持与所传的值一致
                        'title'		=> $this->g_para['title'],
                        'tags'		=> $this->g_para['tag'],
                        'description'	=> $this->g_para['desc'],
                        'uid'		=> $this->g_para['uid'],
                        'ctime'		=> $this->g_para['time'],
						'status'	=> $this->g_para['status'],
                        'showflag'	=> $this->g_para['showflag'],
                        'owner'		=> $this->g_para['owner'],
                        'touid'		=> $this->g_para['touid'],
                        'questionid'	=> $this->g_para['questionid'],
						'classid'	=> $this->g_para['classid'],
						'ip'		=> ip2long($this->g_para['ip']),
						'data_append'	=> $data_append_str,
						'keywords' => $strtags
                );
		$this->api_obj->send_mysql($arr , $rpcdb_result);
		if(!$rpcdb_result){
			$this->error_num(2102);
		}

		//发送BDB
		$arr = array(
			'0'		=> EVENT_QUESTION_ADD,
                        'questionid'	=> $this->g_para['questionid'],
                        'appid'		=> $this->g_para['app'],
                        'title'		=> $this->g_para['title'],
                        'tags'		=> $tags_array,
                        'description'	=> $this->g_para['desc'],
                        'uid'		=> $this->g_para['uid'],
                        'ctime'		=> $this->g_para['time'],
			'status'	=> $this->g_para['status'],
                        'showflag'	=> $this->g_para['showflag'],
                        'owner'		=> $this->g_para['owner'],
                        'touid'		=> $this->g_para['touid'],
			'classid'       => $this->g_para['classid'],
			'ip'		=> ip2long($this->g_para['ip']),
			'data_append'   => $data_append_str,
			'keywords' => $strtags,
                );
		$this->api_obj->send_bdb($arr , $queue_result);
		if($this->g_para['auto_follow']) {
			$follow_param = array(
			  'app'   => API_APP_ID,
			  'uid'   => $this->g_para['uid'],
			  'toid'  => $this->g_para['questionid'],
			  'type'  => 'question',
			  'owner' => $this->g_para['owner'],
			  'time'  => $this->g_para['time'],
			);
			$g_result = array();
			$api_obj = new Follow($follow_param , $g_result);
			$api_obj->addfollow();
		}
		error_log(var_export($arr, true), 3, '/tmp/abc.log');
		if(!$queue_result){
			$this->error_num(2102);
		}

		// 执行订制功能
		$this->run_api_event();

		//分享微博
		if($this->g_para['sharewb']  == 1){
			$res_share = $this->api_obj->send_to_weibo();
		}

		// 返回值
		$json_array = array('questionid'=>$this->g_para['questionid'],'tids_array'=>$tags_array,'logids'=>$this->g_result['logids_array']);
		echo json_encode($json_array);

	}

	/*
	* 调用接口功能订制列表
	*/
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}

}
$exec = new addQuestion();
$result = $exec->run();
?>
