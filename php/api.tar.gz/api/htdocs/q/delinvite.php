<?php
/**
 * @fn              删除邀请回答接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @link            /q/addinvite.php
 * @date            2011-11-25
 * @date            2012-08-01
 */

include_once("apiconf.php");

class delInvite extends  webApp implements Platform_Api{

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

	function  __construct(){
        	$this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();

	}

	function _init_param(){
		$this->g_para['app']    = isset($_REQUEST['app'])? floatval($_REQUEST['app']): "";
		$this->g_para['questionid'] = isset($_REQUEST['questionid']) ? floatval($_REQUEST['questionid']) : "";
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : "";	
		$this->g_para['touid'] = isset($_REQUEST['touid']) ? floatval($_REQUEST['touid']) : "";	
		$this->g_para['ctime'] = isset($_REQUEST['ctime']) ? floatval($_REQUEST['ctime']) : date("Y-m-d H:i:s");
	}

        function _check_param() {
                if(empty($this->g_para['questionid'])) {
                        $this->error_num(2111);
                }

                if(empty($this->g_para['uid'])) {
                        $this->error_num(2112);
                }

                if(empty($this->g_para['touid'])) {
                        $this->error_num(2104);
                }
                if($this->g_para['app'] == ZHISHI_APP_ID) {                                                
                        if(empty($this->g_para['questionid'])) {                                           
                                $this->error_num(2136);                                                    
                        }                                                                                  
                }                                                                                          
                                                                                                           
        }

        function _init_class() {                                                                           
                $this->tools_obj= new Tools();                                                             
                $this->api_obj = new Invite($this->g_para , $this->g_result);                              
        }       

        function _init_api_config() {
                $this->api_name = 'invite';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }

	function main(){
		$this->del_invite();
	}

	function del_invite(){
		$touid = $this->g_para['touid'];
		$qid = $this->g_para['questionid'];
		$uid = $this->g_para['uid'];
		$get_sql = "delete from invite where inviter='$touid' and questionid='$qid' and uid='$uid'";
		$this->api_obj->send_mysql($get_sql , $rpcdb_result,0);
                if(!$rpcdb_result){
                        $this->error_num(2102);
                }
		$arr_bdb = array(
			0=>EVENT_QUESTION_INVITE_DEL,
			'inviter'=>$touid,
			'uid'=>$uid,
			'questionid'=>$qid,
		);
                $this->api_obj->send_bdb($arr_bdb , $queue_result);
                if(!$queue_result){                                                                        
                        $this->error_num(2102);                                                            
                } 
		$json_array = array('result'=>'true',);
		//usleep(500000);
		$this->run_api_event();
		echo json_encode($json_array);
	}
        function run_api_event() {                                                                         
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);                          
                if(!empty($cmd)) {                                                                         
                        if(eval($cmd) === FALSE) {                                                         
                                $this->error_num(3002);                                                    
                        }                                                                                  
                }                                                                                          
        } 
}
$exec = new delInvite();
$exec->run();
?>
