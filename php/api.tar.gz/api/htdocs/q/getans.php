<?php
/**
 * @fn              获取回答摘要接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2 
 * @link            /q/getans.php
 * @date            2011-11-02
 * @edit	    2012-06-15
 */

include_once("apiconf.php");

class getAnswer extends webApp implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		$this->g_para['app']            = isset($_REQUEST['app'])       ? intval($_REQUEST['app'])      : '';
		$this->g_para['answerid']       = isset($_REQUEST['answerid'])  ? floatval($_REQUEST['answerid'])       : '';
              	//图片显示控制标志                                                                         
                $this->g_para['imgflag'] = isset($_REQUEST['imgflag']) ? floatval($_REQUEST['imgflag']) : 0;
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {
		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}

		if(empty($this->g_para['answerid'])) {
			$this->error_num(2131);
		}
	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {
		$this->tools_obj = new Tools();
		$this->bdb_obj = new GetBdb();
		$this->api_obj = new Answer($this->g_para , $this->g_result);
	}

	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = 'getans';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	/**
	 * 主函数
	 **/
	function main() {

		$this->get_answer();
	}

	function get_answer() {

		$result = $this->bdb_obj->gets("answer",$this->g_para['answerid'],$data);
		//deal图片显示  暂时 start
		if(empty($this->g_para['imgflag'])){
			//默认过滤图片
			$apreg = '~.*?\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
			$data['answer'] = preg_replace_callback(
					$apreg,
					function($match){
					return "";
					},                                                         
					$data['answer']                                           
					);                                                         
		}                                                          
		//end

		// 执行订制功能	
		$this->run_api_event();

		if(!empty($data)) {
			echo json_encode($data);
		}else{
			$this->error_num(2135);
		}
	}

	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}
}
$exec = new getAnswer();
$exec->run();
?>
