<?php
/**
 * @fn              批量获取问题摘要接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-08-27
 */

include_once("apiconf.php");

class getQuestion extends  webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['questionids'] = isset($_REQUEST['questionids']) ? $_REQUEST['questionids'] : "";
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
	}

	function _check_param(){                                                                           
		if(empty($this->g_para['questionids'])){              
			$this->error_num(2111);                                                            
		}                                                                                          
	} 

	function _init_class(){
		$this->tools_obj= new Tools();                                                             
		$this->api_obj = new Question($this->g_para , $this->g_result); 
	}

        /*                                                                                                 
        * 初始化接口功能                                                                                   
        */                                                                                                 
        function _init_api_config() {                                                                      
                $this->api_name = 'getquestion';                                                           
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
                if(empty($this->api_config)) {                                                             
                        $this->error_num(3001);                                                            
                }                                                                                          
        }

	function main(){
		$this->get_question();
	}

	function get_question(){
		if( strpos($this->g_para['questionids'],",") === false){
			$this->g_para['questionid'] =	$this->g_para['questionids'];
			$result = $this->api_obj->get_question_baseinfo($data);
			$get_info[$data['questionid']] = $data;

		}else{
			$getids = array();
			$this->g_para['questionid'] = explode(",",$this->g_para['questionids']);
			$result = $this->api_obj->get_question_baseinfo($data);
			foreach($this->g_para['questionid'] as $k=>$v){
				if(empty($v)){
					continue;
				}
				$get_info[$v] = $data[$v];

			}
		}
		if(!empty($get_info)){
			//获取显示答案数
// 			$post_data = array('qid' => $this->g_para['questionids'] );
// 			$this->tools_obj->curl_set( QUESTION_ANSWER_SORT , "post" , $post_data , $json);
// 			$tmp_sort = json_decode($json , true);
// 			$aSort = array();
// 			if(!empty($tmp_sort['data'])) {
// 				foreach($tmp_sort['data'] as $k => $v) {
// 					$aSort[$v['qid']] = $v['num'];
// 				}
// 			}
			$rpcdb_obj = new RpcDb();
			$get_temp_info = array();
			foreach($get_info as $k => $item){
				if(!empty($item['title'])){
					$tableid 	= substr($k, -1);
					$sql 		= "select count(*) as num from answer{$tableid} where questionid={$k} and showflag=0";
					$dbname 	= 'question';
					$data		= array();
					$res 		= $rpcdb_obj->read($dbname,$sql, $data);
					if($res && !empty($data[0])){
						$item["atotal"] = $data[0]["num"];
					}
					$get_temp_info[$k] = $item;
				}
			}
		}

		if(!$result){
			$this->error_num(2130);	
		}
		if(empty($data)){
			$this->error_num(2135);
		}
		$this->run_api_event();
		echo json_encode($get_temp_info);

	}
        /*                                                                                                 
        * 调用接口功能订制列表                                                                             
        */                                                                                                 
        function run_api_event() {                                                                         
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);                          
                if(!empty($cmd)) {                                                                         
                        if(eval($cmd) === FALSE) {                                                         
                                $this->error_num(3002);                                                    
                        }                                                                                  
                }                                                                                          
        } 

}
$exec = new getQuestion();
$exec->run();
?>
