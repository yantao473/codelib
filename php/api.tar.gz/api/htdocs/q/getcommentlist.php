<?php
/**
 * @fn              获取评论接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2
 * @link            /q/getcommentlist.php
 * @date            2012-06-15
 */

include_once("apiconf.php");

class CommentList extends webApp implements Platform_Api {

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;
	
	public function __construct() {
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
	}
	

        /**
         *  获取参数
         **/
        function _init_param() {
                $this->g_para['app']    = isset($_REQUEST['app'])       ? floatval($_REQUEST['app'])    : '';
                $this->g_para['oid']    = isset($_REQUEST['oid'])       ? floatval($_REQUEST['oid'])    : '';
                $this->g_para['type']   = isset($_REQUEST['type'])      ? trim($_REQUEST['type'])	: '';
                $this->g_para['start']  = isset($_REQUEST['start'])	? intval($_REQUEST['start'])	: 0;
                $this->g_para['num']    = isset($_REQUEST['num'])	? intval($_REQUEST['num'])	: 10;
		// zhishi
        }

        /**
         *  判断参数合法性
         **/
        function _check_param() {

                if(empty($this->g_para['app'])) {
                        $this->error_num(3000);
                }

                // 判断对象id
                if(empty($this->g_para['oid'])) {
                        $this->error_num(2003);
                }

                // 判断类型id
                if(empty($this->g_para['type'])) {
                        $this->error_num(2007);
                }

                if($this->g_para['app'] == ZHISHI_APP_ID) {
                }
        }

        /**
         *  初始化对象
         **/
        function _init_class() {

                $this->tools_obj= new Tools();
                $this->api_obj = new Comment($this->g_para , $this->g_result);
        }

        /*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = 'getcommentlist';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }

	public function main() 
	{
		$this->get_comment_list();
	}

	/**
	 * 获取评论列表
	 * 
	 * @param :
	 * @return : bool
	*/
	private function get_comment_list()
	{
		$flag = $this->api_obj->get_comment_bdb($data);
		if(!$flag) 
		{
			$this->error_num(2302);
		}

                // 执行订制功能
                $this->run_api_event();

		echo json_encode($data);
	}

        /*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }
}
$app = new CommentList();
$app->run();
?>
