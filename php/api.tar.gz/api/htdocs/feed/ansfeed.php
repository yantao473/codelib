<?php
/**
 *@package	微博调用模版接口
 *@author      	zhanghua2@staff.sina.com.cn
 *@copyright   	copyright(2011) 新浪网研发中心 all rights reserved
 *@link		/aj/askwb/renderfeed.php
 *@date       	2012-09-10
 */
include_once("weiboconf.php");

class AnsFeed{

	function __construct(){
		$this->tools_obj = new Tools;
		$this->wbv4 = new weibov4;
		$this->bdb = new GetBdb;
		$this->user = new UserMan;
	}

	function main(){
		$this->_check_cgi_pro();	
		$this->_check_param();
		// $this->_check_ip();
		$this->sub_feed_answer();
	}

	/**
	 * 获取参数
	 *
	 * @param
	 * @return
	 */
	private function _check_cgi_pro() {
		$this->g_para['cuid']		= !empty($_REQUEST['cuid'])	? floatval($_REQUEST['cuid']) : 0;
		$this->g_para['actiondata']	= !empty($_REQUEST['actiondata']) ? trim($_REQUEST['actiondata']) : '';
		$this->g_para['cip']		= !empty($_REQUEST['cip'])	? trim($_REQUEST['cip']) : 0;
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {
		if(empty($this->g_para['cuid'])) {
			$this->error_num(20004);
		}
	}

	function sub_feed_answer() {	
		$json = urldecode($this->g_para['actiondata']);	
		$actiondata = json_decode($json , true);
		$this->g_para['qid'] = $actiondata['qid'];
		$this->g_para['uid'] = $actiondata['uid'];
		$this->g_para['share_my_wb']	=  $actiondata['share_my_wb'] ? $actiondata['share_my_wb'] : 0;
		$this->g_para['user_img']	=  strip_tags($actiondata['user_img']);
		$this->g_para['answer'] = $actiondata['answer'];

		// 如果回答提交为空，特殊处理
		if(empty($this->g_para['answer'])) {
			$res = array(
					'code'  => '100000',
					'html'	=> '
					<span class="face"><a title="" href=""><img width="50" height="50" alt="" src="'.$this->g_para['user_img'].'"></a></span>
					<div class="fr" component="widget.component.form" component-param="appkey=common" component-data="qid='.$this->g_para['qid'].'&uid='.$this->g_para['uid'].'&action=110&type=31">
					<div class="ipt">
					<div class="arrow_lt"><div class="inner"><i class="i1"></i><i class="i2"></i></div></div>
					<div class="t">
					<textarea name="answer" component-param="max=20000" component="widget.component.limitInput"></textarea>
					<input type="hidden" name="user_img" value="'.$this->g_para['user_img'].'"/>
					</div>
					</div>
					<div class="opt">
					<a class="W_btn_d btn_noloading" href="#" component="widget.component.submit" component-param="enabledClass=W_btn_d btn_noloading&disabledClass=W_btn_d"><span><b class="loading"></b><em node-type="btnText">回答</em></span></a>
					<font color="red" style="float:right;margin-top:3px;">您的回答过短！</font>
					<label>
					<input type="checkbox" checked="checked" class="W_checkbox" name="share_my_wb" value="1">同时转发到我的微博</label>
					</div>
					</div>
					',
					'msg'   => '',
					);	
			echo json_encode($res);
			exit;
		}
		else {
			$this->g_para['answer'] = $this->tools_obj->deal_text($this->g_para['answer'],6);
		}


		// 获取用户 注册用户
		$this->bdb->gets('user' , $this->g_para['uid'] , $udata);
		if(empty($udata)) {
			$data = array(
					'uniqueid'	=> $this->g_para['uid'],
					'ip'		=> $this->g_para['cip'],
				     );
			$flag = $this->user->register_user($data , $err_msg);
			if(!$flag) {
				$this->error_num(20001);
			}
		}

		// 获取问题详情
		$api = API_DOMAIN . '/q/addans.php';
		$post_data = array( 
				'app'		=> API_APP_ID , 
				'questionid'	=> $this->g_para['qid'] , 
				'uid'		=> $this->g_para['uid'],
				'answer'	=> $this->g_para['answer'],
				);
		$this->tools_obj->curl_set($api , 'post' , $post_data , $json);
		$res = json_decode($json , true);
		// 已经回答过 或者更新失败
		if(!empty($res['error_num']) && $res['error_num'] == 2102) {
			$this->error_num(20002);
		}

		// 分享微博
		if($this->g_para['share_my_wb'] == 1) {
			$url = API_DOMAIN . "/q/getquestion.php";
			$post_data = array("questionid" => $this->g_para['qid']);
			$result = $this->tools_obj->curl_set($url , "post" , $post_data , $json);
			$data_share = json_decode($json , true);
			$title = $data_share['title'];

			$len_title = $this->tools_obj->mb_stringlen($title);
			
			// 对回答中的标签进行处理
			$preg = array(
                                '~(<br[^>]+>)~is',
                                '~<(/?)p[^>]*>~is',
                                '~\[a_(\w+)\]~is',
                                '~\[img_[^\]]+\]~is',
                                '~([ ])+|(&nbsp;)+~'
                        );
                        $replace = array(
                                '',
                                '',
                                '',
                                '',
                                ''
                        );
                	$this->g_para['answer'] = preg_replace($preg, $replace, $this->g_para['answer']);
			
			$str_ans = $this->tools_obj->mb_stringlen($this->g_para['answer']);
			$answer_true_length = (110 - $len_title);
			if($str_ans > $answer_true_length ){
				$ans_wb = $this->tools_obj->htmlSubString($this->g_para['answer'] , $answer_true_length);
				$ans_wb = preg_replace('~...$~is' , ' ...' , $ans_wb);
			}else{
				$ans_wb = $this->g_para['answer'];
			}

			$send_info = '我在@微什么 回答了问题【'.$title.'】 '.$ans_wb.' http://ask.weibo.com/f/'.$this->g_para['qid'];
			$send_info = strip_tags($this->tools_obj->deal_text($send_info,2));
			$get_result = $this->wbv4->update($send_info);
		}

		$res = array(
				'code'  => '100000',
				'html' => '<div class="ask_tips S_line2 S_bg4 clearfix"><div class="fl"><span class="ask_success ask_ico"></span></div><div class="fr"><span class="c">回答成功！<a href="'.DOMAIN.'/q/'.$this->g_para['qid'].'" class="S_link2">查看详情<em class="CH">&gt;&gt;</em></a></span></div></div>',
				'msg'   => '',
			    );	
		echo json_encode($res);
	}

	// 为了微博feed规范 重写error_num方法
	function error_num($code) {
		global $g_error_app;
		$result = array(
				'errcode' => $code,
				'msg'   => $g_error_app[$code],
			       );
		echo json_encode($result);
		die();
	}

}
$exec = new AnsFeed();
$exec->main();
?>
