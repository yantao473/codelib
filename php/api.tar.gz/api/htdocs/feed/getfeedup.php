<?php
include_once("apiconf.php");

class Feed_Getfeedup extends  webApp implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct() { 
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		$this->g_para['oid'] = isset($_POST['oid']) ? sprintf('%.0f', $_REQUEST['oid']): 0;
		$this->g_para['atts'] = isset($_POST['atts']) ? json_decode($_POST['atts'], true) : array();
		$this->g_para['upfid'] = isset($_POST['upfid'])&&is_numeric($_POST['upfid']) ? $_POST['upfid'] : null;
		$this->g_para['span'] = isset($_POST['span']) ? intval($_POST['span']) : 50;
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {
		if(!$this->g_para['oid']||!$this->g_para['atts']||$this->g_para['span']<1){
			$this->error_num(2000);		
		}
	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {
		require_once '/data0/api/class/feedincluded.php';
		feedincluded::toInclude();
		$this->lfeed = modelfactory::getModel('lfeed', 'l', 1);
	}

	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
	}

	/**
	 * 主函数
	 **/
	function main() {
		$this->getFeedUp();
	}

	/**
	 * 获取问题详情
	 **/
	function getFeedUp() {
		$ifeof = false;
		$fidtag = 0;
		//ob_start();
		$result = $this->lfeed->getFeedsUp($this->g_para['oid'], $this->g_para['atts'], $ifeof, $fidtag, $this->g_para['upfid'], $this->g_para['span']);
		//$str = ob_get_contents();
		//ob_end_clean();
		$finres['result'] = $result;
		$finres['ifeof'] = $ifeof ? 1 : 0;
		$finres['fidtag'] = $fidtag;
		//error_log($str, 3, '/tmp/abcd.log');
		echo json_encode($finres);
	}

	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
	}

	// 为了微博feed规范 重写error_num方法
	function error_num($code) {
		global $g_error_app;
		$result = array(
				'errcode' => $code,
				'msg'	=> $g_error_app[$code],		
				);
		echo json_encode($result);
		die();
	}
}
$exec = new Feed_Getfeedup();
$exec->run();
?>
