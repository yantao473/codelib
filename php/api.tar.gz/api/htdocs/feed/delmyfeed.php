<?php
include_once("apiconf.php");

class Feed_Delmyfeed extends  webApp implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct() { 
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		$this->g_para['uid'] = isset($_POST['uid']) ? sprintf('%.0f', $_POST['uid']): 0;
		$this->g_para['fids'] = isset($_POST['fids']) ? explode(',', trim(trim($_POST['fids'], ','))) : array();
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {
		if(!$this->g_para['uid']||!$this->g_para['fids']){
			$this->error_num(1001, 'input error.');	
		}
	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {
		require_once '/data0/api/class/feedincluded.php';
		feedincluded::toInclude();
		$this->lfeed = modelfactory::getModel('lfeed', 'l', 1);
	}

	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
	}

	/**
	 * 主函数
	 **/
	function main() {
		$this->delMyFeed();
	}

	/**
	 * 获取问题详情
	 **/
	function delMyFeed() {
		$res = $this->lfeed->delOnemyfeed($this->g_para['uid'], $this->g_para['fids']);
		$finres = $res ? array('errcode'=>'1000','msg'=>'suc','res'=>'') : array('errcode'=>'1001','msg'=>'err','res'=>'');
		echo json_encode($finres);
	}

	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
	}

	// 为了微博feed规范 重写error_num方法
	function error_num($code, $msg='', $res='') {
		global $g_error_app;
		$result = array(
				'errcode' => $code,
				'msg'	=> $msg,
				'res'	=> $res,
				);
		echo json_encode($result);
		die();
	}
}
$exec = new Feed_Delmyfeed();
$exec->run();
?>
