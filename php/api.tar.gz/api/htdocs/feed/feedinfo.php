<?php
/**
 * @fn              微博feed获取问题信息接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2 
 * @link            /q/getdetail.php
 * @date            2012-09-04
 */

include_once("apiconf.php");

class feedInfo extends  webApp implements Platform_Api {

	private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

	function  __construct() { 
		$this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
	}

	/**
         *  获取参数
         **/
        function _init_param() {
		$this->g_para['app']	= isset($_REQUEST['app'])	? floatval($_REQUEST['app'])		: 1;
		$this->g_para['url']	= isset($_REQUEST['url'])	? trim($_REQUEST['url'])	: "";
	}

	/**
         *  判断参数合法性
         **/
        function _check_param() {
		if(empty($this->g_para['url']) && empty($this->g_para['url'])){
			$this->error_num(2111);		
		}
		
		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}
	}
	
	/**
         *  初始化对象
         **/
        function _init_class() {
                $this->bdb_obj		= new GetBdb;
		$this->tools_obj	= new Tools;
	}

	/*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = $this->g_para['api_name'] = 'feedinfo';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }
	
        /**
         * 主函数
         **/
	function main() {
		$this->get_question();
	}

	/**
         * 获取问题详情
         **/
	function get_question() {
		$preg = '~ask.weibo.com/f/([0-9]+)$~is';
		if(!preg_match($preg , $this->g_para['url'] , $amatch)) {
			$this->error_num(2111);
		}
		$this->g_para['questionid'] = $amatch[1];
		$result = $this->bdb_obj->gets("detail" , $this->g_para['questionid'] , $data);
		if(!$result) {
			$this->error_num(2130);
		}
		elseif(empty($data['title'])) {
			$this->error_num(2135);
		}else {
			$img_url = 'http://ask.sinaimg.cn/f/'.($data['questionid']%100).'/'.$data['questionid'].'.png';
			$flag = $this->tools_obj->file_url_exists($img_url);
			if(!$flag) {
				$img_url = 'http://ww4.sinaimg.cn/thumbnail/a206b2c5jw1dy5fy2p9q9j.jpg';
			}

			$result = array(
				'url'	=> 'http://ask.weibo.com/q/'.$data['questionid'],
				'title'	=> $data['title'],
				'img_prev' => $img_url,
				'id'	=> $data['questionid'],
			);
		}

                // 执行订制功能
                $this->run_api_event();

		echo json_encode($result);
	}

	/*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

	// 为了微博feed规范 重写error_num方法
	function error_num($code) {
		global $g_error_app;
		$result = array(
			'errcode' => $code,
			'msg'	=> $g_error_app[$code],		
		);
		echo json_encode($result);
		die();
	}
}
$exec = new feedInfo();
$exec->run();
?>
