<?php
include_once ("apiconf.php");
class getRelate extends webApp {
	protected $_param = array ();
	protected $_source;
	protected $_qTags = array ();
	protected $klist_tag = array ();
	private $_mem_host, $_mem_port;
	public $memcached, $memresult;
	public $tableid;
	public $_action;
	protected $_id;
	protected $_klist_table = array (
			"ishare" => 23,
			"iask" => 24 
	);
	public function __construct() {
		$this->tools_obj = new Tools ();
		$this->_mem_host = $_SERVER ['MEMCACHE_SERVER'] == "10.39.32.27" ? "10.39.32.28" : "10.83.0.28";
		$this->_mem_port = 12011;
		$this->memresult = $this->_connect_memcache ( $this->memcached );
	}
	/**
	 * 主函数
	 */
	function main() {
		// 参数初始化
		$this->_id = ! empty ( $_REQUEST ["id"] ) ? ( int ) $_REQUEST ["id"] : 0;
		$this->_param ["question"] = ! empty ( $_REQUEST ["question"] ) ? htmlspecialchars ( $_REQUEST ["question"] ) : "";
		$this->_param ["tag"] = ! empty ( $_REQUEST ["tag"] ) ? htmlspecialchars ( $_REQUEST ["tag"] ) : "";
		$this->_param ["category"] = ! empty ( $_REQUEST ["category"] ) ? htmlspecialchars ( $_REQUEST ["category"] ) : "";
		$this->_source = ! empty ( $_REQUEST ["source"] ) ? htmlspecialchars ( $_REQUEST ["source"] ) : "iask";
		$this->show_num = ! empty ( $_REQUEST ["num"] ) ? ( int ) $_REQUEST ["num"] : 1;
		$this->tableid = isset ( $this->_klist_table [$this->_source] ) ? $this->_klist_table [$this->_source] : 0;
		$this->_action = ! empty ( $_REQUEST ["action"] ) ? htmlspecialchars ( $_REQUEST ["action"] ) : "get";
		
		// 返回问题数组
		$qlist = array ();
		$mem_key = md5 ( implode ( "|", $this->_param ) . $this->show_num . $this->_source . $this->_id);
		
		$mem_val = $this->memcached->get($mem_key);
		if ($this->memresult && ! empty ( $mem_val ) && $this->_action != "up") {
			$result = unserialize ( $mem_val );
		} else {
			$tidStr = array ();
			if (! empty ( $this->_id )) {
				$tidStr = $this->get_list_by_klist ();
			}
			if (empty ( $tidStr ) && ($this->_source != "ishare" || $this->_action == "up")) {
				$tidStr = $this->find_match_qid ();
			}
			
			foreach ( $tidStr as $tgname ) {
				$tag_name = is_array ( $tgname ) ? implode ( ",", $tgname ) : $tgname;
				$tmp_qlist = $this->_get_qlist ( $tag_name );
				if (count ( $qlist ) + count ( $tmp_qlist ) >= $this->show_num) {
					if (count ( $qlist ) + count ( $tmp_qlist ) > $this->show_num) {
						$tmp_qlist = array_slice ( $tmp_qlist, 0, $this->show_num - count ( $qlist ) );
					}
					
					$qlist = array_merge ( $qlist, $tmp_qlist );
					break;
				} else {
					$qlist = array_merge ( $qlist, $tmp_qlist );
				}
			}
			
			$result = array ();
			$result ["error_code"] = 0;
			$result ["msg"] = "success";
			$result ["result"] = array (
					"data" => $qlist
			);
			$result ["result"] ["tags"] = $this->_qTags; // 返回匹配上的tags
			
			$mem_val = serialize ( $result );
			$this->memcached->set ( $mem_key, $mem_val, time () + 3 * 3600 );
		}
		
		
		echo json_encode ( $result );
		flush();
		// 存储klist
		if (! empty ( $this->klist_tag )) {
			$this->up_klist ();
		}
	}
	protected function get_list_by_klist() {
		$tidStr = array ();
		if (empty ( $this->tableid ) || empty($this->_id))
			return $tidStr;
		$params = array (
				'tableid' => $this->tableid,
				'key' => $this->_id,
				'start' => 0,
				'num' => 20 
		);
		$this->tools_obj->curl_set ( DOMAIN . '/p/getlist.php', "post", $params, $json_res );
		$klist_data = json_decode ( $json_res, true );
		$qlist = array ();
		$tid = array ();
		
		if ($klist_data ['num'] > 0) {
			foreach ( $klist_data as $key => $list ) {
				$tid [$key] ['tid'] = $list ['keys'] [3];
				$tid [$key] ['time'] = $list ['keys'] [2];
				$tid [$key] ['step'] = $list ['data'];
				$step [] = $list ['data'];
				$time [] = $list ['keys'] [2];
				if ($key + 1 == $klist_data ['num']) {
					break;
				}
			}
			array_multisort ( $step, SORT_ASC, $time, SORT_DESC, $tid );
			$tids_str = '';
			foreach ( $tid as $key => $val ) {
				$tids_str .= $val ['tid'] . ',';
			}
			// ----批量获取话题名称
			$tags_arr = $this->get_tags_string ( $tids_str, 'tids' );
			foreach ( $tags_arr as $key => $tag_name ) {
				$step = $tid [$key] ['step'];
				$tidStr [$step][] = $tag_name;
			}
		}
		
		return $tidStr;
	}
	protected function find_match_qid() {
		$wask_tag = array ();
		foreach ( $this->_param as $p_k => $p_v ) {
			if (! empty ( $p_v ) || (empty ( $p_v ) && $p_k == "tag" && ! empty ( $this->_param ["question"] ))) {
				$wask_tag_tmp = call_user_func_array ( array (
						$this,
						"_get_list_by_" . $p_k 
				), array (
						$p_v 
				) );
				if (! empty ( $wask_tag_tmp )) {
					$wask_tag = array_merge ( $wask_tag, $wask_tag_tmp );
				}
			}
		}

		if (! empty ( $wask_tag )) {
			$this->klist_tag = $wask_tag; // ---准备往klist 里存的tg;
		}
		
		return $wask_tag;
	}
	protected function _get_list_by_question($question) {
		// @todo 问题匹配问题规则已经去掉
		return array ();
	}
	protected function _get_list_by_tag($tag) {
		$tag_arr_tmp = array ();
		if (! empty ( $this->_param ["question"] )) {
			$wask_tag = $this->_get_wask_tag ( $this->_param ["question"] );
		}
		
		if (! empty ( $wask_tag )) {
			$wask_tag_ary = $wask_tag;
			$tag_ary = ! empty ( $tag ) ? explode ( ",", $tag ) : array ();
			$same_ary = array_intersect ( $wask_tag_ary, $tag_ary );
			if (! empty ( $same_ary )) {
				$tag_arr_tmp ['step_1'] = $same_ary;				
			}
			$merg_ary = array_unique ( array_merge ( $tag_ary, $wask_tag_ary ) );
			$tag_arr_tmp ['step_2'] = $merg_ary;
		}
		return $tag_arr_tmp;
	}
	protected function _get_list_by_category($category) {
		// 共享资料为硬指定话题
		$tag_arr = array ();
		if ($this->_source == "ishare") {
			$cateAry = explode ( ",", $category );
			$tagAry = array ();
			$file_handle = fopen ( ROOT_DIR . "/data/open/ishare_cate_2_wask_tag.txt", "r" );
			while ( ! feof ( $file_handle ) ) {
				$line = fgets ( $file_handle );
				if (strpos ( $line, "#" ) !== false) {
					continue;
				}
				$lineAry = explode ( "|", $line );
				if (in_array ( $lineAry [0], $cateAry )) {
					$tagAry = array_unique ( array_merge ( $tagAry, explode ( ",", $lineAry [1] ) ) );
				}
			}
			fclose ( $file_handle );
			if (empty ( $tagAry )) {
				return $tag_arr;
			} else {
				$category = implode ( ",", $tagAry );
			}
		}
		$tmp_arr = $this->_get_wask_tag ( $category );
		if (! empty ( $tmp_arr )) {
			$tag_arr ['step_3'] = $tmp_arr;
		}
		
		return $tag_arr;
	}
	protected function _get_wask_tag($string) {
		$post_data = array (
				'title' => $string,
				'desc' => '' 
		);
		$post_data = array (
				'question' => json_encode ( $post_data ) 
		);
		
		$urlAry = array(
				"http://openapi.iask.sina.com.cn/intelligent/ctags/resys_vask_filter.php",
				"http://172.16.68.112/vask_filter/resys_vask_filter.php",
				"http://openapi.iask.sina.com.cn/intelligent/ctags/resys_vask_filter.php",
		);
		$aryKey = array_rand($urlAry, 1);
		$flag = $this->tools_obj->send_curl($urlAry[$aryKey], 'post' , $post_data , $json);
		$res = json_decode ( $json, true );
		$result = array ();
		if ($res ['err_code'] == 0 && ! empty ( $res ['data'] )) {
			foreach ( $res ['data'] as $k => $v ) {
				$result [] = $v ['word'];
			}
		}
		return $result;
	}
	protected function _get_qlist($tag) {
		$arr = array (
				"app" => 1,
				"syncid" => 1,
				"tnames" => $tag,
				"type" => 1,
				"num" => $this->show_num 
		);
		$this->tools_obj->curl_set ( DOMAIN . '/q/getrelate_v2.php', "post", $arr, $json_info );
		$info = json_decode ( $json_info, true );
		if (! empty ( $info ["q"] )) {
			$tmplist = $info ["q"];
			$qlist = array ();
			if (! empty ( $tmplist )) {
				foreach ( $tmplist as $item ) {
					$qlist [] = array (
							"qid" => $item ["questionid"],
							"title" => $item ["title"] 
					);
				}
			}
			
			$this->_qTags = empty($this->_qTags) ? explode ( ",", $tag ) : array_unique ( array_merge ( $this->_qTags, explode ( ",", $tag ) ) );
			
			return $qlist;
		} else {
			return array ();
		}
	}
	protected function up_klist() {
		if (empty ( $this->tableid ) || empty($this->_id))
			return false;
		foreach ( $this->klist_tag as $step => $tag_arr ) {
			$tags = implode ( ',', $tag_arr );
			$step_arr = explode ( "_", $step );
			$_step = $step_arr [1];
			$tids_arr = $this->get_tags_string ( $tags, 'tags' );
			$klist_value = $_step;
			foreach ( $tids_arr as $tid ) {
				$param = array (
						'tableid' => $this->tableid,
						'key' => array (
								$this->_id,
								time (),
								$tid 
						),
						'value' => $klist_value 
				);
				$result = $this->tools_obj->curl_set ( DOMAIN . '/p/up.php', "post", $param, $json_data );
				$info = json_decode ( $json_data, true );
// 				$_log = "-------------START---" . date ( "Y-m-d H:i:s" ) . "------------------\n";
				
// 				$_log .= " post data :" . var_export ( $param, true ) . "\n";
// 				$_log .= " res : " . var_export ( $info, true ) . "\n";
// 				file_put_contents ( "/tmp/share_klist.log", $_log, FILE_APPEND );
			}
		}
	}
	protected function get_tags_string($tags, $type) {
		$url = DOMAIN . '/t/get_batch_tags.php';
		$params = array (
				'app' => 1,
				'syncid' => 1 
		);
		if ($type == 'tags') {
			$params ['tag_str'] = $tags;
		} else {
			$params ['tid_str'] = $tags;
		}

		$this->tools_obj->curl_set ( $url, "post", $params, $json_data );
		$info = json_decode ( $json_data, true );
		if ($type == 'tags') {
			$tags_arr = array_keys ( $info ['data'] );
		} else {
			foreach ( $info ['data'] as $v ) {
				$tags_arr [] = $v ['name'];
			}
		}
		return $tags_arr;
	}
	protected function _connect_memcache(&$memcached) {
		$memcached = new Memcached ();
		$result = $memcached->addServer ( $this->_mem_host, $this->_mem_port );
		return $result;
	}
}
$exec = new getRelate ();
$exec->run ();
?>
