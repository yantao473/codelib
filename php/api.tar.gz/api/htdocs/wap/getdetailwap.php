<?php
/**
 * @fn              获取问题详情接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2 
 * @link            /q/getdetail.php
 * @date            2011-11-02
 * @edit            2012-06-12
 */
ini_set('display_errors', 0);
include_once("apiconf.php");

class getDetailWap extends  webApp implements Platform_Api {

	private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

	function  __construct() { 
		$this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
	}

	/**
         *  获取参数
         **/
        function _init_param() {
		$this->g_para['app']		= isset($_REQUEST['app'])		? floatval($_REQUEST['app'])		: "";
		$this->g_para['questionid']	= isset($_REQUEST['questionid'])	? floatval($_REQUEST['questionid'])	: "";
        	$this->g_para['questionids']	= isset($_REQUEST['questionids'])	? trim($_REQUEST['questionids'])	: "";
        	//add by guoxianghui 20120714 answer page start
		$this->g_para['astart']	= isset($_REQUEST['astart']) ? trim($_REQUEST['astart'])	: "";
        	$this->g_para['anum']	= isset($_REQUEST['anum'])? trim($_REQUEST['anum'])	: "";
        	//add by guoxianghui 20120714 end
		$this->g_para['uid'] = isset($_REQUEST['uid'])? floatval($_REQUEST['uid'])     : "";
	}

	/**
         *  判断参数合法性
         **/
        function _check_param() {
		if(empty($this->g_para['questionid']) && empty($this->g_para['questionids'])){
			$this->error_num(2111);		
		}
		
		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}
	}
	
	/**
         *  初始化对象
         **/
        function _init_class() {
		$this->follow_obj	= new Follow($this->g_para , $this->g_result);
                $this->bdb_obj		= new GetBdb;
		$this->tools_obj	= new Tools;
	}

	/*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = $this->g_para['api_name'] = 'getdetail';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }
	
        /**
         * 主函数
         **/
	function main() {

		$this->get_question();
	}

	/**
         * 获取问题详情
         **/
	function get_question() {
		
		if(!empty($this->g_para['questionid'])) {
			$questionids = $this->g_para['questionid'];
		}
		elseif(!empty($this->g_para['questionids'])) {
			$questionids = $this->g_para['questionids'];
		}

		$qids = explode(',' , $questionids);
		$result = $this->bdb_obj->gets("detail" , $qids , $data);

		error_log(var_export($data, true), 3, '/tmp/abc.log');
		if(empty($data)) {
			$this->error_num(2135);
			die();
		}
		if(!$result) {
			$this->error_num(2130);
			die();
		}

		// 问题详细接口 增加取问题关注者总数
		if(!empty($data)) {
			if($this->g_para['app'] == ZHISHI_APP_ID) {
				$this->g_para['type'] = 'gso';
			}
			elseif($this->g_para['app'] == API_APP_ID) {
				$this->g_para['type'] = 'gqo';
			}
			foreach($data as $qid => $qinfo) {
				$this->g_para['start'] = $this->g_para['num'] = 0;
				$this->g_para['oid'] = $qid;
				$follow = $this->follow_obj->getfollowlist();
				$data[$qid]['gz_num'] = $follow['total'];
			}
		}

		// 过滤回答 去掉隐藏回答 取真正回答数 add by zhanghau2 2012-03-27
		if(!empty($data)) {
				if(!empty($data[$qid]['a'])){
                                	foreach($data[$qid]['a'] as $item) {
                                        	$time_temp[] = $item['ctime'];
                                        	$vote_temp[] = count($item['2']);
                                	}
                                array_multisort($vote_temp, SORT_DESC ,$time_temp,SORT_DESC, $data[$qid]['a']);
				}
			foreach($data as $qid => $qinfo) {
				$data[$qid]['atotal'] = count($qinfo['a']);
				$data[$qid]['isanswer'] = false;
				if(!empty($qinfo['a'])) {
					$j = 0;
					foreach($qinfo['a'] as $aid => $ainfo) {
						if($this->g_para['uid'] == $ainfo['uid']){
							$data[$qid]['isanswer'] = true;
						}
						if($ainfo['showflag'] == 1) {
							$data[$qid]['atotal']--;
						}else{
							//add by guoxianghui 20120714 start
							$aid_arr[] = $aid;
							//$atemp[$aid] = $ainfo;
							$atemp[$j] = $ainfo;
							//注意跟现在web版本区别下标
							//add end
							$j++;
						}
					}
				}
					//add by guoxianghui  answer page 20120714 start
					$end = $this->g_para['astart']*$this->g_para['anum'] + $this->g_para['anum'];
					$atotal = $data[$qid]['atotal'];
					//if($end <= $atotal ) {
						$start = $this->g_para['astart']*$this->g_para['anum'];
						$a_num = $this->g_para['anum'];
							
						for($g= $start;$g < $end;$g++){
							if(!empty($atemp[$g])){
								$ans_temp[] = $atemp[$g];
							}
						}
					foreach($ans_temp as $ka=>$va){
						$temp_answer[$va['answerid']] = $va;
					}					
					$data[$qid]['a'] = array();
					$data[$qid]['a'] = $temp_answer;
		
					//}else{
						//$data[$qid]['a'] = array(); 
					//	$pageflag = false;
					//}

					//add by guoxianghui  answer page 20120714 end
				$data[$qid]['atotal'] = $data[$qid]['atotal'] < 0 ? 0 : $data[$qid]['atotal'];
			}
		}
	
                // 执行订制功能
                $this->run_api_event();
	
		if(!empty($this->g_para['questionid'])) {
			//print_r($data[$this->g_para['questionid']]);
			//exit();
			//print_r($data[$this->g_para['questionid']]);
			echo json_encode($data[$this->g_para['questionid']]);
                }
                elseif(!empty($this->g_para['questionids'])) {
			echo json_encode($data);
                }
	}

	/*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$exec = new getDetailWap();
$exec->run();
?>
