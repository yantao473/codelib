<?php
/**
 *@package	  手机端读取消息处理
 *@author      	  xianghui@staff.sina.com.cn
 *@copyright      copyright(2011) 新浪网研发中心 all rights reserved
 *@date           2012-09-04
 */
require_once("apiconf.php");

class readno extends webApp implements Platform_Api{
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;
	public $notice_obj;

	function __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function main(){
		$this->deal_notice();
	}

	function _init_param(){
		$this->g_para['mid'] = $_REQUEST['mid'];
		$this->g_para['type'] = isset($_REQUEST['type']) ? floatval($_REQUEST['type']) : "";
		$this->g_para['uid'] = floatval($_REQUEST['uid']);
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1; 
	}
	function _check_param(){
		if(empty($this->g_para['uid'])){
			$this->error_num(2101);
		}
	}

	function _init_class(){
		$this->tools_obj= new Tools();
		$this->notice_obj = new Notice();
	}

	function _init_api_config() {                                                                      
		$this->api_name = 'readwapnotice';                                                             
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	}

	function deal_notice(){
		if($this->g_para['type'] == 1){
			// 处理消息为已读
			if(!empty($this->g_para['mid'])) {
				$str_mid = explode(",",$this->g_para['mid']);
				foreach($str_mid as $val){
					$temp_arr[] = floatval($val);
				}
				$flag = $this->notice_obj->up_realtion($this->g_para['uid'] , $temp_arr);
				if($flag['err_code'] == 0){
					$arr = array('result'=>true);
				}else{
					$arr = array('result'=>false);
				}
				$this->run_api_event();
				echo json_encode($arr);
			}    
		}
		//置用户所有未读消息为已读
		if($this->g_para['type'] == 2){
			// 处理消息为已读
			if(!empty($this->g_para['uid'])) {
				$flag = $this->notice_obj->up_relation_batch($this->g_para['uid']);
				if($flag['err_code'] == 0){
					$arr = array('result'=>true);
				}else{
					$arr = array('result'=>false);
				}
				$this->run_api_event();
				echo json_encode($arr);
			}    
		}
		

	}

	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}


}
$exec = new readno();
$exec->run();
?>
