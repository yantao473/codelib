<?php
/**
 * 用户中心
 *
 * @package     register user
 * @author      xianghui@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2012/07/18
 * @date update guoxianghui 2012/09/11
 */

include_once("apiconf.php");

class wapReg extends webApp implements Platform_Api{

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	private $APP;

	public $g_para;
	public $g_result;

	function  __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function _init_param(){
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : "";          
		$this->g_para['ip'] = isset($_REQUEST['ip']) ? long2ip($_REQUEST['ip']) : "";
		//手机用户用3，知识人用户为2，web社区用户为1     
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 3;           
		//微什么项目处理逻辑id
		$this->g_para['syncid'] = isset($_REQUEST['syncid']) ? floatval($_REQUEST['syncid']) : 1;           
	}                                                                                                  

	function _check_param(){

                if($this->g_para['app'] == 2 ){  //知识人项目
                        if($this->g_para['syncid'] == 1){
                                $this->APP = 1; //知识人数据导入微什么项目的情况
                        }
                        else{
                                $this->APP = 2; //知识人                                                   
                        }
                }
                elseif($this->g_para['app'] == 1 && $this->g_para['syncid'] == 1){  //微什么web版本
                        $this->APP = 1;                                                                    
                }                                                                                          
                elseif($this->g_para['app'] == 3 && $this->g_para['syncid'] == 1){ //微什么手机wap版本     
                        $this->APP = 1;                                                                    
                }                                                                                          
                                                                                                           
                //项目应用与同步规则                                                                       
                if(empty($this->APP)) {                                                                    
                        $this->error_num(3003);                                                            
                } 
		
                if(empty($this->g_para['app'])) {
                        $this->error_num(3000);                                                                   
                } 
                                                                           
		// 判断对象id
		if(empty($this->g_para['uid'])){                                                           
			$this->error_num(2101);                                                            
		}                                                                                 
	}                                                                                                  

	function _init_class(){                                                                            
		$this->user_obj = new Login_UserMan();                                                     
		$this->tools_obj= new Tools();                                                             
		$this->weibov4_obj  = new weibov4();                                                       
		$this->bdb_obj = new GetBdb;                                                               
	}   

	function _init_api_config() {
		$this->api_name = 'userregister';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->APP;
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	function main(){

		$this->do_user_reg($callback);

	}

	/**
	 * 更新用户信息
	 * 
	 * @param :
	 * @return : bool
	 */
	function do_user_reg(&$callback)
	{
		$url = DOMAIN . "/u/getuser.php";
		$param = array('uid' =>  $this->g_para['uid']);
		$res= $this->tools_obj->curl_set($url , 'post' , $param , $json);
		$userinfo=json_decode($json , true);

		if(empty($userinfo[$this->g_para['uid']]['uid'])){
			//get user
			$uinfo = $this->weibov4_obj->showuser($this->g_para['uid']);
			$v = json_decode($uinfo,true); 
			if(!empty($v)){
				$temp_uarr['uid'] = $v['id'];
				//手机注册用9  //加了知识人注册就不用此字段标识手机注册，使用app	 
				$temp_uarr['ag'] = 9; 
				$temp_uarr['gender'] = $v['gender']; 
				$login = "u_".$v['id'];
				$temp_uarr['login'] = $login; 
				$temp_uarr['ip'] = $this->g_para['ip']; 
				$temp_uarr['app'] = $this->g_para['app']; 
				$temp_uarr['nick'] = isset($v['screen_name']) ? $v['screen_name'] : $v['name'];
				$temp_uarr['notice_set'] = 15;
				$temp_uarr['ctime'] = date('Y-m-d H:i:s');
			}
			$r_url = DOMAIN . '/u/register.php';
			$this->tools_obj->curl_set($r_url , 'post' , $temp_uarr , $info_json);

			$this->run_api_event();
			if(!empty($info_json)) {
				$info = json_decode($info_json,true);
				if($info['result'] == 'success') {
					echo json_encode(array('result'=>true));
				}
				else {
					echo json_encode(array('result'=>false));
				}
			}

		}else{
			echo json_encode(array('result'=>true));
		}

	}

	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}


}
$exec = new wapReg();
$exec->run();
?>
