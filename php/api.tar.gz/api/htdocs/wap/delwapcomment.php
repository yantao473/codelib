<?php
/**
 * 评论
 *
 * @package     Question
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
 * @update      xianghui@staff.sina.com.cn 20120827
*/
include_once("apiconf.php");

class CommentDel extends webApp implements Platform_Api{

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;
	
	function __construct() 
	{
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();

	}

	function _init_param(){
		$this->g_para['app']	= isset( $_REQUEST['app'] ) ? floatval($_REQUEST['app']) : 1;
		$this->g_para['cid']	= isset( $_REQUEST['cid'] ) ? floatval($_REQUEST['cid']) : "";
		//add type 表类型 1 question ; 2 answer
		$this->g_para['type']	= isset( $_REQUEST['type'] ) ? floatval($_REQUEST['type']): "";
	}

	function _check_param(){
		$para_stat = $this->_check_params_legal();
		if(!$para_stat)
		{
			$this->error_num($this->err_code);
			die();
		}
	}
	
	function _init_class(){
		$this->tools_obj = new Tools();
		$this->user_obj = new Login_UserMan();
		$this->id_obj	= new IdServer();
		$this->comment_obj = new Commentwap($this->g_para,$this->result);

	} 

        /*                                                                                                 
        * 初始化接口功能                                                                                   
        */                                                                                                 
        function _init_api_config() {                                                                      
                $this->api_name = 'delcomment';                                                            
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
                if(empty($this->api_config)) {                                                             
                        $this->error_num(3001);                                                            
                }                                                                                          
        } 	
	function main() 
	{
		$flag = $this->do_platform();
		if(!$flag)
		{
			$this->error_num($this->err_code);
			die();
		}
		$this->run_api_event();
		echo json_encode(array('result'=>'success'));
	}


	/**
	 * 检查参数合法性
	 * 
	 * @param :
	 * @return : bool
	*/
	private function _check_params_legal()
	{
		// 判断评论id
		if(!$this->_check_empty($this->g_para['cid']))
		{
			$this->err_code = 2012;
			return false;
		}
		elseif(!$this->_check_num($this->g_para['cid'])) {
			$this->err_code = 2013;
			return false;
		}
		
		return true;
	}

	/**
	 * 添加评论
	 * 
	 * @param :
	 * @return : bool
	*/
	private function do_platform()
	{
		$acols = array('commentid'=>$this->g_para['cid']);
		if($this->g_para['type'] == 1){
			$table_name = 'question_comment';
		}
		else if($this->g_para['type'] == 2){
			$table_name = 'answer_comment';
		}
		$this->comment_obj->get_comment_detail($table_name,$acols,$cdata);
		$flag = $this->comment_obj->del_comment($table_name,$this->g_para['cid'],$data);
		if(!$flag) 
		{
			$this->err_code = 2303;
			return false;
		}
		$this->send_to_bdb($cdata);
		return true;
	}

	function send_to_bdb($cdata)
	{
		$acols = array(
			0 => EVENT_COMMENT_DEL,
			'commentid' => $this->g_para['cid'],
			'targetid' => $cdata[0]['targetid'],
			'type' => $this->g_para['type'],
			'ctime' => $cdata[0]['ctime'],
		);
		$this->comment_obj->send_bdb($acols , $queue_result);
                if(!$queue_result){
                        $this->error_num(2102);
                }
	}

    private function _check_empty($v) {
	    if(empty($v)) {
	        return false;
        }
        else{
	        return true;
        }
    }

    private function _check_num($v) {
	    if(!preg_match('~^[0-9]+$~is',$v)) {
	        return false;
        }
        else {
	        return true;
        }
    }

        /*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$app = new CommentDel();
$app->run();
?>
