<?php
/**
 * 垃圾过滤
 * $_POST["data"]=json_encode(array(
			"num"=>1,
			"content"=>array(
							array(
								"qid"=>"",
								"ques"=>$ques,
								"aid"=>"",
								"ans"=>"",
								"desc"=>$desc
							)
							.................
						)
		));
 */
	if(empty($_POST["data"])){
		$json_array = array('error_num'=>-1);
		$json_array['error'] = "参数为空";
		echo json_encode($json_array);
		exit;
	}
	$data=$_POST["data"];
	$url="http://10.210.128.131/WhatFilter/filter.php?charset=utf8";
		
	$mCurl = curl_init();
	curl_setopt($mCurl,CURLOPT_POST,1);
	curl_setopt($mCurl, CURLOPT_POSTFIELDS, $data);
	
	curl_setopt($mCurl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($mCurl, CURLOPT_URL,$url);
	curl_setopt($mCurl,CURLOPT_TIMEOUT,5);	
	
	$result = curl_exec($mCurl);	
	
	if(curl_errno($mCurl)){
		curl_close($mCurl);
		$json_array = array('error_num'=>-2);
		$json_array['error'] = "curl失败";
		echo json_encode($json_array);
		exit;
	}
	curl_close($mCurl);
	$json_array = array('result'=>true);
	$json_array['data'] = $result;
	echo json_encode($json_array);
	exit;
?>