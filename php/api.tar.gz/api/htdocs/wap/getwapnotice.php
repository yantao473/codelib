<?php
/**
 * @fn              获取问题通知
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-09-04
 */

include_once("apiconf.php");

class getNotice extends webApp implements Platform_Api{

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}
	function _init_param(){
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : "";
		$this->g_para['start'] = isset($_REQUEST['start']) ? floatval($_REQUEST['start']) : 0;
		$this->g_para['num'] = isset($_REQUEST['num']) ? floatval($_REQUEST['num']) : 5;
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;
	}

	function _check_param(){
		if(empty($this->g_para['uid'])){
			$this->error_num(2101);		
		}
	}

	function _init_class(){
		$this->user_obj = new Login_UserMan();
		$this->tools_obj= new Tools();                                                             
		$this->notice_obj  = new Notice();
		$this->weibov4_obj  = new weibov4();
		$this->bdb_obj = new GetBdb;
	}

	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = 'wapnotice';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	function main(){
		$this->get_notice();
	}

	function get_notice(){
		//num
		$unnum = $this->notice_obj->get_notice_count_unread($this->g_para['uid']);
		$unread_num = $unnum['result']['num'] > 0 ? $unnum['result']['num']:0;

		$unread_notice_info = $this->notice_obj->get_notice_list_zip($this->g_para['uid']);
		if($unread_notice_info['err_code'] == 18){
			$unread_num = 0;
		}		
		$nlist = array();
		if($unread_num > 0 ){
			//print_r($unread_notice_info['result']);
			if(!empty($unread_notice_info['result'])){
				foreach($unread_notice_info['result'] as $ks => $vs){
					if($ks == 'question'){
						foreach($vs as $q => $qva){
							$unread_notice_info['result']['question'][$q]['questionid'] = $q;
							$time_question[$q] = $qva['ctime'];
						}

					}                                                                          
				}                                                                                  
				if(!empty($unread_notice_info['result']['question'])){                             
					array_multisort($time_question,SORT_DESC,$unread_notice_info['result']['question']);
				}                                                                                  
			}   
			$o = 0;
			$allflagnum = count($unread_notice_info['result']);
			if(isset($unread_notice_info['result']['question'])){
				$allq_num = count($unread_notice_info['result']['question']);
			}else{
				$allq_num = 0 ;
			}
			if(isset($unread_notice_info['result']['vote'])){
				$all_vote_num = 1;
			}else{
				$all_vote_num = 0;
			}
			//print_r($unread_notice_info['result']['question']);
			foreach($unread_notice_info['result'] as $key => $val){                            
				if($key == 'vote'){                                                        
					$nlist['vote']['num'] = $val['num'] ? $val['num'] : 0;             
					//$nlist['vote']['ctime'] = $val['ctime'] ? $val['ctime'] : date("Y-m-d H:i:s"); 
					if($val['num'] == 1){                                              
						//查询nick title
						$this->get_user( $val['desc'][0]['uid'],$cdata);
						$nlist['vote']['desc'][0]['nick'] = $cdata[ $val['desc'][0]['uid']]['nick'];
						//$uids_arr[] = $val['desc'][0]['uid'];                    
						$nlist['vote']['desc'][0]['uid'] = $val['desc'][0]['uid']; 
						$nlist['vote']['desc'][0]['queid'] = $val['desc'][0]['qid'];
						//getquestion                                              
						$qids = $val['desc'][0]['qid'];
						$result = $this->bdb_obj->gets("detail" , $qids , $data); 
						$nlist['vote']['desc'][0]['qid'] = $val['desc'][0]['qid'] + 1;
						$nlist['vote']['desc'][0]['mid'] = $val['desc'][0]['mid']; 
						$nlist['vote']['desc'][0]['ctime'] = $val['desc'][0]['ctime']; 
						// 需要获取title的qid                                      

						$len_title = $this->tools_obj->mb_stringlen($data['title']);
						$nlist['vote']['desc'][0]['title'] = $data['title'];  
					}else{                                                             
						$vote_midarr = array();                                    
						foreach($val['desc'] as $voteval){                         
							$vote_midarr[] = $voteval['mid'];                  
						}                                                          
						$str_vote = @implode(",",$vote_midarr);                    
						$nlist['vote']['desc'][0]['mid'] = $str_vote;              
						$nlist['vote']['desc'][0]['uid'] = $uid;                   
						$nlist['vote']['desc'][0]['qid'] = $val['desc'][0]['qid']+1;
						$nlist['vote']['desc'][0]['queid'] = $val['desc'][0]['qid'];
						$nlist['vote']['desc'][0]['ctime'] = $val['desc'][0]['ctime'];
					}                                                                  

				}
				//问题总数
				if($key == 'question'){                                                    
					if(!empty($unread_notice_info['result']['vote']['num'])){          
						$get_num = $this->g_para['num'] ;                                              						     $i = 1 ;                                                   
					}                                                                  
					else{                                                              
						$get_num = $this->g_para['num'] ;
						$i = 1 ;                                                   
					}
					$i = $this->g_para['start']* $this->g_para['num'] ;
					$end = $this->g_para['start']*$this->g_para['num'] + $this->g_para['num']; 
					$uids_arr = array();                                               
					if(!empty($val)){
						foreach($val as  $k=>$qval ){  
							$g = $k;
							if($g < $i){
								continue;
							}
							//echo $g;
							$k = $qval['questionid'];                                          
							//print_r($qval);  
							if(!empty($k)){  
								$q_num = 0;                                                
								if(!empty($qval['answer']) && $qval['answer']['flag'] == 'answer'){
									$q_num += $qval['answer']['num'];                  
									$qflag = 'answer';                                 
								}                                                          
								if(!empty($qval['comment'])){                              
									$q_num += $qval['comment']['num'];                 
									$qflag = 'coment';                                 

								}                                                          
								if(!empty($qval['invite'])){                               
									$q_num += $qval['invite']['num'];                       
									$qflag = 'invite';                                 
								}                                                          
								if(!empty($qval['adopt'])){                                
									$q_num += 1;                                       
									$qflag = 'adopt';                                  
								}             
								foreach($qval  as  $ko=>$qvalue ){                                 
									$mid_arr = array();                                        
									$mid_arr2 = array();                                       
									$mid_arr3 = array();                                       
									$mid_arr4 = array();                                       
									$mid_arr5 = array();                                       
									$mid_arr6 = array();                                       
									if($ko == 'ctime' || $ko == 'questionid'){
										continue;                                          
									}                                                          
									if( $qvalue['flag'] == 'answer'){                          
										foreach($qvalue['desc'] as $ak=>$aval){            
											$nlist['question']['desc'][$k]['num']  = $qvalue['num']; 
											$nlist['question']['desc'][$k]['flag']  = 'answer';
											$nlist['question']['desc'][$k]['qid']  = $qid;
											$nlist['question']['desc'][$k]['aid'] = $aval['aid'];    
											$nlist['question']['desc'][$k]['mid'] = $aval['mid'];  
											$nlist['question']['desc'][$k]['ctime'] = $aval['ctime'];  
											$uids_arr[$k][] = $aval['uid'];            
											$nlist['question']['desc'][$k]['uid'] = $aval['uid'];    
											$nlist['question']['desc'][$k]['owner'] = $aval['owner'];

											$mid_arr[] = $aval['mid'];                 
										}                                                  
									}                                                          
									//print_r($nlist);                                                                                         
									if($ko == 'comment'){                                              
										//$nlist['comment']['num']  = $qvalue['comment']['num'];   
										//问题评论                                                 
										if(isset($qvalue['desc']['question']) && !empty($qvalue['desc']['question'])){
											foreach($qvalue['desc']['question'] as $cqk=>$cqv){
												$nlist['question']['desc'][$k]['num']  = count($qvalue['desc']['question']);
												$nlist['question']['desc'][$k]['flag']  = 'cq';
												$uids_arr[$k][] = $cqv['uid'];             
												$nlist['question']['desc'][$k]['uid'] = $cqv['uid'];     
												$nlist['question']['desc'][$k]['mid'] = $cqv['mid'];     
												$nlist['question']['desc'][$k]['ctime'] = $cqv['ctime'];     
												//$mid_arr[] = $cqv['mid'];                
												$mid_arr2[] = $cqv['mid'];                 
											}
										}
										//me评论                                                   
										if(isset($qvalue['desc']['me']) && !empty($qvalue['desc']['me'])){
											foreach($qvalue['desc']['me'] as $cqk=>$cqv){      
												$nlist['question']['desc'][$k]['num']  = count($qvalue['desc']['me']);
												$nlist['question']['desc'][$k]['flag']  = 'cm';
												$uids_arr[$k][] = $cqv['uid'];             
												$nlist['question']['desc'][$k]['uid'] = $cqv['uid'];     
												$nlist['question']['desc'][$k]['auid'] = $cqv['auid'];
												$nlist['question']['desc'][$k]['aid'] = $cqv['answerid'];
												$nlist['question']['desc'][$k]['mid'] = $cqv['mid'];     
												$nlist['question']['desc'][$k]['qid'] = $qid;
												$mid_arr3[] = $cqv['mid'];                 
											}                                                  
										} 
										//其他评论
										if(isset($qvalue['desc']['other']) && !empty($qvalue['desc']['other'])){ 
											foreach($qvalue['desc']['other'] as $kea=>$cqv){  
												$uids_arr[$k][] = $cqv['uid'];     
												$nlist['question']['desc'][$k]['flag'] = 'co';   
												$nlist['question']['desc'][$k]['uid'] =$cqv['uid'];
												$nlist['question']['desc'][$k]['auid'] =$cqv['auid'];
												$nlist['question']['desc'][$k]['aid'] = $cqv['answerid'];
												$nlist['question']['desc'][$k]['mid'] = $cqv['mid'];
												$nlist['question']['desc'][$k]['ctime'] = $cqv['ctime'];
												$nlist['question']['desc'][$k]['qid'] = $qid;    
												$mid_arr4[] = $cqv['mid'];  
											}                                                  

										}                                                          

									} 
									if( $ko == 'invite'){                                              
										foreach($qvalue['desc'] as $ak=>$aval){                    
											$nlist['question']['desc'][$k]['mid'] = $aval['mid'];
											$nlist['question']['desc'][$k]['ctime'] = $aval['ctime'];
											$nlist['question']['desc'][$k]['num'] = $qvalue['invite']['num'];
											$nlist['question']['desc'][$k]['flag'] = 'invite'; 
											$uids_arr[$k][] = $aval['inviter'];                
											$nlist['question']['desc'][$k]['uid'] = $aval['inviter'];
											$nlist['question']['desc'][$k]['qid'] = $qid;
											$mid_arr5[] = $aval['mid'];                        

										}                                                          
									}  

									if( $ko == 'adopt'){
										$nlist['question']['desc'][$k]['aid'] = $qvalue['desc']['aid'];
										$nlist['question']['desc'][$k]['flag'] = 'adopt';
										$nlist['question']['desc'][$k]['mid'] = $qvalue['desc']['mid'];
										$nlist['question']['desc'][$k]['ctime'] = $qvalue['desc']['ctime'];
										$uids_arr[$k][] = $qvalue['desc']['uid'];       
										$nlist['question']['desc'][$k]['uid'] = $qvalue['desc']['uid'];
										$nlist['question']['desc'][$k]['qid'] = $qvalue['desc']['qid'];
										$mid_arr6[] = $qvalue['desc']['mid'];      
									} 

									$arr_m = array();                                          
									$arr_m = array_merge($mid_arr,$mid_arr2,$mid_arr3,$mid_arr4,$mid_arr5,$mid_arr6);                                                                                                       

									$nlist['question']['desc'][$k]['qid'] = $k;                
									$nlist['question']['desc'][$k]['marr'][] = $arr_m;         

								} 
								$nlist['question']['desc'][$k]['num'] = $q_num;    
								$nlist['question']['desc'][$k]['qid'] = $k;        


								$arr_qids[$i] = $qval['questionid'];                       

								$i++;
								if($i >= $end){                                         
									break;                                             
								}                                                          
							}                                                          
						}
					} 
					//nick
					$ids_arr = array();                                                
					foreach($uids_arr as $u=>$o){                                      
						if(!empty($o)){                                            
							foreach($o as $vo){                                
								if(!empty($vo)){                           
									$ids_arr[] = $vo;                  
									//$uid_qid[$o] = $u;
								}                                          
							}                                                  
						}                                                          
					}
					$this->get_user($ids_arr,$arr_data);   

					if(!empty($nlist['question']['desc'])){
						foreach($nlist['question']['desc'] as $nk=>$nv){                   
							if(!empty($nv['uid'])){                                    
								if($this->g_para['uid'] == $nv['uid']){                            

									$nlist['question']['desc'][$nk]['nick'] = "你";
								}else{                                             
									$nlist['question']['desc'][$nk]['nick'] = $arr_data[$nv['uid']]['nick'];
								}                                                  
								$nlist['question']['desc'][$nk]['uid'] = $nv['uid'];
							}         

							else{                                                      
								$nlist['question']['desc'][$nk]['nick'] = "你";    

							}                                                          

						}                                                                  
					}
					if(!empty($arr_qids)){
						foreach($arr_qids as $qk=>$qv){
							$tmpq[] = $qv;
						}
						$result = $this->bdb_obj->gets("question",$tmpq,$data);
						foreach($arr_qids as $k=>$v){                                    
							if(empty($v)){                                                             							continue;
							}
							$get_info[$v] = $data[$v];                                                 
						}                                                                                  
						if(!empty($get_info)){                                                                     
							$get_temp_info = array();                                                          
							foreach($get_info as $k => $item){                                                 
								if(!empty($item['title'])){                                                
									$get_temp_info[$k] = $item;                                        
								}                                                                          
							}                                                                                  
						} 


						$data = $get_temp_info;                               
						foreach($arr_qids as $ik=>$kvalue){                                
							$len_title = $this->tools_obj->mb_stringlen($data["$kvalue"]['title']);  
							$nlist['question']['desc'][$kvalue]['title'] = $data["$kvalue"]['title'];
							/*                                                         
														   if($len_title > 18){
														   $nlist['question']['desc'][$kvalue]['title'] = $this->tools_obj->htmlSubString($data["$kvalue"]['title'],18);
														   }                                                          
							 */                                                         
							$nlist['question']['desc'][$kvalue]['qid'] = $kvalue;
						}                                                                  
					}

				}                                                                          
				$o++;        
			}                                                                                  
		}                                                                                          
		//print_r($nlist['question']['desc']);                                                     
		$mid_arr = array();                                                                        
		if(!empty($nlist['question']['desc'])){                                                    
			foreach($nlist['question']['desc'] as $kqid=>$value){                              
				if(!empty($value['marr'])){                                                
					foreach($value['marr'] as $val){                                   
						if(!empty($val)){                                          
							foreach($val as $mmid){                            
								$nlist['question']['desc'][$kqid]['mid_arr'][] = $mmid;  
							}                                                  
						}                                                          
					}                                                                  
				}                                                                          
				$nlist['question']['desc'][$kqid]['midarr'] = @implode(",",$nlist['question']['desc'][$kqid]['mid_arr']);
			}                                                                                  
		}                          


		$nlist['unread_total'] = $unread_num;
		$nlist['qnum']  = $allq_num;
		$nlist['vnum'] = $all_vote_num;
		//print_r($nlist);exit;
		if(!empty($nlist)){
			$this->run_api_event();
			echo json_encode($nlist);
		}else{
			$this->error_num(2135);
		}
	}

	function get_user($uids ,&$info) {
		$v4_ulist = array();
		$flag = $this->user_obj->get_user_detail_bdb($uids,$data);
		//	print_r($data);
		if(!$flag)
		{
			$this->err_code = 2201;
			return false;
		}
		if(!empty($data))
		{
			 if(!isset($data['uid'])){
			foreach($data as $uid => $uinfo)
			{
				if($uid != 'total') {
					//$data[$uid]['nick'] = urlencode($uinfo['nick']);
					$data[$uid]['nick'] = $uinfo['nick'];
					$data[$uid]['description'] = $uinfo['description'];
					//$data[$uid]['description'] = urlencode($uinfo['description']);
				}
			}                         
                        }else{
					$tmp_arr[$data['uid']] = $data;
					unset($data);
					$data = $tmp_arr;
                                        //$data[$data['uid']]['nick'] = $data['nick'];                             
                                        //$data[$data['uid']]['description'] = $data['description'];               
                                                                                                           
                        }                                                          
		}
		if(!empty($data)) {
				$info_array = $data;
			if(!empty($info_array) && empty($info_array['err_code']))
			{
				$uid_arr = $uids;
				$v4_uinfo = $this->weibov4_obj->showusers($uid_arr);
				$v4_uinfo = json_decode($v4_uinfo,true);                                   
				if(!empty($v4_uinfo['users'])) {                                           
					foreach($v4_uinfo['users'] as $v4info) {                           
						$v4_ulist["{$v4info['id']}"] = $v4info;                    
					}                                                                  
				}                                                                          
				foreach($info_array as $uid => $uinfo) {  
					if(!is_array($uinfo) || empty($uinfo['uid'])) {                 // 表示用户不存在
						continue;                                                  
					}                                                                  
					$info["$uid"] = $uinfo;                                            
					$info["$uid"]['uid'] = $uid;                                       
					//$info["$uid"]['description'] = urldecode($uinfo['description']); 
					$info["$uid"]['description'] = htmlspecialchars($uinfo['description']);
					$info["$uid"]['nick_local'] = urldecode($uinfo['nick']);           
					// 微博用自己的头像图片 不用平台的头像图片                         
					$info["$uid"]['picture_ua'] = '';                                  
					$info["$uid"]['picture_ub'] = '';                                  
					$info["$uid"]['picture_uc'] = '';                                  

					// 调微博接口 取数据                                               
					if(!empty($v4_ulist["$uid"]['error_code']) || empty($v4_uinfo['users']) ) {      
						$info["$uid"]['user_isvalid'] = false;                     
					}                                                                  
					else {                                                             
						$info["$uid"]['user_isvalid'] = true;                      
					}                                                                  
					$info["$uid"]["yellowv"] =  false;                                 
					$info["$uid"]["bluev"] =  false;                                   
					if($v4_ulist["$uid"]['verified'] ){   
						if($v4_ulist["$uid"]['verified_type'] == 0){               
							$info["$uid"]["yellowv"] =  true;                  
						}
						if(preg_match("~^[1-7]$~is",$v4_ulist["$uid"]['verified_type'])){
							$info["$uid"]["bluev"] =  true;                    
						}                                                          

					} 
					$info["$uid"]['gender'] = $v4_ulist["$uid"]['gender']; 
					$info["$uid"]['description'] = empty($info["$uid"]['description']) ? htmlspecialchars($v4_ulist["$uid"]['verified_reason']) : $info["$uid"]['description'];
					$info["$uid"]['nick'] = !empty($v4_ulist["$uid"]['screen_name']) ? $v4_ulist["$uid"]['screen_name'] : $data["$uid"]['nick'] ;          
					$info["$uid"]['picture_ua'] = $v4_ulist["$uid"]['profile_image_url'];
					$info["$uid"]['picture_uc'] = $v4_ulist["$uid"]['avatar_large'];   
				}                                                                          
				return true;                                                               
			}                                                                                  
			else {                                                                             
				$info = $info_array;                                                       
			}                           
		}                                                                                          
		return false;                                                                              
	} 





	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);                          
		if(!empty($cmd)) {                                                                         
			if(eval($cmd) === FALSE) {                                                         
				$this->error_num(3002);                                                    
			}                                                                                  
		}                                                                                          
	}   

}
$exec = new getNotice();
$exec->run();
?>
