<?php
/**
 * 用户中心
 *
 * @package     User
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
*/
include_once("apiconf.php");

class UserDetail extends webApp
{
	private $err_code;
	private $err_msg;
	private $g_error_app;
	private $tools_obj;
	
	public function __construct() 
	{
		global $g_error_app;
		$this->g_error_app = $g_error_app;
		$this->tools_obj = new Tools();
		$this->user_obj = new Login_UserMan();
	}
	
	public function main() 
	{
		$this->_check_params();
		$para_stat = $this->_check_params_legal();
		if(!$para_stat)
		{
			$this->error_num($this->err_code);
			die();
		}
		$flag = $this->do_platform($callback);
		if(!$flag)
		{
			$this->error_num($this->err_code);
			die();
		}
		echo $callback;
	}

	/**
	 * 获取参数
	 * 
	 * @param :
	 * @return :
	*/
	private function _check_params()
	{
		$this->g_para['uid']	= $_REQUEST['uid'];
	}

	/**
	 * 检查参数合法性
	 * 
	 * @param :
	 * @return : bool
	*/
	private function _check_params_legal()
	{
	    // 判断对象id
        if(!$this->_check_empty($this->g_para['uid']))
        {
			$this->err_code = 2001;
			return false;
        }
		return true;
	}

	/**
	 * 更新用户信息
	 * 
	 * @param :
	 * @return : bool
	*/
	private function do_platform(&$callback)
	{
		$uid_tmp = explode(',',$this->g_para['uid']);
		$flag = $this->user_obj->get_user_detail_bdb($uid_tmp,$data);
		unset($data['total']);
		if(!$flag) 
		{
			$this->err_code = 2201;
			return false;
		}
		if(!empty($data))
		{
			foreach($data as $uid => $uinfo)
			{
				if($uid != 'total') {
					$data[$uid]['nick'] = urlencode($uinfo['nick']);
					$data[$uid]['description'] = urlencode($uinfo['description']);
				}
			}
		}
		$callback = json_encode($data);
		return true;
	}

     private function _check_empty($v) {
         if(empty($v)) {
            return false;
         }
         else{
             return true;
         }
     }
 
      private function _check_num($v) {
         if(!preg_match('~^[0-9]+$~is',$v)) {
              return false;
         }
         else {
             return true;
        }
      }
}
$app = new UserDetail();
$app->run();
?>
