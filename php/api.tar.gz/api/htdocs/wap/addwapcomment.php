<?php
/**
 * @fn              添加评论接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2
 * @link            /q/addcomment.php
 * @date            2012-06-07
 */

include_once ("apiconf.php");
class AddComment extends webApp implements Platform_Api {
	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;
	function __construct() {
		$this->_init_param ();
		$this->_check_param ();
		$this->_init_class ();
		$this->_init_api_config ();
	}
	
	/**
	 * 获取参数
	 */
	function _init_param() {
		$this->g_para ['app'] = isset ( $_REQUEST ['app'] ) ? floatval ( $_REQUEST ['app'] ) : '';
		$this->g_para ['uid'] = isset ( $_REQUEST ['uid'] ) ? floatval ( $_REQUEST ['uid'] ) : '';
		$this->g_para ['oid'] = isset ( $_REQUEST ['oid'] ) ? floatval ( $_REQUEST ['oid'] ) : '';
		$this->g_para ['type'] = isset ( $_REQUEST ['type'] ) ? floatval ( $_REQUEST ['type'] ) : '';
		$this->g_para ['ctime'] = isset ( $_REQUEST ['ctime'] ) ? trim ( $_REQUEST ['ctime'] ) : date ( 'Y-m-d H:i:s' );
		$this->g_para ['qid'] = isset ( $_REQUEST ['qid'] ) ? floatval ( $_REQUEST ['qid'] ) : '';
		$this->g_para ['comment'] = isset ( $_REQUEST ['comment'] ) ? trim ( $_REQUEST ['comment'] ) : '';
		// zhishi
		$this->g_para ['commentid'] = isset ( $_REQUEST ['commentid'] ) ? floatval ( $_REQUEST ['commentid'] ) : '';
	}
	
	/**
	 * 判断参数合法性
	 */
	function _check_param() {
		if (empty ( $this->g_para ['app'] )) {
			$this->error_num ( 3000 );
		}
		
		// 判断用户id
		if (empty ( $this->g_para ['uid'] )) {
			$this->error_num ( 2001 );
		}
		
		// 判断对象id
		if (empty ( $this->g_para ['oid'] )) {
			$this->error_num ( 2003 );
		}
		
		// 判断类型id
		if (empty ( $this->g_para ['type'] )) {
			$this->error_num ( 2007 );
		}
		
		// 判断评论内容
		if ($this->g_para ['comment'] == '') {
			$this->error_num ( 2009 );
		}
		
		if ($this->g_para ['app'] == ZHISHI_APP_ID) {
			if (empty ( $this->g_para ['commentid'] )) {
				$this->error_num ( 2012 );
			}
		}
	}
	
	/**
	 * 初始化对象
	 */
	function _init_class() {
		
		// 微什么要从发号器获取id
		if ($this->g_para ['app'] == API_APP_ID || $this->g_para ['app'] == WAP_APP_ID) {
			$this->generate_server_id = new IdServer ();
			if ($this->g_para ['type'] == 1) { // question
				$this->g_para ['commentid'] = $this->generate_server_id->get ( "question_comment" );
			} elseif ($this->g_para ['type'] == 2) { // answer
				$this->g_para ['commentid'] = $this->generate_server_id->get ( "answer_comment" );
			}
		}
		
		$this->tools_obj = new Tools ();
		$this->api_obj = new Comment ( $this->g_para, $this->g_result );
	}
	
	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = 'addcomment';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para ['app'];
		$this->api_config = $this->tools_obj->loadApiConfig ( $this->api_config_file );
		if (empty ( $this->api_config )) {
			$this->error_num ( 3001 );
		}
	}
	public function main() {
		$this->add_comment ();
	}
	
	/**
	 * 添加评论
	 *
	 * @param
	 *        	:
	 * @return : bool
	 */
	private function add_comment() {
		
		// 针对知识人 和 微问答 处理个性参数
		if ($this->g_para ['app'] == API_APP_ID || $this->g_para ['app'] == WAP_APP_ID) {
			// 处理其他参数
			$other_param_arr = array (
					'questionid' => $this->g_para ['qid'] 
			);
			$data_append_str = serialize ( $other_param_arr );
		} elseif ($this->g_para ['app'] == ZHISHI_APP_ID) {
			$data_append_str = '';
		}
		
		$this->g_para ['comment'] = $this->tools_obj->deal_text ( $this->g_para ['comment'], 1 );
		// 入mysql
		$arr = array (
				'commentid' => $this->g_para ['commentid'],
				'appid' => $this->g_para ['app'],
				'targetid' => $this->g_para ['oid'],
				'ctime' => $this->g_para ['ctime'],
				'uid' => $this->g_para ['uid'],
				'data_append' => $data_append_str,
				'comment' => $this->g_para ['comment'] 
		);
		$this->api_obj->send_mysql ( $arr, $rpcdb_result );
		if (! $rpcdb_result) {
			$this->error_num ( 2102 );
		}
		
		// 发送BDB
		$arr = array (
				'0' => EVENT_COMMENT_ADD,
				'commentid' => $this->g_para ['commentid'],
				'appid' => $this->g_para ['app'],
				'type' => $this->g_para ['type'], // 特殊字段
				                                                                                                                                                        // BDB
				                                                                                                                                                        // 加
				'targetid' => $this->g_para ['oid'],
				'ctime' => $this->g_para ['ctime'],
				'uid' => $this->g_para ['uid'],
				'data_append' => $data_append_str,
				'comment' => $this->g_para ['comment'] 
		);
		$this->api_obj->send_bdb ( $arr, $queue_result );
		if (! $queue_result) {
			$this->error_num ( 2102 );
		}
		
		// 执行订制功能
		$this->run_api_event ();
		
		echo json_encode ( array (
				'result' => 'success',
				'insertid' => $this->g_para ['commentid'] 
		) );
	}
	
	/*
	 * 调用接口功能订制列表
	 */
	function run_api_event() {
		$cmd = @implode ( '', $this->api_config [$this->api_name] ['func'] );
		if (! empty ( $cmd )) {
			if (eval ( $cmd ) === FALSE) {
				$this->error_num ( 3002 );
			}
		}
	}
}
$app = new AddComment ();
$app->run ();
?>
