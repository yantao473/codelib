<?php
/**
 * @fn              添加问题接口
 * @author          zhanghua2@staff.sina.com.cn & xianghui@staff.sina.com.cn
 * @version         v2
 * @date            2012-06-07
 */

include_once("apiconf.php");

class addQuestion extends webApp implements Platform_Api{

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	private $APP;

	function  __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		$this->g_para['uid']		= isset($_REQUEST['uid'])	? floatval($_REQUEST['uid'])	: "";
		$this->g_para['app']		= isset($_REQUEST['app'])	? floatval($_REQUEST['app'])	: 3;
		$this->g_para['owner']		= isset($_REQUEST['owner'])	? floatval($_REQUEST['owner']) 	: 0;	//0正常，1匿名提问，2团队提问
		$this->g_para['showflag']	= isset($_REQUEST['showflag'])	? floatval($_REQUEST['showflag']) : 0;	//0显示，1隐藏
		$this->g_para['touid']		= isset($_REQUEST['touid'])	? floatval($_REQUEST['touid'])	: 0;
		$this->g_para['title']		= isset($_REQUEST['title'])	? trim($_REQUEST['title']) 	: "";
		$this->g_para['desc']		= isset($_REQUEST['desc'])	? trim($_REQUEST['desc']) 	: "";
		$this->g_para['tag']		= isset($_REQUEST['tag'])	? $_REQUEST['tag'] 		: "";
		$this->g_para['time']		= isset($_REQUEST['ctime'])	? $_REQUEST['ctime'] 		: date("Y-m-d H:i:s");
		// zhishi
		$this->g_para['limitday']	= isset($_REQUEST['limitday'])	? intval($_REQUEST['limitday']) : 0;
		$this->g_para['price']		= isset($_REQUEST['price'])	? intval($_REQUEST['price'])	: 0;
		$this->g_para['degree']		= isset($_REQUEST['degree'])	? intval($_REQUEST['degree'])	: 0;
		$this->g_para['classid']	= isset($_REQUEST['classid'])	? intval($_REQUEST['classid'])	: 0;
		$this->g_para['status']		= isset($_REQUEST['status'])	? trim($_REQUEST['status'])	: '';
		$this->g_para['nick']		= isset($_REQUEST['nick'])	? trim($_REQUEST['nick'])	: '';
		$this->g_para['ip']		= isset($_REQUEST['ip'])	? trim($_REQUEST['ip'])		: '';
		$this->g_para['comments']	= isset($_REQUEST['comments'])	? trim($_REQUEST['comments'])	: '';
		$this->g_para['path']		= isset($_REQUEST['path'])	? trim($_REQUEST['path'])	: '';
		$this->g_para['filename']	= isset($_REQUEST['filename'])	? trim($_REQUEST['filename'])	: '';
		$this->g_para['questionid']	= isset($_REQUEST['questionid'])? trim($_REQUEST['questionid'])	: '';
		//add share wb 
		$this->g_para['sharewb']	= isset($_REQUEST['sharewb'])? floatval($_REQUEST['sharewb'])	: 1;
		$this->g_para['cookie']	= isset($_REQUEST['ck'])? $_REQUEST['ck']:"";
		
		//微博接口OAuth2.0方式调用
		$this->g_para['token']  = isset($_REQUEST['token'])? trim($_REQUEST['token'])	: "";

		//手机接口暂时强制改3
		$this->g_para['app'] =3;
		//微什么项目处理逻辑标识
                $this->g_para['syncid']         = isset($_REQUEST['syncid'])    ? floatval($_REQUEST['syncid']) : 1;     
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {
	
                if($this->g_para['app'] == 2 ){  //知识人项目
                        if($this->g_para['syncid'] == 1){                                                  
                                $this->APP = 1; //知识人数据导入微什么项目的情况
                        }                                                                                  
                        else{                                                                              
                                $this->APP = 2; //知识人                                                   
                        }                                                                                  
                }                                                                                          
                elseif($this->g_para['app'] == 1 && $this->g_para['syncid'] == 1){  //微什么web版本        
                        $this->APP = 1;                                                                    
                }                                                                                          
                elseif($this->g_para['app'] == 3 && $this->g_para['syncid'] == 1){ //微什么手机wap版本     
                        $this->APP = 1;                                                                    
                }                                                                                          
                                                                                                           
                //项目应用与同步规则                                                                       
                if(empty($this->APP)) {                                                                    
                        $this->error_num(3003);                                                            
                }

	
		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}

		if(empty($this->g_para['uid'])) {
			$this->error_num(2101);
		}

		if(empty($this->g_para['title'])) {
			$this->error_num(2103);		
		}

		if($this->g_para['app'] == ZHISHI_APP_ID) {
			if(empty($this->g_para['questionid'])) {
				$this->error_num(2136);
			}
		}
	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {
	
		// 微什么要从发号器获取id	
		//if($this->g_para['app'] == API_APP_ID) {
			$this->generate_server_id = new IdServer();
			$this->g_para['questionid'] = $this->generate_server_id->get("question");
		//}

		$this->tools_obj= new Tools();
		$this->api_obj = new Question($this->g_para , $this->g_result);
	}

	/*
	* 初始化接口功能
	*/
	function _init_api_config() {
		$this->api_name = 'addquestion';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->APP;
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	/**
	 * 主函数
	 **/
	function main() {
		
		$this->add_question();
	}

	/**
	 * 处理添加问题及其日志逻辑
	 **/
	function add_question() {
		//share wb  20120725 guoxianghui
		if($this->g_para['sharewb']  == 1){
			//set cookie
			$cookie_str = $this->tools_obj->del_pwd($this->g_para['cookie']);
                                if(!empty($cookie_str)) {
                                        $preg = '~^Set-Cookie: SUE=(.*?)Set-Cookie: SUP=(.*?)$~is';
                                        if(preg_match($preg , $cookie_str , $aCookieinfo)) {
                                                $SUE_str = $aCookieinfo[1];
                                                $SUP_str = $aCookieinfo[2];
                                                $SUE = preg_replace('~;path=.*?$~is' , '' , $SUE_str);
                                                $SUP = preg_replace('~;path=.*?$~is' , '' , $SUP_str);
                                                $_COOKIE['SUE'] = $SUE;
                                                $_COOKIE['SUP'] = $SUP;
                                                setcookie('SUE' , trim($SUE) ,  0 , '/' , '.weibo.com');
                                                setcookie('SUP' , trim($SUP) ,  0 , '/' , '.weibo.com');

                                        }
                                }
		

			$res_share = $this->api_obj->send_to_weibo(1);
		}

			
		// 针对知识人 和 微问答 处理个性参数
		if($this->g_para['app'] == 3) {
			// 处理话题
                	if(!empty($this->g_para['tag'])) {
                	        $tags_array = $this->api_obj->deal_add_tags();
                	}
			else {
				$tags_array = array();
			}
			$other_param_arr = array(
					'syncid' => API_APP_ID,
			);
			$data_append_json = json_encode($other_param_arr);
		}
		elseif( $this->g_para['app'] == ZHISHI_APP_ID) {
			// 处理标签
			if(!empty($this->g_para['tag'])) {
				$tags_array = explode(' ' , $this->g_para['tag']);
			}
			else {
				$tags_array = array();
			}
			// 处理其他参数
			$other_param_arr = array(
				'limitday'	=> $this->g_para['limitday'],
				'price'		=> $this->g_para['price'],
				'degree'	=> $this->g_para['degree'],
				'status'	=> $this->g_para['status'],
				'nick'		=> $this->g_para['nick'],
				'ip'		=> $this->g_para['ip'],
				'comments'	=> $this->g_para['comments'],
				'path'		=> $this->g_para['path'],
				'filename'	=> $this->g_para['filename'],
				'syncid'	=> ZHISHI_APP_ID,
			);
			$data_append_json = json_encode($other_param_arr);
		}

		$this->g_para['title'] = $this->tools_obj->deal_text($this->g_para['title'],1);
		$this->g_para['desc'] = $this->tools_obj->deal_text($this->g_para['desc'],2);
		// 入mysql
		$arr = array (
			'appid'		=> $this->g_para['app'],
                        'title'		=> $this->g_para['title'],
                        'tags'		=> $this->g_para['tag'],
                        'description'	=> $this->g_para['desc'],
                        'uid'		=> $this->g_para['uid'],
                        'ctime'		=> $this->g_para['time'],
                        'showflag'	=> $this->g_para['showflag'],
                        'owner'		=> $this->g_para['owner'],
                        'touid'		=> $this->g_para['touid'],
                        'questionid'	=> $this->g_para['questionid'],
			'classid'	=> $this->g_para['classid'],
			'data_append'	=> $data_append_json,
                );
		$this->api_obj->send_mysql($arr , $rpcdb_result);
		if(!$rpcdb_result){
			$this->error_num(2102);
		}
		
		//发送BDB
		$arr = array(
			'0'		=> EVENT_QUESTION_ADD,
                        'questionid'	=> $this->g_para['questionid'],
                        'appid'		=> $this->g_para['app'],
                        'title'		=> $this->g_para['title'],
                        'tags'		=> $tags_array,
                        'description'	=> $this->g_para['desc'],
                        'uid'		=> $this->g_para['uid'],
                        'ctime'		=> $this->g_para['time'],
                        'showflag'	=> $this->g_para['showflag'],
                        'owner'		=> $this->g_para['owner'],
                        'touid'		=> $this->g_para['touid'],
			'classid'       => $this->g_para['classid'],
			'data_append'   => $data_append_json,
                );
		$this->api_obj->send_bdb($arr , $queue_result);
		if(!$queue_result){
			$this->error_num(2102);
		}

		// 执行订制功能
		$this->run_api_event();

		// 返回值
		$json_array = array('questionid'=>$this->g_para['questionid'],'tids_array'=>$tags_array,'logids'=>$this->g_result['logids_array']);
		echo json_encode($json_array);

	}

	/*
	* 调用接口功能订制列表
	*/
	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}

}
$exec = new addQuestion();
$result = $exec->run();
?>
