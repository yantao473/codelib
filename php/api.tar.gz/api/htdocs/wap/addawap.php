<?php
/**
 * @fn              添加回答接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @link            /q/addans.php
 * @date            2011-11-02
 * @update time     2012-03-02
 */

include_once("apiconf.php");

class addAnswer extends  webApp{
	public $g_para;
	public $generate_server_id,$insert_id,$db,$queue,$logs_obj,$mysqldb,$tools_obj,$table_name;
	function  __construct(){ 
		$this->g_para['questionid'] = isset($_REQUEST['questionid'])?(sprintf("%.0f", (float)($_REQUEST['questionid']))):"";
		$this->g_para['uid'] = isset($_REQUEST['uid'])?(sprintf("%.0f", (float)($_REQUEST['uid']))):"";
		$this->g_para['app'] = isset($_REQUEST['app'])?(sprintf("%.0f",(float)($_REQUEST['app']))):"";
		//用户是否显示 0显示 1 隐藏
		$this->g_para['owner'] = (isset($_REQUEST['owner']) && !empty($_REQUEST['owner']) )?(sprintf("%.0f", (float)($_REQUEST['owner'])) ):0;
		$this->g_para['answer'] = isset($_REQUEST['answer'])?trim($_REQUEST['answer']):"";
		$this->g_para['refermate'] = isset($_REQUEST['refermate'])?trim($_REQUEST['refermate']):"";
		$this->g_para['time'] = (isset($_REQUEST['ctime']) && !empty($_REQUEST['ctime']))?trim($_REQUEST['ctime']):date("Y-m-d H:i:s");
                //add share wb 
                $this->g_para['sharewb']       = isset($_REQUEST['sharewb'])? floatval($_REQUEST['sharewb'])   : 1;
                $this->g_para['wapcookie'] = isset($_REQUEST['ck'])? $_REQUEST['ck']:"";
	}
	function main(){
		$this->generate_server_id = new IdServer();
		$this->db = new RpcDb();
		$this->tools_obj = new Tools(); 
		$this->queue = new QueueTool();
		$this->logs_obj = new Logs;
		$this->mysqldb = new MysqlDb(); 
 		$this->api_obj = new Question($this->g_para , $this->g_result); 
		//get tagid start
		$this->bdb = new GetBdb();
		//get tagid end
		$this->table_name = $this->mysqldb->get_table('answer' , $this->g_para['questionid']);
		//modify 20120411 guoxianghui 获取insert_id 不用分表
		$this->insert_id = $this->generate_server_id->get('answer');
		$this->add_answer();
	}
	function add_answer(){
		if(isset($this->g_para['questionid']) && empty($this->g_para['questionid'])){
			$this->error_num(2111);		
		}
		if(isset($this->g_para['uid']) && empty($this->g_para['uid'])){
			$this->error_num(2112);		
		}
		if(isset($this->g_para['answer']) && empty($this->g_para['answer'])){
			$this->error_num(2113);		
		}
		$data_append = array(
				'refermate'=> $this->tools_obj->deal_text($this->g_para['refermate'],2),
				);
		$data_append = serialize($data_append);
		$is_or_no_answer = false;
		$result = $this->bdb->gets("detail",$this->g_para['questionid'],$data_ans);
		//send weibo use 
		$this->g_para['title'] = $data_ans['title'];
                if($this->g_para['sharewb']  == 1){
                        //set cookie
                        $cookie_str = $this->tools_obj->del_pwd($this->g_para['wapcookie']);
                                if(!empty($cookie_str)) {
                                        $preg = '~^Set-Cookie: SUE=(.*?)Set-Cookie: SUP=(.*?)$~is';
                                        if(preg_match($preg , $cookie_str , $aCookieinfo)) {
                                                $SUE_str = $aCookieinfo[1];
                                                $SUP_str = $aCookieinfo[2];
                                                $SUE = preg_replace('~;path=.*?$~is' , '' , $SUE_str);
                                                $SUP = preg_replace('~;path=.*?$~is' , '' , $SUP_str);
                                                $_COOKIE['SUE'] = $SUE;
                                                $_COOKIE['SUP'] = $SUP;
                                                setcookie('SUE' , trim($SUE) ,  0 , '/' , '.weibo.com');   
                                                setcookie('SUP' , trim($SUP) ,  0 , '/' , '.weibo.com');   
                                                                                                           
                                        }                                                                  
                                }                                                                          
                                                                                                           
                                                                                                           
                        $res_share = $this->api_obj->send_to_weibo(2);                                      
                }   
		if(!empty($data_ans['a'])) {
			foreach($data_ans['a'] as $aid => $ainfo) {
				if( $ainfo['uid'] == $this->g_para['uid'] ) {
					$is_or_no_answer = true;
					break;
				}
			}
		}	
		if($is_or_no_answer){
			$this->error_num(2102);
			die();
		}
		$this->g_para['answer'] = $this->tools_obj->deal_text($this->g_para['answer'],3);
		$sql =  array(
				'answerid'=>$this->insert_id,
				'appid'=>$this->g_para['app'],
				'answer'=>$this->g_para['answer'],
				'showflag'=>0,
				'data_append'=>$data_append,
				'uid'=>$this->g_para['uid'],
				'ctime'=>$this->g_para['time'],
				'owner'=>$this->g_para['owner'],
				'questionid'=>$this->g_para['questionid'],
			     );
		$get_sql = $this->db->prepare_insert_sql($this->table_name , $sql );
		$rpcdb_result = $this->db->update('question',$get_sql,$data);

		//返回$result  
		if($rpcdb_result){
			$array_sql = array(
					0=>EVENT_ANSWER_ADD,
					'answerid'=>$this->insert_id,
					'appid'=>$this->g_para['app'],
					'answer'=>$this->g_para['answer'],
					'showflag'=>0,
					'data_append'=>$data_append,
					'uid'=>$this->g_para['uid'],
					'ctime'=>$this->g_para['time'],
					'owner'=>$this->g_para['owner'],
					'questionid'=>$this->g_para['questionid'],
					);
			$ser_array = array('data'=>serialize($array_sql));                                 
			$url = QDOMAIN."/send_queue.php";                                                  
			$this->tools_obj->curl_set($url,"POST",$ser_array,$queue_result);
			//$queue_result = $this->queue->AddToLocalQueue(DEFAULT_QUEUE_DATA_FILE,$array_sql,DEFAULT_QUEUE_ID);
			if($queue_result){
				//update by guoxianghui 2012-05-22
				//如果用户是匿名回答，写日志的时候UID直接写成0  不清楚有没有团队回答
			        $uid = $this->get_logs_uid();
				//write answer_log  第一个参数是问题ID 
				$this->logs_obj->add_logs($this->g_para['questionid'],$uid,EVENT_ANSWER_ADD,$this->g_para['answer'],$this->g_para['time'],$logid_ans);
				//update by 2012 05 20
				//$this->logs_obj->add_logs($this->insert_id,$this->g_para['uid'],EVENT_ANSWER_ADD,$this->g_para['answer'],$this->g_para['time'],$logid_ans);
				

				$logids_array[] = $logid_ans;
				$json_array = array('result'=>'true','answerid'=>$this->insert_id,'logids'=>$logids_array);
				$this->add_ans_feed();
				echo json_encode($json_array);
			}else{
				$this->error_num(2102);
			}

		}else{
			$this->error_num(2102);
		}

	}

        /**
         * @fn 写日志获取uid 是否匿名
         * @date 2012-05-22
         **/
        function get_logs_uid(){
                if($this->g_para['owner'] == 1){
                        $uid = 0;                                                                          
                }else if ($this->g_para['owner'] == 0){                                                          
                        $uid = $this->g_para['uid'];                                                             
                }                                                                                          
                return $uid;                                                                               
        } 

	function add_ans_feed(){
		//get qid->tids 
		$result = $this->bdb->gets("question",$this->g_para['questionid'],$data);
		if(!empty($data['tags'])){
			foreach($data['tags'] as $k=>$v){
				$tids_array[] = $k;
			}
		}else{
			$tids_array = array();
		}
		//add feed start
		$eid = EVENT_ANSWER_ADD; 
		$feed = new feed(); 
		$objs = array(
				'uid'=>$this->g_para['uid'],
				'qid'=>$this->g_para['questionid'],
				'aid'=>$this->insert_id,
				'tids'=>$tids_array,
			     );  
		$res = $feed->addFeedataToQueue($eid,$objs);
		//add feed end

	}
}
$exec = new addAnswer();
$exec->run();
?>
