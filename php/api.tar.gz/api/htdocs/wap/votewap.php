<?php
/**
 * @fn              对回答投票接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @link            /q/vote.php
 * @date            2011-11-02
 *update time       2012-03-02   
 */

include_once("apiconf.php");

class dealVote extends  webApp{
	public $get_uid,$get_type,$get_time,$get_questionid,$get_answerid,$get_ip,$get_cflag;
	public $generate_server_id,$insert_id,$db,$queue;
	function  __construct(){ 
		$this->get_questionid = isset($_REQUEST['questionid'])?(sprintf("%.0f", (float)($_REQUEST['questionid']))):"";
		$this->get_answerid = isset($_REQUEST['answerid'])?(sprintf("%.0f", (float)($_REQUEST['answerid']))):"";
		$this->get_uid = isset($_REQUEST['uid'])?(sprintf("%.0f", (float)($_REQUEST['uid']))):"";
		$this->get_type = isset($_REQUEST['type'])?(sprintf("%.0f", (float)($_REQUEST['type'])) ):"";
		$this->get_ip = isset($_REQUEST['ip'])?$_REQUEST['ip']:"";
		$this->get_time = (isset($_REQUEST['ctime']) && !empty($_REQUEST['ctime']))?trim($_REQUEST['ctime']):date("Y-m-d H:i:s");
		$this->get_cflag = (isset($_REQUEST['cflag']) && !empty($_REQUEST['cflag']))?(sprintf("%.0f", (float)($_REQUEST['cflag'])) ):0;
	}
	function main(){
		$this->generate_server_id = new IdServer();
		$this->db = new RpcDb();
		$this->queue = new QueueTool();
		$this->tools_obj = new Tools();
		$this->insert_id = $this->generate_server_id->get("vote");
		$this->deal_vote();
	}
	function deal_vote(){
		global $g_error_app;
		$array_sql = array();
		$sql = array();
		$json_array = array();
		if(isset($this->get_questionid) && empty($this->get_questionid)){
			$this->error_num(2111);		
		}
		if(isset($this->get_uid) && empty($this->get_uid)){
			$this->error_num(2112);		
		}
		if(isset($this->get_answerid) && empty($this->get_answerid)){
			$this->error_num(2131);		
		}
		if(isset($this->get_type) && empty($this->get_type)){
			$this->error_num(2134);		
		}
		if($this->get_cflag == 0){
			//default
			$control_flag = true;
		}else if($this->get_cflag == 1){
			//没有取消赞成作用
			$control_flag = false;
		}
		if(isset($this->get_answerid) && !empty($this->get_answerid)){
			$ip = isset($this->get_ip)?$this->get_ip:'127.0.0.1';
			$ip = ip2long($this->get_ip);
			if($this->get_type == 2){
				$sql =  array(
						'voteid' => $this->insert_id,
						'questionid'=>$this->get_questionid,
						'answerid'=>$this->get_answerid,
						'uid'=>$this->get_uid,
						'ctime'=>$this->get_time,
						'type'=>2,
						'ip'=> $ip,

					     );
				$get_sql  = $this->db->prepare_insert_sql("vote",$sql);
				//$rpcdb_result = $this->db->update(RPC_QUESTION_APP,$get_sql,$data);
				$rpcdb_result = $this->db->update("question",$get_sql,$data);
				if( $data['errno'] != 1062  ){  // unique uid&&answerid
					if($rpcdb_result){
						//add  写到队列里为了计算话题下的最佳答案
						$array_sql = array( 
								0=>EVENT_VOTE_AGREE_ADD,
								'voteid'=>$this->insert_id,
								'questionid'=>$this->get_questionid,
								'answerid'=>$this->get_answerid,
								'uid'=>$this->get_uid,
								'ctime'=>$this->get_time,
								'type'=>2,
								'ip'=> $ip,
								);
						//$this->queue->AddToLocalQueue(DEFAULT_QUEUE_DATA_FILE,$array_sql,DEFAULT_QUEUE_ID);
						$ser_array = array('data'=>serialize($array_sql));                                 
						$url = QDOMAIN."/send_queue.php";                                                  
						$this->tools_obj->curl_set($url,"POST",$ser_array,$queue_result);
						$json_array = array(
								'result'=>$rpcdb_result,
								//'nick'=>$nick,
								'flag'=>'a',
								'uid'=>$this->get_uid,
								);
						echo json_encode($json_array);
						$this->add_vote_feed();
					}else{
						$this->error_num(2102);	
					}
				}else if( $data['errno'] == 1062  && $control_flag   ){ 
					$sql = "delete from vote  
						where uid = $this->get_uid
						and type = 2 
						and answerid = $this->get_answerid 
						and questionid = $this->get_questionid  ";
					$result = $this->db->update(RPC_QUESTION_APP,$sql,$data);
					if($result){
						$array_sql = array(
								0=>EVENT_VOTE_AGREE_DEL,
								'answerid'=>$this->get_answerid,
								'questionid'=>$this->get_questionid,
								'uid'=>$this->get_uid,
								'type'=> 2 , 
								'ctime'=>$this->get_time,
								); 
						//$this->queue->AddToLocalQueue(DEFAULT_QUEUE_DATA_FILE,$array_sql,DEFAULT_QUEUE_ID);

						$ser_array = array('data'=>serialize($array_sql));                                 
						$url = QDOMAIN."/send_queue.php";                                                  
						$this->tools_obj->curl_set($url,"POST",$ser_array,$queue_result);
						$arr = array(
								'result'=>$result,
								//'nick'=>$nick,
								'flag'=>'d',
								'uid'=>$this->get_uid,
							    );
						echo json_encode($arr);
					}else{
						$this->error_num(2102);	
					}
				}
			}



		}

	}
	function add_vote_feed(){
		$eid = EVENT_VOTE_AGREE_ADD;
		$objs = array(
				'uid'=>$this->get_uid,
				'qid'=>$this->get_questionid,
				'aid'=>$this->get_answerid,
			     );
		$res = feed::addFeedataToQueue($eid,$objs);
	}
}
$exec = new dealVote();
$exec->run();
?>
