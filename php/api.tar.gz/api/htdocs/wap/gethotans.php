<?php
/**
 * @fn              获取热点问题接口
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-07-13
 */

include_once("apiconf.php");

class getHotans extends  webApp{
	public $g_para,$bdb_obj,$queue;
	private $cfile;

	function  __construct(){
		$this->_init_param();
		$this->_init_class();
	}

	function _init_param(){
		$this->g_para['uid'] = isset($_REQUEST['uid']) ? floatval($_REQUEST['uid']) : '';
		$this->g_para['start'] = isset($_REQUEST['start'])?intval($_REQUEST['start']):0;
                $this->g_para['num'] = isset($_REQUEST['num'])?intval($_REQUEST['num']):5;;
		$this->cfile = ROOT_DIR.'/data/hot_ans.txt';
                //图片显示控制标志 2012-11-14
                $this->g_para['imgflag'] = isset($_REQUEST['imgflag']) ? floatval($_REQUEST['imgflag']) : 0;
	}

	function _init_class(){
		$this->bdb_obj = new GetBdb();
		$this->queue = new QueueTool();
	}

	function main(){
		$this->get_hotans();
	}
	function get_hotans(){
/*
		if(isset($this->g_para['uid']) && empty($this->g_para['uid'])){
			$this->error_num(2010);		
		}
*/
		if(file_exists($this->cfile)) {                                                            
			$fp = @fopen($this->cfile , 'r');
			flock($fp , LOCK_EX);                                                              
			$scon = fread($fp , @filesize($this->cfile));                                      
			flock($fp , LOCK_UN);                                                              
			fclose($fp);                                                                       
			$aID = json_decode(trim($scon) , true);
			$total = count($aID);
			$end = $this->g_para['start']*$this->g_para['num'] + $this->g_para['num'];
			
			//if($end <= $total ) {
				$start = $this->g_para['start']*$this->g_para['num'];
				for($i = $start; $i < $end ; $i++) { 
					$q_a_id[$aID[$i]['qid']] = $aID[$i]['aid'];
				}
				$qk = 0;
				foreach($q_a_id as $qid => $av){
					if(!empty($av)){
					$qids[$qk] = $qid;
					$aids[$qk] = $av;
					$q_a_id[$qk][$qid] = $av;
					$qk++;
					}
				}
				if(!empty($qids)) {     
					$result = $this->bdb_obj->gets("detail" , $qids , $data);
					if(!empty($data)) {                                                                        					foreach($data as $qid => $qinfo) {                                                
							$data[$qid]['atotal'] = count($qinfo['a']);                         
							if(!empty($qinfo['a'])) { 
								$temp_arr = array();
								foreach($qinfo['a'] as $aid => $ainfo) {                     
									if($ainfo['showflag'] == 1) {                       
										$data[$qid]['atotal']--;                     
									}
									//deal answer
									if(empty($this->g_para['imgflag'])){
										$apreg = '~\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
										$ainfo['answer'] = preg_replace($apreg,'',$ainfo['answer']);
									}
									if( $aid == $q_a_id[$qid]){
										$temp_arr = $ainfo;
									}
								}
							}
							$data[$qid]['a'] = array();
							$data[$qid]['a'][$q_a_id[$qid]] = $temp_arr;
							                                                                   
							$data[$qid]['atotal'] = $data[$qid]['atotal'] < 0 ? 0 : $data[$qid]['atotal'];
						}                                                                 
					}  


				}
			//}                                                                                  
		}   
		if(!empty($data)){
			$data['total'] = $total;
			echo json_encode($data);
		}else{
			$this->error_num(2135);
		}

	}
}
$exec = new getHotans();
$exec->run();
?>
