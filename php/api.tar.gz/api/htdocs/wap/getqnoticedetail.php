<?php
/**
 * 获取某个问题的所有消息
 **/
require_once("apiconf.php");
class notice_detail extends webApp implements Platform_Api{

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function __construct(){
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	function _init_param(){
		$this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;  
		$this->g_para['uid'] = floatval($_REQUEST['uid']);
		$this->g_para['qid'] = floatval($_REQUEST['qid']);
	}

	function _check_param(){
		if(empty($this->g_para['uid'])){                                                           
			$this->error_num(2101);                                                            
		}   
	}

	function _init_class(){
		$this->user_obj = new Login_UserMan();                                                     
		$this->weibov4_obj  = new weibov4();                                                       
		$this->bdb_obj = new GetBdb;    
		$this->tools_obj = new Tools();
		$this->notice = new Notice();
	}

	function _init_api_config() {                                                                      
		$this->api_name = 'getqnoticedetail';                                                             
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
		if(empty($this->api_config)) {                                                             
			$this->error_num(3001);                                                            
		}                                                                                          
	}  

	function main(){
		$this->_check_param();
		$this->deal_data();
	}

	function deal_data(){
		$unnum = $this->notice->get_notice_count_unread($this->g_para['uid']);
		$unread_num = $unnum['result']['num'] > 0 ? $unnum['result']['num']:0;
		$unread_notice_info = $this->notice->get_notice_list_zip($this->g_para['uid']);
		if($unread_notice_info['err_code'] == 18){
			$unread_num = 0;
		}
		$nlist = array();
		if($unread_num > 0 ){
			foreach($unread_notice_info['result'] as $key => $val){
				if($key == 'question'){
					$i = 0 ;                                                           
					foreach($val as  $k=>$qval ){
						if($k == $this->g_para['qid']){
							//qid $k  新答案                                                   
							if(!empty($qval['answer']) && $qval['answer']['flag'] == 'answer'){
								$nlist['answer']['num']  = $qval['answer']['num'];
								$auid_arr = array();
								foreach($qval['answer']['desc'] as $ak=>$aval){
									$nlist['answer']['a'][$aval['aid']]['aid'] = $aval['aid'];
									$nlist['answer']['a'][$aval['aid']]['mid'] = $aval['mid'];
									$nlist['answer']['a'][$aval['aid']]['ctime'] = $aval['ctime'];
									$auid_arr[$aval['aid']][] = $aval['uid'];
									
									//$this->get_user( $aval['uid'],$cdata);
									//print_r($cdata);
									//$nlist['answer']['a'][$aval['aid']]['nick'] = $cdata[$aval['uid']]['nick'];
									$nlist['answer']['a'][$aval['aid']]['uid'] = $aval['uid'];
									$nlist['answer']['a'][$aval['aid']]['owner'] = $aval['owner'];

								}
								if(!empty($auid_arr)){
									foreach($auid_arr as $aid=>$ansuid){
										foreach($ansuid as $vauid){
											$tmp_auidarr[] = $vauid;
										}
										
									}
									$tmp_auidarr = array_unique($tmp_auidarr);
									$this->get_user( $tmp_auidarr,$auiddata);
									if(!empty($auiddata)){
										foreach($auid_arr as $aid=>$ansuid){
											foreach($ansuid as $vauid){
												$nlist['answer']['a'][$aid]['nick'] = $auiddata[$vauid]['nick']; 
											}
										}

									}
								}       
							}                                                          
							if(!empty($qval['comment']) && isset($qval['comment'])){                              
								$nlist['comment']['num']  = $qval['comment']['num'];
								//问题评论
								if(isset($qval['comment']['desc']['question'])){
									$nlist['comment']['question']['num']  = count($qval['comment']['desc']['question']);
								$gg = 0;
								$auid_arr = array();	
								foreach($qval['comment']['desc']['question'] as $cqk=>$cqv){
										$cuid_arr[$k][] = $cqv['uid']; 	
										//$this->get_user( $cqv['uid'],$codata);
										//$nlist['comment']['c'][$k][$gg]['nick'] = $codata[$cqv['uid']]['nick'];
										$auid_arr[$k][$gg] = $cqv['uid'];
										$nlist['comment']['c'][$k][$gg]['uid'] = $cqv['uid'];
										$nlist['comment']['c'][$k][$gg]['self'] = false; 
										if($this->g_para['uid'] == $cqv['uid']){
											$nlist['comment']['c'][$k][$gg]['self'] = true; 
										}
										$comq[] = $cqv['mid'];
										$cqid = @implode(",",$comq);
										$nlist['comment']['c'][$k][$gg]['mid'] = $cqid;
										$nlist['comment']['c'][$k][$gg]['ctime'] = $cqv['ctime'];
									$gg++;
									}
								if(!empty($auid_arr)){
									foreach($auid_arr as $qid=>$ansuid){
										foreach($ansuid as $vauid){
											$tmp_auidarr[] = $vauid;
										}
										
									}
									$tmp_auidarr = array_unique($tmp_auidarr);
									$this->get_user( $tmp_auidarr,$auiddata);
									if(!empty($auiddata)){
										foreach($auid_arr as $qid=>$ansuid){
											foreach($ansuid as $k=>$vauid){
												$nlist['comment']['c'][$qid][$k]['nick'] = $auiddata[$vauid]['nick']; 
											}
										}

									}
								}       
								//print_r($cuid_arr);

								}           
								//me评论
								if(isset($qval['comment']['desc']['me']) && !empty($qval['comment']['desc']['me'])){
									$nlist['comment']['m']['num']  = count($qval['comment']['desc']['me']);
									$auid_arr = array();
									$mm = 0;
									foreach($qval['comment']['desc']['me'] as $cqk=>$cqv){
										//$this->get_user( $cqv['auid'],$cdata);
										//$nlist['comment']['m'][$cqv['auid']][$mm]['nick'] = $cdata[$cqv['auid']]['nick'];
										$auid_arr[$cqv['auid']][$mm] = $cqv['auid'];
										$nlist['comment']['m'][$cqv['auid']][$mm]['uid'] = $cqv['auid'];
										$nlist['comment']['m'][$cqv['auid']][$mm]['aid'] = $cqv['answerid'];
										$nlist['comment']['m'][$cqv['auid']][$mm]['ctime'] = $cqv['ctime'];
										$comm[] = $cqv['mid'];
										$cmid = @implode(",",$comm);
										$nlist['comment']['m'][$cqv['auid']][$mm]['mid'] = $cmid;
										$nlist['comment']['m'][$cqv['auid']][$mm]['self'] = false;
										if($cqv['auid'] == $this->g_para['uid']){
											$nlist['comment']['m'][$cqv['auid']][$mm]['self'] = true;
										}
										$mm++;
									}
								if(!empty($auid_arr)){
									foreach($auid_arr as $aid=>$ansuid){
										foreach($ansuid as $vauid){
											$tmp_auidarr[] = $vauid;
										}
										
									}
									$tmp_auidarr = array_unique($tmp_auidarr);
									$this->get_user( $tmp_auidarr,$auiddata);
									if(!empty($auiddata)){
										foreach($auid_arr as $aid=>$ansuid){
											foreach($ansuid as $k=>$vauid){
												$nlist['comment']['m'][$vauid][$k]['nick'] = $auiddata[$vauid]['nick']; 
											}
										}

									}
								}       
//print_r($nlist['comment']);

								}           
								//其他评论
								if(isset($qval['comment']['desc']['other']) && !empty($qval['comment']['desc']['other'])){
									$nlist['comment']['o']['num']  = count($qval['comment']['desc']['other']);
									$auid_arr = array();
									$cc = 0;
									foreach($qval['comment']['desc']['other'] as $value){
										//$this->get_user( $value['auid'],$cdata);
										//$nlist['comment']['o'][$value['auid']][$cc]['nick'] = $cdata[$value['auid']]['nick'];
										$auid_arr[$value['auid']][$cc] = $value['auid'];
										$nlist['comment']['o'][$value['auid']][$cc]['auid'] = $value['auid'];
										$nlist['comment']['o'][$value['auid']][$cc]['answerid'] = $value['answerid'];
										$como[] = $value['mid'];
										$coid = @implode(",",$como);
										$nlist['comment']['o'][$value['auid']][$cc]['mid'] = $coid;
										$nlist['comment']['o'][$value['auid']][$cc]['ctime'] = $value['ctime'];
									$cc++;
									}
								if(!empty($auid_arr)){
									foreach($auid_arr as $aid=>$ansuid){
										foreach($ansuid as $vauid){
											$tmp_auidarr[] = $vauid;
										}
										
									}
									$tmp_auidarr = array_unique($tmp_auidarr);
									$this->get_user( $tmp_auidarr,$auiddata);
									if(!empty($auiddata)){
										foreach($auid_arr as $aid=>$ansuid){
											foreach($ansuid as $k=>$vauid){
												$nlist['comment']['o'][$vauid][$k]['nick'] = $auiddata[$vauid]['nick']; 
											}
										}

									}
								}       

								}           

							}                                                          
							if(!empty($qval['invite']) && isset($qval['invite']) ){                        							     $nlist['invite']['num']  = $qval['invite']['num'];
								foreach($qval['invite']['desc'] as $ak=>$aval){
									$imid[] = $aval['mid'];
									$iimid = @implode(",",$imid);

									$nlist['invite']['n'][$aval['inviter']]['mid'] = $iimid;
									$nlist['invite']['n'][$aval['inviter']]['ctime'] = $aval['ctime'];
									$this->get_user( $aval['inviter'],$cdata);
									$nlist['invite']['n'][$aval['inviter']]['nick'] = $cdata[$aval['inviter']]['nick'];
									$nlist['invite']['n'][$aval['inviter']]['uid'] = $aval['inviter'];

								}       
							}                                                          
							if(!empty($qval['adopt'])){
								$nlist['adopt']['num']  = $qval['adopt']['num'];
								foreach($qval['adopt']['desc'] as $ak=>$aval){
									$nlist['adopt']['a'][$aval['aid']]['aid'] = $aval['aid'];
									$nlist['adopt']['a'][$aval['aid']]['mid'] = $aval['mid'];
									$nlist['adopt']['a'][$aval['aid']]['ctime'] = $aval['ctime'];
									$this->get_user( $aval['uid'],$cdata);
									$nlist['adopt']['a'][$aval['aid']]['nick'] = $cdata[$aval['uid']]['nick'];
									$nlist['adopt']['a'][$aval['aid']]['uid'] = $aval['uid'];

								}       
							}                                                          
							$nlist['qid'] = $this->g_para['qid'];

							$i++;
						}
					}
				}
			}                                                                                  
		}   
		//print_r($nlist);
		$json_array = array('result'=>true,'list'=>$nlist);
		$this->run_api_event();		
		echo json_encode($json_array);
	}

	function run_api_event() {
		$cmd = @implode('' , $this->api_config[$this->api_name]['func']);
		if(!empty($cmd)) {
			if(eval($cmd) === FALSE) {
				$this->error_num(3002);
			}
		}
	}

	function get_user($uids ,&$info) {
		$v4_ulist = array();
		$flag = $this->user_obj->get_user_detail_bdb($uids,$data);
		if(!$flag)
		{
			$this->err_code = 2201;
			return false;
		}
		if(!empty($data))                                                                          
		{             
			if(!isset($data['uid'])){
				foreach($data as $uid => $uinfo)                                                   
				{
					if($uid != 'total') {
						$data[$uid]['nick'] = $uinfo['nick'];                              
						$data[$uid]['description'] = $uinfo['description'];                
					}                                                                          
				}                        
			}else{
				$uid = $data['uid'];
				$data[$uid]['nick'] = $data['nick'];                              
				$data[$uid]['description'] = $data['description'];                

			}                                                          
		}            
		if(!empty($data)) {
			if(!isset($data['uid'])){                                                                        
				$info_array = $data;                                                               
				if(!empty($info_array) && empty($info_array['err_code']))                          
				{                                                                                  
					$uid_arr = $uids;                                                          
					$v4_uinfo = $this->weibov4_obj->showusers($uid_arr);                       
					$v4_uinfo = json_decode($v4_uinfo,true);                                   
					if(!empty($v4_uinfo['users'])) {                                           
						foreach($v4_uinfo['users'] as $v4info) {                           
							$v4_ulist["{$v4info['id']}"] = $v4info;                    
						}                                                                  
					}       
					foreach($info_array as $uid => $uinfo) {                                   
						if(!is_array($uinfo) || empty($uinfo['uid'])) {                 // 表示用户不存在
							continue;                                                  
						}                                                                  
						$info["$uid"] = $uinfo;                                            
						$info["$uid"]['uid'] = $uid;                                       
						//$info["$uid"]['description'] = urldecode($uinfo['description']); 
						$info["$uid"]['description'] = htmlspecialchars($uinfo['description']);
						$info["$uid"]['nick_local'] = $uinfo['nick'];           
						// 微博用自己的头像图片 不用平台的头像图片                         
						$info["$uid"]['picture_ua'] = '';                                  
						$info["$uid"]['picture_ub'] = '';                                  
						$info["$uid"]['picture_uc'] = ''; 
						// 调微博接口 取数据                                               
						if(!empty($v4_ulist["$uid"]['error_code']) || empty($v4_uinfo['users']) ) {      
							$info["$uid"]['user_isvalid'] = false;                     
						}                                                                  
						else {                                                             
							$info["$uid"]['user_isvalid'] = true;                      
						}                                                                  
						$info["$uid"]["yellowv"] =  false;                                 
						$info["$uid"]["bluev"] =  false;                                   
						if($v4_ulist["$uid"]['verified'] ){                                
							if($v4_ulist["$uid"]['verified_type'] == 0){               
								$info["$uid"]["yellowv"] =  true;                  
							}                                                          
							if(preg_match("~^[1-7]$~is",$v4_ulist["$uid"]['verified_type'])){
								$info["$uid"]["bluev"] =  true;                    
							}                                                          

						}                
						$info["$uid"]['nick'] = !empty($v4_ulist["$uid"]['screen_name'])? $v4_ulist["$uid"]['screen_name'] : $data[$uid]['nick'];          
						$info["$uid"]['picture_ua'] = $v4_ulist["$uid"]['profile_image_url'];
						$info["$uid"]['picture_uc'] = $v4_ulist["$uid"]['avatar_large'];   
					}                                                                          
					return true;                                                               
				}                                                                                  
				else {                                                                             
					$info = $info_array;                                                       
				}                                                                                  
			}else{
				$uid = $data['uid'];
				$info[$uid]['nick'] = $data['nick'];                              
				$info[$uid]['description'] = $data['description'];
			}                                                          
		}
		return false;
	}
}
$exec = new notice_detail();
$exec->run();
?>
