<?php
/**
 * 取所有消息
 * @by guoxianghui
 * @date 2012-09-11
 */
require_once("apiconf.php");

class allReno extends webApp implements Platform_Api{

        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;
        public $notice_obj;

	function __construct() {

                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();

	}
        function _init_param(){                                                                            
                $this->g_para['page'] = isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;      
                $this->g_para['type'] = isset($_REQUEST['type']) ? floatval($_REQUEST['type']) : 1;       
                $this->g_para['uid'] = floatval($_REQUEST['uid']);                                         
                $this->g_para['app'] = isset($_REQUEST['app']) ? floatval($_REQUEST['app']) : 1;           
		$this->g_para['pagesize'] = isset($_REQUEST['pagesize']) ? floatval($_REQUEST['pagesize']) :20 ;
        }                                                                                                  
        function _check_param(){                                                                           
                if(empty($this->g_para['uid'])){                                                           
                        $this->error_num(2101);                                                            
                }                                                                                          
        }                                                                                                  
                                                                                                           
        function _init_class(){     
		$this->user_obj = new Login_UserMan();                                                                       
                $this->tools_obj= new Tools();                                                             
                $this->notice_obj = new Notice();       
 		$this->weibov4_obj  = new weibov4();                                                   
        }                                                                                                  
                                                                                                           
        function _init_api_config() {                                                                      
                $this->api_name = 'getqreadno';                                                             
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];          
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);               
                if(empty($this->api_config)) {                                                             
                        $this->error_num(3001);                                                            
                }                                                                                          
        }  



	function main(){       
		$this->get_all_readnotice(); 

	}

	function get_all_readnotice(){
		if($this->g_para['type'] == 1){
			//获取全部消息总数
			$allnum = $this->notice_obj->get_notice_count($this->g_para['uid']);
			//全部消息 
			$allnews = $this->notice_obj->get_notice_list($this->g_para['uid'],$this->g_para['pagesize'],$this->g_para['page'],$unlastid,0);
			if(!empty($allnews['result'])){
				$all = $this->makecase($allnews['result'],$this->g_para['type']);   
			}
			$all['pagetotal'] = ceil($allnum['result']['num']/$this->g_para['pagesize']);
			$all['noticetotal'] = $allnum['result']['num'];
//print_r($all);
			echo json_encode(array('result'=>$all));
		}
	}
	/***
	 * 处理对应的各种情况
	 * @param $result 为获取到的消息结果 eg：$allnews['result']
	 * @return 返回其需要的信息，flag类型  ，   uid，   用户名称  ，  qid，  问题内容
	 */
	function makecase($result,$type){
		$uids = $qids = array();
		foreach($result as $k=>$v){
			if(empty($v['content'])) {
				continue;
			}
			$ninfo["$k"] = isset($v['content'])?unserialize($v['content']):'';
			$ninfo["$k"]['id'] = $v['id'];
			$ninfo["$k"]['infoid']=$v['infoid'];
			switch($ninfo["$k"][0]){
				case EVENT_ANSWER_ADD:  //添加回答  7
					{ 
						$qids["$k"] = $ninfo["$k"]['questionid'];
						$uids["$k"] = $ninfo["$k"]['uid']; //回答问题id
						break;
					}
				case EVENT_COMMENT_ADD:  //添加评论     11
					{
						$uids["$k"] = $ninfo["$k"]['uid']; //评论人id
						//类别,(1问题,2回答,3收藏)
						if($ninfo[$k]['type'] == 1){
							//$qids["$k"] = $ninfo[$k]['targetid'];
							$data_append = unserialize($ninfo[$k]['data_append']);
							$qids[] = $ninfo[$k]['questionid'] = $data_append['questionid'];
							$ninfo["$k"]['type'] = $ninfo[$k]['type'];
							$ninfo["$k"]['targetid'] = $ninfo[$k]['targetid'];
						}else if($ninfo[$k]['type'] == 2){
							//$aids[$k] = $ninfo[$k]['targetid'];
							$data_append = unserialize($ninfo[$k]['data_append']);
							$qids[] = $ninfo[$k]['questionid'] = $data_append['questionid'];
                                                        $ninfo["$k"]['type'] = $ninfo[$k]['type'];
                                                        $ninfo["$k"]['targetid'] = $ninfo[$k]['targetid'];
						}else if($ninfo[$k]['type'] == 3){
							$sids['type'] = $ninfo[$k]['targetid'];
							$qids["$k"] = $ninfo["$k"]['qid'];
						}
						$uids["$k"] = $ninfo["$k"]['uid'];
						break;
					}
				case EVENT_QUESTION_INVITE: //邀请回答  26                        
					{
						$qids["$k"] = $ninfo["$k"]['questionid'];
						//发起邀请人
						$uids["$k"] = $ninfo["$k"]['uid'];                        
						break;
					}
				case EVENT_VOTE_AGREE_ADD: //赞同投票       13
					{
						$qids["$k"] = $ninfo["$k"]['questionid'];
						//赞同问题的人
						$uids["$k"] = $ninfo["$k"]['uid'];                                                  
						break;
					}
				case EVENT_QUESTION_ADOPT: //采纳回答    41
					{
						$qids["$k"] = $ninfo["$k"]['questionid'];
						if(!empty($ninfo["$k"]['uid'])) {
							$uids["$k"] = $ninfo["$k"]['uid'];
						}
						break;
					}                        
				default:
					{
						break;
					}  
			}// switch end

		}//foreach end

		if(empty($qids)){
			return array();
		}
		$qids = array_unique($qids);
		$uids = array_unique($uids);
		if(!empty($qids)){
			foreach($qids as $val){
				$tmp_qids[] = $val;
			}
		}
		if(!empty($uids)){
			foreach($uids as $val){
				$tmp_uids[] = $val;
			}
		}
		$uids = array();
		$uids = $tmp_uids;
		$qids = array();
		$qids = $tmp_qids;
		$question = $this->get_question($qids);
		$this->get_user($uids,$user);
		foreach($ninfo as $nk => $nv){
			$uid = $nv['uid'];
			//var_dump($nv);
			$qid = $nv['questionid']?intval($nv['questionid']):intval($nv['qid']);
			if(!empty($$nv['questionid'])   && @!array_key_exists($nv['questionid'],$question)){
                                continue;
                        }
			//echo $qid;
			$news["$nk"]['id'] = $nv['id'];
			$news["$nk"]['infoid'] = $nv['infoid'];
			$news["$nk"]['uid'] = $nv['uid'];
			$news["$nk"]['nick'] = $user["$uid"]['nick'];
			$news["$nk"]['qid'] = $nv['questionid']?$nv['questionid']:$nv['qid'];
			$news["$nk"]['title'] = $this->tools_obj->mb_substring(strip_tags($question["$qid"]['title']), 0 , 26);
			$news["$nk"]['type'] = $nv['type'];
			$news["$nk"]['targetid'] = $nv['targetid'];
			if($type == 0){
				$news["$nk"]['ctime'] = $nv['ctime']? $nv['ctime']: $nv['utime'];
			}else if($type == 1){
				$news["$nk"]['ctime'] = $nv['ctime']? $nv['ctime']: $nv['utime'];
			}
			switch($ninfo["$nk"][0]){
				case EVENT_ANSWER_ADD:  //添加回答  7
					{
						$news["$nk"]['owner'] = $nv['owner'];
						$news["$nk"]['flag'] = 7;
						break;
					}
				case EVENT_COMMENT_ADD:  //添加评论     11
					{
						$news["$nk"]['flag'] = 11;
						break;
					}
				case EVENT_QUESTION_INVITE: //邀请回答  26                        
					{
						$news["$nk"]['flag'] = 26;                    
						break;
					}
				case EVENT_VOTE_AGREE_ADD: //赞同投票       13
					{
						$news["$nk"]['flag'] = 13;                                                 
						break;
					}
				case EVENT_QUESTION_ADOPT: //采纳回答    41
					{
						$news["$nk"]['flag'] = 41;
						break;
					}                        
				default:
					{
						break;
					}  
			}// switch end
		}//foreach end   
		return $news;    
	}//function end


	/*批量获取问题摘要信息---问题id及问题名称
	 * @param $qids 问题id用逗号连接的字符串
	 * */
	function get_question($qids){
		$a_url = DOMAIN.'/q/getquestion_batch.php';
		$a_data = implode(',',$qids);
		$a_data = array('questionids'=>$a_data);
		$a_res = $this->tools_obj->curl_set($a_url,'post', $a_data, $q_info);

		if($a_res){
			$que_info = json_decode($q_info,true); 
		}else{ //curl 请求失败

		}
		return $que_info;        
	}
	
	function get_answer($aids) {
		$url = API_DOMAIN.'/q/getans_batch.php';
		$param = array('answerids' => implode(',' , $aids));
		$res = $this->tools_obj->curl_set($url,'post', $param, $json);
		$a_infos = json_decode($json , true);
		if(!empty($a_infos)) {
			foreach($a_infos as $aid => $ainfo) {
				$qids[] = $ainfo['questionid'];
			}
		}
		return $qids;
	}

        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

       function get_user($uids ,&$info) {
                $v4_ulist = array();
                $flag = $this->user_obj->get_user_detail_bdb($uids,$data);
		if(!empty($data))
                {
                         if(!isset($data['uid'])){
                        foreach($data as $uid => $uinfo)
                        {
                                if($uid != 'total') {
                                        //$data[$uid]['nick'] = urlencode($uinfo['nick']);                 
                                        $data[$uid]['nick'] = $uinfo['nick'];                              
                                        $data[$uid]['description'] = $uinfo['description'];                
                                        //$data[$uid]['description'] = urlencode($uinfo['description']);   
                                }                                                                          
                        }                                                                                  
                        }else{
                                $uid = $data['uid'];                                                       
                                $data[$uid]['nick'] = $data['nick'];                                       
                                $data[$uid]['description'] = $data['description'];                                                                              
                        }                                                                                  
                }                                                                                          
                if(!empty($data)) {      
			if(!isset($data['uid'])){                                                                  
                        $info_array = $data;                                                               
                        if(!empty($info_array) && empty($info_array['err_code']))                          
                        {                                                                                  
                                $uid_arr = $uids;                                                          
                                $v4_uinfo = $this->weibov4_obj->showusers($uid_arr);                       
                                $v4_uinfo = json_decode($v4_uinfo,true);                                   
                                if(!empty($v4_uinfo['users'])) {                                           
                                        foreach($v4_uinfo['users'] as $v4info) {                           
                                                $v4_ulist["{$v4info['id']}"] = $v4info;                    
                                        }                                                                  
                                }                                                                          
                                foreach($info_array as $uid => $uinfo) {                                   
                                        if(!is_array($uinfo) || empty($uinfo['uid'])) {                 // 表示用户不存在
                                                continue;                                                  
                                        }                                                                  
                                        $info["$uid"] = $uinfo;                                            
                                        $info["$uid"]['uid'] = $uid;                                       
                                        //$info["$uid"]['description'] = urldecode($uinfo['description']); 
                                        $info["$uid"]['description'] = htmlspecialchars($uinfo['description']);
                                     $info["$uid"]['nick_local'] = urldecode($uinfo['nick']);           
                                        // 微博用自己的头像图片 不用平台的头像图片                         
                                        $info["$uid"]['picture_ua'] = '';                                  
                                        $info["$uid"]['picture_ub'] = '';                                  
                                        $info["$uid"]['picture_uc'] = '';                                  
                                                                                                           
                                        // 调微博接口 取数据                                               
                                        if(!empty($v4_ulist["$uid"]['error_code']) || empty($v4_uinfo['users']) ) {      
                                                $info["$uid"]['user_isvalid'] = false;                     
                                        }                                                                  
                                        else {                                                             
                                                $info["$uid"]['user_isvalid'] = true;                      
                                        }                                                                  
                                        $info["$uid"]["yellowv"] =  false;                                 
                                        $info["$uid"]["bluev"] =  false;                                   
                                        if($v4_ulist["$uid"]['verified'] ){                                
                                                if($v4_ulist["$uid"]['verified_type'] == 0){               
                                                        $info["$uid"]["yellowv"] =  true;                  
                                                }                                                          
                                                if(preg_match("~^[1-7]$~is",$v4_ulist["$uid"]['verified_type'])){
                                                        $info["$uid"]["bluev"] =  true;                    
                                                }                                                          
                                                                                                           
                                        }                                                                  
                                        $info["$uid"]['gender'] = $v4_ulist["$uid"]['gender'];     
                             		$info["$uid"]['description'] = empty($info["$uid"]['description']) ? htmlspecialchars($v4_ulist["$uid"]['verified_reason']) : $info["$uid"]['description'];
                                        $info["$uid"]['nick'] = !empty($v4_ulist["$uid"]['screen_name'])? $v4_ulist["$uid"]['screen_name'] : $data[$uid]['nick'];       
                                        $info["$uid"]['picture_ua'] = $v4_ulist["$uid"]['profile_image_url'];
                                        $info["$uid"]['picture_uc'] = $v4_ulist["$uid"]['avatar_large'];   
                                }                                                                          
                                return true;                                                               
                        }                                                                                  
                        else {                                                                             
                                $info = $info_array;                                                       
                        }     
                        }else{  
                                $uid = $data['uid'];
                                $info[$uid]['nick'] = $data['nick'];
                                $info[$uid]['description'] = $data['description'];
                        }                                                                             
                }                                                                                          
                return false;                                                                              
        }                                           

}
$app = new allReno;
$app->run();
?>
