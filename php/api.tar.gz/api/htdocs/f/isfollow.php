<?php
/**
 * 判断是否关注(话题，问题)
 * @author          zhanghua2@staff.sina.com.cn
 * 2011-11-14
 */

require_once("apiconf.php");

class Isfollow extends webApp implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		#$this->g_para['app']    = isset($_REQUEST['app'])       ? intval($_REQUEST['app'])	: '';
		$this->g_para['uid']    = isset($_REQUEST['uid'])       ? floatval($_REQUEST['uid'])    : '';
		$this->g_para['qid']	= isset($_REQUEST['qid'])	? floatval($_REQUEST['qid'])	: 0 ;
		$this->g_para['tid']	= isset($_REQUEST['tid'])	? floatval($_REQUEST['tid'])	: 0 ;
		$this->g_para['type']   = isset($_REQUEST['type'])      ? intval($_REQUEST['type'])     : 0 ;
		$this->g_para['ids']	= isset($_REQUEST['ids'])	? trim($_REQUEST['ids'])	: '';
		$this->g_para['app']    = 1;
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {

		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}

		if(empty($this->g_para['uid'])) {
			$this->error_num(2101);
		}

		if(!in_array($this->g_para['type'] , array(1 ,2 ,3 ,4))) {
			$this->error_num(2405);
		}
	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {

		$this->tools_obj= new Tools();
		$this->api_obj = new Follow($this->g_para , $this->g_result);
	}

	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = $this->g_para['api_name'] = 'isfollow';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	/**
	 * 主函数
	 **/
	function main() {
		$this->is_follow();
	}

	function is_follow() {
		switch($this->g_para['type']) {
			case 1: //关注问题的人
				$this->g_para['oid'] = $this->g_para['qid'];
				$this->g_para['type'] = 'gqo';
				$this->g_para['ids'] = $this->g_para['uid'];
				break;
			case 2:
				$this->g_para['oid'] = $this->g_para['tid'];
				$this->g_para['type'] = 'gto';
				$this->g_para['ids'] = $this->g_para['uid'];
				break;                      
			case 3:
				$this->g_para['oid'] = $this->g_para['uid'];
				$this->g_para['type'] = 'gqm';
				break;
			case 4:
				$this->g_para['oid'] = $this->g_para['uid'];
				$this->g_para['type'] = 'gtm';
				break;
			default:
				break;
		}
/*
		if(empty($this->g_para['oid'])) {
			$this->error_num(2404);
		}
*/	
		$this->g_para['alluids'] = @explode(',' , $this->g_para['ids']);
		$res = $this->api_obj->isfollow();
		if(!empty($res) && is_array($res)){
			foreach($res as $key=>$v){
				if($v) {
					$i_res['res']["$key"]=1;
				} else {
					$i_res['res']["$key"]=0;
				}
			}                            
		} else {
			foreach( $this->g_para['alluids'] as $ak => $av){
				$i_res['res']["$av"] = 0;
			}
		}
		
                // 执行订制功能
                $this->run_api_event();

		echo json_encode($i_res);                                   
	}

	/*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }

}
$app = new Isfollow;
$app->run();
?>
