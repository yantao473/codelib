<?php
/**
 * 获取关注列表
 * @author          zhanghua2@staff.sina.com.cn
 */

require_once("apiconf.php");

class Getfollowlist extends webApp implements Platform_Api {

	private $api_config_file;
	private $api_config;
	private $tools_obj;
	private $api_obj;
	public $g_para;
	public $g_result;

	function  __construct() {
		$this->_init_param();
		$this->_check_param();
		$this->_init_class();
		$this->_init_api_config();
	}

	/**
	 *  获取参数
	 **/
	function _init_param() {
		$this->g_para['app']	= isset($_REQUEST['app'])	? intval($_REQUEST['app'])	: '';
		$this->g_para['tid']	= isset($_REQUEST['tid'])	? floatval($_REQUEST['tid'])	: 0;
		$this->g_para['qid']	= isset($_REQUEST['qid'])	? floatval($_REQUEST['qid'])	: 0;
		$this->g_para['uid']	= isset($_REQUEST['uid'])	? floatval($_REQUEST['uid'])	: 0;
		$this->g_para['type']	= isset($_REQUEST['type'])	? trim($_REQUEST['type'])	: '';
		$this->g_para['flag']	= isset($_REQUEST['flag'])	? intval($_REQUEST['flag'])	: 0;
		$this->g_para['start']	= isset($_REQUEST['start'])	? intval($_REQUEST['start'])	: 0;
		$this->g_para['num']	= isset($_REQUEST['num'])	? intval($_REQUEST['num'])	: 20;
	}

	/**
	 *  判断参数合法性
	 **/
	function _check_param() {

		if(empty($this->g_para['app'])) {
			$this->error_num(3000);
		}

		if(empty($this->g_para['uid'])) {
			#$this->error_num(2101);
		}

		if(!in_array($this->g_para['type'] , array('gpm','gqm','gtm','gsm','gpo','gqo','gto','gso'))) {
			$this->error_num(2403);
		}
	}

	/**
	 *  初始化对象
	 **/
	function _init_class() {

		$this->tools_obj= new Tools();
		$this->api_obj = new Follow($this->g_para , $this->g_result);
		$this->getbdb_obj = new GetBdb;
		$this->image_obj = new images;
	}

	/*
	 * 初始化接口功能
	 */
	function _init_api_config() {
		$this->api_name = $this->g_para['api_name'] = 'getfollowlist';
		$this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
		$this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
		if(empty($this->api_config)) {
			$this->error_num(3001);
		}
	}

	/**
	 * 主函数
	 **/
	function main() {

		$this->get_follow();
	}

	/*
	* 获取关注
	*/
	function get_follow() {

		switch($this->g_para['type']) {
			case 'gpm':
			case 'gqm':
			case 'gtm':
			case 'gsm':
			case 'gpo':
				$this->g_para['oid'] = $this->g_para['uid'];
				break;
			case 'gqo':
				$this->g_para['oid'] = $this->g_para['qid'];
				break;
			case 'gto':
				$this->g_para['oid'] = $this->g_para['tid'];
				break;
			case 'gso':
				$this->g_para['oid'] = $this->g_para['qid'];
				break;
			default :
				$this->g_para['oid'] = 0;
				break;
		}

		// 得到用户的信息
		if(empty($this->g_para['oid'])) {
			$this->error_num(2404);
		}

		$follow = $this->api_obj->getfollowlist();

		if($this->g_para['flag'] == 0) {  //不得到详细信息
			if(is_array($follow)) {
				foreach($follow as $key => $v) {
					if(is_numeric($key)) {
						$follow_list['follow'][$key] = $v["keys"];
						//匿名标志
						$follow_list['data'][$key] = $v["data"];
					}else{
						$follow_list[$key] = $follow[$key];
					}
				}
			}
		}
		else { // 得到详细信息
			if(is_array($follow)){
				foreach($follow as $key => $v) {
					if(is_numeric($key)) {
						//获取对应的详细信息不做处理直接掉接口   
						if(in_array($this->g_para['type'],array('gto','gpo','gqo','gso','gpm'))){ // 获取用户信息                                     
							$follow_list['follow'][$key]['oid']	= $follow[$key]["keys"][0];
							$follow_list['follow'][$key]['time']	= $follow[$key]["keys"][1];
							$follow_list['follow'][$key]['uid']	= $follow[$key]["keys"][2];
							//匿名问题，话题需要
							if($this->g_para['type'] == 'gto' || $this->g_para['type'] == 'gqo'){
								$follow_list['data']	= $v["data"];
							}
						}
						elseif($this->g_para['type'] == 'gtm') { //获取话题信息
							$tagid = $follow[$key]["keys"][2];
							// 获取用户信息
							$follow_list['follow']["$tagid"]['uids']=$follow[$key]["keys"][0];                                     
							$follow_list['follow']["$tagid"]['time']=$follow[$key]["keys"][1];  
							//获取话题信息
							$t_res = $this->getbdb_obj->gets("tagid", $follow[$key]["keys"][2], $data);
							$follow_list['follow']["$tagid"]['tid'] = $follow[$key]["keys"][2];
							$follow_list['follow']["$tagid"]['tname'] = $data['name'];  //注意id                                    
							$follow_list['follow']["$tagid"]['desc'] = isset($data['description'])?$data['description']:'';
							$follow_list['follow']["$tagid"]['ctime'] = $data['ctime'];
							$follow_list['follow']["$tagid"]['imageid'] = isset($data['image'])?$data['image']:0;        
							$follow_list['follow']["$tagid"]['image'] = $this->image_obj->getlogo($follow_list['follow'][$key]['imageid'], "tc");
							$follow_list['follow']["$tagid"]['image_b'] = $this->image_obj->getlogo($follow_list['follow'][$key]['imageid'], "tb");
							$follow_list['follow']["$tagid"]['image_a'] = $this->image_obj->getlogo($follow_list['follow'][$key]['imageid'], "ta");            
							$follow_list['follow']["$tagid"]['showflag'] = isset($data['showflag'])?$data['showflag']:1; //默认显示
							$follow_list['follow']["$tagid"]['status'] = isset($data['status'])?$data['status']:0; //默认不锁定


						}
						elseif($this->g_para['type'] == 'gqm') { //获取问题信息
							$questionid = $follow[$key]["keys"][2];
							$follow_list['follow']["$questionid"]['uid']=$follow[$key]["keys"][0];
							$follow_list['follow']["$questionid"]['time']=$follow[$key]["keys"][1];
							$q_res = $this->getbdb_obj->gets("detail", $follow[$key]["keys"][2], $q_info);
							$follow_list['follow']["$questionid"]['qid'] = $q_info['questionid'];
							$follow_list['follow']["$questionid"]['title'] = $q_info['title'];
							$follow_list['follow']["$questionid"]['tag'] = $q_info['tag'];
							if(isset($q_info['atotal']) && isset($q_info['a'])){
								$follow_list['follow']["$questionid"]['atotal'] = $q_info['atotal'];
								$ansow = $q_info['a'];
								$follow_list['follow']["$questionid"]['a'] =  $q_info['a'];
							}
						}else if($this->g_para['type'] == 'gsm'){//我关注的收藏目录

						}

					}
					else{
						$follow_list[$key] = $follow[$key];
					}
				} //foreach end                        
			}
		} 

		// 执行订制功能
                $this->run_api_event();

		echo json_encode($follow_list);    
	}    

        /*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }
}
$app = new Getfollowlist;
$app->run();

?>
