<?php
/**
 * @fn              添加问题接口
 * @author          zhanghua2@staff.sina.com.cn
 * @version         v2
 * @link            /q/addquestion.php
 * @date            2012-06-07
 */

require_once('apiconf.php');

class Addfollow extends webApp implements Platform_Api {
	
        private $api_config_file;
        private $api_config;
        private $tools_obj;
        private $api_obj;
        public $g_para;
        public $g_result;

        function  __construct() {
                $this->_init_param();
                $this->_check_param();
                $this->_init_class();
                $this->_init_api_config();
        }

	/**
         *  获取参数
         **/
        function _init_param() {
		$this->g_para['app']	= isset($_REQUEST['app'])	? floatval($_REQUEST['app'])    : '';
		$this->g_para['uid']	= isset($_REQUEST['uid'])	? floatval($_REQUEST['uid'])    : '';
		$this->g_para['toid']	= isset($_REQUEST['toid'])	? floatval($_REQUEST['toid'])	: 0;
		$this->g_para['type']	= isset($_REQUEST['type'])	? trim($_REQUEST['type'])	: '';
		$this->g_para['owner']	= isset($_REQUEST['owner'])	? floatval($_REQUEST['owner'])  : 0;    //0正常，1匿名关注
		$this->g_para['time']	= isset($_REQUEST['ctime'])	? trim($_REQUEST['ctime'])      : date("Y-m-d H:i:s");
	}

        /**
         *  判断参数合法性
         **/
        function _check_param() {

                if(empty($this->g_para['app'])) {
                        $this->error_num(3000);
                }

                if(empty($this->g_para['uid'])) {
                        $this->error_num(2101);
                }
	
		if(empty($this->g_para['toid'])) {
                        $this->error_num(2003);
                }
		
		if(!in_array($this->g_para['type'] , array('user','tag','question'))) {
			$this->error_num(2403);
		}
        }
	
        /**
         *  初始化对象
         **/
        function _init_class() {

                $this->tools_obj= new Tools();
                $this->api_obj = new Follow($this->g_para , $this->g_result);
        }

        /*
        * 初始化接口功能
        */
        function _init_api_config() {
                $this->api_name = $this->g_para['api_name'] = 'addfollow';
                $this->api_config_file = ROOT_DIR . '/system/API_CONFIG_' . $this->g_para['app'];
                $this->api_config = $this->tools_obj->loadApiConfig($this->api_config_file);
                if(empty($this->api_config)) {
                        $this->error_num(3001);
                }
        }

        /**
         * 主函数
         **/
        function main() {

                $this->add_follow();
        }

	function add_follow() {

		$res['res'] = $this->api_obj->addfollow();
		//add feed start
		if($this->g_para['type'] == 'question'){
			$this->api_obj->add_feed();
		}
		//add feed end

		// 执行订制功能
                $this->run_api_event();

		echo json_encode($res);

	}

        /*
        * 调用接口功能订制列表
        */
        function run_api_event() {
                $cmd = @implode('' , $this->api_config[$this->api_name]['func']);
                if(!empty($cmd)) {
                        if(eval($cmd) === FALSE) {
                                $this->error_num(3002);
                        }
                }
        }
}
$app = new Addfollow;
$app->run();
?>
