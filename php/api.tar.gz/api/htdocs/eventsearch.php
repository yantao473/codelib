<?php
/*
 * 事件搜索
 * @author tingting18@
 * @copyright    copyright(2011) 新浪网研发中心 all rights reserved
 * @time  20120306
 */
require_once("apiconf.php");
class EventSearch extends webApp{
	private $smarty_obj,$rpcdb_obj,$getbdb_obj,$image_obj;
	private $g_para,$num;
	public function __construct(){
		$this->tools_obj = new Tools;
		$this->rpcdb_obj = new RpcDb();
		$this->getbdb_obj = new GetBdb();
		$this->image_obj = new images;
		$this->num = 20;  // 每次取20条记录显示
	} 
	/*
	 * 主要逻辑
	 */
	public function main(){
		$this->_check_cgi_pro();
		$info = $this->getinfo();
		#$total = $this->getinfototal();
		$infodata['res'] = $this->makeinfo($info);
		$infodata['total'] = count($infodata['res']);
		echo json_encode($infodata);exit;
	}

	/*
	 * 获取参数
	 */
	private function _check_cgi_pro(){
		// 默认时间为当前时间到前一小时时间
		$this->g_para['time2'] = !empty($_REQUEST['time2']) ? $_REQUEST['time2'] : date('Y-m-d H:i:s',time());
		$this->g_para['time1'] = !empty($_REQUEST['time1']) ? $_REQUEST['time1'] : date('Y-m-d H:i:s',(time()-3600));
		$this->g_para['category'] = $_REQUEST['category'] ? $_REQUEST['category'] : '';	
		$this->g_para['page'] = $_REQUEST['page'] ? $_REQUEST['page'] : 0;
	}
	/*
	 * 获取数据
	 */
	private function getinfo(){
		$dbname = 'stat';
		if(!empty($this->g_para['category']) && !empty($this->g_para['time1']) && !empty($this->g_para['time2'])){
			$startnum = $this->g_para['page'] * $this->num;
			$sql = "SELECT * FROM event_search WHERE eventid IN (".$this->g_para['category'].") AND createtime < '".$this->g_para['time2']."' AND createtime > '".$this->g_para['time1']."'    order by createtime desc limit $startnum,$this->num" ;
			$res = $this->rpcdb_obj->read($dbname, $sql, $data);			
		}else{
			exit('类别和时间都不能为空');
		}
		return $data;
	}
	private function getinfototal(){
		$dbname = 'stat';
		if(!empty($this->g_para['category']) && !empty($this->g_para['time1']) && !empty($this->g_para['time2'])){
			$sql = "SELECT count(eventid) as total FROM event_search WHERE eventid IN (".$this->g_para['category'].") AND createtime < '".$this->g_para['time2']."' AND createtime > '".$this->g_para['time1']."'";
			$res = $this->rpcdb_obj->read($dbname, $sql, $data);
		}else{
			exit('类别和时间都不能为空');
		}	
		return $data[0]['total'];
	}
	/*
	 * 处理数据
	 */
	private function makeinfo($data){

		if(is_array($data) && !empty($data)){
			foreach($data as $k=>$v){
				$content = unserialize($v['content']);		
				if(isset($content['questionid'])&&$content['questionid'] < 30000000){
					continue;
				}
				$info[$k]['eventid'] = $v['eventid'];
				$info[$k]['createtime'] = $v['createtime'];
				switch ($v['eventid']){
					case EVENT_QUESTION_ADD: //添加问题  1
					case EVENT_QUESTION_TITLE_UPDATE: //问题标题更新 28
					case EVENT_QUESTION_TAG_ADD: //问题话题添加 5
					case EVENT_QUESTION_TAG_DEL: //问题话题删除 6  -- 前台貌似没有提供删除按钮
					case EVENT_QUESTION_DESC_UPDATE: //问题描述更新 29
					{
						$info[$k]['qid'] = $content['questionid'];	
						$que = $this->get_queinfo($content['questionid']);
						$info[$k]['title'] = isset($content['title'])?htmlspecialchars($content['title']):$que['title'];
						$info[$k]['uid'] = $content['uid'];
						$info[$k]['nick'] =	$this->get_usernick($content['uid']) ;
						$info[$k]['desc'] = isset($content['description'])? htmlspecialchars($content['description']) : $que['desc'];
						$info[$k]['tag'] = isset($content['tag'])?$content['tag']:'';
						break;
					}
					case EVENT_ANSWER_ADD: //添加答案 7
					case EVENT_ANSWER_UPDATE: //更新答案 9
					{
						$info[$k]['aid'] = $content['answerid'];
						$info[$k]['answer'] = htmlspecialchars($content['answer']);
						$info[$k]['qid'] = $content['questionid'];	
						$que = $this->get_queinfo($content['questionid']);
						$info[$k]['title'] = isset($content['title'])? htmlspecialchars($content['title']):$que['title'];
						$info[$k]['uid'] = $content['uid'];
						$info[$k]['nick'] =	$this->get_usernick($content['uid']) ;
						break;
					}
					case EVENT_TAG_ADD://话题添加 32
					case EVENT_TAG_UPDATE: //话题更新 18
					case EVENT_TAG_UPDATE_LOGO: //话题修改头像 42
					{
						$info[$k]['tid'] = $content['tid'];
						$tname = $this->get_tname($content['tid']);
						$info[$k]['tname'] = isset($content['name'])? htmlspecialchars($content['name']):$tname['tname'];
						$info[$k]['uid'] = $content['uid'];
						$info[$k]['nick'] =	$this->get_usernick($content['uid']) ;
						$info[$k]['tdesc']	= isset($content['description'])? htmlspecialchars($content['description']) : $tname['tdesc'];  
						$info[$k]['image_c'] = isset($content['image'])?$this->image_obj->getlogo($content['image'], "tc") : $tname['image_c'];
						break;
					}
					default:
						break;
				}	// switch end
			} // foreach end
					
		}else{
			$info = array();
		}
		error_log(var_export($info,true),3,"/tmp/test");
		return $info;
	}
	
	private function get_usernick($uid){
		$flag = $this->getbdb_obj->gets('user', $uid , $data);
		$usernick = htmlspecialchars($data['nick']);
		return $usernick;
	}
	private function get_queinfo($qid){
		$result = $this->getbdb_obj->gets("question",$qid,$data); 	
		$que['title'] = !empty($data['title'])?htmlspecialchars($data['title']):"";
		$que['desc'] = !empty($data['description'])?htmlspecialchars($data['description']):"";
		return $que;
	}
	private function get_tname($tid){
		$res = $this->getbdb_obj->gets("tagid",$tid,$data);
		$tname['tname'] = htmlspecialchars($data['name']);
		$tname['tdesc'] = isset($data['description'])?htmlspecialchars($data['description']):'';
		$imageid = isset($data['image'])?$data['image']:0; 
		$tname['image_c'] = $this->image_obj->getlogo($imageid, "tc");
		return $tname;
	}
}
$app = new EventSearch();
$app->run();
echo "/////";
