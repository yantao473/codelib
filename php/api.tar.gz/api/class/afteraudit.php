<?php
/*
 * editor by : zhanghua2 
 */
class afteraudit {
	private static $pub;
	private static $tools;
	private static $mysql_db;
	private static $rpc_db;
	private static $dbname;
	private static $queue_obj;
	private static $dealimg_obj;	

	public static function doaudit(&$args) {
		self::$tools = new Tools();
		self::$mysql_db = new MysqlDb();
		self::$rpc_db = new RpcDb();
		self::$dbname = 'stat';
		self::$queue_obj = new QueueTool();
		self::$dealimg_obj = new dealimg();

		if(!$args['audit_tag']) {
			return -10;
		}

		print_r($args);

		switch($args['audit_tag']) {
			// 添加问题
			case 'weiboask_eid_'.EVENT_QUESTION_ADD :
				if($args['audit_type'] == 'P') {
					// 添加问题删除后没有版本回退
					if($args['audit_result'] == 'D') {
						$api = DOMAIN . '/q/upquestion.php';
						$data = array(
								'questionid'	=> $args['data']['questionid'],
								'uid'		=> $args['data']['uid'],
								'showflag'	=> 1, // 正常 0;隐藏 1;
								'app'		=> $args['data']['app'],
							     );
						print_r($data);
						self::$tools->curl_set($api , 'post' , $data , &$json);
						$flag = json_decode($json , true);
						var_dump($flag);
						return 0;
					}
					// 发布的话 会建立版本库
					else {
						self::reversion($args , 'add');
						return 0;
					}
				}
				elseif($args['audit_type'] == 'A') {
					if($args['audit_result'] == 'P') {
						// 发布到线上

						$api = DOMAIN . '/q/addquestion.php';
						$data = $args['data'];
						self::$tools->curl_set($api , 'post' , $data , &$json);
						$flag = json_decode($json , true);
						$args['data']['questionid'] = $flag['questionid'];
						// 建立版本
						self::reversion($args , 'add');
						//先发后审 邀请专家 start
						if(isset($args['data']['toexpert']) && !empty($args['data']['toexpert'])){
							$api = DOMAIN . '/q/addinvite.php';
							$expertids = @explode(",",$args['data']['toexpert']);
							if(!empty($expertids)){
								foreach($expertids as $v){
									$data = array();
									$data = array(
											"app"=>1,
											"syncid"=>1, 
											"uid"=>$args['data']['uid'],
											"questionid"=>$args['data']['questionid'],
											"touid"=>$v
									);
									self::$tools->curl_set($api , 'post' , $data , $json);
									echo "invite post data :\n";
									var_dump($data);
									echo "return : \n";
									var_dump($json);
								}
							}
						}
							
						//先发后审 邀请专家 end
						return 0;
					}
					else{
						return 0;
					}
				}
				break;
				// 更新问题
			case 'weiboask_eid_'.EVENT_QUESTION_UPDATE :
				if($args['audit_type'] == 'P') {
					if($args['audit_result'] == 'D') {
						// 版本回退
						self::reversion($args , 'rev');
						return 0;
					}
					else {
						// 更新版本
						self::reversion($args , 'add');
						return 0;
					}
				}
				elseif($args['audit_type'] == 'A') {
					if($args['audit_result'] == 'P') {
						$data = array(
								'questionid'	=> $args['data']['questionid'],
								'title'		=> $args['data']['title'],
								'desc'		=> $args['data']['desc'],
								'utime'		=> date('Y-m-d H:i:s'),
								'uid'		=> $args['data']['uid'],
								'status'	=> $args['data']['status'] ? $args['data']['status'] : 0, // 正常 0;隐藏 1;  锁定 2
								'tag'		=> $args['data']['tag'],
								'deltag'	=> $args['data']['deltag'],
								'share_wb'	=> $args['data']['share_wb'],
								'showflag'	=> 0,
								'app'		=> $args['data']['app'],
								'link'      => $args['data']['link'],                 
                                                        	'imgtags'       => $args['data']['imgtags'],    
							     );
						$api = DOMAIN . '/q/upquestion.php';
						self::$tools->curl_set($api , 'post' , $data , $json);
						$flag = json_decode($json , true);
						// 更新版本
						self::reversion($args , 'add');
						return 0;
					}
					else {
						return 0;
					}
				}
				break;
				// 添加回答
			case 'weiboask_eid_'.EVENT_ANSWER_ADD :
				if($args['audit_type'] == 'P') {
					if($args['audit_result'] == 'D') {
						$data = array(
								'questionid'	=> $args['data']['questionid'],
								'answerid'	=> $args['data']['answerid'],
								'uid'		=> $args['data']['uid'],
								'utime'		=> $args['data']['utime'],
								'answer'	=> $args['data']['answer'],
								'adopt'		=> $args['data']['adopt'],
								'showflag'	=> 1,
								'audit_del'	=> 1,
								'app'           => isset($args['data']['app']) ? $args['data']['app'] : 1 ,
							     );
						$api = DOMAIN . '/q/upans.php';
					}
					else {
						//set audit status start 20120927
						$qapi =  DOMAIN . '/q/upquestion.php';
						$audit_set_status = array(
								'app'           => isset($args['data']['app']) ? $args['data']['app'] : 1,
								'auditaflag'	=> 2,
								'questionid'    => $args['data']['questionid'],
								'utime'         => $args['data']['utime'],
								'uid'		=> $args['data']['uid'],
								);	
						self::$tools->curl_set($qapi , 'post' , $audit_set_status , $json);
						//set audit status end
						return 0;
					}
				}
				elseif($args['audit_type'] == 'A') {
					if($args['audit_result'] == 'P') {
						$args['data']['app'] = 1;
						$data = $args['data'];
						$api = DOMAIN . '/q/addans.php';
					}
					else {
						//set audit status start 20120927
						$qapi =  DOMAIN . '/q/upquestion.php';
						$audit_set_status = array(
								'app'           =>  isset($args['data']['app']) ? $args['data']['app'] : 1,
								'auditaflag'	=> 2,
								'questionid'    => $args['data']['questionid'],
								'utime'         => $args['data']['utime'],
								'uid'		=> $args['data']['uid'],
								);	
						self::$tools->curl_set($qapi , 'post' , $audit_set_status , $json);
						//set audit status end
						return 0;
					}
				}
				//set audit status start 20120927
				$qapi =  DOMAIN . '/q/upquestion.php';
				$audit_set_status = array(
						'app'           => 1,
						'auditaflag'	=> 2,
						'questionid'    => $args['data']['questionid'],
						'utime'         => $args['data']['utime'],
						'uid'		=> $args['data']['uid'],
						);	
				self::$tools->curl_set($qapi , 'post' , $audit_set_status , $json);
				//set audit status end

				self::$tools->curl_set($api , 'post' , $data , $json);
				echo '发送数组:';print_r($data);
				echo '返回值:';var_dump($json);
				$flag = json_decode($json , true);
				//从后台23审核服务拉图片
				self::get_pic($args);
				//deal answer images
				self::$dealimg_obj->answer_images($args);
				break;
				// 编辑回答
			case 'weiboask_eid_'.EVENT_ANSWER_UPDATE :
				if($args['audit_type'] == 'P') {
					if($args['audit_result'] == 'D') {
						$data = array(
								'questionid'    => $args['data']['questionid'],
								'answerid'      => $args['data']['answerid'],
								'utime'         => $args['data']['utime'],
								'showflag'      => 1,
								'audit_del'	=> 1,
								'app'           => isset($args['data']['app']) ? $args['data']['app'] : 1,
							     );
						$api = DOMAIN . '/q/upans.php';
					}
					else {
						//set audit status start 20120927
						$qapi =  DOMAIN . '/q/upquestion.php';
						$audit_set_status = array(
								'app'           => 1,
								'auditaflag'	=> 2,
								'questionid'    => $args['data']['questionid'],
								'utime'         => $args['data']['utime'],
								'uid'		=> $args['data']['uid'],
								);	
						self::$tools->curl_set($qapi , 'post' , $audit_set_status , $json);
						//set audit status end
						return 0;
					}
				}
				elseif($args['audit_type'] == 'A') {
					if($args['audit_result'] == 'P') {
						$args['data']['app'] = 1;
						$data = $args['data'];
						$api = DOMAIN . '/q/upans.php';
					}
					else {
						//set audit status start 20120927
						$qapi =  DOMAIN . '/q/upquestion.php';
						$audit_set_status = array(
								'app'           => 1,
								'auditaflag'	=> 2,
								'questionid'    => $args['data']['questionid'],
								'utime'         => $args['data']['utime'],
								'uid'		=> $args['data']['uid'],
								);	
						self::$tools->curl_set($qapi , 'post' , $audit_set_status , $json);
						//set audit status end
						return 0;
					}		
				}
				//set audit status start 20120927
				$qapi =  DOMAIN . '/q/upquestion.php';
				$audit_set_status = array(
						'app'           => 1,
						'auditaflag'	=> 2,
						'questionid'    => $args['data']['questionid'],
						'utime'         => $args['data']['utime'],
						'uid'		=> $args['data']['uid'],
						);	
				self::$tools->curl_set($qapi , 'post' , $audit_set_status , $json);
				//set audit status end
				print_r($data);
				self::$tools->curl_set($api , 'post' , $data , $json);
				$flag = json_decode($json , true);
				//从后台23审核服务拉图片
				self::get_pic($args);
				//deal answer images
				self::$dealimg_obj->answer_images($args);
				break;
				// 添加评论
			case 'weiboask_eid_' . EVENT_COMMENT_ADD :
				if($args['audit_type'] == 'P') {
					if($args['audit_result'] == 'D') {
						$data = array(
								'type'	=>	$args['data']['type'],
								'cid'	=>	$args['data']['cid'],
								'app'   =>	$args['data']['app'],
							     );
						$api = DOMAIN . '/q/delcomment.php';
					}
					else {
						return 0;
					}
				}
				elseif($args['audit_type'] == 'A') {
					if($args['audit_result'] == 'P') {
						$data = $args['data'];
						$api = DOMAIN . '/q/addcomment.php';
					}
					else {
						return 0;
					}
				}
				self::$tools->curl_set($api , 'post' , $data , $json);
				$flag = json_decode($json , true);
				break;
				// 修改话题头像 只有先发后审 没有先审后发 所以这里可以只删除话题
			case 'weiboask_eid_' . EVENT_TAG_UPDATE_LOGO : 
				if($args['audit_type'] == 'P') {
					if($args['audit_result'] == 'D') {
						// 版本回退
						self::reversion($args , 'rev');
						return 0;
					}
					else {
						// 版本更新
						self::reversion($args , 'add');
						return 0;
					}
				}
				elseif($args['audit_type'] == 'A') {
					if($args['audit_result'] == 'P') {
						return 0;
					}
					else {
						return 0;
					}
				}
				break;
				// 修改话题描述
			case 'weiboask_eid_' . EVENT_TAG_UPDATE :
				if($args['audit_type'] == 'P') {
					if($args['audit_result'] == 'D') {
						// 版本回退
						self::reversion($args , 'rev');
					}
					else {
						// 版本更新
						self::reversion($args , 'add');
					}
				}
				elseif($args['audit_type'] == 'A') {
					if($args['audit_result'] == 'P') {
						// 发布更新的话题 
						$data = array(
								'tid'	=> $args['data']['tid'],
								'uid'	=> $args['data']['uid'],
								'desc'	=> $args['data']['desc'],
								'showflag'	=> 0,	// '0表示显示，1为隐藏'
								'app'           => $args['data']['app'],
							     );
						$api = DOMAIN . '/t/uptag.php';
						// 版本更新
						self::reversion($args , 'add');
					}
					else {
						return 0;
					}
				}
				self::$tools->curl_set($api , 'post' , $data , $json);
				$flag = json_decode($json , true);
				break;
		}
	}

	function get_pic($origdata){
		if(!empty($origdata['data']['answer'])) {
              		$preg = '~\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
                        preg_match_all($preg , $origdata['data']['answer'] , $match);
                        if(!empty($match[0])) {
                        	foreach($match[0] as $key => $val) {
                                	$file_name = $origdata['data']['questionid'].'_'.$match[2][$key].'.'.$match[3][$key];
                                        $wjj = $origdata['data']['questionid']%100;
					$dir = '/data0/weibo_attached/answer_pic/'.$wjj.'/';

                                        if(!file_exists($dir . $file_name)) {
                				$cmd = 'rsync -v 10.44.3.23::WEIBO_ATTACHED/'.$match[1][$key].'/'.$file_name. ' '.$dir;
                				echo $cmd . "\n";                                                                          				     @system($cmd , $ret);
						if($ret != 0) {
							@system($cmd , $ret);                                                              
                				}  

                                 	}
                        	}                                                                  
                        }                                                                          
                }      
	}

	// 版本回退逻辑
	function reversion(&$args , $act) {
		echo 'reversion : ' . "\n";
		switch($args['audit_tag']) {	
			case 'weiboask_eid_'.EVENT_QUESTION_ADD :
				if($act == 'add') {
					// 理论上一个问题的添加事件只会出现1次 但是考虑到队列误操作的可能性 也需要对库做查询判断
					$table = 'question_reversion';
					$sql = 'select * from '.$table.' where `questionid` = '.$args['data']['questionid'];
					self::$rpc_db->read(self::$dbname , $sql , $data);
					$row['questionid']	= $args['data']['questionid'];
					$row['uid']		= $args['data']['uid'];
					$row['title']		= $args['data']['title'];
					$row['description']	= $args['data']['desc'];
					$row['tags']		= $args['data']['tag'];
					$row['ctime']		= $args['time'];
					if(!empty($data[0])) {
						$sql = self::$mysql_db->prepare_update_sql($table , $row);	
						$sql .= " WHERE `questionid` = '{$row[questionid]}'" ;
						$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
					} else {
						$sql = self::$mysql_db->prepare_insert_sql($table, $row);
						$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
					}
					echo $sql . "\n";
					var_dump($flag);
					var_dump($data);
				}
				break;
				// 更新问题
			case 'weiboask_eid_'.EVENT_QUESTION_UPDATE :
				$table = 'question_reversion';
				$sql = 'select * from '.$table.' where `questionid` = '.$args['data']['questionid'];
				self::$rpc_db->read(self::$dbname , $sql , $data);

				if($act == 'add') {
					$row['questionid']	= $args['data']['questionid'];
					$row['uid']		= $args['data']['uid'];
					$row['title']		= $args['data']['title'];
					$row['description']	= $args['data']['desc'];
					$row['tags']		= $args['data']['all_tags'];
					$row['ctime']		= $args['data']['utime'];
					// 要判断先后时间
					if(!empty($data[0])) {
						// 如果后台的数据时间 大于 库里的时间 就更新库
						if(strtotime($args['data']['utime']) > strtotime($data[0]['ctime'])) {
							$sql = self::$mysql_db->prepare_update_sql($table , $row);	
							$sql .= " WHERE `questionid` = '{$row[questionid]}'" ;
							$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
						}
						else {
							return 0;
						}
					}
					// 如果库里没有数据(应该在新增数据的时候就有数据的)考虑特殊情况 就增加数据
					else {
						$sql = self::$mysql_db->prepare_insert_sql($table, $row);
						$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
					}
					echo $sql ."\n";
					var_dump($flag);
				}
				elseif($act == 'rev') {
					if(!empty($data[0])) {
						// 用版本信息更新线上
						// 此处比较特别 API平台更新问题接口对于话题接收两个参数 tag,deltag
						// 分别是增加的话题 和 删除的话题 , 对应两个事件类型
						// 所以版本库中的tag字段 只是记录的话题被通过时的tag总体情况
						// 如果想使之生效 那么要根据当前线上的tag状态 与版本库里的tag字段进行
						// 分别求交集 和 差集 传递给API接口 这样线上相应问题的话题信息 才可以
						// 实际做到版本回退 . 线上的tag信息只能实时取,无法记录在版本库中
						// 需注意
						$api = DOMAIN . '/q/getquestion.php';
						$post_data = array('questionid' => $data[0]['questionid'] , 'app' => API_APP_ID);
						self::$tools->curl_set($api , 'post' , $post_data , &$json);
						$q_info = json_decode($json , true);
						$old_tags = is_array($q_info['tags']) ? $q_info['tags'] : array();
						$now_tags = explode(',' , $data[0]['tags']);
						// 获得应该增加的话题 和 应该删除的话题
						$del_tags = array_diff($old_tags , $now_tags);
						$add_tags = array_diff($now_tags , $old_tags);

						$post_data = array(
								'questionid'    =>  $data[0]['questionid'],
								'title'         =>  $data[0]['title'],
								'desc'          =>  $data[0]['description'],
								'tag'           =>  implode(',' , $add_tags),
								'deltag'	=>  implode(',' , $del_tags),
								'utime'         =>  date('Y-m-d H:i:s'),
								'uid'           =>  $data[0]['uid'],
								'nolog'	=>  1,  // 存在此参数表示不对日志进行对比 
								'app'		=> API_APP_ID,
								);
						// 删除历史日志
						// 删除标题修改日志
						if(!empty($args['data']['logids'])) {
							foreach($args['data']['logids'] as $k => $logid) {
								$dellog_queue_data = array(
										'0'	=> EVENT_LOG_DEL,
										'uid'	=> $args['data']['uid'],
										'ctime'	=> $args['data']['utime'],
										'oid'	=> $args['data']['questionid'],
										'type'	=> EVENT_QUESTION_TITLE_UPDATE,
										'logid' => $logid,
										);
								self::$queue_obj->AddToLocalQueue(BDB_QUEUE_DATA_FILE , $dellog_queue_data , BDB_QUEUE_ID);
								// 删除描述修改日志
#$dellog_queue_data['type'] = EVENT_QUESTION_DESC_UPDATE;
#$dellog_queue_data['ctime'] = date('Y-m-d H:i:s',strtotime($dellog_queue_data['ctime']) + 1);
#self::$queue_obj->AddToLocalQueue(API_QUEUE_DATA_FILE , $dellog_queue_data , API_QUEUE_ID);
							}
						}

					} else {
						// 无版本信息则直接对线上数据做隐藏
						$post_data = array(
								'questionid'	=> $args['data']['questionid'],
								'uid'		=> $args['data']['uid'],
								'showflag'	=> 1, // 正常 0;隐藏 1;  锁定 2
								'app'		=> API_APP_ID,
								);
					}
					print_r($post_data);
					$api = DOMAIN . '/q/upquestion.php';
					self::$tools->curl_set($api , 'post' , $post_data , &$json);
					$flag = json_decode($json , true);
				}
				break;
			case 'weiboask_eid_' . EVENT_TAG_UPDATE_LOGO :
				$table = 'tag_reversion';
				$sql = 'select * from '.$table.' where `tid` = '.$args['data']['tid'];
				self::$rpc_db->read(self::$dbname , $sql , $data);
				if($act == 'add') {
					$row['tid']	= $args['data']['tid'];
					$row['uid']	= $args['data']['uid'];
					$row['image']	= $args['data']['image'];
					$row['pic_ctime'] = $args['time'];
					// 要判断先后时间
					if(!empty($data[0])) {
						// 如果后台的数据时间 大于 库里的时间 就更新库
						if(strtotime($args['time']) > strtotime($data[0]['pic_ctime'])) {
							$sql = self::$mysql_db->prepare_update_sql($table , $row);	
							$sql .= " WHERE `tid` = '{$row[tid]}'" ;
							$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
						}
						else {
							return 0;
						}
					}
					else {
						$sql = self::$mysql_db->prepare_insert_sql($table, $row);
						$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
					}
				}
				elseif($act == 'rev') {
					if(!empty($data[0])) {
						// 用版本信息更新线上
						$post_data = array(
								'tid'	=>  $data[0]['tid'],
								'uid'	=>  $data[0]['uid'],
								'image' =>  $data[0]['image'],
								'nolog' => 1,
								'app'	=> API_APP_ID,
								);
					} else {
						// 无版本信息则直接对线上数据做隐藏
						$post_data = array(
								'tid'	=>  $args['data']['tid'],
								'uid'	=>  $args['data']['uid'],
								'showflag'	=> 1,
								'app'	=> API_APP_ID,
								);
						// 如果隐藏话题的话 需要把关联的问题下的话题删除掉
						$bdb_special['tid'][] = $args['data']['tid'];
						$bdb_special['bdbspecial'] = 1;
						$ser_array = array('data'=>serialize($bdb_special));
						self::$tools->curl_set(QDOMAIN . '/send_queue.php','POST',$ser_array,$result);
					}
					$api = DOMAIN . '/t/uptag.php';
					self::$tools->curl_set($api , 'post' , $post_data , &$json);
					$flag = json_decode($json , true);
				}
				break;
				// 修改话题描述
			case 'weiboask_eid_' . EVENT_TAG_UPDATE :
				$table = 'tag_reversion';
				$sql = 'select * from '.$table.' where `tid` = '.$args['data']['tid'];
				self::$rpc_db->read(self::$dbname , $sql , $data);
				if($act == 'add') {
					$row['tid']	= $args['data']['tid'];
					$row['uid']	= $args['data']['uid'];
					$row['name']	= $args['data']['tname'];
					$row['description']	= $args['data']['desc'];
					$row['ctime']	= $args['time'];
					// 要判断先后时间
					if(!empty($data[0])) {
						// 如果后台的数据时间 大于 库里的时间 就更新库
						if(strtotime($args['time']) > strtotime($data[0]['ctime'])) {
							$sql = self::$mysql_db->prepare_update_sql($table , $row);	
							$sql .= " WHERE `tid` = '{$row[tid]}'" ;
							$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
						}
						else {
							return 0;
						}
					}
					else {
						$sql = self::$mysql_db->prepare_insert_sql($table, $row);
						$flag = self::$rpc_db->update(self::$dbname, $sql, $data);
					}
					echo $sql . "\n";
					var_dump($flag);

				}
				elseif($act == 'rev') {
					if(!empty($data[0])) {
						// 用版本信息更新线上
						$post_data = array(
								'tid'	=>  $data[0]['tid'],
								'uid'	=>  $data[0]['uid'],
								'tname'	=>  $data[0]['name'],
								'desc'	=>  $data[0]['description'],
								'nolog' => 1,  // nolog 为1表示不进行版本比较
								'app'	=> API_APP_ID,
								);
						// 删除历史日志
						// 删除标题修改日志
						$dellog_queue_data = array(
								'0'	=> EVENT_LOG_DEL,
								'uid'	=> $args['data']['uid'],
								'ctime'	=> $args['data']['utime'],
								'oid'	=> $args['data']['tid'], 
								'type'	=> EVENT_TAG_UPDATE,
								);
						self::$queue_obj->AddToLocalQueue(BDB_QUEUE_DATA_FILE , $dellog_queue_data , BDB_QUEUE_ID);
					} else {
						// 无版本信息则直接对线上话题做隐藏
						$post_data = array(
								'tid'	=>  $args['data']['tid'],
								'uid'	=>  $args['data']['uid'],
								'showflag'	=> 1,
								'app'	=> API_APP_ID,
								);
						// 如果隐藏话题的话 需要把关联的问题下的话题删除掉
						$bdb_special['tid'][] = $data[0]['tid'];
						$bdb_special['bdbspecial'] = 1;
						$ser_array = array('data'=>serialize($bdb_special));
						self::$tools->curl_set(QDOMAIN . '/send_queue.php','POST',$ser_array,$result);
					}
					$api = DOMAIN . '/t/uptag.php';
					self::$tools->curl_set($api , 'post' , $post_data , $json);
					$flag = json_decode($json , true);
					print_r($post_data);
					var_dump($flag);
				}
				break;
		}
	}
}
?>
