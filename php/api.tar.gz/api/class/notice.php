<?php
if (class_exists('Notice'))
{
    return true;
}else{
	Class Notice{
		private $Aplication;
		private $operationHander;
		private $MCHander;
		private $g_system_error_msg = array(
							0=>'OK',
							1=> 'IP不合法',

							2=> '参数不正确',
							3=> '参数不能为空',

							4=> '该好友为黑名单',
							5=> '重复',
							6=> '超出容量',

							7=> '数据库连接错误',
							8=> '数据库操作错误',
							11=> '缓存连接错误',

							9=> '系统忙',
							10=> '未知错误',
							16=> '调用队列接口出错',

							17 => '发送uid格式错误',
							12 => '接收uid格式错误',
							13 => '邀请类型格式错误',
							19 => '该邀请已经发过',
							14 => '组类型格式错误',
						    15 => '不能发送给自己',
							15 => '不能给自己发送',

							18 => '不存在该数据',
		);
		
		public function get_error() {
			return $this->Error;
		}

		/**
		 * @param int $Error
	 	*/
		private function set_error($Error) {
			$this->Error = $Error;
		}		
		
		public function __construct($app=2){			
			$this->Application = $app;
			$this->operationHander = new Notice_Operation($app);
			//$this->MCHandler = new MemcacheClass();
		}
		///////////////////////////////////////////////////////////////////////////////////////////
		//以下是添加信息
		///////////////////////////////////////////////////////////////////////////////////////////
		
		public function add_notice($fromuid,$content,$otheruid=0,$status=1,$productid=0){
			//add_one_with_content($fromuid,$touid,$content,$productid,$type=0,$status=0,$uniq_key="")
			$result =   $this->operationHander->add_one_with_content($fromuid,$otheruid,$content,0,1,$status,"");
			if($result){
				return $this->result_output();
			}else{
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);				
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////
		//以下是删除信息
		///////////////////////////////////////////////////////////////////////////////////////////
		
		public function del_notice($uid,$arr_id){
			$result = $this->operationHander->del_relation_more($uid,$arr_id);
			if($result){
				return $this->result_output();
			}else{
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);				
			}			
		} 

		public function empty_all($uid,$otheruid = 0,$productid = 0){
			$result = $this->operationHander->destroy_relation_by_uid($uid,$otheruid,$productid);
			if($result){
				return $this->result_output();
			}else{
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);				
			}
		}

		///////////////////////////////////////////////////////////////////////////////////////////
		//以下是修改信息
		///////////////////////////////////////////////////////////////////////////////////////////		
		
		public function up_realtion($owneruid,$ids,$type=0){
			//update info from table relation by id	
			//up_realtion_more($owneruid,$ids,$type)
			$result =  $this->operationHander->up_realtion_more($owneruid,$ids,$type);
			if($result){
				return $this->result_output();
			}else{
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);				
			}		
		}
		
		//up_relation_batch($owneruid,$type)
		public function up_relation_batch($owneruid,$category=0,$type=0){
			//update info from table realtion by uid
			$result =  $this->operationHander->up_relation_batch($owneruid,$category,$type);			
			if($result){
				return $this->result_output();
			}else{
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);				
			}
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////
		//以下是查找信息
		///////////////////////////////////////////////////////////////////////////////////////////
		//get_list_by_uid($uid,$pagesize,$page,$lastid=0,$status,$productid=0)
		public function  get_notice_list($uid,$pagesize,$page,$lastid=0,$status=0,$productid=0,$category=0){
			$result = $this->operationHander->get_list_by_uid($uid,$pagesize,$page,$lastid,$status,$productid,$category);
			if($result===false){
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);	
			}else{
				return $this->result_output(0,$result);			
			}		
		}
		/*
		 * categroy: 11 comment ; 26 invite; 13 voted;  7 answer
		 */
		public function  get_notice_list_by_group($uid,$pagesize,$page,$category=0,$status=0,$lastid=0,$productid=0){
			$result = $this->operationHander->get_list_by_uid($uid,$pagesize,$page,$lastid,$status,$productid,$category);
			if($result===false){
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);	
			}else{
				$data = $result;
				if(count($data)<1){
					return $this->result_output(18);#no data
				}
				switch ($category) {
					
					case 7:  //case answer
						$cj = 10;
						$thefirst = 0;
						foreach ($data as $tmp_data){						
							$mid = $tmp_data["id"];
							$ctime = $tmp_data["ctime"];
							$tmp_status = $tmp_data["status"];
							$data_array = unserialize($tmp_data["content"]);
							if($data_array[0] != $category){
								continue;
							}
							$questionid =$data_array["questionid"];
							$tmp_array =  array(
								"mid"=>"$mid",
								"ctime"=>"$ctime",
								"aid"=>$data_array["answerid"],
								"uid"=>$data_array["uid"],
								"owner"=>$data_array["owner"],
								"qid"=>$questionid,						
								"status"=>$tmp_status,
							);
							if($tmp_status==1){	 //new 			
								$array_answer["new"]["$questionid"][$cj] = $tmp_array;
							}else{
								$array_answer["old"]["{$cj}_".$questionid][0] = $tmp_array;
							}
							$cj++;						
						}
						return $this->result_output(0,$array_answer);							
					break;
					
					case 11: //case comment
						$cj = 10;
						$thefirst = 0;
						foreach ($data as $tmp_data){						
							$mid = $tmp_data["id"];
							$ctime = $tmp_data["ctime"];
							$tmp_status = $tmp_data["status"];
							$data_array = unserialize($tmp_data["content"]);
							if($data_array[0] != $category){
								continue;
							}
							$array_data_append = unserialize($data_array["data_append"]);
							$questionid = $array_data_append["questionid"];
							if($data_array["type"]==2){ //对回答的评论回答
								$array_comment[$cj] = array(
									"type"=>2,
									"qid"=>$questionid,									
									"mid"=>"$mid",
									"ctime"=>"$ctime",
									"answerid"=>$data_array["targetid"],//答案id
									"auid"=>@$data_array["auid"],//所评论的答案提供者uid
									"uid"=>$data_array["uid"], //评论人的uid
									"comment"=>$data_array["comment"],
									"status"=>$tmp_status,
								);
							}elseif($data_array["type"]==1){
								$array_comment[$cj] = array(
									"type"=>1,
									"qid"=>$questionid,
									"mid"=>"$mid",
									"ctime"=>"$ctime",
									"uid"=>$data_array["uid"], 								
									"comment"=>$data_array["comment"],
									"status"=>$tmp_status,
								);
							}
							$cj++;
						}
						return $this->result_output(0,$array_comment);
					break;
					
					case 13: //case voted
						$cj = 10;
						$thefirst = 0;
						foreach ($data as $tmp_data){					
							$mid = $tmp_data["id"];
							$ctime = $tmp_data["ctime"];
							$tmp_status = $tmp_data["status"];
							$data_array = unserialize($tmp_data["content"]);
							if($data_array[0] != $category){
								continue;
							}
							$questionid =$data_array["questionid"]; 
							$array_vote[$cj] = array(
								"mid"=>"$mid",
								"ctime"=>"$ctime",
								"vid"=>$data_array["voteid"],
								"qid"=>$data_array["questionid"],
								"uid"=>$data_array["uid"],
								"aid"=>$data_array["answerid"],
								"status"=>$tmp_status,
							);						
							$cj++;						
						}
						return $this->result_output(0,$array_vote);							
					break;
										
					case 26: //case invite
						$cj = 10;
						$thefirst = 0;
						foreach ($data as $tmp_data){						
							$mid = $tmp_data["id"];
							$ctime = $tmp_data["ctime"];
							$tmp_status = $tmp_data["status"];
							$data_array = unserialize($tmp_data["content"]);
							if($data_array[0] != $category){
								continue;
							}
							$questionid =$data_array["questionid"];						
							$array_invite[$cj] = array(
								"qid"=>$questionid,
								"mid"=>"$mid",
								"ctime"=>"$ctime",
								"inviter"=>$data_array["uid"],
								"status"=>$tmp_status,
							);						
							$cj++;						
						}
						return $this->result_output(0,$array_invite);						
					break;
					
					default:
						return $this->result_output(2); // param error;
					break;
				}
				
				
				
			}				
		
		
		}
		
		
		
		
		public function get_notice_list_zip($uid,$getnum = 100,$productid=0){			
			$array_zip = array();
			$result = $this->operationHander->get_list_by_uid($uid,$getnum,1,0,1,0);
			$err_code = intval(@$result["err_code"]);
			if($result===false || $err_code !=0 ){
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);
			}else{
				$data = $result;
				if(count($data)<1){
					return $this->result_output(18);#no data
				}
				$array_answer = array();
				$array_comment = array();
				$array_vote = array();
				$array_invite = array();
				$array_other = array();
				$array_adopt = array();
				$cj = 0;
				foreach ($data as $tmp_data){
					$cj++;
					$mid = $tmp_data["id"];
					$ctime = $tmp_data["ctime"];
					$data_array = unserialize($tmp_data["content"]);
					if($data_array[0]==13){
						$array_vote[] = array(
							"mid"=>"$mid",
							"ctime"=>"$ctime",
							"vid"=>$data_array["voteid"],
							"qid"=>$data_array["questionid"],
							"uid"=>$data_array["uid"],
							"aid"=>$data_array["answerid"],
						);						
					}elseif($data_array[0]==7){
						$questionid =$data_array["questionid"]; 
						$array_answer["$questionid"][] = array(
							"mid"=>"$mid",
							"ctime"=>"$ctime",
							"aid"=>$data_array["answerid"],
							"uid"=>$data_array["uid"],
							"owner"=>$data_array["owner"],						
						);						
					}elseif($data_array[0]==11){
						$array_data_append = unserialize($data_array["data_append"]);
						$questionid = $array_data_append["questionid"];
						if($data_array["type"]==2){ //对回答的评论回答
							$array_comment["$questionid"][2][] = array(
								//"ctime"=>"$tmp_data[ctime]",
								"mid"=>"$mid",
								"ctime"=>"$ctime",
								"answerid"=>$data_array["targetid"],//答案id
								"auid"=>@$data_array["auid"],//所评论的答案提供者uid
								"uid"=>$data_array["uid"], //评论人的uid
							);
						}elseif($data_array["type"]==1){
							$array_comment["$questionid"][1][] = array(
								"mid"=>"$mid",
								"ctime"=>"$ctime",
								"uid"=>$data_array["uid"], 								
							);
						}						
					}elseif($data_array[0]==26){
						$questionid =$data_array["questionid"];
						
						$array_invite["$questionid"][] = array(
							"mid"=>"$mid",
							"ctime"=>"$ctime",
							"inviter"=>$data_array["uid"],
						);
					}elseif($data_array[0]==41){ //41 is take it right
						$questionid =$data_array["questionid"];
						$array_adopt["$questionid"] = array(
							"mid"=>"$mid",
							"ctime"=>"$ctime",
							"qid"=>$data_array["questionid"],
							"aid"=>$data_array["answerid"],
							"uid"=>@$data_array["uid"],

                                                );
					}else{
					
					}
					//now deal the time
					if($data_array[0]==13){
						if(!isset($array_time["vote"])){
							$array_time["vote"] = $tmp_data["ctime"];
						}else if($tmp_data["ctime"]>$array_time["vote"]){
							$array_time["vote"] = $tmp_data["ctime"];
						}

					}else{
						
						if(!isset($array_time_question["$questionid"])){
							$array_time_question["$questionid"] = $tmp_data["ctime"];
						}else if($tmp_data["ctime"]>$array_time_question["$questionid"]){
							$array_time_question["$questionid"] = $tmp_data["ctime"];
						}
					}
			
				}
				if(count($array_time_question)>0){
					foreach($array_time_question as $tmp_qid => $qctime){
						$array_zip["question"]["$tmp_qid"]["ctime"] = $qctime;

					}	
				}
			
				if(count($array_vote)>0){
					$num =count($array_vote);
					$array_zip["vote"] = array(
						"flag"=>"vote",
						"num" => "$num",
						"ctime"=>$array_time["vote"],
						"desc"=> $array_vote,						
					);
					
				}
				
				if(count($array_answer)>0){
					foreach ($array_answer as $tmp_qid => $tmp_array){
						$num =count($tmp_array);
						$array_zip["question"]["$tmp_qid"]["answer"] = array(
							"flag"=>"answer",
							"num" => "$num",
							"qid" => "$tmp_qid",
							"desc"=> $tmp_array,						
						);
					}
				}				
				
				if(count($array_invite)>0){
                                        foreach ($array_invite as $tmp_qid => $tmp_array){
                                                $num =count($tmp_array);
                                                $array_zip["question"]["$tmp_qid"]["invite"] = array(
                                                        "flag"=>"invite",
                                                        "num" => "$num",
                                                        "qid" => "$tmp_qid",
                                                        "desc"=> $tmp_array,
                                                );
                                        }
                                }

	
                                if(count($array_adopt)>0){
				        foreach ($array_adopt as $tmp_qid => $tmp_array){
                                                $num =count($tmp_array);
                                                $array_zip["question"]["$tmp_qid"]["adopt"] = array(
                                                        "flag"=>"adopt",
                                                        "desc"=> $tmp_array,
                                                );
                                        }	
                                }

				if(count($array_comment)>0){
					foreach ($array_comment as $tmp_qid => $tmp_array){
						$num = 0;
						$array_one_qid = array();
						if(isset($tmp_array[2])){
							$num += count($tmp_array[2]);
							foreach ($tmp_array[2] as $tmp_data){
								if($uid==$tmp_data["auid"]){ //对我的回答的评论
									$array_one_qid["me"][] = $tmp_data;
								}else{
									$array_one_qid["other"][] = $tmp_data;
								}
							}
						}
						
						if(isset($tmp_array[1])){ //问题的评论
							$num += count($tmp_array[1]);							
							$array_one_qid["question"] = $tmp_array[1];
						}
						
						$array_zip["question"]["$tmp_qid"]["comment"] = array(
							"num" => "$num",
							"qid" => "$tmp_qid",
							"desc"=> $array_one_qid,						
						);
					}
				
				}
			}
			return $this->result_output(0,$array_zip);
		
		}
		
		
		
		public function get_notice_count($uid,$status=0,$otheruid=0,$type=0){
			$result =  $this->operationHander->get_count_from_db($uid,$otheruid,$type,$status);
			if($result===false){
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);	
			}else{
				return $this->result_output(0,array("num"=>$result));		
			}	
		}
		
		public function get_notice_count_unread($uid,$status=1,$otheruid=0,$type=0){
			$result = $this->operationHander->get_count_from_db($uid,$otheruid,$type,$status);
			if($result===false){
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);	
			}else{
				return $this->result_output(0,array("num"=>$result));		
			}	
		}

		public function get_notice_count_unread_group($uid,$status=1,$group=1,$type=0,$otheruid=0){
			$result = $this->operationHander->get_count_from_db($uid,$otheruid,$type,$status,$group);
			if($result===false){
				$error = $this->operationHander->get_error();
				if(empty($error)){
					$error  = 8;
				}
				$this->set_error($error);
				return $this->result_output($error);	
			}else{
				return $this->result_output(0,$result);		
			}	
		}
		
		public function result_output($err_code=0,$array=array()){
			$re_array = array(
				"err_code"=>$err_code,
				"err_msg"=>$this->g_system_error_msg[$err_code],
				"result" =>$array,			
			);
			return $re_array;		
		}
		
	}
}
