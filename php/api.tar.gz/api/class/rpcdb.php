<?php
//rpc操作
class RpcDb
{
	static $client;
	function __construct()
	{
		self::$client = new xmlRpcClient('', '', RPC_TIMEOUT);
	}
	/**
	* 获取mysql信息
	* @param $dbname 分库前缀名（总库名）
	* @param $sql 查询sql语句
	* @param $data 返回值，以数据形式,如果是错误的,会有errinfo
	* @return true/false
	*/
	function read($dbname, $sql, &$data)
	{
		$data = array();
		if (!self::getdbinfo($dbname, $sinfo)){
			$data["errinfo"] = 'dbname错误';
			return false;
		}
		self::$client->clearBuf();
		self::$client->setServer($sinfo['ip']);
		self::$client->setPort($sinfo['port']);
		self::$client->setFunction("mysql_exec");
		self::$client->setPara("app", $sinfo['app']);
		self::$client->setPara("sql", $sql);
		if (0 < self::$client->callRemote()){
			if (0 < self::$client->getResult("re")){
				$num = self::$client->getResult("rownum");
				$colnum = self::$client->getResult("colnum");
				for ($i=0; $i < $num; $i++)
				{
					for ($j=0; $j < $colnum; $j++)
					{
						$data[$i][self::$client->getResult("col_".$j)] = self::$client->getResult2(self::$client->getResult("col_".$j)."_", $i);
					}
				}
			}
			else
			{
				$data["errinfo"] = self::$client->getResult("errinfo");
				$data["errno"] = self::$client->getResult("errno");
				return false;
			}
		}
		else
		{
			$data["errinfo"] = '网络错误';
			return false;
		}
		return true;
	}
	
	/**
	* 更新mysql信息
	* @param $dbname 分库前缀名（总库名）
	* @param $sql 更新sql语句
	* @return data[] array
	*/
	function update($dbname, $sql, &$data)
	{
		$data = array();
		if (!self::getdbinfo($dbname, $sinfo)){
			$data["errinfo"] = 'dbname错误';
			return false;
		}
		self::$client->clearBuf();
		self::$client->setServer($sinfo['ip']);
		self::$client->setPort($sinfo['port']);
		self::$client->setFunction("mysql_exec");
		self::$client->setPara("app", $sinfo['app']);
		self::$client->setPara("sql", $sql);
		if (0 < self::$client->callRemote()){
			if (0 < self::$client->getResult("re")){
				$data["insertid"] =  @intval(self::$client->getResult("insertid"));
			}
			else
			{
				$data["errinfo"] = self::$client->getResult("errinfo");
				$data["errno"] = self::$client->getResult("errno");
				return false;
			}
		}
		else
		{
			$data["errinfo"] = '网络错误';
			return false;
		}
		return true;
	}
	
	/**
	* 根据id,dbname前缀获取库配置信息
	* @param $dbname 分库前缀名（总库名）
	* @return true/false
	*/
	function getdbinfo($dbname, &$sinfo)
	{
		switch($dbname)
		{
			case 'question':
				$sinfo['ip'] = RPC_QUESTION_SERVER;
				$sinfo['port'] = RPC_QUESTION_PORT;
				$sinfo['app'] = RPC_QUESTION_APP;
				break;
			case 'user':
				$sinfo['ip'] = RPC_USER_SERVER;
				$sinfo['port'] = RPC_USER_PORT;
				$sinfo['app'] = RPC_USER_APP;
				break;
			case 'feedata_00':
				$sinfo['ip'] = RPC_FEED_DATA_SERVER;
				$sinfo['port'] = RPC_FEED_DATA_PORT;
				$sinfo['app'] = RPC_FEED_DATA_APP;
				break;
			case 'feedindex_00':
				$sinfo['ip'] = RPC_FEED_INDEX_SERVER;
				$sinfo['port'] = RPC_FEED_INDEX_PORT;
				$sinfo['app'] = RPC_FEED_INDEX_APP;
				break;
			case 'stat':
				$sinfo['ip'] = RPC_STAT_SERVER;
				$sinfo['port'] = RPC_STAT_PORT;
				$sinfo['app'] = RPC_STAT_APP;
				break;
			case 'message':
				$sinfo['ip'] = RPC_MESSAGE_SERVER;
				$sinfo['port'] = RPC_MESSAGE_PORT;
				$sinfo['app'] = RPC_MESSAGE_APP;
				break;
			case 'reversion':
				$sinfo['ip'] = RPC_REVERSION_SERVER;
				$sinfo['port'] = RPC_REVERSION_PORT;
				$sinfo['app'] = RPC_REVERSION_APP;
				break;
			default:
			return false;
		}
		return true;
	}
	
	//made in sql
	//add by matong
	function getInParams($params)
	{
		if($params&&is_array($params))
		{
			$str = '';
			foreach($params as $p)
			{
				$str .= '\''.$p.'\',';
			}

			return $str ? '('.rtrim($str, ',').')' : false;
		}
		return false;
	}
	
	function prepare_insert_sql($tablename, $row, $fields_not_quote = "")
	{
		$first = TRUE;
		$x = ($fields_not_quote == '') ? array() : explode(',', $fields_not_quote);
		$fs = "";
		$vs = "";
		foreach ($row as $k=>$v)
		{
			if ($v == ''){
				$v = "''";
			}
			else if (!in_array($k, $x)){
				$v = sprintf("'%s'", mysql_escape_string($v));
			}
	
			if ($first){
				$first = FALSE;
				$fs .= "$k";
				$vs .= "$v";
			}
			else{
				$fs .= ",$k";
				$vs .= ",$v";
			}
		}
		$sql = "insert into $tablename($fs)values($vs)";
		return $sql;
	}
	
	function prepare_update_sql($tablename, $row, $fields_not_quote = "")
	{
		$first = TRUE;
		$x = ($fields_not_quote == '') ? array() : explode(',', $fields_not_quote);
		$fs = "";
		$vs = "";
		foreach ($row as $k=>$v)
		{
			if ($v == ''){
				$v = "''";
			}
			else if (!in_array($k, $x)){
				$v = sprintf("'%s'", mysql_escape_string($v));
			}
	
			if ($first){
				$first = FALSE;
				$fs .= "$k=$v";
			}
			else{
				$fs .= ",$k=$v";
			}
		}
		$sql = "update $tablename set $fs";
		return $sql;
	}
}
?>
