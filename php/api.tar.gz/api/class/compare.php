<?php
class Compare{
	function __construct(){
	}

    /** for tetx diff
     * @param $str1 字符串一
     * @param $str2 字符串二     
     * @param $add 文本增加的显示样式
     * @param $del 文本减少的显示样式  change = add and del
     * @param $diff 比较结果
     * @return TRUE/FASLE
     */
    
    function textdiff($str2,$str1,&$textdiff){
        if(empty($str1) && empty($str2)){
			$textdiff = $str1;
            return FALSE;
        }else{
			if($str1 === $str2){
				$textdiff = $str1;
			}else{
            $long1 = mb_strlen($str1,"UTF-8");
            $long2 = mb_strlen($str2,"UTF-8");    
            $lines1 = $lines2 = array();
            for($i=0;$i<$long1;$i++){
                $lines1[] = mb_substr($str1,$i,1,"UTF-8");
            }   
            for($i = 0;$i<$long2;$i++){
                $lines2[] = mb_substr($str2,$i,1,"UTF-8");
            }   
            $add = 'lo_lv';
            $del  = 'lo_fen lo_litr';
            $diff = new Text_Diff('auto', array($lines1, $lines2));
            $r_inline = new Text_Diff_Renderer_inline(
                array(
                    'leading_context_lines' => 10000,
                    'trailing_context_lines' => 10000,
                    'ins_prefix' => '<span class="'.$add.'">',
                    'ins_suffix' => '</span>',
                    'del_prefix' => '<span class="'.$del.'">',
                    'del_suffix' => '</span>'
                )   
            );  
            $textdiff = $r_inline->render($diff);
			}
            return TRUE;
        }
    }
}

