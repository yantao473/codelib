<?php
/**
 * 用户中心
 *
 * @package     User
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
*/

class Login_UserMan {

	private $sql;
	private $rpc_obj;
	private $server_info;
	private $dbname;

	public function __construct() {
		$this->dbname = 'user';
		$this->rpc_obj = new RpcDb();
		$this->rpc_obj->getdbinfo('user',$this->server_info);
		$this->tools_obj = new Tools();
		$this->mysql_obj = new MysqlDb();
		$this->bdb_obj  = new GetBdb();
		$this->image_obj = new images();
	}
	
	/**
	 * 获取用户详细信息 本地 
	 *
	 * @param array
	 * @return bool
	*/
	public function get_user_detail($arr , &$data) {
		unset($this->sql);
		$query = '';
		if(!empty($arr)) {
			foreach($arr as $col => $val) {
				$query .= !empty($query) ? " AND `{$col}`='{$val}' " : " `{$col}`='{$val}' ";
			}
			$this->sql = "SELECT * FROM `user` WHERE {$query}";
			if(!$this->read($data)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 获取用户详细信息 本地 
	 *
	 * @param array
	 * @return bool
	*/
	public function get_user_detail_bdb($uid,&$data) {
		$flag = $this->bdb_obj->gets('user', $uid , $data);
		#if(!empty($data)) {
		#	$data['picture'] = $this->image_obj->getlogo($data['picture'] , 'uc');
        	#}
        return true;
	}

	/**
	 * 更新用户详细信息 本地 
	 *
	 * @param unsign int uid , array , array
	 * @return bool
	*/
	public function update_user_detail($uid , $arr , &$data) {
		unset($this->sql);
		$query = '';
		if(!empty($arr)) {
			$table_name = $this->mysql_obj->get_table('user' , $uid);
			$this->sql = $this->mysql_obj->prepare_update_sql($table_name , $arr );
			$this->sql .= " WHERE `uid` = $uid";
			if(!$this->update($data)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 获取用户详细信息 统一登录 
	 *
	 * @param array
	 * @return bool
	*/
	public function get_user_sso($arr , &$data) {
		$post_data = array();
		if(!empty($arr)) {
			foreach($arr as $col => $val) {
				$post_data[$key] = rawurlencode($val); 
			}
			$this->tools->curl_set($post_data,SSO_GET_URL,$res);
		}

	}
	
	/**
	 * 查询验证码
	 * @param string
	 * return bool
	 */
	 public function check_invite($sql , &$data) {
		$this->sql = $sql ;
		if(!$this->read($data)) {
			return false;
		}
	 	if($data[0]['count'] > 0) {
			return false;
		}
		else {
			return true;
		}
	 }
	
	/**
	 * 查询验证码
	 * @param string
	 * return bool
	 */
	public function get_invite($sql , &$data) {
		$this->sql = $sql ;
		if(!$this->read($data)) {
			return false;
		}
		return true;
	}
	/**
	 * 查询验证码
	 * @param string
	 * return bool
	 */
	public function update_invite($sql, &$data) {
		$this->sql = $sql;
		if(!$this->update($data)) {
			return false;
		}
		return true;
	}
	public function invite_left_times() {
		$this->sql = 'SELECT `invite_nums` FROM `user` WHERE uid = '.$_SESSION['session_uid'];
		if(!$this->read($data)) {
			return false;
		}
		#$invite_nums = INVATE_TOTAL_NUMS - $data[0]['invite_nums'];
		#$invite_nums = $invite_nums <= 0 ? 0 : $invite_nums; 
		$invite_nums = $data[0]['invite_nums'];
		return $invite_nums;
	}
	/**
	 * 调用rpc函数查询 
	 *
	 * @param array
	 * @return bool
	*/
	private function read(&$data) {
		if($this->rpc_obj->read($this->dbname,$this->sql,$data)) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * 注册统一登录接口 
	 *
	 * @param array
	 * @return bool
	*/
	public function reg_sso($aconf,&$res) {
		$post_data = array();
		if(!empty($aconf)) {
			foreach($aconf as $key => $val) {
				$val = rawurlencode($val);
				$param .= !empty($param) ? "&{$key}={$val}" : "{$key}={$val}";
			}   
			$url .= SSO_REG_URL."?".$param;

			$this->tools_obj->curl_set($url, 'GET', '', $res);
			if(strpos($res,'succ')===false)
			{
				return false;
			}
			else {
				return true;
			}
		}
	}

	/**
	 * 注册本地
	 *
	 * @param array
	 * @return bool
	*/
	public function reg_local($aconf,&$err_msg) {
		unset($this->sql);
		$cols = '';
		$vals = '';
		if(!empty($aconf)) {
			$table_name = $this->mysql_obj->get_table('user' , $aconf['uid']);
			$this->sql = $this->mysql_obj->prepare_insert_sql($table_name, $aconf);
			if(!$this->update($err_msg))
			{
				return false;
			}
			return true;
		}
	}
	
	/**
	 * 注册用户入库操作
	 *
	 * @param array
	 * @return bool
	*/
	private function update(&$data) {
		if($this->rpc_obj->update($this->dbname,$this->sql,$data)) {
			return true;
		}
		else {
			return false;
		}
		
	}

	public function login_history() {
		return true;
		if(!$_SESSION['session_uid'])
		{
			return ;
		}
		$this->sql = 'INSERT INTO `login_history` (`uid`,`ip`,`login_time`) VALUES ("'.$_SESSION['session_uid'].'",     "'.ip2long($this->tools_obj->get_user_ip()).'","'.date('Y-m-d H:i:s').'")';
		if(!$this->update($err_msg)){
			return false;
		}    
		return true;
	}

}
?>
