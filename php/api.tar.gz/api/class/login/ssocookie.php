<?php
/**
 * SSOCookie class file.
 *
 * PHP版本要求 >= PHP4.3.0，请勿用于PHP5.3及以上的环境
 * @package      SSOClient
 * @author       zhanghua2@staff.sina.com.cn
 * @copyright    copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/15 21:18:00
*/

/**
 * set & get cookie for sina.com.cn
 */
class Login_SSOCookie extends Login_SSOBase {

    var $COOKIE_SUE			= 'SUE';   //sina user encrypt info
    var $COOKIE_SUP			= 'SUP';   //sina user plain info
    var $COOKIE_KEY_FILE	= '/data0/sinasrv/lib/php/cookiekey.conf';
		
	/**
	 * cookie conf中定义方式如下
	 *		rv=1
	 *		rv1=xxxxx
	 *		rv2=yyyyyy
	 * rv为当前使用的版本号，rv[n]为该版本号的base64_encode(公钥)
	 */
	var $COOKIE_SIGN_VERSION_NAME	= 'rv';
	/**
	 * cookie的SUE中rs[n]即为不同版本的签名
	 */
	var $COOKIE_SIGN_VALUE_NAME		= 'rs';
	/**
	 * rsa version
	 * @var int
	 */
	var $_rsa_version				= 0;

	var $_arrConf; // the infomation in cookie.conf
	var $_arrKeyMap		= array(
		'cv'	=> 'cookieversion',
		'bt'	=> 'begintime',
		'et'	=> 'expiredtime',
		'uid'	=> 'uniqueid',
		'user'	=> 'userid',
		'ag'	=> 'appgroup',
		'nick'	=> 'displayname',
		'sex'	=> 'gender',
		'ps'	=> 'paysign',
	);
	var $_arrCookie;

	function Login_SSOCookie($config = NULL) {
		if ($config == NULL) $config = $this->COOKIE_KEY_FILE;
		if(!$this->_parseConfigFile($config)){
			die("parse config file failed");
		}
		$this->_arrCookie = $_COOKIE;
	}
	
	function setCustomCookie($arrCookie) {
		if (!is_array($arrCookie)) {
			$this->_setError("custom cookie is not array");
			return false;
		}
		$this->_arrCookie = $arrCookie;
		return true;
	}
	
    function getCookie(&$arrUserInfo, $use_rsa_sign=false) {
		$sup = $this->_arrCookie[$this->COOKIE_SUP];
		if(!$sup) return false;
		
		parse_str($sup,$arrSUP);
		$cookieVersion = $arrSUP['cv'];
		switch($cookieVersion) {
			case 1:
				return $this->_getCookieV1($arrUserInfo, $use_rsa_sign);
				break;
			default:
				return false;
		}
	}

    /**
     * delete cookie
     */
	function delCookie() {
		// 产品可以在这里删除自己的cookie
		return true;
	}

	function _getCookieV1(&$arrUserInfo, $use_rsa_sign) {
        // 不存在密文cookie或明文cookie视为无效
        if( !isset($this->_arrCookie[$this->COOKIE_SUE]) ||
            !isset($this->_arrCookie[$this->COOKIE_SUP])) {
                $this->_setError('not all cookie are exists ');
                return false;
		}
		parse_str($this->_arrCookie[$this->COOKIE_SUE],$arrSUE);
		parse_str($this->_arrCookie[$this->COOKIE_SUP],$arrSUP);
		foreach( $arrSUP as $key=>$val) {
			if(isset($this->_arrKeyMap[$key])) $key = $this->_arrKeyMap[$key];
			//$arrUserInfo[$key] = iconv("UTF-8","GBk",$val);
			$arrUserInfo[$key] = $val;
		}
		// 判断是否超时
		if($arrUserInfo['expiredtime'] < time()) {
			$this->_setError("cookie is timeout ");
            return false;
		}
		
		//	set rsa version
		$this->_setRsaVersion($arrSUE);

		$rawsup = rawurlencode($_COOKIE[$this->COOKIE_SUP]);
		
		//	选择性验证，设置或传递使用RSA方式验证参数
		if ($use_rsa_sign) {
			$rskey		= $this->_getRsaCookieName();	// "rs"."0"
			$crypted	= base64_decode($arrSUE[$rskey]);
			$public_key	= $this->_getPublicKey();		// "rv"."0"
			if (empty($crypted)) {
				$this->_setError($rskey . ' cookie not exist');
				return false;
			}
			if (empty($public_key)) {
				$this->_setError('public key not exist');
				return false;
			}
			// 检查rsa sign
			if (!$this->_validateRsaCookie($this->_signSUP($rawsup), $crypted, $public_key)) {
				$this->_setError('rsa sign string error');
				return false;
			}
		} else {
			// 检查加密cookie
			if ($arrSUE['es2'] != md5($rawsup . $this->_arrConf[$arrSUE['ev']])) {
				$this->_setError('encrypt string error');
				return false;
			}
		}
		return true;
	}

	/**
	 * parse cookie config file.
	 * @param $config: cookie config file
	 */
	function _parseConfigFile($config) {
		$arrConf = @parse_ini_file($config);
		if(!$arrConf) {
			$this->_setError('parse file '.$config . ' error');
			return false;
		}
		$this->_arrConf = $arrConf;
		return true;
	}

		
	/**
	 * 获取当前rsa算法在cookie中的名字rs[n]（内容为密钥生成的签名）
	 * 
	 * @access private
	 * @return string
	 */
	function _getRsaCookieName() {
		return $this->COOKIE_SIGN_VALUE_NAME . $this->_getRsaVersion();
	}
	
	/**
	 * 获取当前rsa算法所使用的公钥的名字rv[n]
	 * 其内容为base64_encode(公钥)，在配置文件中
	 * 
	 * @access private
	 * @return string
	 */
	function _getPublicKeyName() {
		return $this->COOKIE_SIGN_VERSION_NAME . $this->_getRsaVersion();
	}

	/**
	 * 设置当前所使用的RSA版本
	 * 
	 * @access private
	 * @return int
	 */
	function _setRsaVersion($sue) {
		return $this->_rsa_version = $sue[$this->COOKIE_SIGN_VERSION_NAME];
	}
		
	/**
	 * 当前所使用的RSA版本
	 * 
	 * @access private
	 * @return int
	 */
	function _getRsaVersion() {
		return $this->_rsa_version;
	}
	
	/**
	 * 对sup做签名
	 * 
	 * @access private
	 * @param string $sup
	 * @return string 
	 */
	function _signSUP($sup) {
		return md5($sup);
	}
	
	/**
	 * 从conf中获取密钥，base64解密
	 * conf中COOKIE_SIGN_VERSION_NAME值为当前正在使用的版本
	 * 
	 * @access private
	 * @return string
	 */
	function _getPublicKey() {
		$public_key = $this->_arrConf[$this->_getPublicKeyName()];
		return base64_decode($public_key);
	}
	
	/**
	 * 验证
	 * 
	 * @access private
	 * @param string $sign				正确的签名数据
	 * @param string $crypted			签名数据
	 * @param string $public_key		公钥
	 * @return bool 
	 */
	function _validateRsaCookie($sign, $crypted, $public_key) {
		if (!openssl_public_decrypt($crypted, $decrypted, openssl_pkey_get_public($public_key))) {
			$this->_setError('decrypt error : ' . openssl_error_string());
			return false;
		}
		return $sign === $decrypted;
	}
}

?>
