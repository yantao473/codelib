<?php
/**
 * 用户中心
 *
 * @package     User
 * @author      zhanghua2@staff.sina.com.cn
 * @copyright   copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/16 21:19:00
*/

class Login_QMan {

	private $sql;
	private $rpc_obj;
	private $server_info;
	private $dbname;

	public function __construct() {
		$this->dbname = 'question';
		$this->rpc_obj = new RpcDb();
		$this->rpc_obj->getdbinfo('question',$this->server_info);
		$this->tools_obj = new Tools();
		$this->mysql_obj = new MysqlDb();
		$this->bdb_obj  = new GetBdb();
		$this->image_obj = new images();
	}
	
	/**
	 * 获取用户详细信息 本地 
	 *
	 * @param array
	 * @return bool
	*/
	public function get_ans_top_list(&$data) {
		unset($this->sql);
		$query = '';
		# $this->sql = "select *,count(1) as `count` from (select answerid,questionid,ctime from vote where ctime between '".date('Y-m-d',strtotime("-1 day"))."' and '".date("Y-m-d")."') b group by b.answerid order by count desc limit 0,20";
		$this->sql = "select *,count(1) as `count` from (select answerid,questionid,ctime from vote where ctime between '".date('Y-m-d')." 00:00:00' and '".date("Y-m-d H:i:s")."') b group by b.answerid order by count desc limit 0,40";
		//echo $this->sql;
		
		if(!$this->read($data)) {
			return false;
		}
		return true;
	}

	/**
	 * 调用rpc函数查询 
	 *
	 * @param array
	 * @return bool
	*/
	private function read(&$data) {
		if($this->rpc_obj->read($this->dbname,$this->sql,$data)) {
			return true;
		}
		else {
			return false;
		}
	}
}
?>
