<?php
/**
* 登陆的流程处理
*
* @package      Session
* @author       zhanghua2@staff.sina.com.cn
* @copyright    copyright(2011) 新浪网研发中心 all rights reserved
* @version      1.0    2011/08/15 21:18:00
*/

//$G_DT_SEESION = false; // SESSION 打开标志

$session_obj = new Login_Setsession();
$session_obj->my_session_start();

class Login_Setsession {

	public function __construct() {
		$this->my_session_start();
	}

    /**
	* 激活 SESSION
    *
    * @param
    * @return
    */
	public function my_session_start() {
		global $G_DT_SEESION;
		if (!$G_DT_SEESION) { 
			//session_set_cookie_params(0, '/', '', true);
			session_start();
			$G_DT_SEESION = true;
		}
	}

	/**
	* 判断登陆
	*
	* @param
	* @return bool
	*/
	public function is_zhishi_login() {
		$login_obj = new Login_Logic();
		if(!$login_obj->check_login($err_code)) {
			return false;
		}
		return true;
	}

	/**
	* 指定SESSION变量是否存在
	*
	* @param string
	* @return bool
	*/
	public function is_my_session($sname) {
		$this->my_session_start();
		if (isset($_SESSION["$sname"])){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	* 获取指定SESSION值，并返回
	*
	* @param string,bool
	* @return string
	*/
	public function get_my_session($sname, $defval = false) {
		$this->my_session_start();
	
		if (isset($_SESSION["$sname"])) {
			return $_SESSION["$sname"];
		}
		else {
			return $defval;
		}
	}

	/**
	* 种session
	*
	* @param array
	* @return
	*/
	public function SetSessions($sesarray) {
		$this->my_session_start();
		foreach ($sesarray as $k => $v) {
			if (strlen($v) > 0) {
				$_SESSION[$k] = $v;
			}
		}
	}

	/**
	* 删除session
	* 激活 SESSION
	*
	* @param array
	* @return
	*/
	public function UNSessions($sesarray) {
		$this->my_session_start();
		foreach ($sesarray as $k => $v) {
			if ($this->is_my_session($k)) {
				unset($_SESSION[$k]);
			}
		}
	}
	
	/**
	* 注册单个session
	*
	* @param string
	* @return bool
	*/
	public function set_my_session($name,$value) {
		$this->my_session_start();
		$_SESSION[$name] = $value;
		return true;
	}
	
	/**
	* 注册单个session
	*
	* @param string
	* @return bool
	*/
	public function set_my_cookie($name,$value) {
		$_COOKIE[$name] = $value;
		setcookie($name,$value,time()+3600*24*30,"/");
	}

	/**
	* 删除单个session
	*
	* @param string
	* @return bool
	*/
	public function unset_my_session($se) {
		$this->my_session_start();
		if ($this->is_my_session($se)) {
			session_unregister($se);
			return ture;
		}
		else {
			return false;
		}
	}
}
?>
