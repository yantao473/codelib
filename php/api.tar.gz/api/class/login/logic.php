<?php
/**
 * 登陆的流程处理
 *
 * @package		login
 * @author		zhanghua2@staff.sina.com.cn
 * @copyright	copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/15 21:18:00
*/

class Login_Logic {

	private $sso_obj;
	private $session_obj;
	private $bdb_obj;
	private $tools_obj;

	public function __construct() {
		$this->session_obj = new Login_Setsession();
        $this->sso_obj = new Login_SSOClient();
    	$this->bdb_obj = new GetBdb();
		$this->tools_obj   = new Tools();
		$this->user_obj	= new Login_UserMan();
	}
	
	public function check_login_auto($jump='') {
		if(!$this->check_sso_cookie($err_code , $userinfo)) {
			if($jump) {
				$this->tools_obj->location_url("/login/login.php");
				die();
			}else{
				return false;
			}
		}
		if(!$this->check_local_cookie()) {				// local_cookie 只有在成功登陆或者成功注册以后才会产生
			if($jump) {
				$this->tools_obj->location_url("/login/login.php");
				die();
			} else {
				return false;
			}
		}
		return true;
	}

    /**
    * 判断是否登陆统一登录
    *
    * @param
    * @return bool
    */
	public function check_sso_cookie(&$err_code , &$userinfo) {
		if($this->sso_obj->isLogined()) {
			$userinfo = $this->sso_obj->getUserInfo();
			$uniqid = $userinfo["uniqueid"];
			if(!empty($_SESSION["session_uid"]) && $_SESSION["session_uid"] == $uniqid) {
				return true;
			}
			else {
				if(!$this->get_login($uniqid,"1",$userinfo,$userinfores)) {
					$err_code = -2;
					//return false;
				}
			}
		}
		else {
			return false;
		}
		$this->set_login_session($userinfores);
		return true;
	}
	
	/*
	 *判断是否已经注册过本地项目
	 *
	*/
	public function check_local_cookie() {
		if(!empty($_COOKIE['isvaliduser']) && $_COOKIE['isvaliduser'] == md5($_SESSION['session_uid'].$_SESSION['session_login'])) {
			return true;
		}
		else{
			return false;
		}
	}

	/*
	 *判断是否已经注册过本地项目
	 *
	*/
	public function check_user($uid = '') {
		$uid = empty($uid) ? $_SESSION['session_uid'] : $uid;
		$this->bdb_obj->user($uid,$udata);
		if(empty($udata['uid'])) {
			return false;
		}
		return true;
	}
	
	private function get_login($uid, $pro_type, $userinfosso, &$userinfo) {
      	$arr = array('uid' => $uid);
		$this->user_obj->get_user_detail($arr , $udata);
		$ip = $this->tools_obj->get_user_ip();
		if(!empty($udata[0]))
		{
			$userinfo = $udata[0];
			return true;
		}
		else {
			//$userinfo['uid'] = $uid;
			$errmsg = '无用户信息';
			return false;
		}
		/*
		if(is_array($loginRet)) {	
            if($loginRet["result"] == "succ") {
                $userinfo = $loginRet["info"][0];
                $userinfo['isvalidate'] = 'y';
                return true;
            }
			else{
				if(strlen($loginRet["reason"]) != 0){
					$errmsg = $loginRet["reason"];
					return false;
				}
				else{
					$errmsg = "用户名或密码错误";
					return false;
				}
			}
		}
		else{
			$errmsg = "用户名或密码错误。";
			return false;
		}*/
	}

	//种新浪统一验证cookie
	public function set_login_session($userinfo){
		//种session
		if(!empty($userinfo))
		{
			foreach($userinfo as $k => $v) {
				$arr['session_'.$k] = $v;
			}
			$this->session_obj->SetSessions($arr);
		}
	}

	public function write_login_history() {
		$this->user_obj->login_history();
	}
}
?>
