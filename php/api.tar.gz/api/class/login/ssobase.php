<?PHP
/**
 * SSOBase class file.
 *
 * PHP版本要求 >= PHP4.3.0，请勿用于PHP5.3及以上的环境
 * @package      SSOClient
 * @author       zhanghua2@staff.sina.com.cn
 * @copyright    copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/15 21:18:00
*/

class Login_SSOBase {
    /**
	 * 程序版本
	 */
	var $VERSION	= 'PHP4-1.4';
    /**
     * 标识是否出错
     */
    var $_is_error	= false;
    /**
     * 错误描述
     */
    var $_err_str	= '';	
    /**
     * 错误代码
     */
    var $_err_no	= '';	

    //============== method about error ==========//
    /**
     * 设置出错信息
     */
    function _setError($str,$num = '') {
        $this->_is_error = true;
        $this->_err_str = $str;
        $this->_err_no = $num;
        return true;
    }
    /**
     * 判断是否出错
     */
    function isError() {
        return $this->_is_error;
    }
    /**
     * 返回出错信息
     */
    function getError() {
        return $this->_err_str;
    }
    /**
     * 返回错误号
     */
    function getErrno() {
        return $this->_err_no;
    }
    /**
     * 清除出错信息
     */
    function clearError() {
        $this->_is_error = false;
        $this->_err_str = '';
        $this->_err_no = '';
        return true;
    }

}
?>
