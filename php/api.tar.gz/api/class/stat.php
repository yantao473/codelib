<?php
/**
 * 统计相关公用函数
 * @by tingting18
 * 
 */
class Stat{
    public $rpcdb_obj,$getbdb_obj,$queue_obj;
    public $filename,$cmdid;
    function __construct() {
        $this->rpcdb_obj = new RpcDb;
        $this->mysqldb_obj = new MysqlDb;
        $this->getbdb_obj = new GetBdb;         
        $this->queue_obj = new QueueTool;
        
        //如默认队列
        $this->filename = DEFAULT_QUEUE_DATA_FILE;
        $this->cmdid = DEFAULT_QUEUE_ID;        
    }
    
    /**
     * 增量统计获取前一天的投票结果，
     * @param $day   时间  date("Y-m-d")
     * @return $data 更新数据
     */
    function get_vote($day){
        $dbname = 'question';
        $sql = 'SELECT questionid as qid,answerid as aid,count(answerid) as num FROM vote WHERE left(ctime,10) = "'.$day .'" group by answerid';
        $s_res = $this->rpcdb_obj->read($dbname, $sql, $data);
        if(!empty($data) && is_array($data) && !isset($data['errno'])){
            $votes = $data; 
        }else{
            $votes = 0;
        }
        return $votes;
    }// function get_vote end
    
    /**
     * 查询数据库
     * @param $row = 数据库参数   ('qid'=>$qid,'aid'=>$aid,'num'=>$num)
     * @return 查询结果 若无结果则返回0，有，返回num值
     * 
     */
    function get_data($row,$dbname='stat',$tablename='best_answer'){
        $sql = 'SELECT num FROM '.$tablename.' WHERE qid = '.$row['qid'].' AND aid = '.$row['aid'];
        $s_res = $this->rpcdb_obj->read($dbname, $sql, $data);
        if(!empty($data)){
            $num = $data[0]['num'];
        }else{
            $num = 0;
        }
		return $num;
    }
    
    /***
     * 插入数据库，
     * @param $row = 数据库参数   ('qid'=>$qid,'aid'=>$aid,'num'=>$num)
     * @param $dbname
     * @param $tablename 
     * @return true/false
     */
    function insert_data($row,$dbname='stat',$tablename='best_answer'){
        /*
        $dbname = 'stat';
        $tablename = 'best_answer';
         */
        $row['ctime'] = date("Y-m-d H:i:s");
        $sql = $this->mysqldb_obj->prepare_insert_sql($tablename, $row);
        $s_res = $this->rpcdb_obj->update($dbname, $sql, $data);
        if($s_res){
            return $s_res;
        }else{
            die('插入数据库失败');exit;
        }
    }
    
    /**
     * 更新数据库，更新bdb函数
     * @param $row = 数据库参数   ('qid'=>$qid,'aid'=>$aid,'num'=>$num)
     * @param $dbname
     * @param $tablename 
     * @return true/false
     */
    function up_data($row,$dbname='stat',$tablename='best_answer'){  
        $row['ctime'] = date("Y-m-d H:i:s");
        $updata['ctime'] = $row['ctime'];
        $updata['num'] = $row['num'];   
        $sql = $this->mysqldb_obj->prepare_update_sql($tablename, $updata); 
        $sql .= ' WHERE qid = '.$row['qid'].' AND '.' aid = '.$row['aid'];   
        $s_res = $this->rpcdb_obj->update($dbname, $sql, $data);
        if($s_res){
            return $s_res;            
        }else{
            die('更新数据库失败');exit;
        }   
    }//function end
    
    /***
     * 删除数据 
     * @param $row=($qid,$uid,$aid)
     * @param $dbname
     * @param $tablename 
     * @return true/false 
     */ 
     function del_data($row,$dbname='stat',$tablename='good_answer'){
         $sql = 'DELEL FROM '.$tablename.' WHERE aid = '.$row['aid'].' AND qid = '.$row['qid'].' AND uid = '.$row['uid'];
         $s_res = $this->rpcdb_obj->update($dbname, $sql, $data);
        if($s_res){
            return $s_res;            
        }else{
            die('删除数据失败');exit;
        }          
     }
    
    /**
     * 获取大于等于阀值的统计数据,qid相同时取num最大的aid
     * @param $num 阀值
     * @param $dbname
     * @param $tablename
     * @param 返回统计结果
     */
    function get_gt_stat($num=10,$dbname='stat',$tablename='best_answer'){
        $sql = 'SELECT qid, aid, max(num) as num FROM '.$tablename.' WHERE num >= '.$num.' group by qid';
        $s_res = $this->rpcdb_obj->read($dbname, $sql, $data);
        if(!empty($data) && is_array($data)){
            foreach($data as $k=>$v){
                $qid = $v['qid'];
                $gtdata["$qid"] = $v;
            }
        }else{
            $gtdata = 0;
        }
        return $gtdata;
    }
    
    /***
     * 获取bdb中tid对应的统计数据
     * @param $tid
     * @param $type 
     * @return $data;
     */
    function get_tag_ask($tid,$type='vanswer'){
        $res = $this->getbdb_obj->gets($type, $tid, $data);
        return $data;
    }
    
    
    /**
     * 获取问题对应的话题id
     * @param $qid 
     * @return $tid =array
     * 从question中取问题摘要
     */
    function gettid_from_question($qid){
        $this->getbdb_obj->gets("question", $qid, $data);
        if(isset($data['tag'])){
            $tag = $data['tag'];
            $tids = array_keys($tag);
        }else{
            $tids = 0;
        }
        return $tids;
    }
    
    /***
     * 根据qid 及 tid 的关系返回tid及aid的关系
     * @param $tids  qid对应的tids 
     * @param $data  大于阀值的统计数据  qid, aid ,num
     * @return tid,aid,num
     *    * */  
     function get_tid_aid($tids,$data){
        foreach($tids as $qid =>$tid){
            $data_t_a["$tid"]['tid'] = $tid;
            $data_t_a["$tid"]['aid'] = $data['aid'];
            if(isset($data['num'])){
                $data_t_a["$tid"]['num'] = $data['num'];
            }            
            if(isset($data['uid'])){
                $data_t_a["$tid"]['uid'] = $data['uid'];
            } 
        }//foreach end
        return $data_t_a;
     }  
     
     /**
      * 根据情况排序取前$num个tid展示 
      * @param $num 判断条件
      * @param $data  tid，aid，num  来自get_tid_aid
      * @return 排序后的数据
      */
     function sort_data($num=60,$data){
         foreach($data as $qid=>$qv){
			foreach($qv as $tid=>$v){
				$aid = $v['aid'];
				$s_data["$tid"]["$aid"] = $v['num'];
			}//foreach
		 }//foreach end
		return $s_data;
     }
    
    
    /*
     * 写bdb先把bdb清空传0为清空
     * @param  $data  array["$tid"] tid=>$tid,aid=>$aid,num=>$num
     * @param $day  统计时候的时间
     * @return true/false
     */
    function add_bdb($t_data,$day){
        $tablename = 'tag';
        $dbname = 'question';
        $sql = 'SELECT max(tid) as mtid from '.$tablename.' WHERE left(ctime,10) <= "'.$day.'"';
        $s_res = $this->rpcdb_obj->read($dbname, $sql, $data);
        if(!empty($data)){
            $mtid = $data[0]['mtid'];
            for($i=15000;$i<=$mtid;$i++){
                if(array_key_exists($i,$t_data)){
					foreach($t_data["$i"] as $k=>$v){
						$row['tid'] = $i;
						$row["$k"]['aid'] = $k;
						$row["$k"]['num'] = $v;
                    	$row[0] = EVENT_TAG_ANSWER_VOTE;
					}//foreach end
            		$queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);
                }else{//不存在清空
                    $rows['tid'] = '';
					$rows["$i"]['aid'] = '';
					$rows["$i"]['num'] = '';
                    $rows[0] = EVENT_TAG_ANSWER_VOTE;
            		$queue = $this->queue_obj->AddToLocalQueue($this->filename, $rows,$this->cmdid);
                } 
            }//for end
            $res =  $queue;
        }else{
            $res = false;
        }
        return $res;
    }

/**************************for tagexcellentuser****************************/
    /**
     * 获取 某一天添加的回答及删除的回答aid && qid && uid
     * @param $day  时间   $day = date('Y-m-d',strtotime("-1 day"));
     * @return $data['add']=>array(),$data['del'] = array();
     */
    function get_answer($day){
        $dbname = 'question';
        $tablename = 'answer';
        // add answer
        $a_sql = 'SELECT answerid as aid,questionid as qid,uid FROM '.$tablename.' WHERE left(ctime,10) = "'.$day.'" AND status = 0';
        $a_res = $this->rpcdb_obj->read($dbname, $a_sql, $a_data);
        // del answer
        $d_sql = 'SELECT answerid as aid,questionid as qid,uid FROM '.$tablename.' WHERE left(utime,10) = "'.$day.'" AND status = 1';   
        $d_res = $this->rpcdb_obj->read($dbname, $d_sql, $d_data);
        if(!empty($a_data)&& is_array($a_data)&&!isset($a_data['errno'])){
            $data['add'] = $a_data;
        }else{
            $data['add'] = 0;
        }
        if(!empty($d_data)&& is_array($d_data)&&!isset($d_data['errno'])){
            $data['del'] = $d_data;
        }else{
            $data['del'] = 0;
        }        
        return $data;
    }
    
    function get_stat_user($tablename='good_answer',$dbname = 'stat'){
        $sql = "SELECT * FROM ".$tablename;
        $s_res = $this->rpcdb_obj->read($dbname, $sql, $data);
        return $data;
    }
    

}
?>
