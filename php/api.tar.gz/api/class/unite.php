<?php

class unite{
	var $host;
	function unite()
	{
		$this->host = 'http://i.iask.sina.com.cn/';
	}
	function up($tableid, $key, $data, $secondid='')
	{
		$query = $this->doquery($tableid, $key, $data, $secondid);
		if (!($rdata = $this->postdata($this->host.'p/up.php', $query)))
		{
			return false;
		}
		$rdata = unserialize($rdata);
		if (@array_key_exists('error_num', $rdata) && @array_key_exists('error', $rdata))
		{
			return false;
		}
		return true;
	}
	function dump($tableid, $key, $data, $secondid='')
	{
		$query = $this->doquery_ex($tableid, $key, $data, $secondid);
		$u = new upbdb();
		$bdb = new bdbdb();
		if (!$bdb->gettableconf($query['tableid'], $tarray))
			return false;;
		$keys = array();
		$keys[0] = $query['tableid'];
		if (array_key_exists('secondid', $query) && $query['secondid'] !== '')
			$keys[1] = $query['secondid'];
		if (is_array($query['key'])){
			foreach ($query['key'] as $v)
			{
				$keys[] = $v;
			}
		}else{
			$keys[] = $query['key'];
		}
		foreach ($tarray['lkey'] as $k => $v)
		{
			if (!isset($keys["$k"]))
				return false;
			if (is_numeric($v) && !is_numeric($keys["$k"]))
				return false;
		}
		$info = $query['value'];
		if ($tarray['flag'] == 'array'){
			if (!is_array($query['value'])){
				if ($query['format'] === 0){
					$info = json_decode($query['value'], true);
				}else{
					$info = unserialize($query['value']);
				}
			}
			if (!is_array($info))
				return false;
		}else if ($tarray['flag'] == 'int'){
			if (count($tarray['v']) !== count($info))
				return false;
		}
		//����
		if (!$u->updata($tarray['t'], $keys, $info))
			return false;
		return true;
	}
	function del($tableid, $key, $data='', $secondid='')
	{
		$query = $this->doquery($tableid, $key, $data, $secondid);
		if (!($rdata = $this->postdata($this->host.'p/del.php', $query)))
			return false;
		$rdata = unserialize($rdata);
		if (@array_key_exists('error_num', $rdata) && @array_key_exists('error', $rdata))
			return false;
		return true;
	}
	function get($tableid, $key, &$rdata, $secondid='')
	{
		$rdata = array();
		$query = $this->doquery($tableid, $key, '', $secondid);
		if (!($data = $this->postdata($this->host.'p/get.php', $query)))
			return false;
		$rdata = unserialize($data);
		if (@array_key_exists('error_num', $rdata) && @array_key_exists('error', $rdata))
			return false;
		return true;
	}
	function getlist($tableid, $key, $start, $num, &$rdata, $order=0, $secondid='')
	{
		$rdata = array();
		$query = $this->doquery($tableid, $key, '', $secondid, $start, $num, $order);
		if (!($data = $this->postdata($this->host.'p/getlist.php', $query)))
			return false;
		$rdata = unserialize($data);
		if (@array_key_exists('error_num', $rdata) && @array_key_exists('error', $rdata))
			return false;
		return true;
	}
	function checklist($tableid, $key, $findkeys, $isvalue, &$rdata, $secondid='')
	{
		$rdata = array();
		$query = $this->doquery($tableid, $key, '', '', 0, 0, 0, $findkeys, $isvalue);
		if (!($data = $this->postdata($this->host.'p/checklist.php', $query)))
			return false;
		$rdata = unserialize($data);
		if (@array_key_exists('error_num', $rdata) && @array_key_exists('error', $rdata))
			return false;
		return true;
	}
	function http_build_query_ex($data, $prefix='', $sep='', $key='')
	{
		$ret = array();
		foreach ((array)$data as $k => $v) {
			if (is_int($k) && $prefix != null)
				$k = urlencode($prefix . $k);
			if (!empty($key))
				$k = $key.'['.urlencode($k).']';
			
			if (is_array($v) || is_object($v))
				array_push($ret, $this->http_build_query_ex($v, '', $sep, $k));
			else
				array_push($ret, $k.'='.urlencode($v));
		}
		if (empty($sep))
			$sep = ini_get('arg_separator.output');
		return implode($sep, $ret);
	}
	function doquery_ex($tableid, $key, $data, $secondid, $start=0, $num=0, $order=0,$findkeys='',$isvalue='')
	{
		$q = array();
		$q['tableid'] = $tableid;
		$q['key'] = $key;
		$q['format'] = 1;
		if ($secondid !== '')
		$q['secondid'] = $secondid;
		if ($start !== 0)
			$q['start'] = $start;
		if ($num !== 0)
			$q['num'] = $num;
		if ($order !== 0)
			$q['order'] = $order;
		$q['value'] = $data;
		if ($findkeys !== '')
			$q['findkeys'] = $findkeys;
		if ($isvalue !== '')
			$q['isvalue'] = $isvalue;
		return $q;
	}
	function doquery($tableid, $key, $data, $secondid, $start=0, $num=0, $order=0,$findkeys='',$isvalue='')
	{
		$q = array();
		$q['tableid'] = $tableid;
		$q['key'] = $key;
		$q['format'] = 1;
		if ($secondid !== '')
		$q['secondid'] = $secondid;
		if ($start !== 0)
			$q['start'] = $start;
		if ($num !== 0)
			$q['num'] = $num;
		if ($order !== 0)
			$q['order'] = $order;
		$q['value'] = $data;
		if ($findkeys !== '')
			$q['findkeys'] = $findkeys;
		if ($isvalue !== '')
			$q['isvalue'] = $isvalue;
		return $this->http_build_query_ex($q);
	}
	function postdata($url, $query)
	{
		$info = parse_url($url);
		$info['port'] = empty($info['port'])?80:$info['port'];
		$info['path'] = empty($info['path'])?'/':$info['path'];
		$fp = @fsockopen($info['host'], $info['port'], $err, $errinfo, 1);
		if (!$fp){
			return false;
		}
		$head = "POST $info[path] HTTP/1.0\r\n";
		$head .= "Host: $info[host]\r\n";
		$head .= "Content-type: application/x-www-form-urlencoded\r\n";
		$head .= "Content-Length: ".strlen($query)."\r\n";
		$head .= "\r\n";
		$head .= $query."\r\n";
		$head .= "\r\n";
		//echo $head;
		stream_set_timeout($fp, 1);
		fwrite($fp, $head);
		$i = 0;
		$result = '';
		while (!feof($fp))
		{
			$line = fread($fp, 8192);
			if ($i == 0){
				$i++;
				list($protocol,$sts,$statuswork) = explode(" ",$line);
				if ($sts != 200){
					fclose($fp);
					return false;
				}
				if(($p = strpos($line, "\r\n\r\n")) === false){
					if(($p = strpos($line, "\n\n")) === false)
						return false;
					$p += 2;
				}else{
					$p += 4;
				}
				$result = substr($line, $p);
				continue;
			}
			$status = stream_get_meta_data($fp);
			if($status["timed_out"]){   
				fclose($fp);
				return false;
			}
			$result .= $line;
			if ($line === '')
				break;
		}
		fclose($fp);
		//echo $result;
		return $result;
	}
	
}
?>
