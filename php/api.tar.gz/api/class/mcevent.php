<?php
// 写MC功能
// Author : xianghui@staff.sina.com.cn 
// Date : 2012-04-12
class mcevent{
	private $mem_host,$mem_port;
	private $tools_obj;
	function __construct(){
		$this->mem_host  = $_SERVER['MEMCACHE_SERVER'];
		$this->mem_port  = $_SERVER['MEMCACHE_PORT'];
		$this->tools_obj = new Tools();
	}

	public  function run(&$args)
	{
		switch($args[0])
		{
			case EVENT_VOTE_AGREE_ADD:
				if($args['vote_mc']){
					unset($args['vote_mc']);
					$array_vote = array();
					#$array_vote = array($args['questionid'],$args['answerid']);
					#$array_vote[$args['answerid']] = array($args['questionid']);
					//只存questionid
					$array_vote[$args['questionid']] = array($args['questionid']);
					$key = $args['questionid'] % 10 ;
					#$key = $args['answerid'] % 10 ;
					#$value = implode(",",$array_vote);
					#$value = $array_vote;
					$name = MC_VOTE.$key;
					#$result = $this->write_memcache($name,$array_vote,2);
					//$result = self::connect_memcache($memcache);
					$result = $this->connect_memcache($memcache);
					if($result){
						$result_memcache = $memcache->get($name); 
						if(!$result_memcache){
							$result = $memcache->set($name,$array_vote,0); 
						}
					}
				}
				break;
			case EVENT_QUESTION_ADD:
				break;

		}
		return $result;
	}

        /**
         * fn:获取MC数据
         **/
        public function get($data){
                $result = false;                                                                                   
                if($this->connect_memcache($memcache)){                                                                                		    	$result = $memcache->get($data);                                                      
                }                                                                                                 
                return $result;                                                                                      
        }       

	public  function connect_memcache(&$memcache){
		$memcache = new Memcached();
		$result = $memcache->addServer($this->mem_host , $this->mem_port ) or exit('can not connect memcache!');
		//$result = $memcache->connect($this->mem_host , $this->mem_port ) or exit('can not connect memcache!');
		return $result;		
	}
/*
	public function write_memcache($name,$value,$type=1){
		$memcache = new Memcache();
		$memcache->connect($this->mem_host , $this->mem_port ) or exit('can not connect memcache!');
		if($type == 1){
			$result = $memcache->set($name,$value,false,0);
		}
		if($type == 2){
			$result_memcache = $memcache->get($name);
			if($result_memcache){
				$result = $memcache->replace($name,$value,0);
			}else{
				$result = $memcache->set($name,$value,0);
			}
		}
		return $result;
	} 
*/
}
?>
