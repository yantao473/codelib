<?php
//bdb事件处理

class bdbevent{
	static private $wbdb;
	static private $rbdb;
	static private $com;
	function __construct()
	{
		self::$rbdb = new getbdb;
		self::$wbdb = new upbdb;
		self::$com = new bdbcommon;
	}
	function run($row)
	{
		if (!isset($row[0]))
			return false;
		$type = $row[0];
		unset($row[0]);
		$info = array();
		switch($type)
		{
			case EVENT_QUESTION_ADD://新加问题
				$row['last'] = $row['ctime'];
				if (!empty($row['classid'])){
					$f = self::$com->get_All_Fatherclass($row['classid']);
					$row['father'] = $f;
					$row['clsname'] = $f[0][1];
				}
				if (isset($row['data_append']) && !is_array($row['data_append'])){
					$row['data_append'] = json_decode($row['data_append'] , true);
				}
				if (!self::$wbdb->updata('detail', $row['questionid'], $row,array(), array()))
					return false;
				unset($row['description']);
				unset($row['last']);
				if (!self::$wbdb->updata('question', $row['questionid'], $row,array(), array()))
					return false;
				return self::$com->add2list($row);
			case EVENT_QUESTION_DEL://删除问题
			case EVENT_QUESTION_REST://恢复问题
				if (isset($row['uid']))
					unset($row['uid']);
				if (!self::$wbdb->updata('question', $row['questionid'], $row))
					return false;
				if (isset($row['utime']))
					$row['last'] = $row['utime'];
				if (!self::$wbdb->updata('detail', $row['questionid'], $row))
					return false;
				return ($type == EVENT_QUESTION_DEL?self::$com->del2list(self::$wbdb->mdata):self::$com->add2list(self::$wbdb->mdata));
			case EVENT_QUESTION_UPDATE:
			case EVENT_QUESTION_TITLE_UPDATE:
			case EVENT_QUESTION_REDIRECT:
			case EVENT_QUESTION_LOCK:
				if (isset($row['uid']))
					unset($row['uid']);
				if (!self::$rbdb->gets('question', $row['questionid'], $rdata))
					return false;
				if (!self::$wbdb->updata('question', $row['questionid'], $row, array(), $rdata))
					return false;
				if (isset($row['utime']))
					$row['last'] = $row['utime'];
				return self::$wbdb->updata('detail', $row['questionid'], $row);
			case EVENT_QUESTION_DESC_UPDATE:
				if (isset($row['uid']))
					unset($row['uid']);
				$row['last'] = $row['utime'];
				return self::$wbdb->updata('detail', $row['questionid'], $row,array());
			case EVENT_QUESTION_TAG_ADD://问题增加话题
				if (is_array($row['tags'])){
					$info['tags'] = $row['tags'];
				}else{
					if (empty($row['tid']))
						return false;
					$info['tags'][$row['tid']] = $row['tags'];
				}
				if (!self::$wbdb->updata('question', $row['questionid'], $info))
					return false;
				$info['last'] = $row['utime'];
				$info['utime'] = $row['utime'];
				if (!self::$wbdb->updata('detail', $row['questionid'], $info))
					return false;
				if (!self::$com->addtag(self::$wbdb->mdata, $info)) return false;
				break;
			case EVENT_QUESTION_TAG_DEL:
				if (is_array($row['tags'])){
					$info['tags'] = $row['tags'];
				}else{
					if (empty($row['tid']))
						return false;
					$info['tags'][$row['tid']] = '';
				}
				if (!self::$wbdb->updata('question', $row['questionid'], $info))
					return false;
				$info['last'] = $row['utime'];
				$info['utime'] = $row['utime'];
				if (!self::$wbdb->updata('detail', $row['questionid'], $info))
					return false;
				if (!self::$com->deltag(self::$wbdb->mdata, $info)) return false;
				break;
			case EVENT_ANSWER_ADD://添加回答
				if (isset($row['data_append']) && !is_array($row['data_append'])){
					$row['data_append'] = unserialize($row['data_append']);
				}
			case EVENT_QUESTION_READOPT://纠错---知识人，同添加回答逻辑
				if (isset($row['data_append']) && !is_array($row['data_append'])){
					$row['data_append'] = json_decode($row['data_append'] , true);
				}
				$info['a']["$row[answerid]"] = $row;
				if (!self::$rbdb->gets('detail', $row['questionid'], $rqdata))
					return false;
				if (!is_array($rqdata))
					return false;
				if(!empty($rqdata['data_append'])) {
					if ($rqdata['data_append']['syncid'] != ZHISHI_APP_ID){
						if (!self::$rbdb->gets('user', $row['uid'], $udata))
							return false;
						$info['a']["$row[answerid]"]['weight'] = $udata['weight'];
						$info['a']["$row[answerid]"]['index'] = $udata['weight'];
					}
				}
				if (!self::$wbdb->updata('answer', $row['answerid'], $row))
					return false;
				//每人只能回答一条
				if (!empty($row['uid']) && !empty($rqdata['a'])){
					foreach ($rqdata['a'] as $v){
						if ($v['uid'] == $row['uid'])
							return true;
					}
				}
				if(!empty($rqdata['data_append'])) {
					if ($rqdata['data_append']['syncid'] != ZHISHI_APP_ID){
						$info['weight'] = 2*$udata['weight'] - self::$com->userweight;
					}
				}
				$info['last'] = $row['ctime'];
				if (!isset($rqdata['a']["$row[answerid]"])){
					$rqdata['atotal']++;
				}
				$info['atotal'] = $rqdata['atotal'];
				if (!self::$wbdb->updata('question', $row['questionid'], array('atotal'=>$rqdata['atotal']), array())) return false;
				$info['utime'] = $row['ctime'];
				if (!self::$wbdb->updata('detail', $row['questionid'], $info, array('weight','index'))) return false;
				return self::$com->addanswerlist(self::$wbdb->mdata, $row);
			case EVENT_ANSWER_DEL:
			case EVENT_ANSWER_RECOVER:
				if (isset($row['data_append']) && !is_array($row['data_append'])){
					if (isset($row['appid']) &&  $row['appid'] == API_APP_ID){
						$row['data_append'] = unserialize($row['data_append']);
					}else{
						$row['data_append'] = json_decode($row['data_append'] , true);
					}
				}
				$info['a']["$row[answerid]"] = $row;
				if (!self::$rbdb->gets('answer', $row['answerid'], $rdata))
					return false;
				if (isset($rdata['showflag']) && $rdata['showflag'] == $row['showflag'])//一致时，不做改动
					return true;
				if ($row['status'] >= 1 && self::$rbdb->mdata['status'] ==1){//删除采纳的回答时，要去除问答的采纳标记
					$row['status'] = 0;
					$info['status'] = 0;
				}
				if (!self::$wbdb->updata('answer',$row['answerid'], $row,array(),$rdata))
					return false;
				$uid = $rdata['uid'];
				if (!self::$rbdb->gets('detail', $row['questionid'], $rqdata))
					return false;
				if (!is_array($rqdata))
					return false;
				if ($row['status'] >= 1 && $row['status'] !== $rqdata['a']["$row[answerid]"]['status']){
					$rqdata['atotal'] = $rqdata['atotal'] > 0?($rqdata['atotal']--):0;
				}else if($row['status'] == 0 && $row['status'] !== $rqdata['a']["$row[answerid]"]['status']){
					$rqdata['atotal'] = $rqdata['atotal'] > 0?($rqdata['atotal']++):0;
				}
				$last = $row['utime'];
				$info['last'] = $last;
				$info['utime'] = $last;
				if (!self::$wbdb->updata('detail', $row['questionid'], $info, array(), $rqdata))
					return false;
				$info = array();
				$info['atotal'] = $rqdata['atotal'];
				if ($row['status'] >= 1 && self::$rbdb->mdata['status'] ==1){
					$info['status'] = 0;
				}
				if (!self::$wbdb->updata('question', $row['questionid'], $info, array()))
					return false;
				if ($type == EVENT_ANSWER_DEL){
					if (!isset($row['ctime']))
						$row['ctime'] = $rqdata['a']["$row[answerid]"]['ctime'];
					return self::$com->delanswerlist($rqdata, $row);
				}
				return self::$com->addanswerlist($rqdata, $row);
			case EVENT_ANSWER_UPDATE:
				if (isset($row['data_append']) && !is_array($row['data_append'])){
					if (isset($row['appid']) &&  $row['appid'] == API_APP_ID){
						$row['data_append'] = unserialize($row['data_append']);
					}else{
						$row['data_append'] = json_decode($row['data_append'] , true);
					}
				}
				$info['a']["$row[answerid]"] = $row;
				$info['last'] = $row['utime'];
				$info['utime'] = $row['utime'];
				if (!self::$wbdb->updata('detail', $row['questionid'], $info))
					return false;
				return self::$wbdb->updata('answer', $row['answerid'], $row);
			case EVENT_QUESTION_ADOPT://采纳答案
				$answerid = explode(',', $row['answerid']);
				if (empty($answerid))
					return true;
				if (isset($row['data_append']) && !is_array($row['data_append'])){
					if (isset($row['appid']) &&  $row['appid'] == API_APP_ID){
						$row['data_append'] = unserialize($row['data_append']);
					}else{
						$row['data_append'] = json_decode($row['data_append'] , true);
					}
				}
				if (!self::$rbdb->gets('detail', $row['questionid'], $rqdata))
					return false;
				if (!is_array($rqdata))
					return false;
				$info['status'] = $row['status'];
				$info['data_append']['indbtime'] = $row['utime'];
				$info['auid'] = '';
				foreach ($answerid as $aid)
				{
					$info['auid'] .= ($info['auid']===''?'':',').$rqdata['a']["$aid"]['uid'];
				}
				if (!self::$wbdb->updata('question', $row['questionid'], $info))
					return false;
				if (isset($row['data_append']) && count($answerid) == 1){//采纳单个回答
					$info['a']["$answerid[0]"]['data_append'] = $row['data_append'];
				}
				//可能会有多个正确答案
				foreach ($answerid as $aid)
				{
					$info['a']["$aid"]['status'] = $row['status'];
					$info['a']["$aid"]['utime'] = $row['utime'];
					if (!self::$wbdb->updata('answer', $aid, $info['a']["$aid"])) return false;
				}
				$info['last'] = $row['utime'];
				$info['utime'] = $row['utime'];
				if (!self::$wbdb->updata('detail', $row['questionid'], $info, array(), $rqdata))
					return false;
				if (!self::$com->upstatus(self::$wbdb->mdata, $rqdata)) return false;
				break;
			case EVENT_COMMENT_ADD://评论
				$info[0] = $row['targetid'];
				$info[1] = strtotime($row['ctime']);
				$info[2] = $row['commentid'];
				if ($row['type'] == 1){//问题评论
					if (self::$rbdb->lists('tqc', $info[0], 0, 1, $rdata)){//已经存在时要退出
						for($i=0;$i<$rdata['num'];$i++)
						{
							if ($rdata[$i]['data']['commentid'] == $info[2])
								return true;
						}
					}
					if (!self::$wbdb->lists('tqc', $info, $row))
						return false;
					$info = array();
					$info['cnum'] = intval($rdata['total'])+1;
					if (!self::$wbdb->updata('question', $row['targetid'], $info))
						return false;
					return self::$wbdb->updata('detail', $row['targetid'], $info);
				}else if ($row['type'] == 2){//回答评论
					if (self::$rbdb->lists('tac', $info[0], 0, 1, $rdata)){//已经存在时要退出
						for($i=0;$i<$rdata['num'];$i++)
						{
							if ($rdata[$i]['data']['commentid'] == $info[2])
								return true;
						}
					}
					if (!self::$wbdb->lists('tac', $info, $row))
						return false;
					$info = array();
					$info['cnum'] = intval($rdata['total'])+1;
					if (!self::$wbdb->updata('answer', $row['targetid'], $info))
						return false;
					$qid = self::$wbdb->mdata['questionid'];
					$info = array();
					$info['a']["$row[targetid]"]['cnum'] = intval($rdata['total'])+1;
					return self::$wbdb->updata('detail', $qid, $info);
				}
				break;
			case EVENT_COMMENT_DEL:
				if ($row['type'] == 1){//问题评论
					if (!self::$com->dellist('tqc', $row['targetid'], strtotime($row['ctime']), $row['commentid']))
						return false;
					$info = array();
					$info['cnum'] = -1;
					if (!self::$wbdb->updata('question', $row['targetid'], $info,array('cnum')))
						return false;
					return self::$wbdb->updata('detail', $row['targetid'], $info,array('cnum'));
				} else if ($row['type'] == 2){
					if (!self::$com->dellist('tac', $row['targetid'], strtotime($row['ctime']), $row['commentid']))
						return false;
					$info = array();
					$info['cnum'] = -1;
					if (!self::$wbdb->updata('answer', $row['targetid'], $info,array('cnum')))
						return false;
					$qid = self::$wbdb->mdata['questionid'];
					$info = array();
					$info['a']["$row[targetid]"]['cnum'] = -1;
					return self::$wbdb->updata('detail',$qid, $info,array('cnum'));
				}
				break;
			case EVENT_QUESTION_INVITE:
				return self::$com->addlist('tin',$row['questionid'],strtotime($row['ctime']),$row['inviter'],(float)$row['uid']);
			case EVENT_QUESTION_INVITE_DEL:
				return self::$com->dellist('tin',$row['questionid'], $row['inviter'], $row['inviter']);
			case EVENT_VOTE_AGREE_ADD://投票赞同；知识人回答赞同
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				if (!is_array($rdata))
					return false;
				if (isset($rdata['a']["$row[answerid]"][2]["$row[uid]"]))//已经投票成功
					return true;
				if (empty($rdata['a']["$row[answerid]"]['answerid']))//投票比回答同步快的
					return false;
				$info['a']["$row[answerid]"][2]["$row[uid]"] = $row['uid'];
				$info['a']["$row[answerid]"][1]["$row[uid]"] = '';
				if ($rdata['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
					if (count($rdata['a']["$row[answerid]"][2]) + count($rdata['a']["$row[answerid]"][1]) >= $rdata['data_append']['votetotal'])
						return true;//达到投票上限
				}else{
					if (!self::$rbdb->gets('user',$row['uid'], $udata))
						return false;
					$info['a']["$row[answerid]"]['weight'] = $udata['weight'];
					$info['a']["$row[answerid]"]['index'] = $udata['weight'];
				}
				self::$wbdb->upinfo($info, $rdata, array('weight','index'));
				$info = array();
				$info['weight'] = self::getqweight($rdata);
				$info['last'] = $row['ctime'];
				$info['utime'] = $row['utime'];
				if (!self::$wbdb->updata('detail',$row['questionid'], $info, array(), $rdata))
					return false;
				if ($rdata['data_append']['syncid'] != ZHISHI_APP_ID){
					$weight = self::$wbdb->mdata['weight'];
					if (!empty(self::$wbdb->mdata['tags']))
					foreach(self::$wbdb->mdata['tags'] as $tid => $v)
					{
						$info = array();
						$info[0] = $row['questionid'];
						$info[1] = $weight;
						if ($weight >= self::$com->userweight)
							if (!self::$wbdb->updata('relate', $tid, $info))
								return false;
					}
					//摘要回答计数投票+1
					if (!self::$wbdb->updata('answer',$row['answerid'], array('vnum'=> 1), array('vnum')))
						return false;
					if (!empty($rdata['a']["$row[answerid]"]['uid'])){
						//给回答者增加个人权重
						if (!self::$wbdb->updata('user',$rdata['a']["$row[answerid]"]['uid'], array('weight'=>10),array('weight','vnum')))
							return false;
						return self::$com->addlist('uqv', $rdata['a']["$row[answerid]"]['uid'], strtotime($row['ctime']), $row['uid'], (float)$row['questionid']);
					}
				}else{
					if (!empty($rdata['a']["$row[answerid]"]['uid']))
						return self::$com->addlist('uzv', $rdata['a']["$row[answerid]"]['uid'], strtotime($row['ctime']), $row['uid'], (float)$row['questionid']);
				}
				break;
			case EVENT_VOTE_AGREE_DEL://取消赞同投票
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				if (!isset($rdata['a']["$row[answerid]"][2]["$row[uid]"]))//已经无投票
					return true;
				$info['a']["$row[answerid]"][2][$row['uid']] = '';
				if (!self::$rbdb->gets('user',$row['uid'], $udata))
					return false;
				$info['a']["$row[answerid]"]['weight'] = -$udata['weight'];
				$info['a']["$row[answerid]"]['index'] = -$udata['weight'];
				self::$wbdb->upinfo($info, $rdata, array('weight','index'));
				if (!self::$wbdb->updata('detail',$row['questionid'], array('weight'=>self::getqweight($rdata),'last'=>$row['ctime']), array(), $rdata))
					return false;
				if (!self::$wbdb->updata('answer',$row['answerid'], array('vnum'=>1), array('vnum')))
					return false;
				//投票数减少，减个人权重
				if (!self::$wbdb->updata('user',$rdata['a']["$row[answerid]"]['uid'], array('weight'=>-10),array('weight','vnum')))
					return false;
				return self::$com->dellist('uqv', $rdata['a']["$row[answerid]"]['uid'], $row['uid'], $row['uid']);
			case EVENT_VOTE_AGAINST_ADD://反对票；知识人回答反对
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				if (isset($rdata['a']["$row[answerid]"][1]["$row[uid]"]))//已经有反对票，退出
					return true;
				if (isset($rdata['a']["$row[answerid]"][2]["$row[uid]"])){//如果有赞同票
					if ($rdata['data_append']['syncid'] == ZHISHI_APP_ID)
						return true;
					if (!self::$wbdb->updata('answer',$row['answerid'], array('vnum'=>-1), array('vnum')))
						return false;
					//投票数减少，减个人权重
					if (!self::$wbdb->updata('user',$rdata['a']["$row[answerid]"]['uid'], array('weight'=>-10),array('weight','vnum')))
						return false;
					if (!self::$com->dellist('uqv', $rdata['a']["$row[answerid]"]['uid'], $row['uid'], $row['uid']))
						return false;
				}
				if ($rdata['data_append']['syncid'] != ZHISHI_APP_ID){
					if (!self::$rbdb->gets('user',$row['uid'], $udata))
						return false;
					$info['a']["$row[answerid]"]['index']  = -$udata['weight'];
				}else{
					return self::$com->addlist('uzv', $rdata['a']["$row[answerid]"]['uid'], strtotime($row['ctime']), $row['uid'], (float)$row['questionid']);
				}
				$info['a']["$row[answerid]"][2][$row['uid']] = '';
				$info['a']["$row[answerid]"][1][$row['uid']] = $row['uid'];
				self::$wbdb->upinfo($info, $rdata, array('index'));
				return self::$wbdb->updata('detail',$row['questionid'], array('weight'=>self::getqweight($rdata),'last'=>$row['ctime']), array(), $rdata);
			case EVENT_VOTE_AGAINST_DEL:
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				if (!isset($rdata['a']["$row[answerid]"][1]["$row[uid]"]))//已经无反对票，退出
					return true;
				$info['a']["$row[answerid]"][1][$row['uid']] = '';
				if (!self::$rbdb->gets('user',$row['uid'], $udata))
					return false;
				$info['a']["$row[answerid]"]['index']  = $udata['weight'];
				self::$wbdb->upinfo($info, $rdata, array('index'));
				return self::$wbdb->updata('detail',$row['questionid'], array('weight'=>self::getqweight($rdata),'last'=>$row['ctime']), array(), $rdata);
			case EVENT_VOTE_NOHELP:
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				if (!is_array($rdata))
					return false;
				if (isset($rdata['a']["$row[answerid]"][0]["$row[uid]"]))//已经有无帮助，退出
					return true;
				$rdata['a']["$row[answerid]"][0][$row['uid']] = $row['uid'];
				//$info['a']["$row[answerid]"]['weight']  = -1000;
				//self::$wbdb->upinfo($info, $rdata, array('weight'));
				return self::$wbdb->updata('detail',$row['questionid'], array('last'=>$row['ctime']), array(), $rdata);
			case EVENT_TAG_ADD://增加话题
				if (!self::$wbdb->updata('tagid',$row['tid'], $row,array(), array()))
					return false;
				return self::$wbdb->updata('tag',$row['name'], $row['tid']);
			case EVENT_TAG_UPDATE:
			case EVENT_TAG_UPDATE_LOGO:
				$uid = $row['uid'];
				unset($row['uid']);
				if (isset($row['name']) && !self::$wbdb->updata('tag',$row['name'], $row['tid']))
					return false;
				return self::$wbdb->updata('tagid',$row['tid'], $row);
			case EVENT_TAG_UPDATE_NAME:
			return self::$wbdb->updata('tag',$row['name'], $row['tid']);
			case EVENT_TAG_DEL:
			case EVENT_TAG_REST:
				return self::$wbdb->updata('tagid',$row['tid'], array('showflag'=>$row['showflag']));
			case EVENT_TAG_LOCK:
				return self::$wbdb->updata('tagid',$row['tid'], array('status'=>$row['status']));
			case EVENT_TAG_FATHER_ADD://增加父话题id
			case EVENT_TAG_CHILD_ADD:
				$fid = $row['fid'];
				$cid = $row['cid'];
				$info['cid']["$cid"] = $row['tag'];
				return self::$wbdb->updata('tagid',$fid, $info);
			case EVENT_TAG_FATHER_DEL:
			case EVENT_TAG_CHILD_DEL:
				$fid = $row['fid'];
				$cid = $row['cid'];
				$info['cid']["$cid"] = '';
				return self::$wbdb->updata('tagid', $fid, $info);
			case EVENT_TAG_EXP_UPDATE://话题经验
				if ($row['content'] == ''){
					return self::$com->dellist('ut', $row['uid'], $row['tid'], $row['tid']);
				}
				$info['content'] = $row['content'];
				$info['tname'] = $row['tname'];
				return self::$com->addlist('ut',$row['uid'],strtotime($row['ctime']),$row['tid'],$info);
			case EVENT_USER_UPDATE_LOGO://用户修改头像
			case EVENT_USER_UPDATE://用户修改
				if (isset($row['utime'])){
					$utime = $row['utime'];
					unset($row['utime']);
				}
				if (!self::$rbdb->gets('user',$row['uid'], $rdata))
					return false;
				if (!self::$wbdb->updata('user',$row['uid'], $row, array(), $rdata))
					return false;
				if (isset($row['nick'])){
					return self::$wbdb->updata('nick',$row['nick'], $row['uid'], self::$wbdb->mdata['nick']);
				}
				break;
			case EVENT_USER_REGISTER:
				$row['weight'] = self::$com->userweight;
				if (!self::$wbdb->updata('user', $row['uid'], $row,array(), array()))
					return false;
				return self::$wbdb->updata('nick', $row['nick'], $row['uid'],'');
			case EVENT_INDEX_INTEREST:
				if (!isset($row['uid']))
					return false;
				$uid = $row['uid'];
				unset($row['uid']);
				return self::$wbdb->updata('interest', $uid, $row);
			case EVENT_USER_FOLLOW_ADD://关注用户
			case EVENT_TAG_FOLLOW_ADD:
			case EVENT_QUESTION_FOLLOW_ADD:
			case EVENT_QUESTION_FOLLOW_ADD_ZHISHI:
				$ctime = (empty($row['ctime'])?time():strtotime($row['ctime']));
				$mtype = '';
				$otype = '';
				switch($type)
				{
					case EVENT_USER_FOLLOW_ADD:
						$mtype = 'gpm';
						$otype = 'gpo';
						break;
					case EVENT_TAG_FOLLOW_ADD:
						$mtype = 'gtm';
						$otype = 'gto';
						break;
					case EVENT_QUESTION_FOLLOW_ADD:
						$mtype = 'gqm';
						$otype = 'gqo';
						break;
					case EVENT_QUESTION_FOLLOW_ADD_ZHISHI:
						$mtype = 'gsm';
                                                $otype = 'gso';
                                                break;
					default:
						return false;
				}
				if (!self::$com->addlist($mtype, $row['uid'], $ctime, $row['toid']))//我关注的
					return false;
				if (!self::$com->addlist($otype, $row['toid'], $ctime, $row['uid'], (isset($row['owner'])?$row['owner']:'')))//关注他的
					return false;
				if ($type == EVENT_USER_FOLLOW_ADD){//判断双向关注
					if (!self::$rbdb->getlistkey($otype, $row['toid'], $row['uid'], $data))
						return false;
					if (is_numeric($data)){
						if (!self::$com->addlist('gpd', $row['uid'], $ctime, $row['toid']) || !self::$com->addlist('gpd', $row['toid'], $data, $row['uid']))
							return false;
					}
				}
				break;
			case EVENT_USER_FOLLOW_DEL:
			case EVENT_TAG_FOLLOW_DEL:
			case EVENT_QUESTION_FOLLOW_DEL:
			case EVENT_QUESTION_FOLLOW_DEL_ZHISHI:
				$mtype = '';
				$otype = '';
				switch($type)
				{
					case EVENT_USER_FOLLOW_DEL:
						$mtype = 'gpm';
						$otype = 'gpo';
						break;
					case EVENT_TAG_FOLLOW_DEL:
						$mtype = 'gtm';
						$otype = 'gto';
						break;
					case EVENT_QUESTION_FOLLOW_DEL:
						$mtype = 'gqm';
						$otype = 'gqo';
						break;
					case EVENT_QUESTION_FOLLOW_ADD_ZHISHI:
                                                $mtype = 'gsm';
                                                $otype = 'gso';
                                                break;
					default:
						return false;
				}
				if (!self::$com->dellist($mtype, $row['uid'], $row['toid'], $row['toid']))
					return false;
				if (!self::$com->dellist($otype, $row['toid'], $row['uid'], $row['uid']))
					return false;
				if ($type == EVENT_USER_FOLLOW_DEL){//判断双向关注
					if (!self::$rbdb->getlistkey($otype, $info[0], $info[2], $data))
						return false;
					if (is_numeric($data)){
						if (!self::$com->dellist('gpd', $row['uid'], $row['toid'], $row['toid']) || !self::$com->dellist('gpd', $row['toid'], $row['uid'], $row['uid']))
							return false;
					}
				}
				break;
			case EVENT_LOG_ADD:
				return self::$com->uplog($row);
			case EVENT_LOG_DEL:
				return self::$com->uplog($row,'del');
			case EVENT_TAG_ANSWER_VOTE:
				if (isset($row['data']['tid'])){
					$tid = $row['data']['tid'];
					unset($row['data']['tid']);
					return self::$wbdb->updata('vanswer', $tid, $row['data']);
				}
				break;
			case EVENT_TAG_ANSWER_USER:
				$tid = $row['tid'];
				unset($row['tid']);
				return self::$wbdb->updata('canswer', $tid, $row);
			case EVENT_INDEX_HOT_ANSWER:
				$ctime = strtotime($row['ctime']);
				unset($row['ctime']);
				return self::$wbdb->updata('hotanswer', $ctime, $row);
			case EVENT_INDEX_SAME_USER:
				$uid = $row['uid'];
				unset($row['uid']);
				return self::$wbdb->updata('same', $uid, $row);
			case EVENT_QUESTION_PRICE://提高悬赏分
				if (!self::$wbdb->updata('question', $row['questionid'], $row))
					return false;
				if (!self::$wbdb->updata('detail', $row['questionid'], $row))
					return false;
				return self::$com->addclist(self::$wbdb->mdata, 'ch');
			case EVENT_QUESTION_FUN_ADD://添加有趣问题
			case EVENT_QUESTION_FUN_DEL://删除有趣问题
				if (!self::$wbdb->updata('question', $row['questionid'], $row))
					return false;
				if (!self::$wbdb->updata('detail', $row['questionid'], $row))
					return false;
				return ($type==EVENT_QUESTION_FUN_ADD?self::$com->addclist(self::$wbdb->mdata, 'cc'):self::$com->delclist(self::$wbdb->mdata, 'cc'));
			case EVENT_QUESTION_EXPIRED://过期
				if (!self::$rbdb->gets('detail', $row['questionid'], $rqdata))
					return false;
				if (!self::$wbdb->updata('question', $row['questionid'], $row))
					return false;
				if (!self::$wbdb->updata('detail', $row['questionid'], $row))
					return false;
				return self::$com->upstatus(self::$wbdb->mdata, $rqdata);
			case EVENT_QUESTION_VOTE://设置投票状态
				$info['data_append']['votetotal'] = $row['votetotal'];
				$info['data_append']['prizetime'] = $row['utime'];
				$info['status'] = $row['status'];
				if (!self::$rbdb->gets('detail', $row['questionid'], $rqdata))
					return false;
				if (!self::$wbdb->updata('question', $row['questionid'], $info))
					return false;
				$info['a'] = $row['a'];
				if (!self::$wbdb->updata('detail', $row['questionid'], $info, array(), $rqdata))
					return false;
				return self::$com->upstatus(self::$wbdb->mdata, $rqdata);
			case EVENT_QUESTION_CLASS://转移分类
				if (empty($row['classid'])) return true;
				$f = self::$com->get_All_Fatherclass($row['classid']);
				$row['father'] = $f;
				$row['clsname'] = $f[0][1];
				if (!self::$rbdb->gets('detail', $row['questionid'], $rqdata))
					return false;
				if (!self::$com->delclist($rqdata)) return false;
				if (!self::$wbdb->updata('question', $row['questionid'], $row))
					return false;
				if (!self::$wbdb->updata('detail', $row['questionid'], $row, array(), $rqdata))
					return false;
				return self::$com->addclist(self::$wbdb->mdata);
			default:
				return false;
		}
		return true;
	}
	//获取权重
	private function getqweight($rdata)
	{
		$total = 0;
		foreach ($rdata['a'] as $aid => $v)
		{
			if (isset($v['weight']) && $v['weight'] > 0)
				$total += 2*$v['weight'] - self::$com->userweight;
		}
		return $total;
	}
}
?>