<?php
//搜索操作类

class search{
	static $mtype; //搜索类型 1 问题， 2 话题， 3 问题和话题
	static $timeout;
	function __construct()
	{
		self::$mtype = array(1,2,3);
		self::$timeout = 2;
	}
	
	//key 搜索关键词
	//data array(m 总个数 result 结果数组 array(id qid_type,title ,content, type)) 
	//话题 source = 2  关键字 title2  
	//问题 source = 1  关键字 title1 不需要加*%2b
	//问题和话题都有 source = 1  关键字 title1 title2
	function get($arr, $start, $num,&$data)
	{
		//test 
		//$test_ip = 'http://172.16.106.100/openapi/rpcAsk2.php';		
		$title = '?title1='.urlencode($arr['title1']).'&title2=*%2b'.urlencode($arr['title2']);
		//排序的时候是单独查的，排序的参数如下:	
		if($arr['source'] == 1){
			$x_calc = '&x_calc1=matchratio*(256-title_len)';
		}
		else if($arr['source'] == 2){
			$x_calc = '&x_calc2=matchratio*(256-title_len)';
		}
		else if ($arr['source'] == 3){
			$x_calc = '&x_calc2=matchratio*(256-title_len)';
		}
		$data = array();
		if (!in_array($arr['source'], self::$mtype))
			return '';
		
		//$query = SEARCH_CGI.'?title=*%2b'.urlencode($key).($source?'&source='.$source:'').'&x_calc=matchratio*(256-title_len)&start='.(empty($start)?0:$start).'&num='.(empty($num)?10:$num);
		$query = SEARCH_CGI.$title.'&source='.$arr['source'].$x_calc.'&start='.(empty($start)?0:$start).'&num='.(empty($num)?10:$num);
		$m = file_get_contents($query, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		$data = json_decode($m, true);
		return true;
	}
	
	//获取原始接口数据
	function getreal($key, $start, $num, $type=0)
	{
		if (!in_array($type, self::$mtype))
			return '';
		$query = SEARCH_CGI.'?query=title:'.urlencode($key).($type==0?'':'%20X_where:type_d=='.$type).'&start='.(empty($start)?0:$start).'&num='.(empty($num)?10:$num);
		return file_get_contents($query, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
	}
	
}

?>
