<?php
//bdb详细执行

class BdbClient
{
	function __construct()
	{
		
	}
	//组织发送信息
	private function createhead($input, &$header)
	{
		$header = '';
		if (empty($input['database']) || empty($input['type']) || (isset($input['data']) && is_array($input['data'])))
			return false;
		$header  = $input['type'].' /'.$input['database'].'/';
		$header .= is_array($input['table'])?'*':$input['table'];
		$header .= '/';
		//if (!empty($input['binkey']) || is_array($input['table']))
		//{
			$header .= '/';
			$header .= pack('v', count($input['key']));
			if (is_array($input['key'])){
				$keys = '';
				foreach($input['key'] as $k => $key)
				{
					if (is_array($input['table'])){
						$header .= pack('v', strlen($key)+strlen($input['table'][$k])+1);
						$keys   .= $input['table'][$k]."\0".$key;
					}else{
						$header .= pack('v', strlen($key));
						$keys   .= $key;
					}
				}
				$header .= $keys;
			}else{
				$header .= pack('v', strlen($input['key']));
				$header .= $input['key'];
			}
		//}
		/*else
		{
			if (is_array($input['key']))
				$header .= implode(',', $input['key']);
			else
				$header .= $input['key'];
		}*/
		$query = '';
		if (array_key_exists('num', $input))
			$query .= '&num='.$input['num'];
		if (array_key_exists('start', $input))
			$query .= '&start='.$input['start'];
		if (array_key_exists('order', $input))
			$query .= '&order='.$input['order'];
		if (!empty($input['keys']))
			$query .= '&keys='.$input['keys'];
		if (!empty($query))
			$header .= '?'.substr($query, 1);
		$header .= " HTTP/1.0\r\n";
		$header .= "Host: ".$input['ip']."\r\n";
		$header .= "Content-Length: ".(array_key_exists('data', $input)?strlen($input['data']):0)."\r\n";
		$header .= "\r\n";
		$header .= (array_key_exists('data', $input)?$input['data']:'');
		$header = 'v'.pack("V", strlen($header)+6)."\n".$header;
		return true;
	}
	//解析返回值
	public function parse($data, &$rdata)
	{
		if (strlen($data) < 6)
			return ;
		$ver = @unpack("v", substr($data, 0, 2));
		switch($ver[1])
		{
			case 1://getlist
				$total = @unpack("V", substr($data, 2, 4));
				if (!$total)
					return ;
				$num = @unpack("v", substr($data, 6, 2));
				if (!$num)
					return ;
				$tsize = 8+$num[1]*8;
				for($i=0;$i<$num[1];$i++)
				{
					$size = @unpack("V", substr($data, 8+$i*8, 4));
					if ($size){
						$rdata[$i]['data'] = ($size[1] === 0?'':substr($data, $tsize, $size[1]));
						$tsize += $size[1];
					}else{
						$rdata[$i]['data'] = '';
					}
					$ksize = @unpack("V", substr($data, 8+$i*8+4, 4));
					if ($ksize){
						$rdata[$i]['key'] = ($ksize[1] === 0?'':substr($data, $tsize, $ksize[1]));
						$tsize += $ksize[1];
					}else{
						$rdata[$i]['key'] = '';
					}
				}
				$rdata['total'] = $total[1];
				$rdata['num'] = $num[1];
			break;
			case 2://get
				$num = @unpack("V", substr($data, 2, 4));
				if (!$num)
					return ;
				$tsize = 6+$num[1]*4;
				for($i=0;$i<$num[1];$i++)
				{
					$size = @unpack("V", substr($data, 6+$i*4, 4));
					if ($size){
						$rdata[$i] = ($size[1] === 0?'':substr($data, $tsize, $size[1]));
						$tsize += $size[1];
					}else{
						$rdata[$i] = '';
					}
				}
			break;
			case 3://get visit
				$total = @unpack("v", substr($data, 2, 2));
				if (!$total)
					return ;
				$num = @unpack("v", substr($data, 4, 2));
				if (!$num)
					return ;
				$rdata['total'] = $total[1];
				$rdata['num'] = $num[1];
				$tsize = 6+$rdata['num']*4;
				for($i=0;$i<$num[1];$i++)
				{
					$size = @unpack("V", substr($data, 6+$i*4, 4));
					if ($size){
						$rdata[$i] = ($size[1] === 0?'':substr($data, $tsize, $size[1]));
						$tsize += $size[1];
					}else{
						$rdata[$i] = '';
					}
				}
			break;
			case 4://getlist multi
				$total = @unpack("V", substr($data, 2, 4));
				if (!$total)
					return ;
				$num = @unpack("v", substr($data, 6, 2));
				if (!$num)
					return ;
				$tsize = 8+$num[1]*8;
				for($i=0, $j=$num[1]-1;$i<$num[1];$i++,$j--)
				{
					$size = @unpack("V", substr($data, 8+$i*8, 4));
					if ($size){
						$rdata[$j]['data'] = ($size[1] === 0?'':substr($data, $tsize, $size[1]));
						$tsize += $size[1];
					}else{
						$rdata[$j]['data'] = '';
					}
					$ksize = @unpack("V", substr($data, 8+$i*8+4, 4));
					if ($ksize){
						$rdata[$j]['key'] = ($ksize[1] === 0?'':substr($data, $tsize, $ksize[1]));
						$tsize += $ksize[1];
					}else{
						$rdata[$j]['key'] = '';
					}
				}
				ksort($rdata);
				$rdata['total'] = $total[1];
				$rdata['num'] = $num[1];
			break;
			default:
			return;
		}
	}
	//执行
	public function run($input, &$out)
	{
		$out = array();
		if (!self::createhead($input, $header))
			return false;
		if (!self::send($header, $rdata, $input['ip'], $input['port'])){
			usleep(10);
			if (!self::send($header, $rdata, $input['ip'], $input['port']))
				return false;
		}
		self::parse($rdata, $out);
		return true;
	}
	//并行执行多条
	public function runmulti($inputs, &$out)
	{
		$out = array();
		$pout = array();
		$sockets = array();
		foreach ($inputs as $i => $input)
		{
			if (!self::createhead($input, $sdata))
				return false;
			if (!($sockets["$i"] = self::casyncsocket($input['ip'], $input['port'], $sdata)))
				return false;
		}
		$read = $sockets;
		$null = NULL;
		while(stream_select($read, $null, $null, BDB_DEFAULT_TIMEOUT) > 0){
			foreach ($read as $r)
			{
				$i = array_search($r, $sockets);
				$ret = fread($r, 8192);
				if (strlen($ret) == 0){
					@fclose($r);
					unset($sockets["$i"]);
				}else if (!isset($pout["$i"])){
					if (strncmp($ret, "HTTP/1.1 200", 12) !== 0){
						@fclose($r);
						unset($sockets["$i"]);
						$pout["$i"] = '';
					}else{
						$pout["$i"] = substr($ret, strpos($ret, "\r\n\r\n") + 4);
					}
				}else{
					$pout["$i"] .= $ret;
				}
			}
			if (empty($sockets))
				break;
			$read = $sockets;
		}
		foreach ($pout as $i => $v)
		{
			self::parse($v, $out["$i"]);
		}
		return true;
	}
	//异步socket
	private function casyncsocket($server, $port, $data)
	{
		$fp = @stream_socket_client('tcp://'.$server.':'.$port, $errno, $errstr, BDB_DEFAULT_TIMEOUT, STREAM_CLIENT_CONNECT | STREAM_CLIENT_ASYNC_CONNECT);
		if (!$fp){
			usleep(100);
			$fp = @stream_socket_client('tcp://'.$server.':'.$port, $errno, $errstr, BDB_DEFAULT_TIMEOUT, STREAM_CLIENT_CONNECT | STREAM_CLIENT_ASYNC_CONNECT);
		}
		if (!@fwrite($fp, $data)){
			@fclose($fp);
			return false;
		}
		//if (!@stream_socket_shutdown($fp, STREAM_SHUT_WR)){
		//	@fclose($fp);
		//	return false;
		//}
		return $fp;
	}
	
	//发送
	public function send($sdata, &$rdata, $server, $port)
	{
		$rdata = '';
		$fp = @fsockopen($server, $port, $errno, $errstr, BDB_DEFAULT_TIMEOUT);
		if (!$fp){
			usleep(100);
					$fp1 = @fopen('/tmp/client.err', 'a');
                                	@fwrite($fp1, $server.':'.$port.':connect0:'.substr($lines,0, 50)."\n");
                                	@fclose($fp1);
			$fp = @fsockopen($server, $port, $errno, $errstr, BDB_DEFAULT_TIMEOUT);
			if (!$fp){
					$fp1 = @fopen('/tmp/client.err', 'a');
                                	@fwrite($fp1, $server.':'.$port.':connect1:'.substr($lines,0, 50)."\n");
                                	@fclose($fp1);
				return false;
			}
		}
		if (!@fwrite($fp, $sdata)){
			@fclose($fp);
			return false;
		}
		//if (!@stream_socket_shutdown($fp, STREAM_SHUT_WR)){
		//	@fclose($fp);
		//	return false;
		//}
		$i = 0;
		while(!@feof($fp))
		{
			$lines = fread($fp, 8192);
			if (strlen($lines) == 0){
				if ($i === 0){
					$fp1 = @fopen('/tmp/client.err', 'a');
                                	@fwrite($fp1, $server.':'.$port.':line0:'.$lines."\n");
                                	@fclose($fp1);
					@fclose($fp);
					return false;
				}
				break;
			}
			if ($i === 0){
				if (strncmp($lines, "HTTP/1.1 200", 12) !== 0){
					$fp1 = @fopen('/tmp/client.err', 'a');
                                	@fwrite($fp1, $server.':'.$port.':return:'.substr($lines,0, 50)."\n");
                                	@fclose($fp1);
					@fclose($fp);
					return false;
				}else{
					$rdata = substr($lines, strpos($lines, "\r\n\r\n") + 4);
				}
				$i++;
				continue;
			}
			$rdata .= $lines;
		}
		@fclose($fp);
		return true;
	}
}
?>
