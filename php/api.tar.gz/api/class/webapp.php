<?php
//web 基类

abstract class webApp
{
	abstract function main();

	function run()
	{
		try 
		{
			$this->main();
		}
		catch (Exception $e)		//普通异常
		{
			//处理异常
			self::error($e);
		}
	}
	
	
	//异常处理
	function error($e)
	{
		//错误处理
		
		//输出错误页面
		
	}

	//错误对应
	function error_num($v){
		global $g_error_app;
		$json_array = array('error_num'=>$v);
		$json_array['error'] = $g_error_app[$v];
		echo json_encode($json_array);
		exit;
	}
}

?>
