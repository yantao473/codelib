<?php

class mysqlevent {
	private $sql;
	private $dbname;
	function __construct()
	{
		$this->mysql_obj = new MysqlDb;
		$this->rpc_obj = new RpcDb;
	}

	function run($row)
	{
		if (!isset($row[0]))
			return false;
		$type = $row[0];
		unset($row[0] , $this->sql);
		// 调用mysql 只涉及update语句
		switch($type)
		{
			case EVENT_QUESTION_ADD://新加问题
				break;
			case EVENT_QUESTION_DEL://删除问题
			case EVENT_QUESTION_REST://恢复问题
				break;
			case EVENT_QUESTION_UPDATE:
			case EVENT_QUESTION_TITLE_UPDATE:
			case EVENT_QUESTION_REDIRECT:
				$this->dbname = 'question';
				$this->sql  = $this->mysql_obj->prepare_update_sql("question" , $row);
				$this->sql .= " where questionid = '{$row['questionid']}' ";
				break;
			case EVENT_QUESTION_DESC_UPDATE:
				break;
			case EVENT_QUESTION_LOCK:
				break;
			case EVENT_QUESTION_TAG_ADD://问题增加话题
				break;
			case EVENT_QUESTION_TAG_DEL:
				break;
			case EVENT_ANSWER_ADD://添加回答
				break;
			case EVENT_ANSWER_DEL:
			case EVENT_ANSWER_RECOVER:
				break;
			case EVENT_ANSWER_UPDATE:
				break;
			case EVENT_QUESTION_ADOPT:
				break;
			case EVENT_COMMENT_ADD://评论
				break;
			case EVENT_COMMENT_DEL:
				break;
			case EVENT_QUESTION_INVITE:
				break;
			case EVENT_QUESTION_INVITE_DEL:
				break;
			case EVENT_VOTE_AGREE_ADD://投票赞同
				break;
			case EVENT_VOTE_AGREE_DEL://取消赞同投票
				break;
			case EVENT_VOTE_AGAINST_ADD://反对票
				break;
			case EVENT_VOTE_AGAINST_DEL:
				break;
			case EVENT_VOTE_NOHELP:
				break;
			case EVENT_TAG_ADD://增加话题
				break;
			case EVENT_TAG_UPDATE:	// 话题更新
			case EVENT_TAG_UPDATE_LOGO:
				$this->dbname = 'question';
				$this->sql  = $this->mysql_obj->prepare_update_sql("tag" , $row);
				$this->sql .= " where tid = '{$row['tid']}' ";
				break;
			case EVENT_TAG_DEL:
				break;
			case EVENT_TAG_LOCK:
				break;
			case EVENT_TAG_FATHER_ADD://增加父话题id
			case EVENT_TAG_CHILD_ADD:
				break;
			case EVENT_TAG_FATHER_DEL:
			case EVENT_TAG_CHILD_DEL:
				break;
			case EVENT_TAG_EXP_UPDATE://话题经验
				break;
			case EVENT_USER_UPDATE_LOGO://用户修改头像
			case EVENT_USER_UPDATE://用户修改
				break;
			case EVENT_USER_REGISTER:
				break;
			case EVENT_INDEX_INTEREST:
			case EVENT_TAG_FOLLOW_ADD:
			case EVENT_QUESTION_FOLLOW_ADD:
				break;
			case EVENT_USER_FOLLOW_DEL:
			case EVENT_TAG_FOLLOW_DEL:
			case EVENT_QUESTION_FOLLOW_DEL:
				break;
			case EVENT_LOG_ADD:
				break;
			case EVENT_LOG_DEL:
				break;
			case EVENT_TAG_ANSWER_VOTE:
				break;
			case EVENT_TAG_ANSWER_USER:
				break;
			case EVENT_INDEX_HOT_ANSWER:
				break;
			case EVENT_INDEX_SAME_USER:
				break;
			default:
				return false;
		}
		if($this->sql) {
			echo 'sql : ' . $this->sql . "\n";
			$this->rpc_obj->update($this->dbname , $this->sql , $data);
			return true;
		}
		else {
			echo 'sql : 此事件不产生sql' . "\n";
			return false;
		}
	}
}
?>
