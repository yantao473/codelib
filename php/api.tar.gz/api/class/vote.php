<?php
/**
 * @fn              赞接口类
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-08-24
 */

include_once("apiconf.php");

class Vote {
	
	public $g_para;
	public $g_result;

	function  __construct(&$g_para , &$g_result) {
		$this->g_para	= &$g_para;
		$this->g_result = &$g_result;
		$this->db	= new RpcDb();
		$this->tools_obj= new Tools();
	}

	/**
	 * @公共 之 发送BDB
	 * @date 2012-08-24
	 **/
	function send_bdb($arr , &$queue_result) {
		$ser_array = array('data' => serialize($arr));
		$url = QDOMAIN . "/send_queue.php";
		$res = $this->tools_obj->curl_set($url , 'POST' , $ser_array , $queue_result);
		return $res;
	}

	/**
	 * @公共 之 写MYSQL
	 * @date 2012-08-24
	 **/	
	function send_mysql($arr ,$type, &$data){
		if($type == 1){
			$get_sql  = $this->db->prepare_insert_sql("vote" , $arr);
		}else if ($type == 2){
			$get_sql = $arr;
		}
		$rpcdb_result = $this->db->update("question",$get_sql,$data);
		return $rpcdb_result;
	}

	/**
	 * @微什么 之 添加赞同feed
	 * @date 2012-08-24
	 **/
        function add_vote_feed(){
                $eid = EVENT_VOTE_AGREE_ADD;
                $objs = array(
                                'uid'=>$this->g_para['uid'],
                                'qid'=>$this->g_para['questionid'],
                                'aid'=>$this->g_para['answerid'],
                             );
                $res = feed::addFeedataToQueue($eid,$objs);
        }
}
?>
