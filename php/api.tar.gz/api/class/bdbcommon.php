<?php
//bdb事件处理，公共处理函数

class bdbcommon{
	static private $wbdb;
	static private $rbdb;
	static public $userweight;
	static private $key2all;
	static private $level1;
	static private $cachetime;
	static private $classarray;
	static private $readtime;
	function __construct()
	{
		self::$rbdb = new getbdb;
		self::$wbdb = new upbdb;
		self::$userweight = 7000;
		self::$key2all = array('cr'=>'lzr', 'cn'=>'lzn', 'cv'=>'lzv', 'ck'=>'lzk','ch'=>'lzh','ce'=>'lze','cc'=>'lzc','cm'=>'lzm');
		self::$level1 = array(1,2,3,4,5,6,7,8,9,10,11,12,373,506,4522);
		self::$cachetime = 1200;
		self::$classarray = array();
		self::$readtime = 0;
	}
	//取分类信息
	private function getclassinfo($c, &$data)
	{
		foreach ($c as $cid => $v)
		{
			$data[$cid][0] = $v['father'];
			$data[$cid][1] = mb_convert_encoding($v['name'], 'UTF-8', 'GBK');
			if (isset($v['child'])){
				self::getclassinfo($v['child'], $data);
			}
		}
	}
	//生成分类cache文件
	public function createclassfile()
	{
		if (time() - @filectime(QUESTION_CLASS_CACHE_PATH) < self::$cachetime)
			return true;
		$newcarray = array();
		foreach (self::$level1 as $id)
		{
			if (!($ret = @file_get_contents(GETCLASSIFYINFOLINK."?classid=$id&recurrence=y", false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>1)))))){
				usleep(1000);
				if (!($ret = @file_get_contents(GETCLASSIFYINFOLINK."?classid=$id&recurrence=y", false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>1)))))){
					return false;
				}
			}
			$r = unserialize($ret);
			if (!$r) return false;
			self::getclassinfo(array($id=>$r), $newcarray);
		}
		$f = serialize($newcarray);
		if (@file_put_contents(QUESTION_CLASS_CACHE_PATH, $f) === 0){
			return false;
		}
		return true;
	}
	//从cache文件获取分类信息
	private function getclassfile(&$data)
	{
		$data = array();
		$data = unserialize(file_get_contents(QUESTION_CLASS_CACHE_PATH));
		if (!$data)
			return false;
		return true;
	}
	//获取父分类关系
	private function getfather($data, $id, &$out)
	{
		if (isset($data["$id"])){
			$info = array();
			$info[0] = $id;
			$info[1] = $data["$id"][1];
			$out[] = $info;
			if ($data["$id"][0] != 0){
				self::getfather($data, $data["$id"][0], $out);
			}
		}
	}
	//获取分类信息
	public function get_All_Fatherclass($classid)
	{
		$t = array();
		if (time() - self::$readtime > self::$cachetime){
			if (!self::getclassfile(self::$classarray))
				return $t;
			self::$readtime = time();
		}
		self::getfather(self::$classarray, $classid, $t);
		return $t;
	}
	//取最新时间
	public function getnewtime($data)
	{
		return strtotime($data['ctime'] < $data['data_append']['prizetime'] ? ($data['data_append']['prizetime']> $data['data_append']['appendtime']?$data['data_append']['prizetime']:$data['data_append']['appendtime']):($data['ctime'] < $data['data_append']['appendtime']?$data['data_append']['appendtime']:$data['ctime']));
	}
	//添加话题列表
	public function addtag($row, $info)
	{
		if ($row['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
			if (!self::uptag($row,$info)) return false;
		}else{
			if (!empty($info['tags']))
			foreach ($info['tags'] as $tid => $tag)
			{
				if ($row['weight'] >= self::$userweight)
					if (!self::$wbdb->updata('relate', $tid, array($row['questionid'],$row['weight'])))	return false;
				
			}
			if (!self::addwtaglist($row, $info)) return false;
		}
		return true;
	}
	//删除话题列表
	public function deltag($row, $info)
	{
		if ($row['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
			if (!self::uptag($row,array(),$info)) return false;
		}else{
			if (!empty($info['tags']))
			foreach ($info['tags'] as $tid => $tag)
			{
				if (!self::$wbdb->updata('relate', $tid, array($row['questionid'],0)))	return false;
			}
			if (!self::delwtaglist($row, $info)) return false;
		}
		return true;
	}
	//添加分类，用户列表
	public function add2list($row)
	{
		$ctime = strtotime($row['ctime']);
		if ($row['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
			//添加分类，tag列表
			if (!self::addclist($row)) return false;
			if (!self::uptag($row, $row['tags'])) return false;
			//添加个人中心列表
			if (!empty($row['touid'])){
				if ($row['owner'] == 2){//向团队求助
					if (!self::addlist('cgt',$row['touid'], $ctime, $row['questionid'],(float)$row['uid'])) return false;
				}else{
					if (!self::addlist('cga',$row['touid'], $ctime, $row['questionid'],(float)$row['uid'])) return false;
					if ($row['atotal'] == 0 && !self::addlist('cgn',$row['touid'], $ctime, $row['questionid'],(float)$row['uid'])) return false;
					if ($row['atotal'] > 0 && !self::addlist('cgb',$row['touid'], $ctime, $row['questionid'],(float)$row['uid'])) return false;
				}
			}
			if (!self::addlist('uzq',$row['uid'], $ctime, $row['questionid'],(float)$row['touid'])) return false;
			if (!self::addlist('lzq', $ctime, $row['questionid'])) return false;
		}else{
			if (!empty($row['touid'])){
				if (!self::addlist('um', $row['touid'], $ctime, $row['questionid'],(float)$row['uid']))	return false;
			}
			if ($row['owner'] != 1 && !self::addlist('uq',$row['uid'], $ctime, $row['questionid'], $row['touid'])) return false;
			if (!self::addwtaglist($row)) return false;
			return self::addlist('lq', strtotime($row['ctime']), $row['questionid']);
		}
		return true;
	}
	public function del2list($row)
	{
		$ctime = strtotime($row['ctime']);
		if ($row['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
			if (!self::delclist($row)) return false;
			if (!self::uptag($row,array(), $row['tags'])) return false;
			if (!empty($row['touid'])){
				if ($row['owner'] == 2){//向团队求助
					if (!self::dellist('cgt',$row['touid'], $ctime, $row['questionid'])) return false;
				}else{
					if (!self::dellist('cga',$row['touid'], $ctime, $row['questionid'])) return false;
					if ($row['atotal'] == 0 && !self::dellist('cgn',$row['touid'], $ctime, $row['questionid'])) return false;
					if ($row['atotal'] > 0 && !self::dellist('cgn',$row['touid'], $ctime, $row['questionid'])) return false;
				}
			}
			if (!self::dellist('lzq', $ctime, $row['questionid'])) return false;
		}else{
			if (!self::dellist('uq', $row['uid'], $ctime, $row['questionid']))
				return false;
			if (!empty($row['touid'])){
				if (!self::dellist('um', $row['touid'], $ctime, $row['questionid']))
					return false;
			}
			if (!self::dellist('lq', $ctime, $row['questionid'])) return false;
			if (!self::delwtaglist($row)) return false;
		}
		return true;
	}
	//添加全部分类，知识人
	public function addclist($data, $type = '')
	{
		if (empty($data['classid']))
			return true;
		if (!empty($data['father']))
			$f = $data['father'];
		else
			$f = self::get_All_Fatherclass($data['classid']);
		$time = self::getnewtime($data);
		$f[][0] = 0;
		foreach ($f as $id)
		{
			if ($type !== ''){
				if ($type == 'ch' && $data['data_append']['price'] > 0){
					$time = (int)($data['data_append']['price'] * 1000000) + (int)($time /2000);
				}
				if (!self::addlist($type, $id[0], $time, $data['questionid'])) return false;
					continue;
			}
			switch($data['status'])
			{
				case 0://'R':
					if (!self::addlist('cr', $id[0], $time, $data['questionid'])) return false;
					if (intval($data['atotal']) == 0)
						if (!self::addlist('cn', $id[0], $time, $data['questionid'])) return false;
					if ($data['data_append']['price'] > 0){
						$ctime = (int)($data['data_append']['price'] * 1000000) + (int)($time /2000);
						if (!self::addlist('ch', $id[0], $ctime, $data['questionid'])) return false;
					}
					if ($data['data_append']['warnflag'] == 'c')
						if (!self::addlist('cm', $id[0], $time, $data['questionid'])) return false;
					break;
				case 3://'V':
					if (!self::addlist('cv', $id[0], $time, $data['questionid'])) return false;
					break;
				case 1://'K':
					if (!self::addlist('ck', $id[0], $time, $data['questionid'])) return false;
					break;
				case 2://'E':
					if (!self::addlist('ce', $id[0], $time, $data['questionid'])) return false;
					break;
				case 4://'W':
					break;
				default:
					return true;
					break;
			}
			if (empty($data['showflag'])){
				if (!self::addlist('ca', $id[0], $time, $data['questionid'])) return false;
				if ($data['data_append']['isfun'] == 1)
					if (!self::addlist('cc', $id[0], $time, $data['questionid'])) return false;
				if ($data['data_append']['auditflag'] == 'e'){//专家回答
					foreach ($f as $m)
					{
						if ($m[0] == 350){//育儿
							if (!self::addlist('cz', $id[0], $time, $data['questionid'])) return false;
						}
					}
				}
			}
		}
		return true;
	}
	//改变问题状态时，列表改变
	public function upstatus($data, $odata)
	{
		if ($data['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
			if ($odata['status'] == $data['status'])
				return true;
			if (!self::upcliststatus($data, $odata)) return false;
			$ctime = strtotime($data['ctime']);
			switch($data['status'])
			{
				case 1:
					$ctime = strtotime($data['data_append']['indbtime']);
					foreach ($data['a'] as $aid => $v)
					{
						if ($v['status'] == 1){
							if (!self::addlist('uzc',$v['uid'], $ctime, $data['questionid'],(float)$data['uid'])) return false;
							if ($v['owner'] == 2 && !self::addlist('uzy',$v['uid'], $ctime, $data['questionid'],(float)$data['uid'])) return false;
						}
					}
					break;
				case 2:
					if (!self::addlist('uze',$data['uid'], $ctime, $data['questionid'])) return false;
					break;
			}
			switch($odata['status'])
			{
				case 2:
					if (!self::dellist('uze',$data['uid'], $ctime, $data['questionid'])) return false;
					break;
			}
			return self::uptagstatus($data, $odata['status']);
		}else{
			if ($data['status'] == 1 && !self::addwtaglist($data, array(), 1)) return false;
		}
		return true;
	}
	//改变问题状态时，分类列表改变--知识人
	private function upcliststatus($data, $odata = '')
	{
		if (empty($data['classid']) || $odata['status'] == $data['status'])
			return true;
		if (!empty($data['father']))
			$f = $data['father'];
		else
			$f = self::get_All_Fatherclass($data['classid']);
		$f[][0] = 0;
		foreach ($f as $id)
		{
			$time = self::getnewtime($data);
			switch($data['status'])
			{
				case 0://'R':
					if (!self::addlist('cr', $id[0], $time, $data['questionid'])) return false;
					break;
				case 3://'V':
					if (!self::addlist('cv', $id[0], $time, $data['questionid'])) return false;
					break;
				case 1://'K':
					if (!self::addlist('ck', $id[0], $time, $data['questionid'])) return false;
					break;
				case 2://'E':
					if (!self::addlist('ce', $id[0], $time, $data['questionid'])) return false;
					break;
				case 4://'W':
					break;
				default:
					return true;
					break;
			}
			$time = self::getnewtime($odata);
			switch($odata['status'])
			{
				case 0://'R':
					if (!self::dellist('cr', $id[0], $time, $data['questionid'])) return false;
					break;
				case 3://'V':
					if (!self::dellist('cv', $id[0], $time, $data['questionid'])) return false;
					break;
				case 1://'K':
					if (!self::dellist('ck', $id[0], $time, $data['questionid'])) return false;
					break;
				case 2://'E':
					if (!self::dellist('ce', $id[0], $time, $data['questionid'])) return false;
					break;
				case 4://'W':
					break;
				default:
					break;
			}
		}
		return true;
	}
	//更新tag状态时，列表改变--知识人
	private function uptagstatus($data, $status='')
	{
		if ($data['status'] == $status)
			return true;
		$time = strtotime($data['ctime']);
		if (!empty($data['tags'])){
			foreach ($data['tags'] as $tid => $v){
				switch($data['status'])
				{
					case 0://'R':
						if (!self::addlist('tzr', $tid, $time, $data['questionid'])) return false;
						break;
					case 3://'V':
						if (!self::addlist('tzv', $tid, $time, $data['questionid'])) return false;
						break;
					case 1://'K':
						if (!self::addlist('tzk', $tid, $time, $data['questionid'])) return false;
						break;
					case 2://'E':
						if (!self::addlist('tze', $tid, $time, $data['questionid'])) return false;
						break;
					case 4:
						break;
					default:
						return true;
				}
				switch($status)
				{
					case 0://'R':
						if (!self::dellist('tzr', $tid, $time, $data['questionid'])) return false;
						break;
					case 3://'V':
						if (!self::dellist('tzv', $tid, $time, $data['questionid'])) return false;
						break;
					case 1://'K':
						if (!self::dellist('tzk', $tid, $time, $data['questionid'])) return false;
						break;
					case 2://'E':
						if (!self::dellist('tze', $tid, $time, $data['questionid'])) return false;
						break;
					case 4:
						break;
					default:
						return true;
				}
			}
		}
		return true;
	}
	//更新tag列表--知识人
	private function uptag($data, $newtags=array(), $oldtags=array())
	{
		$add = array_diff_assoc($newtags, $oldtags);
		$del = array_diff_assoc($oldtags, $newtags);
		$time = strtotime($data['ctime']);
		if (!empty($del)){
			foreach (@$del as $tid => $v){
				switch($data['status'])
				{
					case 0://'R':
						if (!self::dellist('tzr', $tid, $time, $data['questionid'])) return false;
						break;
					case 3://'V':
						if (!self::dellist('tzv', $tid, $time, $data['questionid'])) return false;
						break;
					case 1://'K':
						if (!self::dellist('tzk', $tid, $time, $data['questionid'])) return false;
						break;
					case 2://'E':
						if (!self::dellist('tze', $tid, $time, $data['questionid'])) return false;
						break;
					case 4:
						if (!self::dellist('tzr', $tid, $time, $data['questionid'])) return false;
						if (!self::dellist('tzv', $tid, $time, $data['questionid'])) return false;
						if (!self::dellist('tzk', $tid, $time, $data['questionid'])) return false;
						if (!self::dellist('tze', $tid, $time, $data['questionid'])) return false;
						break;
					default:
						return true;
				}
				if ($data['data_append']['isfun'] == 1)
					if (!self::dellist('tzc', $tid, $time, $data['questionid'])) return false;
				if (!self::dellist('tza', $tid, $time, $data['questionid'])) return false;
				if (intval($data['atotal']) == 0)
					if (!self::dellist('tzn', $tid, $time, $data['questionid'])) return false;
				if ($data['data_append']['price'] > 0){
					$ctime = (int)($data['data_append']['price'] * 1000000) + (int)($time /2000);
					if (!self::dellist('tzn', $tid, $ctime, $data['questionid'])) return false;
				}
			}
		}
		if (!empty($add)){
			foreach (@$add as $tid => $v){
				switch($data['status'])
				{
					case 0://'R':
						if (!self::addlist('tzr', $tid, $time, $data['questionid'])) return false;
						if (intval($data['atotal']) == 0)
							if (!self::addlist('tzn', $tid, $time, $data['questionid'])) return false;
						if ($data['data_append']['price'] > 0){
							$ctime = (int)($data['data_append']['price'] * 1000000) + (int)($time /2000);
							if (!self::addlist('tzn', $tid, $ctime, $data['questionid'])) return false;
						}
						break;
					case 3://'V':
						if (!self::addlist('tzv', $tid, $time, $data['questionid'])) return false;
						break;
					case 1://'K':
						if (!self::addlist('tzk', $tid, $time, $data['questionid'])) return false;
						break;
					case 2://'E':
						if (!self::addlist('tze', $tid, $time, $data['questionid'])) return false;
						break;
					case 4:
						break;
					default:
						return true;
						break;
				}
				if ($data['data_append']['isfun'] == 1)
					if (!self::addlist('tzc', $tid, $time, $data['questionid'])) return false;
				if (!self::addlist('tza', $tid, $time, $data['questionid'])) return false;
			}
		}
		return true;
	}
	//删除全部分类 --知识人
	public function delclist($data, $type='')
	{
		if (empty($data['classid']))
			return true;
		if (!empty($data['father']))
			$f = $data['father'];
		else
			$f = self::get_All_Fatherclass($data['classid']);
		$time = self::getnewtime($data);
		$f[][0] = 0;
		foreach ($f as $id)
		{
			if ($type !== ''){
				if ($type == 'ch' && $data['data_append']['price'] > 0){
					$time = (int)($data['data_append']['price'] * 1000000) + (int)($time /2000);
				}
				if (!self::dellist($type, $id[0], $time, $data['questionid'])) return false;
				continue;
			}
			switch($data['status'])
			{
				case 0://'R':
					if (!self::dellist('cr', $id[0], $time, $data['questionid'])) return false;
					break;
				case 3://'V':
					if (!self::dellist('cv', $id[0], $time, $data['questionid'])) return false;
					break;
				case 1://'K':
					if (!self::dellist('ck', $id[0], $time, $data['questionid'])) return false;
					break;
				case 2://'E':
					if (!self::dellist('ce', $id[0], $time, $data['questionid'])) return false;
					break;
				case 4://'W':
					break;
				default:
					return true;
					break;
			}
			if (!self::dellist('ca', $id[0], $time, $data['questionid'])) return false;
			if ($data['data_append']['isfun'] == 1)
				if (!self::dellist('cc', $id[0], $time, $data['questionid'])) return false;
			if ($data['data_append']['auditflag'] == 'e'){//专家回答
				foreach ($f as $m)
				{
					if ($m[0] == 350){//育儿
						if (!self::dellist('cz', $id[0], $time, $data['questionid'])) return false;
					}
				}
			}
			if (intval($data['atotal']) == 0)
				if (!self::dellist('cn', $id[0], $time, $data['questionid'])) return false;
			if ($data['data_append']['price'] > 0){
				$ctime = (int)($data['data_append']['price'] * 1000000) + (int)($time /2000);
				if (!self::dellist('ch', $id[0], $ctime, $data['questionid'])) return false;
			}
			if ($data['data_append']['warnflag'] == 'c')
				if (!self::dellist('cm', $id[0], $time, $data['questionid'])) return false;
		}
		return true;
	}
	//添加微问答tag
	private function addwtaglist($data, $tags=array(),$noq=0)
	{
		$ctime = (empty($data['utime'])?strtotime($data['ctime']):strtotime($data['utime']));
		$utags = (empty($tags['tags'])?$data['tags']:$tags['tags']);
		if (!empty($utags))
		foreach ($utags as $tid => $tag){
			if ($data['status'] == 1)
				if (!self::addlist('tk', $tid, $ctime,$data['questionid']))	return false;
			if ($noq == 0 && !self::addlist('tq', $tid, $ctime,$data['questionid']))	return false;
		}
		return true;
	}
	//删除微问答tag
	private function delwtaglist($data, $tags=array())
	{
		$utags = (empty($tags['tags'])?$data['tags']:$tags['tags']);
		if (!empty($utags))
		foreach ($utags as $tid => $tag){
			if ($data['status'] == 1)
				if (!self::dellist('tk', $tid, $data['questionid'],$data['questionid']))	return false;
			if (!self::dellist('tq', $tid, $data['questionid'],$data['questionid']))	return false;
		}
		return true;
	}
	//添加回答列表改变
	public function addanswerlist($data, $row)
	{
		$ctime = strtotime($row['ctime']);
		if ($data['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
			if ($data['atotal'] == 1){
				if (!self::delclist($data, 'cn'))	return false;
			}
			//添加个人中心列表
			if (!empty($data['touid']) && $row['uid'] == $data['touid']){
				if ($data['owner'] != 2){
					if (!self::addlist('cgb',$data['touid'], strtotime($data['ctime']), $data['questionid'],(float)$row['uid'])) return false;
					if (!self::dellist('cgn',$data['touid'], strtotime($data['ctime']), $data['questionid'])) return false;
				}
			}
			switch($row['owner'])
			{
				case 1:
					if (!self::addlist('uzn', $row['uid'], $ctime, $data['questionid'], (float)$row['answerid'])) return false;
					break;
				case 2:
					if (!self::addlist('uzt', $row['uid'], $ctime, $data['questionid'], (float)$row['answerid'])) return false;
					if ($row['status'] == 1 && !self::addlist('uzy', $row['uid'], $ctime, $data['questionid'], (float)$row['answerid'])) return false;
					break;
				default:
					if (!self::addlist('uza', $row['uid'], $ctime, $data['questionid'], (float)$row['answerid'])) return false;
					break;
			}
			if ($row['status'] == 1 && !self::addlist('uzc', $row['uid'], $ctime, $data['questionid'], (float)$row['answerid'])) return false;
		}else{
			if (!empty($data['tags'])){
				foreach($data['tags'] as $tid => $v)
				{
					if (!self::addlist('tq', $tid, $ctime, $data['questionid'], (float)$row['answerid'])) return false;
					if ($data['weight'] >= self::$userweight && !self::$wbdb->updata('relate', $tid, array($row['questionid'],$data['weight']))) return false;
					if ($row['status'] == 1 && !self::addlist('tk', $tid, $ctime, $data['questionid'], (float)$row['answerid'])) return false;
				}
			}
			if ($row['owner'] != 1 && !self::addlist('ua', $row['uid'], $ctime, $data['questionid'], $row['answerid'])) return false;
		}
		return true;
	}
	//添加回答列表改变
	public function delanswerlist($data, $row)
	{
		$ctime = strtotime($row['ctime']);
		if ($data['data_append']['syncid'] == ZHISHI_APP_ID){//知识人
		}else{
			if (!empty($data['tags'])){
				$isdel = 1;
				foreach($data['tags'] as $tid => $v)
				{
					if ($isdel == 1){
						if (!self::$rbdb->getlistkey('tq', $tid, $data['questionid'], $rdata)) return false;
						if ($rdata != $ctime){
							break;
						}
						$isdel = 2;
					}
					if (!self::dellist('tq', $tid, $data['questionid'], $data['questionid']))	return false;
					if ($data['status'] ==1 && !self::dellist('tk', $tid, $row['questionid'], $row['questionid'])) return false;
				}
			}
			if (!self::dellist('ua', $row['uid'], $ctime, $data['questionid'])) return false;
		}
		return true;
	}
	//简单增加列表
	public function addlist($type,$id,$time,$sid='',$data='')
	{
		if ($id === 0){
			if (isset(self::$key2all["$type"])){
				$type = self::$key2all["$type"];
			}
		}
		$info = array();
		$info[0] = $id;
		$info[1] = $time;
		if ($sid !== '')
			$info[2] = $sid;
		return self::$wbdb->lists($type, $info, $data);
	}
	//简单删除列表
	public function dellist($type, $id0, $id1, $id2='')
	{
		if ($id0 === 0){
			if (isset(self::$key2all["$type"])){
				$type = self::$key2all["$type"];
			}
		}
		$info = array();
		$info[0] = $id0;
		$info[1] = $id1;
		if ($id2 !== '')
			$info[2] = $id2;
		return self::$wbdb->dellist($type, $info);
	}
	//添加日志
	public function uplog($row, $flag='add')
	{
		switch($row['type'])
		{
			case EVENT_QUESTION_ADD:
			case EVENT_QUESTION_DEL:
			case EVENT_QUESTION_REST:
			case EVENT_QUESTION_UPDATE:
			case EVENT_QUESTION_TITLE_UPDATE:
			case EVENT_QUESTION_DESC_UPDATE:
			case EVENT_QUESTION_TAG_ADD:
			case EVENT_QUESTION_TAG_DEL:
			case EVENT_ANSWER_ADD:
			case EVENT_ANSWER_DEL:
			case EVENT_ANSWER_RECOVER:
			case EVENT_ANSWER_UPDATE:
			case EVENT_QUESTION_ADOPT:
				if ($flag == 'del'){
					return self::delloglist($row, 'q');
				}else{
					return self::addloglist($row, 'q');
				}
				break;
			case EVENT_TAG_ADD:
			case EVENT_TAG_UPDATE:
			case EVENT_TAG_UPDATE_LOGO:
			case EVENT_TAG_DEL:
			case EVENT_TAG_FATHER_ADD:
			case EVENT_TAG_CHILD_ADD:
			case EVENT_TAG_FATHER_DEL:
			case EVENT_TAG_CHILD_DEL:
				if ($flag == 'del'){
					return self::delloglist($row, 't');
				}else{
					return self::addloglist($row, 't');
				}
				break;
			case EVENT_TAG_EXP_UPDATE:
			case EVENT_USER_UPDATE_LOGO:
			case EVENT_USER_UPDATE:
			case EVENT_USER_REGISTER:
				if ($flag == 'del'){
					return self::delloglist($row);
				}else{
					return self::addloglist($row);
				}
				break;
		}
		return true;
	}
	//生成日志列表
	private function addloglist($row, $type='t')
	{
		$info = array();
		$r = $row;
		$info[0] = $row['uid'];
		$info[1] = strtotime($row['ctime']);
		$info[2] = $row['logid'];
		if ($row['uid'] != 0 && !self::$wbdb->lists('ue', $info, $r))
			return false;
		$info[0] = $row['oid'];
		if ($type == 'q'){
			return self::$wbdb->lists('tqe', $info, $r);
		}else if ($type == 't'){
			return self::$wbdb->lists('te', $info, $r);
		}
		return true;
	}
	//删除日志列表
	private function delloglist($row, $type='t')
	{
		$info = array();
		$info[0] = $row['uid'];
		$info[1] = strtotime($row['ctime']);
		$info[2] = $row['logid'];
		if (!self::$wbdb->dellist('ue', $info))
			return false;
		$info[0] = $row['oid'];
		if ($type == 'q'){
			return self::$wbdb->dellist('tqe', $info);
		}else if ($type == 't'){
			return self::$wbdb->dellist('te', $info);
		}
		return true;
	}
}
?>