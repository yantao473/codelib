<?php
#include "apiconf.php";
class sortAnswer {
	public $g_para;
	function __construct(){
		$this->_init_class();
	}

	function _init_class(){
		$this->bdb = new GetBdb();
		$this->url = QUESTION_ANSWER_SORT;
		$this->tool = new Tools();
	}

	function run($row){
		
		if(($row[0] == 17 ) || ( $row[0] == 7 ) || ( $row[0] == 13 ) ){	
		//$tmp_qids = array( 30001585);
		$tmp_qids = array( $row['questionid'] );
		$this->bdb->gets("detail" , $tmp_qids , $data);
		//answer not empty
		//print_r($data);
		//$row['questionid'] = 30001585;
		if($data['showflag'] == 0){
			$data['data_append']['syncid'] = 1;
			if($data['data_append']['syncid'] == 1){
				if(!empty($data[$row['questionid']]['a']) && ( count($data[$row['questionid']]['a'])>1)){
					$i=0;
					$arr = array();
					foreach( $data[$row['questionid']]['a'] as $k => $v){
						if($v['showflag'] == 0){
							$this->bdb->lists("ua", $v['uid'], 0, 0, $uadata,0);
							$this->bdb->lists("uqv", $v['uid'], 0, 0, $uvdata,0);
							//回答问题次数                                             
							$arr[$i]['answ_times'] = $uadata['total'] ? $uadata['total'] : 0;
							//答案被赞的次数
							$arr[$i]['favour_times'] = isset($v[2]) ? count($v[2]) :0 ; 
							$arr[$i]['no_help_times'] = isset($v[0]) ? count($v[0]) :0 ; 
							//回答者的声望
							$arr[$i]['answ_repu'] = $uvdata['total'] ? $uvdata['total'] : 0;
							$arr[$i]['comment_times'] = !empty($v['cnum']) ? $v['cnum'] : 0;
							$arr[$i]['adopted'] = (isset($v['status']) && ($v['status'] == 1)) ? true : false;
							$arr[$i]['publish_time'] = strtotime($v['ctime']); 
							$arr[$i]['aid'] = $k; 
							$arr[$i]['uid'] = floatval($v['uid']); 
							$i++;
						}
					}
					$questions[0]['qid'] = intval($row['questionid']);
					$questions[0]['anum'] = $data[$row['questionid']]['atotal'];
echo "答案个数:\n".$questions[0]['anum'];

					$questions[0]['answers'] = $arr;

				}
			}
		}	
		$arr_q = array( 'num' => count($questions), 'questions'=>$questions);
		//开始调用接口                                                             
		$time_start = $this->microtime_float();                                    
		$post_arr = array('qids'=>json_encode($arr_q));                            
		echo "发送数据：\n";                                                       
		print_r($post_arr);                                                        
		$this->tool->curl_set($this->url,"post",$post_arr,$get_zj_data);           
		echo "\n\r";                                                               
		echo "返回数据 : \n";                                                      
		var_dump($get_zj_data);                                                    
		echo "\n";                                                                 

		$time_end = $this->microtime_float();                                      
		$time = $time_end - $time_start;                                           
		echo "\n";                                                                 
		echo " 调用接口时间 : \n".$time;
		}

	}
	function microtime_float()                                                                         
	{                                                                                                  
		list($usec, $sec) = explode(" ", microtime());                                             
		return ((float)$usec + (float)$sec);                                                       
	} 

}
?>
