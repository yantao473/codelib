<?php
//图片操作

class images{
	private static $format;
	private static $url;
	
	function __construct()
	{
		self::$format = array('30'=>'a','50'=>'b','100'=>'c');
		self::$url = 'http://q.sinaimg.cn';
	}
	
	//获取头像地址，分a 小图; b 中图; c大图;$type值 ua  ta
	function getlogo($id, $type)
	{
		return (self::$url.'/l'.self::getrealpath($id, $type));
	}
	
	//转换并上传头像，返回id，$type u用户, t 话题
	function convertimage($filename, $type, &$id)
	{
		//转换
		if (!self::setimagetype($filename, $itype))
			return false;
		$ids = new IdServer;
		$id = $ids->get('img');
		if (empty($id)){
			return false;
		}
		$tofile = array();
		if ($itype == "sample")
			$filename .= '[0]';
		foreach (self::$format as $k => $v)
		{
			$size = $k;
			$cfile = '/tmp/'.$type.$v.$id.'.jpg';
			$tofile[$v] = $cfile;
			system("/usr/local/bin/convert -{$itype} {$size}x{$size} $filename $cfile > /dev/null 2>&1");
		}
		//上传
		system("/usr/bin/rsync -z ".implode(' ', $tofile)." ".IMAGE_UPLOAD_SERVER1."::IMAGE_LORE".self::getprepath($id).' >/dev/null 2>&1');
		system("/usr/bin/rsync -z ".implode(' ', $tofile)." ".IMAGE_UPLOAD_SERVER2."::IMAGE_LORE".self::getprepath($id).' >/dev/null 2>&1');
		foreach ($tofile as $k => $v)
		{
			@unlink($v);
		}
		return true;
	}
	
	private function setimagetype($filename, &$type)
	{
		$size = getimagesize($filename);
		$type = "thumbnail";
		if (!is_array($size))
			return false;
		if ($size[2] == 1){
			$type = "sample";
		}
		
		return true;
	}
	private function getprepath($id)
	{
		return sprintf("/%d/%d/%d/", ($id/10000)%100, ($id/100)%100, $id%100);
	}
	private function getrealpath($id, $type)
	{
		if ($id == 0)
			return sprintf("/%s.jpg", $type);
		else
			return sprintf("/%d/%d/%d/%s%d.jpg", ($id/10000)%100, ($id/100)%100, $id%100, $type, $id);
	}
}

?>