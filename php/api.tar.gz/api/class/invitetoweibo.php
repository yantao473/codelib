<?php
/**
 * @fn              邀请 应用微博发通知类
 * @author          xianghui@staff.sina.com.cn
 * @copyright       v1
 * @date            2012-12-07
 */

include_once("apiconf.php");

class InviteToWeibo {
	
	public $g_para;
	public $g_result;

	function  __construct(&$g_para , &$g_result) {
		$this->g_para	= &$g_para;
		$this->g_result = &$g_result;
		$this->_init_class();
	}
	
	function _init_class(){
		$this->tools_obj= new Tools();
		$this->wbv4_obj = new weibov4();
	}

	function deal_invite_toweibo(){
		//$this->g_para['from']  来源：1，首页专家邀请 toexpert 2 浮层邀请expert  3 详情页邀请朋友 friend
                // 获取用户昵称
		$res = false;
                $send = array();
                $send[] = array(
                                'url' => DOMAIN . '/u/getuser.php',
                                 'params' => array(
                                        'uid' => $this->g_para['uid'] ,
                                        'app' => API_APP_ID,
                                        'syncid' => 1
                                ),
                                'method' => 'post',
                                );

                $send[] = array(
                                'url' => DOMAIN . '/q/getquestion.php',
                                'params' => array(
                                        'questionid' => $this->g_para['questionid'] ,
                                        'app' => API_APP_ID,
                                        'syncid' => 1
                                ),
                                'method' => 'post',                                                               
                                                                                                                  
                                );                                                                                
                $result = $this->tools_obj->multi_curl_set($send);                                                
                $uinfo = json_decode($result[0],true);                                                            
                $qinfo = json_decode($result[1],true); 

                //如果是朋友邀请      
		switch($this->g_para['from']){   
			case 'friend' :         
				$actionurl = $this->wbv4_obj->get_short_url('http://ask.weibo.com/q/'.$this->g_para['questionid']."?from=weiboinvF&t=".date("Ymd"));       
                		$res = json_decode($actionurl,true);
                		if($res['urls'][0]['result']){
                        		$action = $res['urls'][0]['url_short'];
                		}
                                                         
                        	$params = array(                                                                          
                                	'uids' => $this->g_para['inviter'], 
                                	'tpl_id' => '3517716255849266',                                                   
                                	'objects1' => $this->tools_obj->sub_str(urldecode($uinfo[$this->g_para['uid']]['nick']),0,29),                                        
               				'action_url' => $action,                     
                                	'objects2' => $this->tools_obj->sub_str($qinfo['title'],0,29),                                                    
                        	);
				echo "friend rec:\n";                                                                                  		                    print_r($params);                                                                         
                                $res = $this->msg_send_weibo($params);                      
                        	$res = json_decode($json , true);                                                         
                        	echo "friend rec res : \n";print_r($res);                                                            
                       		return $res; 
				break;                   
			
			case  'expert': 
				#$tag = explode(",",$this->g_para['recomtag']);
				#$tkey = array_rand($tag,1);
				#$rtag = $tag[$tkey];                   
				#objects1使用，需要穿推荐的话题名称                                                   
				$actionurl = $this->wbv4_obj->get_short_url('http://ask.weibo.com/q/'.$this->g_para['questionid']."?from=weiboinvE&t=".date("Ymd"));       
                		$res = json_decode($actionurl,true);
                		if($res['urls'][0]['result']){
                        		$action = $res['urls'][0]['url_short'];
                		}
                        	$params = array(                                                                          
                        	        'uids' => $this->g_para['inviter'], 
                        	        'tpl_id' => '3517715409003574',                                                   
                        	        'objects1' => '某个',                                                     
                  			'action_url' => $action,                     
                        	        'objects2' => $this->tools_obj->sub_str(urldecode($uinfo[$this->g_para['uid']]['nick']),0,29),                                        
                        	        'objects3' => $this->tools_obj->sub_str($qinfo['title'],0,29),                                                     
                        	);
				echo "expert rec:  \n";
				print_r($params);                                                                         
                                $res = $this->msg_send_weibo($params);                      
                		echo "expert res : \n";print_r($res);      
                       		return $res; 
                        	break;                                                                                          
                	
			case 'toexpert':                                                
				$actionurl = $this->wbv4_obj->get_short_url('http://ask.weibo.com/q/'.$this->g_para['questionid']."?from=weiboinvT&t=".date("Ymd"));       
                		$res = json_decode($actionurl,true);
                		if($res['urls'][0]['result']){
                        		$action = $res['urls'][0]['url_short'];
                		}
                        	$params = array(                                                                          
                                	'uids' => $this->g_para['inviter'], 
                                	'tpl_id' => '3517766721730889',                                                   
                                	'objects1' => '今日话题',                                        
                    			'action_url' => $action,                     
                                	'objects2' => '刚刚',
					'objects3' => '一',                                                    
                        	);     
				echo "toexpert rec: \n";
				print_r($params);                                                                         
                                $res = $this->msg_send_weibo($params);                      
                        	$res = json_decode($json , true);                                                         
                        	echo "toexpert rec  res : \n";print_r($res);                                                            
                       		return $res; 
				break;
			
			default:
				break;
		}
	

	}
	function msg_send_weibo($params){
        	$url = '/2/notification/send.json';                                                       
                $json = $this->wbv4_obj->post($url , $params , 'POST');                                   
                $res = json_decode($json , true);
		return $res;                                                         
	}


}
?>
