<?php
/*
* 批量处理审核后台的话题隐藏功能 需要连带将话题下的问题中都去掉此话题信息
* add by zhanghua2 
* 2012-02-21 14:46:00
*/
class bdbSpecial {
	private $getbdb;
	private $upbbd;
	private $bdb;
	private $bdb_table;

	function __construct() {
		global $g_bdb_table;
		$this->bdb_table = $g_bdb_table;
		$this->getbdb = new GetBdb;
		$this->upbdb = new UpBdb;
		$this->bdb = new BdbDb;
	}

	/**
	 * 修改问题对应的话题
	**/
	function deal_question_tags($row){
		if(empty($row['uptname'])){
			return false;
		}
		foreach($row['uptname'] as $k=>$v){
			$tids[] = $v['id'];
			$tname[$v['id']] = $v['name'];
		}
		foreach($tids as $k => $tid) {
			$this->getbdb->lists('tq' , $tid , 0 , 0 , $data);
			$total = $data['total'];
			$this->getbdb->lists('tq' , $tid , 0 , $total , $data);
			if(!empty($data)) {
				foreach($data as $k => $v) {
					if(!empty($v['keys']))
						$qids[] = $v['keys'][2];
				}
			}
			if(!empty($qids)) {
				$this->up_question_tag($qids , $tid , $tname[$tid]);
			}
		}
		

	}
	function deal($row) {
		if(empty($row['tid'])) {
			return false;
		}

		foreach($row['tid'] as $k => $v) {
			$tids[] = $v['id'];
			$status[$v['id']] = $v['showflag'];
		}
		foreach($tids as $k => $tid) {
			$this->getbdb->lists('tq' , $tid , 0 , 0 , $data);
			$total = $data['total'];
			$this->getbdb->lists('tq' , $tid , 0 , $total , $data);
			if(!empty($data)) {
				foreach($data as $k => $v) {
					if(!empty($v['keys']))
						$qids[] = $v['keys'][2];
				}
			}
			if(!empty($qids)) {
				$this->up_questions($qids , $tid , $status[$tid]);
			}
		}
		echo "\n";
	}
	
	function up_questions($qids , $tid , $status) {
		// 每个问题要更新两张表
		foreach($qids as $k => $qid) {
			// 取摘要表数据 需要话题列表 
			$type = 'question';
			$this->bdb->get($this->bdb_table["$type"]['app'], $this->bdb_table["$type"]['table'], $qid, $rdata);
			$qdetail = unserialize(gzuncompress($rdata[0]));
			// 话题 1隐藏  0显示
			if($status == 0) {
				$type = 'tagid';
				$this->bdb->get($this->bdb_table["$type"]['app'], $this->bdb_table["$type"]['table'], $tid, $tdata);
				$taginfo = unserialize(gzuncompress($tdata[0]));
			}
			if(!empty($qdetail)) {
				if($status == 0) {
					$qdetail['tags'][$tid] = $taginfo['name'];
					$row[0] = EVENT_QUESTION_TAG_ADD;
				}
				else {
					$qdetail['tags'][$tid] = '';
					$row[0] = EVENT_QUESTION_TAG_DEL;
				}
			}
			$row['questionid'] = $qid;
			$row['tags'] = $qdetail['tags'];
			$row['uid'] = $qdetail['uid'];
			$row['utime'] = date('Y-m-d H:i:s');
			print_r($row);	

			$this->upbdb->updata('question', $qid , $row);
			$row['last'] = $row['utime'];
			$this->upbdb->updata('detail', $qid , $row);
		}
	}
	/*修改问题对应的话题*/
	function up_question_tag($qids , $tid , $tname) {
		// 每个问题要更新两张表
		foreach($qids as $k => $qid) {
			// 取摘要表数据 需要话题列表 
			$type = 'question';
			$this->bdb->get($this->bdb_table["$type"]['app'], $this->bdb_table["$type"]['table'], $qid, $rdata);
			$qdetail = unserialize(gzuncompress($rdata[0]));
			// 话题 1隐藏  0显示
			if($status == 0) {
				$type = 'tagid';
				$this->bdb->get($this->bdb_table["$type"]['app'], $this->bdb_table["$type"]['table'], $tid, $tdata);
				$taginfo = unserialize(gzuncompress($tdata[0]));
			}
			if(!empty($qdetail) && ($tname != $taginfo['name'])) {
				$qdetail['tags'][$tid] = $tname;
				$row[0] = EVENT_TAG_UPDATE;
				/*
				if($status == 0) {
					$qdetail['tags'][$tid] = $taginfo['name'];
					$row[0] = EVENT_QUESTION_TAG_ADD;
				}
				else {
					$qdetail['tags'][$tid] = '';
					$row[0] = EVENT_QUESTION_TAG_DEL;
				}*/
			}
			$row['questionid'] = $qid;
			$row['tags'] = $qdetail['tags'];
			$row['uid'] = $qdetail['uid'];
			$row['utime'] = date('Y-m-d H:i:s');
			print_r($row);	

			$this->upbdb->updata('question', $qid , $row);
			$row['last'] = $row['utime'];
			$this->upbdb->updata('detail', $qid , $row);
		}
	}
}
