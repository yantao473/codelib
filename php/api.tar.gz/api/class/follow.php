<?php
/**
 * 关注接口
 */

include_once("apiconf.php");

class Follow {

        public $g_para;
        public $g_result;

	function __construct(&$g_para , &$g_result) {
	        $this->g_para   = &$g_para;
                $this->g_result = &$g_result;
		
		$this->rpcdb_obj = new RpcDb;
		$this->mysqldb_obj = new MysqlDb;
		$this->queue_obj = new QueueTool;
		$this->getbdb_obj = new GetBdb;
		$this->tools_obj = new Tools;

		$this->dbname = "question";
		$this->filename = DEFAULT_QUEUE_DATA_FILE;
		$this->cmdid = DEFAULT_QUEUE_ID;
	}

	/**
	 * 添加关注
	 * @param $type 关注类型决定选择的数据表 (user，tag，question)
	 * @param $uid 关注用户id
	 * @param $toid 被关注对象id
	 * @param $ctime 添加时间
	 * @return false/true
	 */

	function addfollow() {
		$row['uid']	=	$this->g_para['uid'];
		//添加问题第一次关注和之后的关注
                $row['toid']	=	isset($this->g_para['questionid']) ? $this->g_para['questionid'] : $this->g_para['toid'];
                $row['ctime']	=	$this->g_para['time'];
                if(isset($this->g_para['owner']) && $this->g_para['owner'] != ''){
                        $row['owner']   =       $this->g_para['owner'];
                }
		//$row['owner']	=	isset($this->g_para['owner']) ? $this->g_para['owner'] : 0;
                $tablename	=	'follow' . $this->g_para['type'];
		$sql = $this->mysqldb_obj->prepare_insert_sql($tablename , $row);
                $res = $this->rpcdb_obj->update($this->dbname , $sql , $data);
		if($res) {
                        	switch($this->g_para['type']) {
                        	        case 'user':
						$row[0] = EVENT_USER_FOLLOW_ADD;
						break;
                        	        case 'tag':
						$row[0] = EVENT_TAG_FOLLOW_ADD;
						break;
                        	        case 'question':
						$row[0] =  ( $this->g_para['app'] == ZHISHI_APP_ID ) ? EVENT_QUESTION_FOLLOW_ADD_ZHISHI  :  EVENT_QUESTION_FOLLOW_ADD;
						break;
                        	        default:
						break;
                        	}
                        $row['type'] = $this->g_para['type'];
                        $url = QDOMAIN . "/send_queue.php";
                        $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
                        return $queue;

                }else{
                        $rs['error_num'] = 2401;
                        $rs['error'] = '添加关注失败，写数据库失败';
                        return $rs;
                }
	}


	/**
	 * 取消(删除)关注
	 * @param $type 类型
	 * @param $uid 用户id
	 * @param $toid 被取消对象id
	 */
	function delfollow() {
		$tablename = 'follow' . $this->g_para['type'];
		$sql = 'DELETE  FROM ' . $tablename . ' WHERE  uid = ' . $this->g_para['uid'] . ' AND toid = ' . $this->g_para['toid'];
		$res = $this->rpcdb_obj->update($this->dbname , $sql,  $data);
		if($res) {
				switch($this->g_para['type']) {
					case 'user':
						$row[0] = EVENT_USER_FOLLOW_DEL;
						break;
					case 'tag':
						$row[0] = EVENT_TAG_FOLLOW_DEL;
						break;
					case 'question':
						$row[0] =  ( $this->g_para['app'] == ZHISHI_APP_ID ) ? EVENT_QUESTION_FOLLOW_DEL_ZHISHI  :  EVENT_QUESTION_FOLLOW_DEL;
						break;
					default:
						break;
				}
			$row['uid']	= $this->g_para['uid'];
			$row['toid']	= $this->g_para['toid'];
			$row['type']	= $this->g_para['type'];

			$url = QDOMAIN . "/send_queue.php";
			$this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);

			return $queue;            
		}else{
			$rs['error_num'] = 2402;
			$rs['error'] = '取消关注失败';
			return $rs;
		}
	}

	/**
	 * 获取我关注的(关注的话题gtm，问题gqm，人gpm，收藏目录gsm)列表 和获取关注 (话题，问题，人，收藏目录)的人
	 * @param $type 类型，(关注的话题gtm，问题gqm，人gpm，收藏目录gsm)&&(话题gto，问题gpo，人gqo，收藏目录gso）
	 * @param $oid 对象id（话题gto，问题gpo，人gqo，收藏目录gso）
	 * @param $start 开始
	 * @param $num 跨度
	 * @return 关注列表
	 */
        function getfollowlist() {
                $res = $this->getbdb_obj->lists($this->g_para['type'] , $this->g_para['oid'] , $this->g_para['start'] , $this->g_para['num'] , $data);

                return $data;
        }




	/**
	 * 获取双向关注列表(我关注的人和关注我的人的交集)
	 * @param $type 类型
	 * @param $uid 用户id
	 * @param $start
	 * @param $num
	 * @return 双向关注列表
	 */
	function getfriendlist($uid , $start , $num){
		//获取uid的所有关注，循环得到所有关注的结果
		/*
		   $this->getbdb_obj->lists("gpm", $uid, $start, $num, $myfollow);
		   $this->getbdb_obj->lists("gpo", $uid, $start, $num, $myfans);
		   $data = array_intersect($myfollow,$myfans);
		 */
		$res = $this->getbdb_obj->lists("gpd", $uid, $start, $num, $data);
		return $data;
	}

	/**
	 * 判断是否关注
	 * @param $type 类型  0,1
	 * @param $oid qid/tid 单个
	 * @param $uids array类型，多个
	 * @return 是否关注,有值表示关注成功，空或者0表示关注失败
	 */
	function isfollow() {
		$res = $this->getbdb_obj->getlistkey($this->g_para['type'], $this->g_para['oid'], $this->g_para['alluids'], $data);
                return $data;
	}

	function add_feed(){
		$eid = EVENT_QUESTION_FOLLOW_ADD; 
		$objs = array(
				'uid'=>$this->g_para['uid'],
				'qid'=>$this->g_para['toid'],
				);  
		$res = feed::addFeedataToQueue($eid,$objs);
	}

}
?>
