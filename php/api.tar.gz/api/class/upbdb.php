<?php
//写bdb接口

class UpBdb {
	static $bdb;
	static $conf;
	public $mdata;
	//auto 是否使用自动恢复功能，默认关闭
	function __construct($auto=false)
	{
		global $g_bdb_table;
		
		self::$conf = $g_bdb_table;
		self::$bdb = new BdbDb($auto);
		$this->mdata = array();
	}
	//更新数据组合，addinfo增量更新的字段
	function upinfo($info, &$data, $addinfo=array())
	{
		if(is_array($info))
		foreach ($info as $k => $v)
		{
			if ($v === null || $v === ''){
				if (@array_key_exists($k, $data))
					unset($data["$k"]);
			}
			else if (is_array($v)){
				self::upinfo($v, $data["$k"], $addinfo);
				if ($data["$k"] === null || $data["$k"] === '')
					unset($data["$k"]);
			}
			else{
				$data["$k"] = (in_array($k, $addinfo, true)?($v+(@array_key_exists($k, $data)?$data["$k"]:0)):$v);
			}
		}
	}
	//更新 各种列表$type 类型;$keys 索引;$data 数据
	function lists($type, $keys, $data)
	{
		$app = self::$conf["$type"]['app'];
		if (empty($app))
			return false;
		if (!self::$bdb->getkey(self::$conf["$type"], $keys, $karray))
			return false;
		$table = isset(self::$conf["$type"]['table'])?self::$conf["$type"]['table']:$type;
		$value = '';
		if ($data !== ''){
			if (isset(self::$bdb->conf['v'])){
				if (!is_array($data))
					return false;
				foreach ($data as $k => $v)
				{
					$value .= (self::$bdb->conf['v']["$k"]===''?$v:self::$bdb->i2b((float)$v, self::$bdb->conf['v']["$k"]));
				}
			}else{
				$value = gzcompress(serialize($data));
			}
		}
		//列表只做更新，不做增量查询
		if (!self::$bdb->update($app, $table, $karray['real'], $value, $karray['part']))
			return false;
		return true;
	}
	
	//删除列表数据，只能单个删除,$keys是列表的key数组
	function dellist($type, $keys)
	{
		$app = self::$conf["$type"]['app'];
		if (empty($app))
			return false;
		if (!self::$bdb->getkey(self::$conf["$type"], $keys, $karray, 'del'))
			return false;
		if (!self::$bdb->del($app, $type, $karray['real'], $karray['part']))
			return false;
		return true;
	}
	
	//删除，只能单个删除； keys可以是数组（同列表），必须是完整的key值; 访客形式需要value
	function del($type, $keys, $value='')
	{
		if (!isset(self::$conf["$type"]))
			return false;
		if (self::$conf["$type"]['type'] == 'list'){
			return self::dellist($type, $keys);
		}
		if (!self::$bdb->getkey(self::$conf["$type"], $keys, $karray, 'del'))
			return false;
		$data = '';
		if (isset($karray['flag']) && $karray['flag'] == 'int'){
			foreach ($value as $k => $v)
			{
				$data .= (self::$bdb->conf['v']["$k"]===''?$v:self::$bdb->i2b((float)$v, self::$bdb->conf['v']["$k"]));
			}
		}
		return self::$bdb->del(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $karray['part'], $data);
	}
	//批量删除，只允许一般k/v list
	function multidel($type, $keys, &$rdata)
	{
		if (!isset(self::$conf["$type"]))
			return false;
		if (!self::$bdb->getkey(self::$conf["$type"], $keys, $karray, 'del'))
			return false;
		if (!self::$bdb->multidel(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $karray['part'], $rdata))
			return false;
		return true;
	}
	function multiupdate($type, $id, $info, &$rdata)
	{
		if (empty($id))
			return false;
		if (empty(self::$conf["$type"]))
			return false;
		if (!self::$bdb->getkey(self::$conf["$type"], $id, $karray))
			return false;
		if (in_array(array('int', 'num', 'array'), $karray['flag']))
			return false;
		if (self::$conf["$type"]['app'] == 'klist')
			return false;
		if (self::$conf["$type"]['ltype'] == 'list'){
			foreach ($info as $k => $v)
			{
				$info["$k"] = gzcompress(serialize($v));
			}
		}else{
			foreach ($info as $k => $v)
			{
				$info["$k"] = gzcompress($v);
			}
		}
		if (!self::$bdb->multiupdate(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $info, $karray['part'], $rdata))
			return false;
		return true;
	}
	
	//通用更新 type 应用;$info 数据;addinfo 增量计数数组；read 是否有缓存数据
	function updata($type, $id, $info, $addinfo=array(), $read='')
	{
		if (empty($id))
			return false;
		if (empty(self::$conf["$type"]))
			return false;
		if (!self::$bdb->getkey(self::$conf["$type"], $id, $karray))
			return false;
		switch($karray['flag'])
		{
			case 'array'://value是数组序列化形式，可增量更新
				return self::adata($type, $id, $info, $karray, $addinfo, $read);
			break;
			case 'char'://value是字符串形式
			case 'chardel'://字符串形式，并唯一，用于索引删除
				if (is_array($info))
					return false;
				return self::cdata($type, $id, $info, $karray, $addinfo);
			break;
			case 'int'://value是数字，二进制形式，每个int是无符号整型范围，长度是8
				return self::idata($type, $id, $info, $karray);
			break;
			case 'num'://计数器类型
				return self::idata($type, $id, $info, $karray, $addinfo);
			break;
			default:
				if (('t' == self::$conf["$type"]['type'] && self::$conf["$type"]['ltype'] == 'list') || self::$conf["$type"] == 'list')//列表形式
					return self::lists($type, $id, $info);
				return false;
		}
		return false;
	}
	
	//数组序列化
	private function adata($type, $id, $info, $karray, $addinfo=array(), $read='')
	{
		if ($read === ''){
			if (!self::$bdb->get(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $rdata, $karray['part'], 0)){
				return false;
			}
			$this->mdata = ($rdata[0]==''?'':unserialize(gzuncompress($rdata[0])));
			if ($this->mdata === false)
				return false;
		}else{
			$this->mdata = $read;
		}
		if (!empty($karray['max'])){
			if (count($this->mdata) > $karray['max'])
				array_slice($this->mdata, 0, $karray['max'], true);
		}
		self::upinfo($info, $this->mdata,$addinfo);
		return self::$bdb->update(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], gzcompress(serialize($this->mdata)), $karray['part']);
	}
	//字符串型 oldid非空时，要先验证并删除
	private function cdata($type, $id, $info, $karray, $oldid='')
	{
		if (self::$conf["$type"]['flag'] === 'chardel'){
			if ($oldid != ''){
				if (!self::$bdb->getkey(self::$conf["$type"], $oldid, $karray,'del'))
					return false;
				if (!self::$bdb->del(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $karray['part']))
					return false;
			}
		}
		if (strlen($info) > BDB_GZ_MIN_LEN)
			$info = gzcompress($info);
		if (!self::$bdb->getkey(self::$conf["$type"], $id, $karray))
			return false;
		return self::$bdb->update(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $info, $karray['part']);
	}
	//整型
	private function idata($type, $id, $info, $karray, $offset=0)
	{
		$data = '';
		foreach ($info as $k => $v)
		{
			$data .= (self::$bdb->conf['v']["$k"]===''?$v:self::$bdb->i2b((float)$v, self::$bdb->conf['v']["$k"]));
		}
		return self::$bdb->update(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $data, $karray['part'], $offset);
	}
}

?>