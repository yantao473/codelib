<?php
/**
 * @fn              添加修改问题类
 * @author          zhanghua2@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-06-07
 * @date            2012-08-15  modify question add  by guoxianghui
 */

include_once("apiconf.php");

class Question {
	
	public $g_para;
	public $g_result;

	function  __construct(&$g_para , &$g_result) {
		$this->g_para	= &$g_para;
		$this->g_result = &$g_result;
		$this->db	= new RpcDb();
		$this->bdb = new GetBdb();
		$this->tools_obj= new Tools();
		$this->queue	= new QueueTool();
		$this->logs_obj = new Logs;
		$this->compare_obj = new Compare();  
		$this->tag_obj	= new Tag;
		$this->wbv	= new weibov4();
		$this->follow_obj = new Follow($g_para , $g_result);
		//$this->follow_obj = new Follow;
	}

	/**
	 * @微什么 之 添加话题
	 **/
	function deal_add_tags() {
		$array_tag =  explode("," , $this->g_para['tag']); 
		$str_tag = $uktime = '';
		foreach($array_tag as $val) {
			if(empty($val)) {
				continue;
			}

			$tag_time = $uktime =  date("Y-m-d H:i:s");
			$this->tag_obj->gettag($val,$tid);

			if(empty($tid)) {
				$tag_result_id = $this->tag_obj->addtag($this->g_para['app'], $val, $this->g_para['uid'], "" , $tag_time);
				if(is_numeric($tag_result_id)) {
					$temp_array[$tag_result_id] = $val;
				}
			}else{
				$temp_array[$tid] = $val;
			}
			
			$tids_array = array();
			$tags_array = array();
			if(!empty($temp_array)) {
				foreach($temp_array as $k => $v) {
					$tids_array[] = $k;
					$tags_array[$k] = $v;
				}
			}
			$str_tag .= $val.",";
			// 话题添加feed
			$this->add_tag_feed($tids_array);
			$uid = $this->get_logs_uid();
			// 写话题日志
			$this->logs_obj->add_logs($this->g_para['questionid'], $uid, EVENT_QUESTION_TAG_ADD, $val, $tag_time, $tag_logid);
			$this->g_result['logids_array'][] = $tag_logid;
		}
		return $tags_array;
	}

	/**
	 * @微什么 之 发微博
	 * @date 2012-05-03
	 **/
        function send_to_weibo(){
        	/*
        	// 由于发送到微博的问题需要回调地址 每个应用的地址不同 应该通过配置文件读取应用的地址信息 暂时没有细化到这些功能上
           	//手机wap需要
			$img_url = "http://www.sinaimg.cn/pfp/w_ask/t1/images/weibopeitu20120_07_25_13.png";
			if($type == 1){
				$send_info = "我在@微什么 提了一个问题【".$this->g_para['title']."】 http://ask.weibo.com/q/".$this->g_para['questionid'];
			}else if ($type == 2){
            	$send_info = '我在@微什么 回答了问题【'.$this->g_para['title'].'】 '.$this->g_para['answer'].'http://ask.weibo.com/q/'.$this->g_para['questionid'];
            }
            if(isset($this->g_para['token'])&&!empty($this->g_para['token'])){
            	$res = $this->wbv->update_text_img($send_info,$img_url,$this->g_para['token']);
            }else{
           		$res = $this->wbv->update_text_img($send_info,$img_url);
            }
            return $res;
			*/
        	
        	
        	$res = false;
			if($this->g_para['sharewb']  == 1){					
				$title = preg_replace('~(&nbsp;)+~is',' ',$this->g_para['title']);
	
				$send_info = '我在@微什么 发现了一个不错的问题【'.$title.'】 ';
				
				$mshare_data = array (
						'qid'   => $this->g_para['questionid'],                                   
						'm'     => $this->tools_obj->add_pwd($send_info),                         
						'c1'    => $this->g_para['c1'],                                           
						'c2'    => $this->g_para['c2'], 
						'token'    => $this->g_para['token'],                                           
						'create_pic_only' =>0,     //发微薄又创建图片                             
						);                                                                        
				$url = QDOMAIN . '/mshare.php';
				$this->tools_obj->send_curl($url , 'post' , $mshare_data , $res);                         
	
			}                                                                                                 
			return $res;   
        	
        } 


	/**
	 * @微什么 之 写问题日志
	 * @date 2012-05-03
	 **/
	function add_log_list(){
		$uid = $this->get_logs_uid();
		$this->logs_obj->add_logs($this->g_para['questionid'],$uid,EVENT_QUESTION_ADD,$this->g_para['title'],$this->g_para['time'],$question_logid);
		$this->g_result['logids_array'][] = $question_logid;
		return true;
	}

	/**
	 * @公共 之 发送BDB
	 * @date 2012-05-03
	 **/
	function send_bdb($arr , &$queue_result) {
		$ser_array = array('data' => serialize($arr));
		$url = QDOMAIN . "/send_queue.php";
		$res = $this->tools_obj->curl_set($url , 'POST' , $ser_array , $queue_result);
		return $res;
	}

	/**
	 * @公共 之 写MYSQL
	 * @date 2012-05-03
	 **/	
	function send_mysql($arr , &$rpcdb_result){
		$get_sql  = $this->db->prepare_insert_sql("question" , $arr);
		$rpcdb_result = $this->db->update("question",$get_sql,$data);
		return true;
	}
	/**
	 * @ 修改MYSQL 问题表
	 * @date 2012-08-15
	 **/	
	function update_mysql($arr ,&$rpcdb_result){
		$get_sql  = $this->db->prepare_update_sql("question" , $arr);
		$get_sql .= " where  questionid = " .$this->g_para['questionid'];
		$rpcdb_result = $this->db->update("question",$get_sql,$data);
		return true;
	}

	/**
	 * @对比内容写日志
	 * @date 2012-08-15
	 **/	
        function compare_q_log($readcon,$getcon,$event){
                $deal_answer = $this->compare_obj->textdiff(strip_tags($getcon),strip_tags($readcon),$diff);
                if(!empty($diff)){
                        $compar_result = $diff;
                }else{
                        $compar_result = $getcon;
                }   
                if($readcon !== $getcon && !$this->g_para['nolog'] ){
                        $uid = $this->get_logs_uid();
     			$this->logs_obj->add_logs($this->g_para['questionid'],$uid,$event,$compar_result,$this->g_para['time'],$uptitle_logid);
                       	$this->g_para['logids_array'][] = $uptitle_logid;
                }   
        } 

	/**
	 *删除问题中的话题
	 *date 20120815
	**/
	function del_q_tags(&$stalk){
               $delta = explode(',' , $this->g_para['deltag']);
                $temp_array = array();
                foreach($delta as $k=>$v){
                        if(empty($v)){
                                continue;
                        }
                        $talktext = str_replace($v,"",$talktext);
                        //获取即将删除的话题的话题id
                        $this->tag_obj->gettag($v,$tid);
                        //tag_log
                        $temp_array[$tid]="";
                        if(!$this->g_para['nolog']){
                                $uid = $this->get_logs_uid();
                            	$this->logs_obj->add_logs($this->g_para['questionid'],$uid,EVENT_QUESTION_TAG_DEL,$v,$this->g_para['time'],$deltag_logid);
                                $this->g_para['logids_array'][] = $deltag_logid;
                        }
                }                            
                $array_temp = array();                                                                     
                $array_temp = explode(",",$talktext);// 原有话题去掉要删除的话题以后剩下的话题             
                $atemp = array();                                                                            
                foreach($array_temp as $item){                                                             
                        if(" " != $item){                                                                  
                                $atemp[] = $item;                                                    
                        }                                                                                  
                }                                                                                          
                $stalk = @implode(',',$atemp);
                return $temp_array;  

	}
	/**
	 * @微什么 之 是否匿名
	 * @date 2012-05-22
	 **/
	function get_logs_uid(){
		if($this->g_para['owner'] == 1){
			$uid = 0;
		}else if ($this->g_para['owner'] == 0){
			$uid = $this->g_para['uid'];
		}
		return $uid;
	}

	/**
	 * @微什么 之 添加问题feed
	 * @date 2012-05-03
	 **/
	function add_feed(){
		if($this->g_para['owner'] == 0){
			$eid = EVENT_QUESTION_ADD; 
			$objs = array(
					'uid'=>$this->g_para['uid'],
					'qid'=>$this->g_para['questionid'],
				     ); 
			$res = feed::addFeedataToQueue($eid , $objs);
			return $res;
		}
	}

	/**
	 * @微什么 之 添加问题话题feed
	 * @date 2012-05-03
	 **/
	function add_tag_feed($tids){
		$eid = EVENT_QUESTION_TAG_ADD; 
		$objs = array(
				'uid'=>$this->g_para['uid'],
				'qid'=>$this->g_para['questionid'],
				'tids'=>$tids,
			     );  
		$res = feed::addFeedataToQueue($eid,$objs);
		return $res;
	}

	function add_follow() {
		$result = $this->follow_obj->addfollow($this->g_para['type'] = "question", $this->g_para['uid'], $this->g_para['questionid'],$this->g_para['time'],$this->g_para['owner']);
	}

	/**
	 * 获取问题基本详情
	 * @date 2012-08-24
	 **/
	function get_question_baseinfo(&$data){
		$result = $this->bdb->gets("question",$this->g_para['questionid'],$data);
		return $result;
	}

        /**
         * @fn write addtags log
         * @ 05-03
         **/
        function write_addtags_log($tag_arr_log){
                $i=0;
                $temp_array = array();
                $talkarr = explode(",",$this->g_para['tag']);
                foreach($talkarr as $v){
                        if(empty($v)){
                                continue;
                        }
                        $tidres = $this->tag_obj->gettag($v,$tid);
                        if(empty($tid)) {
                                $tag_result_id = $this->tag_obj->addtag($this->g_para['app'], $v, $this->g_para['uid'], "",$this->g_para['time']);
                                if(is_numeric($tag_result_id)) {
                                        $temp_array[$tag_result_id] = $v;                                  
                                }                                                                          
                        } else {                                                                           
                                $temp_array[$tid] = $v;                                                    
                        }                                                                                  
                        $tids_array = array();         
                        foreach($temp_array as $k=>$v){                                                    
                                $tids_array[] = $k;                                                        
                        }                                                                                  
                        //add feed                                                                         
                        $this->add_tag_feed($tids_array);                                         
                        $array_tag_exp = explode(",",$tag_arr_log);                                        
                        if(!in_array($v ,$array_tag_exp,true) && !$this->g_para['nolog'] ){                
                                $uid = $this->get_logs_uid();                                     
                                $this->logs_obj->add_logs($this->g_para['questionid'],$uid,EVENT_QUESTION_TAG_ADD,$v,$this->g_para['time'],$tag_logid);
                                $this->g_para['logids_array'][] = $tag_logid;                              
                        }                                                                                  
                        $i++;                                                                              
                }                                                                                          
                                                                                                           
                return $temp_array;                                                                        
        }

	function get_question_detail(&$qdata){
 		$this->bdb->gets('detail' , $this->g_para['questionid'] , $qdata);
	}

         /**
         * @fn 修改问题title入mysql,bdb
         * @date 2012-11-20
         **/
        function modify_qtitle($type){
                $arr =  array(
                                'questionid'=>$this->g_para['questionid'],
                                'title'=>$this->g_para['title'],
                                'utime'=>$this->g_para['time'],
                                'showflag'=>$this->g_para['showflag'],
                             );
		if($type == 'bdb'){
			$arr[0] = EVENT_QUESTION_TITLE_UPDATE;
			$this->send_bdb($arr , $result);
		}
		else if ($type == 'mysql'){
                	$this->update_mysql($arr , $result);
		}
                return $result;
        }
         /**
         * @fn 修改问题desc入mysql,bdb
         * @date 2012-11-20
         **/
        function modify_qdesc($type,$data_append){
                $arr =  array(
                                'questionid'=>$this->g_para['questionid'],
                                'description'=>$this->g_para['desc'],
                                'utime'=>$this->g_para['time'],
                                'showflag'=>$this->g_para['showflag'],
                                //'owner'=>$this->g_para['owner'],
                             );
		if(!empty($data_append)){
			$arr['data_append'] = $data_append;
		}
		if($type == 'bdb'){
			$arr[0] = EVENT_QUESTION_DESC_UPDATE;
			$this->send_bdb($arr , $result);
		}
		else if ($type == 'mysql'){
                	$this->update_mysql($arr , $result);
		}
                return $result;
        }
         /**
         * @fn 删除和添加问题的话题
         * @date 2012-11-20
         **/
        function modify_qtags($talktext,$type,$flag){
                $arr =  array(
                                'questionid'=>$this->g_para['questionid'],
                                'tags'=>$talktext,
                                'utime'=>$this->g_para['time'],
                             );
		if($type == 'bdb'){
			if($flag == 'd'){
				$arr[0] = EVENT_QUESTION_TAG_DEL;
			}
			elseif($flag == 'a'){
				$arr[0] = EVENT_QUESTION_TAG_ADD;
			}
			$arr['app'] = 1;
			$this->send_bdb($arr , $result);
		}
		else if ($type == 'mysql'){
			$arr['appid'] = 1;
                	$this->update_mysql($arr , $result);
		}
                return $result;
        }

         /**
         * @fn 恢复 或者删除问题
         * @date 2012-11-20
         **/
        function modify_qshowfalg($type,$showflag){
                $arr =  array(
                                'questionid' => $this->g_para['questionid'],
                                'showflag' => $this->g_para['showflag'],
                                'utime' => $this->g_para['time'],
                             );
		if($type == 'bdb'){
			$arr['app'] = 1;
			if($this->g_para['showflag'] == 0){
				$arr[0] = EVENT_QUESTION_REST;
			}
			elseif($this->g_para['showflag'] == 1){
				$arr[0] = EVENT_QUESTION_DEL;
			}
			$this->send_bdb($arr , $result);
		}
		else if ($type == 'mysql'){
			$arr['appid'] = 1;
                	$this->update_mysql($arr , $result);
		}
                return $result;
        }
         /**
         * @fn 修改问题status
         * @date 2012-11-20
         **/
        function modify_qstatus($type){
                $arr =  array(
                               'questionid'=>$this->g_para['questionid'],
                                'status'=>$this->g_para['status'],
                                'utime'=>$this->g_para['time'],
                             );
		if($type == 'bdb'){
			$arr['app'] = 1;
			$arr[0] = EVENT_QUESTION_ADOPT;
			$this->send_bdb($arr , $result);
		}
		else if ($type == 'mysql'){
			$arr['appid'] = 1;
                	$this->update_mysql($arr , $result);
		}
                return $result;
        }
        /**
         * @fn 更新日志
         * @date 2012-05-03
         **/
        function update_qlog($qdata,$event){
		if($event == EVENT_QUESTION_TITLE_UPDATE){
			$value = $this->g_para['title'];
		}
		else if ($event == EVENT_QUESTION_DESC_UPDATE){
			$value = $this->g_para['desc'];
		}
                $this->compare_q_log($qdata,$value,$event);
        	return true;
	}



}
?>
