<?php
//search事件处理

class searchevent{
	static $mtype; //搜索类型 1 人， 3 话题， 2 问题
	static $mstatus;
	static $userweight;
	static $rbdb;
	
	function __construct()
	{
		self::$rbdb = new getbdb;
		self::$mtype = array(1,2,3);
		self::$mstatus = array('T','T','D','U');
		self::$userweight = 7000;
	}
	//$type 2 问题， 1 人， 3 话题;$status 状态 A 添加；T 修改;D 删除;U 整型修改
	function writedata($row, $type, $status)
	{
		if (empty($row['id']))
			return ;
		$flist  = "@\n";
		$flist .= '@id:'.$row['id'].'_'.$type."\n";
		$flist .= '@DF:'.$status."\n";
		if ($status != 'D'){
			$flist .= '@type:'.$type."\n";
			$flist .= '@weight:'.$row['weight']."\n";
			$flist .= '@isres:'.(empty($row['isres'])?0:1)."\n";
			$flist .= '@title:'.str_replace("\n", '', strip_tags($row['title']))."\n";
			$flist .= '@content:'.str_replace("\n", '', strip_tags($row['content']))."\n";
		}
		$filename = ROOT_DIR.'/data/search/lore_'.strtotime(date('Y-m-d H:i')).'.txt';
		return file_put_contents($filename, $flist, FILE_APPEND);
	}
	//上传数据
	function rsyncdata()
	{
		$ctime = time();
		$spath = ROOT_DIR."/data/search/";
		$bpath = ROOT_DIR."/data/searchbak/".date('Ymd').'/';
		if (!file_exists($bpath)){
			mkdir($bpath , 0777 , true);
		}
		if ($handle = @opendir($spath)){
			while (false !== ($file = @readdir($handle))){
				if ($file != "." && $file != ".."){
					$filename = $spath.$file;
					if ($ctime - @filectime($filename) >= 60){
						$sys = "/usr/bin/rsync -z --timeout=5 --force {$filename} ".SEARCH_DATA_RSYNC." >/dev/null 2>&1";
						echo $sys . "\n";
						system($sys,$ret);
						if ($ret == 0){
							system("/bin/mv -f {$filename} {$bpath} >/dev/null 2>&1");
						}
					}
				}
			}
			@closedir($handle);
		}
	}
	//定期清理历史数据
	function deldata()
	{
		$bpath = ROOT_DIR."/data/searchbak/".date('Ymd', strtotime("-1 week"));
		system("/bin/rm -rf $bpath >/dev/null 2>&1 &");
	}
	//实时数据
	function run($row)
	{
		if (!isset($row[0]))
			return false;
		$type = $row[0];
		unset($row[0]);
		$info = array();
		switch($type)
		{
			case EVENT_QUESTION_ADD://新加问题
			case EVENT_QUESTION_REST:
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				$info['id'] = $row['questionid'];
				$info['weight'] = 0;
				$info['title'] = $rdata['title'];
				$info['content'] = (empty($rdata['tag'])?'':implode(' ', $rdata['tag']));
				self::writedata($info, 2, 'T');
				break;
			case EVENT_QUESTION_DEL:
				$info['id'] = $row['questionid'];
				self::writedata($info, 2, 'D');
				break;
			case EVENT_QUESTION_TITLE_UPDATE:
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				$info['id'] = $row['questionid'];
				$info['weight'] = $rdata['weight'];
				$info['title'] = $rdata['title'];
				$info['isres'] = $rdata['resolved'];
				$info['content'] = (empty($rdata['tag'])?'':implode(' ', $rdata['tag']));
				self::writedata($info, 2, 'T');
				break;
			case EVENT_QUESTION_TAG_ADD://问题增加话题
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				$info['id'] = $row['questionid'];
				$info['weight'] = $rdata['weight'];
				$info['title'] = $rdata['title'];
				$info['isres'] = $rdata['resolved'];
				$info['content'] = (empty($rdata['tag'])?'':implode(' ', $rdata['tag']));
				self::writedata($info, 2, 'T');
				break;
			case EVENT_QUESTION_TAG_DEL:
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				$info['id'] = $row['questionid'];
				$info['weight'] = $rdata['weight'];
				$info['title'] = $rdata['title'];
				$info['isres'] = $rdata['resolved'];
				$info['content'] = (empty($rdata['tag'])?'':implode(' ', $rdata['tag']));
				self::writedata($info, 2, 'T');
				break;
			case EVENT_ANSWER_ADD://添加回答
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				$info['id'] = $row['questionid'];
				$info['weight'] = (isset($rdata['weight'])?$rdata['weight']:0);
				$info['title'] = $rdata['title'];
				$info['isres'] = (isset($rdata['resolved'])?$rdata['resolved']:0);
				$info['content'] = (empty($rdata['tag'])?'':implode(' ', $rdata['tag']));
				self::writedata($info, 2, 'T');
				break;
			case EVENT_QUESTION_ADOPT:
			if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				$info['id'] = $row['questionid'];
				$info['weight'] = $rdata['weight'];
				$info['title'] = $rdata['title'];
				$info['content'] = (empty($rdata['tag'])?'':implode(' ', $rdata['tag']));
				$info['isres'] = $row['adopt'];
				self::writedata($info, 2, 'T');
				break;
			case EVENT_VOTE_AGREE_ADD://投票赞同
				if (!self::$rbdb->gets('detail',$row['questionid'], $rdata))
					return false;
				$info['id'] = $row['questionid'];
				$info['weight'] = $rdata['weight'];
				$info['title'] = $rdata['title'];
				$info['isres'] = $rdata['resolved'];
				$info['content'] = (empty($rdata['tag'])?'':implode(' ', $rdata['tag']));
				self::writedata($info, 2, 'T');
				
				$uid = $rdata['a']["$row[answerid]"]['uid'];
				if (!self::$rbdb->gets('user',$uid, $rdata))
					return false;
				$info = array();
				$info['id'] = $uid;
				$info['weight'] = $rdata['weight'];
				$info['title'] = $rdata['nick'];
				$info['content'] = $rdata['description'];
				self::writedata($info, 1, 'T');
				break;
			case EVENT_TAG_ADD://增加话题
				$info['id'] = $row['tid'];
				$info['weight'] = 0;
				$info['title'] = $row['name'];
				$info['content'] = '';
				self::writedata($info, 3, 'T');
				break;
			case EVENT_TAG_UPDATE:
				self::$rbdb->lists('tq', $row['tid'], 0, 0, $tdata);
				if (!self::$rbdb->gets('tagid',$row['tid'], $rdata))
					return false;
				$info['id'] = $row['tid'];
				$info['weight'] = $tdata['total'];
				$info['title'] = $rdata['name'];
				$info['content'] = $row['description'];
				self::writedata($info, 3, 'T');
				break;
			case EVENT_TAG_DEL:
				$info['id'] = $row['tid'];
				self::writedata($info, 3, 'D');
				break;
			case EVENT_TAG_REST:
				$info['id'] = $row['tid'];
				$info['title'] = $row['title'];
				self::writedata($info, 3, 'T');
				break;
			case EVENT_USER_UPDATE://用户修改
				if (isset($row['nick'])){
					if (!self::$rbdb->gets('user',$row['uid'], $rdata))
						return false;
					$info['id'] = $row['uid'];
					$info['weight'] = $rdata['weight'];
					$info['title'] = $row['nick'];
					$info['content'] = $rdata['description'];
					self::writedata($info, 1, 'T');
				}
				else if (isset($row['description'])){
					if (!self::$rbdb->gets('user',$row['uid'], $rdata))
						return false;
					$info['id'] = $row['uid'];
					$info['weight'] = $rdata['weight'];
					$info['title'] = $rdata['nick'];
					$info['content'] = $row['description'];
					self::writedata($info, 1, 'T');
				}
				else if (isset($row['status'])){
					if ($row['status'] == 1){
						$info['id'] = $row['uid'];
						self::writedata($info, 1, 'D');
					}
					else{
						if (!self::$rbdb->gets('user',$row['uid'], $rdata))
							return false;
						$info['id'] = $row['uid'];
						$info['weight'] = $rdata['weight'];
						$info['title'] = $rdata['nick'];
						$info['content'] = $rdata['description'];
						self::writedata($info, 1, 'T');
					}
				}
				break;
			case EVENT_USER_REGISTER:
				$info['id'] = $row['uid'];
				$info['weight'] = self::$userweight;
				$info['title'] = $row['nick'];
				$info['content'] = $row['description'];
				self::writedata($info, 1, 'T');
				break;
			default:
				return false;
		}
		return true;
	}

}

?>
