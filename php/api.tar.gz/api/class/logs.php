<?php
/**
 * logs class 
 * by tingting18
 * 20111103
 */

class Logs {
    public $rpcdb_obj,$mysqldb_obj,$queue_obj;
    public $dbname,$filename,$cmdid;
    function __construct() {
        $this->rpcdb_obj = new RpcDb;
        $this->mysqldb_obj = new MysqlDb;
        $this->queue_obj = new QueueTool;
	$this->tools_obj = new Tools();
	$this->id_server = new IdServer();
       
        $this->dbname = question;
    }
    
    
    /**
     * 添加日志
     * @param $oid 对象id（话题，用户，问题）
     * @param $uid 操作人id
     * @param $type 操作方法 (各种事件)
     * @param $content 操作内容(可为任意需要记录的内容)
     * @param $ctime 添加时间
     * @return ture/false
     * 
     */
    
    public function add_logs($oid,$uid,$type,$content,$ctime , &$logid = ''){
        # $table_name = 'logs';
        $table_name = $this->mysqldb_obj->get_table('log' , $type);
	$row['logid'] = $logid = $this->id_server->get($table_name);
        $row['oid'] = $oid;
        $row['uid'] = $uid;
        $row['type'] = $type;
        $row['content'] = $content;
        $row['ctime'] = $ctime;
        $sql = $this->mysqldb_obj->prepare_insert_sql($table_name, $row);
        $res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
        if($res){
		$row[0] = EVENT_LOG_ADD;
		$url = QDOMAIN."/send_queue.php";
		$queue = $this->tools_obj->curl_set($url , "POST" , array('data' => serialize($row)) , $queue);
		# $queue = $this->tools_obj->queue_send('log', $row);
		if($queue){
			return true;
		}else{
                	return false;
            	}
        }else{
		return false;
        } 
    }
   

    public function create_logs($arr , &$logid = ''){
        $table_name	= $this->mysqldb_obj->get_table('log' , $arr['type']);
        $row['logid']	= $logid = $this->id_server->get($table_name);
        $row['oid']	= $arr['oid'];
        $row['uid']	= $arr['uid'];
        $row['type']	= $arr['type'];
        $row['content']	= $arr['content'];
        $row['ctime']	= $arr['ctime'];
        $sql = $this->mysqldb_obj->prepare_insert_sql($table_name , $row);
        $res = $this->rpcdb_obj->update($this->dbname , $sql , $data);
        if($res){
                $row[0] = EVENT_LOG_ADD;
                $url = QDOMAIN."/send_queue.php";
                $queue = $this->tools_obj->curl_set($url , "POST" , array('data' => serialize($row)) , $queue);
                if($queue){
                        return true;
                }else{
                        return false;
                }
        }else{
                return false;
        }
    } 

}
?>
