<?php
//mysqlֱl

class MysqlDb extends mysqli{
	static $m_db = null;
	
	function __construct()
	{
	}
	
	function connect($dbname, $read = true)
	{
		switch($dbname)
		{
			case 'question':
				if ($read){
					return self::my_connect(MYSQL_QUESTION_READ_SERVER,MYSQL_QUESTION_USER,MYSQL_QUESTION_PW,MYSQL_QUESTION_DBNAME,MYSQL_STAT_READ_PORT);
				}
				else{
					return self::my_connect(MYSQL_QUESTION_WRITE_SERVER,MYSQL_QUESTION_USER,MYSQL_QUESTION_PW,MYSQL_QUESTION_DBNAME,MYSQL_STAT_WRITE_PORT);
				}
				break;
			case 'stat':
				if ($read){
					return self::my_connect(MYSQL_STAT_READ_SERVER,MYSQL_STAT_USER,MYSQL_STAT_PW,MYSQL_STAT_DBNAME,MYSQL_STAT_READ_PORT);
				}
				else{
					return self::my_connect(MYSQL_STAT_WRITE_SERVER,MYSQL_STAT_USER,MYSQL_STAT_PW,MYSQL_STAT_DBNAME,MYSQL_STAT_WRITE_PORT);
				}
				break;
			case 'feed':
				if ($read){
					return self::my_connect(MYSQL_FEED_READ_SERVER,MYSQL_FEED_USER,MYSQL_FEED_PW,MYSQL_FEED_DBNAME,MYSQL_REED_READ_PORT);
				}
				else{
					return self::my_connect(MYSQL_FEED_WRITE_SERVER,MYSQL_FEED_USER,MYSQL_FEED_PW,MYSQL_FEED_DBNAME,MYSQL_REED_WRITE_PORT);
				}
				break;
			case 'user':
				if ($read){
					return self::my_connect(MYSQL_USER_READ_SERVER,MYSQL_USER_USER,MYSQL_USER_PW,MYSQL_USER_DBNAME,MYSQL_USER_READ_PORT);
				}
				else{
					return self::my_connect(MYSQL_USER_WRITE_SERVER,MYSQL_USER_USER,MYSQL_USER_PW,MYSQL_USER_DBNAME,MYSQL_USER_WRITE_PORT);
				}
				break;
			default:
				return false;
		}
		return true;
	}
	
	function my_connect($host,$usr,$pass,$database,$port)
	{
		self::$m_db = $this->mysqli($host,$usr,$pass,$database,$port);
		if (!self::$m_db) {
			return false;
		}
		
		if (!$this->query("set names utf8")) {
			return false;
		}
		return true;
	}
	function read($sql, &$result)
	{
		$result = array();
		if (!$res = $this->query($sql)) {
			return false;
		}
		if ($res->num_rows != 0) {
			while ($row = $res->fetch_array(MYSQLI_ASSOC))  {
				$result[] = $row;
			}
		}
		return true;
	}
	function update($sql, $result)
	{
		$result = array();
		if (!$this->query($sql)) {
			return false;
		}

		$result["insertid"] =$db->insert_id;
		$result["affectedrows"] = $db->affected_rows;
		return true;
	}
	
	function prepare_insert_sql($tablename, $row, $fields_not_quote = "")
	{
		$first = TRUE;
		$x = ($fields_not_quote == '') ? array() : explode(',', $fields_not_quote);
		$fs = "";
		$vs = "";
		foreach ($row as $k=>$v)
		{
			if ($v == ''){
				$v = "''";
			}
			else if (!in_array($k, $x)){
				$v = sprintf("'%s'", mysql_escape_string($v));
			}
	
			if ($first){
				$first = FALSE;
				$fs .= "`$k`";
				$vs .= "$v";
			}
			else{
				$fs .= ",`$k`";
				$vs .= ",$v";
			}
		}
		$sql = "insert into $tablename($fs)values($vs)";
		return $sql;
	}
	
	function prepare_update_sql($tablename, $row, $fields_not_quote = "")
	{
		$first = TRUE;
		$x = ($fields_not_quote == '') ? array() : explode(',', $fields_not_quote);
		$fs = "";
		$vs = "";
		foreach ($row as $k=>$v)
		{
			if ($v == ''){
				$v = "''";
			}
			else if (!in_array($k, $x)){
				$v = sprintf("'%s'", mysql_escape_string($v));
			}
	
			if ($first){
				$first = FALSE;
				$fs .= "$k=$v";
			}
			else{
				$fs .= ",$k=$v";
			}
		}
		$sql = "update $tablename set $fs";
		return $sql;
	}
	
	function get_table($type , $term = '') {
		$table_name = '';
		switch($type) {
			case 'log' :
				$question_log = array(
					EVENT_QUESTION_ADD,
					EVENT_QUESTION_DEL,
					EVENT_QUESTION_UPDATE,
					EVENT_QUESTION_TITLE_UPDATE,
					EVENT_QUESTION_DESC_UPDATE,
					EVENT_QUESTION_LOCK,
					EVENT_QUESTION_REST,
					EVENT_QUESTION_TAG_ADD,
					EVENT_QUESTION_TAG_DEL,
					EVENT_QUESTION_REDIRECT,
					EVENT_QUESTION_INVITE,
					EVENT_ANSWER_ADD,
					EVENT_ANSWER_DEL,
					EVENT_ANSWER_UPDATE,
					EVENT_ANSWER_RECOVER,
					EVENT_COMMENT_ADD,
					EVENT_COMMENT_DEL,
					EVENT_VOTE_AGREE_ADD,
					EVENT_VOTE_AGREE_DEL,
					EVENT_VOTE_AGAINST_ADD,
					EVENT_VOTE_AGAINST_DEL,
					EVENT_VOTE_NOHELP,
				);
				$tag_log = array(
					EVENT_TAG_ADD,
					EVENT_TAG_UPDATE,
					EVENT_TAG_DEL,
					EVENT_TAG_LOCK,
					EVENT_TAG_FATHER_ADD,
					EVENT_TAG_FATHER_DEL,
					EVENT_TAG_CHILD_ADD,
					EVENT_TAG_CHILD_DEL,
					EVENT_TAG_EXP_UPDATE,
				);
				$user_log = array(
					EVENT_USER_UPDATE,
					EVENT_USER_REGISTER,
					EVENT_USER_UPDATE_LOGO,
					EVENT_INDEX_INTEREST,
					EVENT_USER_FOLLOW_ADD,
					EVENT_USER_FOLLOW_DEL,
					EVENT_TAG_FOLLOW_ADD,
					EVENT_TAG_FOLLOW_DEL,
					EVENT_QUESTION_FOLLOW_ADD,
					EVENT_QUESTION_FOLLOW_DEL,
					EVENT_QUESTION_ADOPT,
					EVENT_TAG_UPDATE_LOGO,
					EVENT_QUESTION_INVITE_DEL,
				);
				if(in_array($term , $question_log)) {
					$table_name = 'question_logs';
				}
				elseif(in_array($term , $tag_log)) {
					$table_name = 'tag_logs';
				}
				elseif(in_array($term , $user_log)) {
					$table_name = 'user_logs';
				}
				break;
			case 'answer' :
				if(!empty($term) && floatval($term) > 0) {
					$table_num = intval(floatval($term) % ANSWER_TABLE_COUNT);
					$table_name = 'answer'.$table_num;
				}
				break;
			case 'user' :
				if(!empty($term) && floatval($term) > 0) {
					$table_num = intval(floatval($term) % USER_TABLE_COUNT);
					$table_name = 'user'.$table_num;
				}
				break;
		}
		return $table_name;
	}
}

?>
