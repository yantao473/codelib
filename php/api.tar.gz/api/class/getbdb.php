<?php
//获取bdb接口

class GetBdb {
	static $bdb;
	static $conf;
	function __construct()
	{
		global $g_bdb_table;
		
		self::$conf = $g_bdb_table;
		self::$bdb = new BdbDb;
	}
	
	//各种列表 um 问我,uq 问过,ua 答过,tq 话题下的问题,lq 全部问题,ue用户编辑
	function lists($type, $id, $start, $num, &$data, $order=0)
	{
		$data = array();
		$app = self::$conf["$type"]['app'];
		if (empty($app))
			return false;
		if (!self::$bdb->getkey(self::$conf["$type"], $id, $karray))
			return false;
		$table = isset(self::$conf["$type"]['table'])?self::$conf["$type"]['table']:$type;
		if ($app == 'list'){
			if (!self::$bdb->getalist($app, $table, $start, $num, $data, $order))
				return false;
		}
		else if (!self::$bdb->getlist($app, $table, $karray['real'], $start, $num, $data, $order, $karray['part'])){
			return false;
		}
		$lkeyarray = self::$conf["$type"]['lkey'];
		if (self::$conf["$type"]['type'] == 't'){
			if (!self::$bdb->gettableconf($id[0], $tarray))
				return false;
			$lkeyarray = $tarray['lkey'];
		}
		for($i=0;$i<$data['num'];$i++)
		{
			$len = strlen($data["$i"]['key']);
			$tlen = 0;
			foreach ($lkeyarray as $k0 => $k1){
				$data["$i"]['keys']["$k0"] = self::$bdb->getoutkey($k1, substr($data["$i"]['key'], $tlen, $k1[0]));
				$tlen += $k1[0];
			}
			unset($data["$i"]['key']);
			$data["$i"]['data'] = ($data["$i"]['data']==''?'':unserialize(gzuncompress($data["$i"]['data'])));
		}
		return true;
	}
	
	//批量获取列表内容，必须是特殊格式列表才可以。id 类似lists的$id;$ids 需要查找的id，可以是数组形式;$getkey 只获取key默认，false时获取内容
	function getlistkey($type, $id, $ids, &$data, $getkey=true)
	{
		$data = array();
		if (empty($id))
			return false;
		$app = self::$conf["$type"]['app'];
		if (empty($app))
			return false;
		$keyconf = self::$conf["$type"];
		if (self::$conf["$type"]['type'] == 't'){
			if (!self::$bdb->gettableconf($id[0], $tarray))
				return false;
			$keyconf = $tarray;
		}
		if (!self::$bdb->getkey(self::$conf["$type"], $id, $karray))
			return false;
		$table = isset(self::$conf["$type"]['table'])?self::$conf["$type"]['table']:$type;
		$types = ($getkey===true?'k.':'').$table;
		$keys = '';
		$i = $keyconf['dkey'] + 1;
		if (is_array($ids)){
			$keys = array();
			foreach($ids as $v)
			{
				if (is_array($v)){
					$j = $i;
					$v1 = '';
					foreach ($v as $v0)
					{
						$v1 .= self::$bdb->getrealkey($keyconf['lkey']["$j"], $v0);
						$j++;
					}
					$keys[] = $karray['real'].$v1;
				}else{
					$keys[] = $karray['real'].self::$bdb->getrealkey($keyconf['lkey']["$i"], $v);
				}
			}
		}else{
			$keys = $karray['real'].self::$bdb->getrealkey($keyconf['lkey']["$i"], $ids);
		}
		if (!self::$bdb->get($app, $types, $keys, $rdata, $karray['part'], 0, 1))
				return false;
		$lkeylen = 0;
		$stop = ($keyconf['dkey'] == $keyconf['ikey']?$i:($i-1));
		foreach ($keyconf['lkey'] as $k => $v)
		{
			if ($k >= $stop)
				break;
			$lkeylen += $v[0];
		}
		if (!is_array($ids)){
			if ($getkey === true){
				$data = ($rdata[0]==''?'':self::$bdb->getoutkey($keyconf['lkey']["$keyconf[dkey]"], $rdata[0]));
			}else{
				$data = ($rdata[0]==''?'':unserialize(gzuncompress($rdata[0])));
			}
		}
		else foreach ($rdata as $k => $v)
		{
			$k0 = self::$bdb->getoutkey($keyconf['lkey']["$i"], substr($k, $lkeylen, $keyconf['lkey']["$i"][0]));
			if ($getkey === true){
				$v = ($v == ''?'':self::$bdb->getoutkey($keyconf['lkey']["$keyconf[dkey]"], $v));
			}else{
				$v = ($v == ''?'':unserialize(gzuncompress($v)));
			}
			$data["$k0"] = $v;
		}
		return true;
	}
	//type 应用;$id 可以是数组形式;$data 返回值
	function gets($type, $id, &$data)
	{
		$data = array();
		if (empty($id))
			return false;
		if (empty(self::$conf["$type"]))
			return false;
		if (!self::$bdb->getkey(self::$conf["$type"], $id, $karray))
			return false;
		switch($karray['flag'])
		{
			case 'array':
				if (!self::$bdb->get(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $rdata, $karray['part'], 0))
					return false;
				if (!is_array($karray['real'])){
					$data = ($rdata[0]==''?'':@unserialize(gzuncompress($rdata[0])));
					if ($data === false)
						return false;
				}
				else foreach ($rdata as $k => $v)
				{
					$data["$k"] = ($v==''?'':@unserialize(gzuncompress($v)));
				}
			break;
			case 'char':
				if (!self::$bdb->get(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $rdata, $karray['part'], 0))
					return false;
				if (!is_array($karray['real'])){
					$v1 = @gzuncompress($rdata[0]);
					$data = $v1?$v1:$rdata[0];
				}
				else foreach ($rdata as $k => $v)
				{
					$v1 = @gzuncompress($v);
					$data["$k"] = $v1?$v1:$v;
				}
			break;
			case 'int':
				if (!self::$bdb->get(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $rdata, $karray['part'], 0))
					return false;
				$sum = array_sum(self::$bdb->conf['v']);
				$count = count(self::$bdb->conf['v']);
				if (!is_array($karray['real'])){
					$ilen = strlen($rdata[0]);
					for ($i=0,$j=0;$i<$ilen;$i+=$sum,$j++)
					{
						$start = $i;
						$tmp = array();
						foreach (self::$bdb->conf['v'] as $v0)
						{
							$tmp[] = strval(self::$bdb->b2i(substr($rdata[0], $start, $v0), $v0));
							$start += $v0;
						}
						if ($count == 2){
							$data["$tmp[0]"] = $tmp[1];
						}else{
							$data[] = $tmp;
						}
					}
				}
				else foreach ($rdata as $k => $v)
				{
					$ilen = strlen($v);
					for ($i=0,$j=0;$i<$ilen;$i+=$sum,$j++)
					{
						$start = $i;
						$tmp = array();
						foreach (self::$bdb->conf['v'] as $v0)
						{
							$tmp[] = strval(self::$bdb->b2i(substr($v, $start, $v0), $v0));
							$start += $v0;
						}
						if ($count == 2){
							$data["$k"]["$tmp[0]"] = $tmp[1];
						}else{
							$data["$k"][] = $tmp;
						}
					}
				}
			break;
			case 'num':
				if (!self::$bdb->get(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $rdata, $karray['part'], 0))
					return false;
				if (!is_array($karray['real'])){
					for ($i=0;$i<strlen($rdata[0]);$i+=4)
					{
						$m0 = unpack('V', substr($rdata[0], $i, 4));
						$data[] = sprintf("%u", $m0[1]);
					}
				}
				else foreach ($rdata as $k => $v)
				{
					for ($i=0;$i<strlen($v);$i+=4)
					{
						$m0 = unpack('V', substr($v, $i, 4));
						$data["$k"][] = sprintf("%u", $m0[1]);
					}
				}
			break;
			default:
				if (('t' == self::$conf["$type"]['type'] && self::$conf["$type"]['ltype'] == 'list') || self::$conf["$type"] == 'list')  //如果是列表
{
					if (!self::$bdb->get(self::$conf["$type"]['app'], self::$conf["$type"]['table'], $karray['real'], $rdata, $karray['part'], 0))		       
						return false;
					if (!is_array($karray['real'])){
						$data = ($rdata[0]==''?'':@unserialize(gzuncompress($rdata[0])));
						if ($data === false)
							return false; 
					}       
					else foreach ($rdata as $k => $v){
						$data["$k"] = ($v==''?'':@unserialize(gzuncompress($v)));
					}
					return true;
				}
				return false;
		}
		return true;
	}
	
}

?>
