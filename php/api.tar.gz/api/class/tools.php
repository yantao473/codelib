<?php
/**
 * 工具类 
 *
 * @editor zhanghua2@staff.sina.com.cn
 * @package      tool
 * @copyright    copyright(2011) 新浪网研发中心 all rights reserved
 * @version      1.0    2011/08/17 11:08:00
*/

class Tools {

	private $queue_obj;
	private $queue_conf;

	public function __construct() {
		global $queue_config;
		$this->queue_conf = $queue_config;
		$this->queue_obj = new QueueTool();
	}

	/**
	 * 获取用户IP
	 *
     * @editor zhanghua2@staff.sina.com.cn
	 * @param
	 * @return bool
	*/
	public function get_user_ip() {
	    if (getenv('HTTP_CLIENT_IP')) {
	        $IP = getenv('HTTP_CLIENT_IP');
	    }
	    elseif (getenv('HTTP_X_FORWARDED_FOR')) {
	        $IP = getenv('HTTP_X_FORWARDED_FOR');
	    }
	    elseif (getenv('HTTP_X_FORWARDED')) {
	        $IP = getenv('HTTP_X_FORWARDED');
	    }
	    elseif (getenv('HTTP_FORWARDED_FOR')) {
	        $IP = getenv('HTTP_FORWARDED_FOR');
	    }
	    elseif (getenv('HTTP_FORWARDED')) {
	        $IP = getenv('HTTP_FORWARDED');
	    }
	    else {
	        $IP = $_SERVER['REMOTE_ADDR'];
	    }
	    return $IP;
	 }
	
	/**
	 * Curl 远程调用 POST/GET 方式
	 * 参数使用rawurlencode编码
	 * 
     * @editor zhanghua2@staff.sina.com.cn
	 * @param
	 * @return bool
	*/
	public function curl_set($url , $type='post', $post_data='', &$res) {
		$param = '';
		//$post_data = array();
		if(is_array($post_data)) {
			$post_data = http_build_query($post_data);
		}
		/*
		if(!empty($aconf)) {
			return false;
		}*/
		
		$curl_handle = curl_init();
		curl_setopt($curl_handle, CURLOPT_URL, $url);
		curl_setopt($curl_handle, CURLOPT_HEADER, 0);
		if(strtolower($type) == 'get') {
			curl_setopt($curl_handle, CURLOPT_HTTPGET, true);
		}
		if(strtolower($type) == 'post') {
			curl_setopt($curl_handle, CURLOPT_POST, 1);
			curl_setopt($curl_handle, CURLOPT_POSTFIELDS, $post_data);
		}
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
 		curl_setopt($curl_handle, CURLOPT_TIMEOUT, 2);
		$res = curl_exec($curl_handle);
		curl_close($curl_handle);
		
		return true;
	}


	/** 
	 * 截取字符串
	 *
	 * @editor zhanghua2@staff.sina.com.cn
	 * @param string
	 * @return 
	*/
        public function mb_substring($str , $start , $end , $encoding = 'utf-8') {
                $new_str = '';                                  // 声明截取后的字符串
                $n = 0;
                $lth_en = $lth_ch = 0;                  // 表示中英文个数
                $length = mb_strlen($str , $encoding);

                while($n < $length)
                {
                        $word = mb_substr($str, $n , 1, $encoding);     // 系统函数截一个字符
                        $word_len = strlen($word);              // 判断截出字符的字节数

                        if($n >= $start)
                        {
                                $new_str .= $word;
                                if($word_len == 3 || $word_len == 2)                              // 中文
                                {
                                        $lth_ch++;
                                }
                                elseif($word_len == 1)                  // E文
                                {
                                        $lth_en++;
                                }
                        }

                        if(floor($lth_en / 2) + $lth_ch >= $end)        // 两个英文字符作为一个长度单位进行判断 只跟显示有关 跟编码无关
                        {
                                break;
                        }

                        $n++;
                }
                if($n < $length)
                {
                        $new_str .= '...';
                }
                return $new_str;
        }

	public function mb_stringlen($str , $encoding = 'utf-8') {
		return mb_strlen($str,$encoding);
	}

	public function string_analyze($str) {
		$p = $lth_en = $lth_ch = 0;
		$length = strlen($str);
		while($p < $length)
		{
			$word = $this->mb_substring($str , $lth_en+$lth_ch , 1);
			$word_len = strlen($word);
			if($word_len == 3 || $word_len == 2 )
			{
				$lth_ch++;
			}
			elseif($word_len == 1)
			{
				$lth_en++;
			}
			$p+=$word_len;
		}
		return array('en' => $lth_en , 'ch' => $lth_ch , 'length' => $length);
	}

	/** 
	 * 页面跳转函数带回调链接
	 *
	 * @editor zhanghua2@staff.sina.com.cn
	 * @param string
	 * @return 
	*/
	public function location_url($url , $arr='' , $callback_url='') {
		if(!empty($arr) && is_array($arr)) {
			foreach($arr as $k=>$v) {
				$param .= $param ? "&{$k}=".urlencode($v) : "{$k}=".urlencode($v);
			}
		}
		if(!empty($callback_url)) {
			$param .= "callback_url={$callback_url}";
		}
		header("Location:{$url}".($param ? '?'.$param : ''));
		die();
	}

	/** 
	 * 页面跳转函数 js
	 *
	 * @editor zhanghua2@staff.sina.com.cn
	 * @param string
	 * @return 
	*/
	public function location_url_js($url) {
		echo '<script>window.location.href="'.$url.'";</script>';
		die();
	}

    /** 
    * 队列转发函数 适用于所有队列
    *
    * @editor zhanghua2@staff.sina.com.cn
    * @param string
    * @param array
    * @return 
    */
    public function queue_send($qname,$data)
    {
		switch($qname) {
			case 'audit_queue' :
	            		$data['login']  = $_SESSION['session_login'];
                		$data['nick']   = $_SESSION['session_nick'];
                		$data['email']  = $_SESSION['session_email'];
                		$data['logo']   = $_SESSION['session_picture'];
                		$data['createtime'] = $_SESSION['session_create_time'];
                	break;
        	}
		$this->queue_obj->forward($qname,$this->queue_conf,$data);
    }

	/**
	* cut str add html tags
	*add by guoxianghui@staff.sina.com.cn
	**/
	function htmlSubString($content,$maxlen=120){
		//把字符按HTML标签变成数组。
		$content = preg_split("/(<[^>]+?>)/si",$content, -1,PREG_SPLIT_NO_EMPTY| PREG_SPLIT_DELIM_CAPTURE);
		$wordrows=0;   //中英字数
		$outstr="";     //生成的字串
		$wordend=false;   //是否符合最大的长度
		$beginTags=0;   //除<img><br><hr>这些短标签外，其它计算开始标签，如<div*>
		$endTags=0;     //计算结尾标签，如</div>，如果$beginTags==$endTags表示标签数目相对称，可以退出循环。
		//print_r($content);
		foreach($content as $value){
			if (trim($value)=="") continue;   //如果该值为空，则继续下一个值
    		if (strpos(";$value","<")>0){
	 	//如果与要载取的标签相同，则到处结束截取。
	 			if (trim($value)==$maxlen) {
	 				$wordend=true;
	 				continue;
	 			}
	        	if ($wordend==false){
					$outstr.=$value;
					if (!preg_match("/<img([^>]+?)>/is",$value) && !preg_match("/<param([^>]+?)>/is",$value) && !preg_match("/<!([^>]+?)>/is",$value) && !preg_match("/<br([^>]+?)>/is",$value) && !preg_match("/<hr([^>]+?)>/is",$value)){
						$beginTags++; //除img,br,hr外的标签都加1
					}
				}else if (preg_match("/<\/([^>]+?)>/is",$value,$matches)){
					$endTags++;
					$outstr.=$value;
					if ($beginTags==$endTags && $wordend==true) break;   //字已载完了，并且标签数相称，就可以退出循环。
					}else{
							if(!preg_match("/<img([^>]+?)>/is",$value) && !preg_match("/<param([^>]+?)>/is",$value) && !preg_match("/<!([^>]+?)>/is",$value) && !preg_match("/<br([^>]+?)>/is",$value) && !preg_match("/<hr([^>]+?)>/is",$value)) {
								$beginTags++; //除img,br,hr外的标签都加1
								$outstr.=$value;
							}
					}
			}else{
				if (is_numeric($maxlen)){   //截取字数
					$curLength	=	$this->getStringLength($value);
					$maxLength=$curLength+$wordrows;
					if ($wordend==false){
						if ($maxLength>$maxlen){   //总字数大于要截取的字数，要在该行要截取
							$outstr .= $this->subString($value,0,$maxlen-$wordrows);
							//$outstr .= $value;
							$wordend=true;
						}else{
							$wordrows=$maxLength;
							$outstr.=$value;
						}
					}
				}else{
					if ($wordend==false) $outstr.=$value;
				}
			}
		}
		//循环替换掉多余的标签，如<p></p>这一类
		//while(preg_match("/<([^\/][^>]*?)><\/([^>]+?)>/is",$outstr)){
		//	$outstr=preg_replace_callback("/<([^\/][^>]*?)><\/([^>]+?)>/is","strip_empty_html",$outstr);
		//}
		//把误换的标签换回来
		if (strpos(";".$outstr,"[html_")>0){
			$outstr=str_replace("[html_<]","<",$outstr);
			$outstr=str_replace("[html_>]",">",$outstr);
		}
		   //echo htmlspecialchars($outstr);
		   	return $outstr;
	}

	//去掉多余的空标签
	function strip_empty_html($matches){
		$arr_tags1=explode(" ",$matches[1]);
		if ($arr_tags1[0]==$matches[2]){   //如果前后标签相同，则替换为空。
			return "";
		}else{
			$matches[0]=str_replace("<","[html_<]",$matches[0]);
			$matches[0]=str_replace(">","[html_>]",$matches[0]);
			return $matches[0];
		}
	}

	//取得字符串的长度，包括中英文。
	function getStringLength($text){
		if (function_exists('mb_substr')) {
			$length=mb_strlen($text,'UTF-8');
		} else if (function_exists('iconv_substr')) {
			$length=iconv_strlen($text,'UTF-8');
		} else {
			 preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $text, $ar);
			 $length=count($ar[0]);
		}
		return $length;
	}

	/***********按一定长度截取字符串（包括中文）*********/
	function subString($text, $start=0, $limit=12) {
		if (function_exists('mb_substr')) {
			$more = (mb_strlen($text,'UTF-8') > $limit) ? TRUE : FALSE;
			$text = mb_substr($text, 0, $limit, 'UTF-8');
			return $text;
		} else if (function_exists('iconv_substr')) {
			$more = (iconv_strlen($text,'UTF-8') > $limit) ? TRUE : FALSE;
			$text = iconv_substr($text, 0, $limit, 'UTF-8');
			//return array($text, $more);
			return $text;
		} else {
			preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $text, $ar);
			if(func_num_args() >= 3) {
				if (count($ar[0])>$limit) {
					$more = TRUE;
					$text = join("",array_slice($ar[0],0,$limit));
				} else {
					$more = FALSE;
					$text = join("",array_slice($ar[0],0,$limit));
				}
			} else {
				$more = FALSE;
				$text = join("",array_slice($ar[0],0));
			}
			return $text;
		}
	}
	//加载配置文件
	public function loadconfig($filename)
	{
		$config = @parse_ini_file($filename);
		if ($config){
			$_SERVER = array_merge($_SERVER, $config);
		}
	}

	//加载接口功能订制文件
	public function loadApiConfig($filename)
	{
		$config = @parse_ini_file($filename , true);
		return $config;
	}

        /** 
         * 读取本项目的app
         *
         * 说明:
         * 此功能涉及到使用二进制表示权限的 检查、修改、读取的操作方式。
         * 支持全部修改,也支持单一修改 视应用的需要,如果应用具有排他性 选择1就不能选择2,3,4 选择3,4就不能选择1,2这样
         * 的情况, 那么1,2,3,4就都是必传的参数 勾选用1表示，没勾选用0表示。参数名必须跟配置里定义的应用名一样。
         * 如果应用没有排他性, 则只传递某一位上的应用选项即可。
         * @editor zhanghua2@staff.sina.com.cn
         * @param string
         */
        public function read_app($app_val , &$app_code) {
                $app_code = array();
                $app_bin = decbin($app_val);
                for($i = 0 ; $i < strlen($app_bin) ; $i++) {
                        if($app_bin{$i} == 1) {
                                $app_code[] = strlen($app_bin) - 1 - $i;
                        }
                }
                return true;
        }

        function add_pwd($cookie_str) {
                $search = array("M" , "N" , "B" , "u" , "i");
                $replace = array("%" , "@" , "~" , "*" , "#");
                $encode_str = base64_encode($cookie_str);
                $rep_str = str_replace($search , $replace , $encode_str);
                //echo 'add pwd : ' . $rep_str . "\n\n";
                return $rep_str;
        }

       function del_pwd($rep_str) {
                $replace = array("M" , "N" , "B" , "u" , "i");
                $search = array("%" , "@" , "~" , "*" , "#");
                $rep_str = str_replace($search , $replace , $rep_str);
                $rep_str = base64_decode($rep_str);
                //echo 'del pwd : ' . $ori_str . "\n\n";
                return $rep_str;
        }


        function microtime_float_start()
        {
                list($usec, $sec) = explode(" ", microtime());
                $this->time_start = ((float)$usec + (float)$sec);
        }

        function microtime_float_end($partition)
        {
                list($usec, $sec) = explode(" ", microtime());
                $this->time_end = ((float)$usec + (float)$sec);

                $fp = @fopen('/tmp/apitime.log' , 'a');
                $log = $partition . ' : ' . ($this->time_end - $this->time_start) . "\n";
                @fwrite($fp , $log);
                @fclose($fp);
                #$log = ($this->time_end - $this->time_start);
                #return $log;
        }

/*
        function deal_text($text,$flag = 1 ){
                $text = trim($text);
                if($flag == 3){
                }
                if($flag == 2){
                        $text = preg_replace( "~([\n]*<br\s*[/]?>[\n]*)+~is","\n",$text);
                        $text = preg_replace( "~[\n]+~is","\n",$text);
                }
                if($flag == 1){
                        $text = preg_replace( "~[\n]+~is",'',$text);
                }
                   
                $text = preg_replace( '~([ ])+|(&nbsp;)+~is',' ',$text);
                $result = str_replace("\n" , '<br />' , htmlspecialchars($text));                          
                if($flag == 4){                                                                            
                        $result = str_replace("\n" , '' , htmlspecialchars($text));
                        $result = str_replace("<br />" , '' , htmlspecialchars($text));                    
                }                                                                                          
                return $result;                                                                            
        } 

*/
        function deal_text($text,$flag = 1 ){
                $text = trim($text);
		//手机端使用
		if($flag == 3){

		}
                //提问和 回答 时分别处理 问题描述 ，参考资料；  将一个或多个\n，br 替换成一个\n
                if($flag == 2){
                        $text = preg_replace( "~([\n]*<br\s*[/]?>[\n]*)+~is","\n",$text);
                        $text = preg_replace( "~[\n]+~is","\n",$text);
                }
                //提问和评论 时分别处理标题，评论内容；  一个或者多个\n替换成空   
                if($flag == 1){
                        $text = preg_replace( "~[\n]+~is",'',$text);
                }

                $text = preg_replace( '~([ ])+|(&nbsp;)+~is',' ',$text);
                // 提交回答 和 编辑回答 时的处理逻辑
                if($flag == 5){
                        // 特殊处理 对安全部强行插入标签的情况下 或者 网站被入侵 从站内发起攻击的话，此处不能对字符串再做htmlspecialchars处理 只能对尖括号进行处理
                        $pattern[] = '~<~';
                        $pattern[] = '~>~';
                        $pattern[] = '~[\r\n]+~';

                        $replace[] = '&lt;';
                        $replace[] = '&gt;';
                        $replace[] = '<br />';                                                                    
                        $result = preg_replace($pattern , $replace , $text);                                      
                }                                                                                                 
                else{                                                                                             
                        $result = preg_replace('~(\r\n)+~is' , '<br />' , htmlspecialchars($text));               
                }                                                                                                 
                //获取个人签名 \n,br 替换成空                                                                     
                if($flag == 4){                                                                                   
                        $result = str_replace("\n" , '' , htmlspecialchars($text));                               
                        $result = str_replace("<br />" , '' , htmlspecialchars($text));
                }                                                                                                 
                return $result;                                                                                   
        }
        
        
        
        function deal_text_web($text,$flag = 1 ){
			$text = trim($text);
			//$flag = 2 只针对回答时过滤参考资料
			if($flag == 2){
				$result = htmlspecialchars($text);
			}
			//$flag = 1 只针对提问时过滤标题  鲍巍 在 2012/11/21 11:16:38 说 需要 把回车全过滤掉
			elseif($flag == 1){
				$text = preg_replace( "~[\n]+~is",'',$text);
				$result = preg_replace('~(\r\n)+~is' , '' , htmlspecialchars($text));
				$result = preg_replace( '~([ ])+|(&nbsp;)+~is','&nbsp;',$result);
			}
			//$flag = 3 只针对问题或者回答的 评论内容
			elseif($flag == 3){
				$result = preg_replace('~[\r\n]+~is' , '<br />' , htmlspecialchars($text));
				$result = preg_replace( '~(&nbsp;)+~is','&nbsp;',$result);
			}
			//$text = preg_replace( '~([ ])+|(&nbsp;)+~is','&nbsp;',$text);
			// 只针对 提交回答 和 编辑回答 和 添加问题时的问题描述    处理逻辑
			elseif($flag == 5){
				// 特殊处理 对安全部强行插入标签的情况下 或者 网站被入侵 从站内发起攻击的话，此处不能对字符串再做htmlspecialchars处理 只能对尖括号进行处理
				$text = preg_replace( '~([ ])+|(&nbsp;)+~is','&nbsp;',$text);
	
				$pattern[] = '~(<br[^>]*>)~';
				$pattern[] = '~<(/?)p[^>]*>~is';
				$pattern[] = '~(\[paragraph\](?:&nbsp;|\s*)\[/paragraph\]\s*){2,}~is';
				$pattern[] = '~^(\s*\[paragraph\](?:&nbsp|\s*)\[/paragraph\])+~';
				$pattern[] = '~(\s*\[paragraph\](?:&nbsp;|\s*)\[/paragraph\])+$~';
				$pattern[] = '~<~';
				$pattern[] = '~>~';
	
				$replace[] = '<p>&nbsp;</p>';
				$replace[] = '[$1paragraph]';
				$replace[] = '[paragraph]&nbsp;[/paragraph]';
				$replace[] = '';
				$replace[] = '';
				$replace[] = '&lt;';
				$replace[] = '&gt;';
	
				$result = preg_replace($pattern , $replace , $text);
	
				$pos = strpos($result, '[paragraph');
				if($pos === false) {
					if(strlen($result) > 0) {
						$result = '[paragraph]'.$result.'[/paragraph]';
					}
				} else {
					if($pos !==0) {
						$result = '[paragraph]'.substr($result, 0, $pos).'[/paragraph]'.substr($result, $pos);
					}
				}
	
			}
			// 针对feed提交回答后 对回答的字符串处理
			elseif($flag == 6) {
				$text = htmlspecialchars($text);
				$text = preg_replace('~[\n]{2,}~is',"\n<p>&nbsp;</p>\n" , $text);
				$tmp_arr =  explode("\n" , $text);
				$result = array();
				foreach($tmp_arr as $k => $v) {
	        			if($v != '<p>&nbsp;</p>') {
	                			$result[$k] = '<p>'.$v.'</p>';
	        			}
	        			else {
	                			$result[$k] = $v;
	        			}
				}
				$result = implode('' , $result);
			}
			return $result;
		}

		
		function deal_filter_link($content,&$linkarr){
			$preg = "!https?\:\/\/[a-zA-Z0-9\$\-\_\.\+\!\*\'\,\{\}\~\`\%\/\?\:\@\&\=(\&amp\;)\#\|]+!is";
			$data = preg_replace_callback(
					$preg,
					function($match) use (&$linkarr) {
						//获取短链
						$weibov4	= new weibov4();
						$ret		= $weibov4->get_short_url($match[0]);
						$ret		= json_decode($ret, true);
						$short_url	= "";
						if(!empty($ret["urls"])){
							$short_url = $ret["urls"][0]["result"] ? $ret["urls"][0]["url_short"] : "";
						}
	
						if(!empty($short_url)){
							$linkarr[] 	= '[a_'.$short_url.']';
							return '[a_'.str_replace("http://t.cn/", "", $short_url).']';
						}else{
							return "";
						}
	
					} ,
					$content
			);
	
			return $data;
		}


	// 判断远程文件是否存在
        function file_url_exists($url) {
                $ch = curl_init();
                curl_setopt($ch , CURLOPT_URL , $url);
                curl_setopt($ch , CURLOPT_NOBODY , true);
		curl_setopt($ch,  CURLOPT_NOSIGNAL, true);
                curl_setopt($ch , 156 , 2000);
                curl_setopt($ch , CURLOPT_TIMEOUT , 1);

                $res = curl_exec($ch);
                $find = false;
                if($res !== false) {
                        $status = curl_getinfo($ch);
                        if($status['http_code'] == 200) {
                                $find = true;
                        }
                }
                curl_close($ch);
                return $find;
        }

        function send_curl($url , $type='post', $post_data, &$res, $options = array()) {                          
                $curl_handle = curl_init();                                                                       
                curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);                                             
                curl_setopt($curl_handle, CURLOPT_HEADER, 0);                                                     
                curl_setopt($curl_handle, CURLOPT_TIMEOUT, 5);                                                    
                if(strtolower($type) == 'get') {                                                                  
                        curl_setopt($curl_handle, CURLOPT_URL, $url.'?'.$post_data);                              
                        curl_setopt($curl_handle, CURLOPT_HTTPGET, true);                                         
                }elseif(strtolower($type) == 'post') {                                                            
                        curl_setopt($curl_handle, CURLOPT_URL, $url);
                        curl_setopt($curl_handle, CURLOPT_POST, 1);                                               
                        curl_setopt($curl_handle, CURLOPT_POSTFIELDS, $post_data);                                
                }                                                                                                 
                if(!empty($options)){                                                                             
                        foreach($options as $k => $v){                                                            
                                curl_setopt($curl_handle, $k, $v);                                                
                        }                                                                                         
                }                                                                                                 
                $res = curl_exec($curl_handle);                                                                   
                curl_close($curl_handle);                                                                         
                return true;                                                                                      
        }

        //批量获取，并行执行 $input = array(0=>array('url'=>, 'params'=>,'method'=>),...
        function multi_curl_set($input)
        {
                if (empty($input))
                        return array();
                $out = array();
                $ch = array();
                $mh = curl_multi_init();
             	foreach ($input as $i => $in)
                {
                        $ch[$i] = curl_init();
                        // 对请求平台接口的数据增加app应用id字段
                        if(preg_match('~^'.DOMAIN.'~is' , $in['url'])) {
                                $in['params']['app'] = 1;
                                $in['params']['syncid'] = 1;
                        }
                        if (strtolower($in['method']) == 'post'){
                                curl_setopt($ch[$i], CURLOPT_URL, $in['url']);
                                curl_setopt($ch[$i], CURLOPT_POST, 1);
                                curl_setopt($ch[$i], CURLOPT_POSTFIELDS, http_build_query($in['params']));
                        }else{
                                curl_setopt($ch[$i], CURLOPT_URL, $in['url'].'?'.http_build_query($in['params']));
                        }                                                                                         
                        curl_setopt($ch[$i], CURLOPT_TIMEOUT, 2);                                                 
                        curl_setopt($ch[$i], CURLOPT_HEADER, 0);                                                  
                        curl_setopt($ch[$i], CURLOPT_RETURNTRANSFER, 1);                                          
                        curl_multi_add_handle($mh,$ch[$i]);                                                       
                }                                                                                                 
                $active = null;                                                                                   
                do {                                                                                              
                        $mrc = curl_multi_exec($mh, $active);                                                     
                } while ($mrc == CURLM_CALL_MULTI_PERFORM);         
                                                                                                                  
                while ($active && $mrc == CURLM_OK) {                                                             
                        if (curl_multi_select($mh) != -1) {                                                       
                                do {                                                                              
                                        $mrc = curl_multi_exec($mh, $active);                                     
                                } while ($mrc == CURLM_CALL_MULTI_PERFORM);                                       
                        }                                                                                         
                }                                                                                                 
                foreach ($input as $i => $in)                                                                     
                {                                                                                                 
                        $out[$i] = curl_multi_getcontent($ch[$i]);                                                
                        curl_close($ch[$i]);                                                                      
                        curl_multi_remove_handle($mh, $ch[$i]);                                                   
                }                                                                                                 
                curl_multi_close($mh);                                                                            
                return $out;                                                                                      
        }   
	//发送应用通知时
	function sub_str($s,$start,$len,$encoding='utf-8'){                                                        
        	$slen = mb_strlen($s,$encoding);                                                                   
        	if($slen > $len){                                                                                  
        	        $s = mb_substr($s,$start,$len,$encoding).'...';                                            
        	}                                                                                                  
        	return $s;                                                                                         
	}  


    
}

?>
