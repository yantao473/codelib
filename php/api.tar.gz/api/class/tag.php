<?php
/**
 * tag class 
 * by tingting18
 * 20111101
 */

class Tag {

	public $rpcdb_obj,$mysqldb_obj,$image_obj,$queue_obj,$compare_obj,$getbdb_obj,$idserver_obj,$logs_obj;
	public $dbname,$filename,$cmdid;

	function __construct() {
		$this->rpcdb_obj = new RpcDb;
		$this->mysqldb_obj = new MysqlDb;
		$this->image_obj = new images;
		$this->queue_obj = new QueueTool;
		$this->compare_obj = new Compare;
		$this->getbdb_obj = new GetBdb;
		$this->idserver_obj = new IdServer;
		$this->logs_obj = new Logs;
		$this->wbv4_obj = new weibov4;
		$this->tools_obj = new Tools;

		$this->dbname = question;
		$this->filename = DEFAULT_QUEUE_DATA_FILE;
		$this->cmdid = DEFAULT_QUEUE_ID;
	}


	/**
	 * 添加话题
	 * @param $app where is the tag come
	 * @param $tname  the tag name
	 * @param $uid who added the tag
	 * @param $desc the tag descrion
	 * @param $ctime the time of added tag
	 * @return  $tid/false the id of  added tag 
	 */
	function addtag($app,$tname,$uid,$desc,$ctime){        
		$tablename = 'tag';
		$tid = $this->idserver_obj->get($tablename);
		$row['tid'] = $tid;
		$row['name'] = $tname;
		$row['uid'] = $uid;
		$row['description'] = $desc;
		$row['showflag'] = 0;
		$row['ctime'] = $ctime;
		$row['app'] = $app;        
		$sql = $this->mysqldb_obj->prepare_insert_sql($tablename,$row);
		$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
		#echo 'insert:';var_dump($res);
		if($res){
			$row[0] = EVENT_TAG_ADD;
			$content = $row['name'];
			//$queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);
			$url = QDOMAIN."/send_queue.php";
			$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
			$log_res = $this->logs_obj->add_logs($tid, $uid,$row[0],$content,$ctime); 
			if($queue){
				return $tid;

			}else{
				return false;
			}  
		}else{
			return false;
		}   
	}

	/**
	 * 修改话题话题描述
	 * @param $tid the id of tag
	 * @param $desc the tag descrion
	 * ***for the logs     
	 * @param $uid who update the tag  
	 * @param $utime the time of added tag 
	 * @param $nodiff for desc compare  
	 * @return  true/false
	 */
	public function uptag_desc($tid,$desc,$utime,$uid,$nodiff=0,&$logids,$nolog){
		$res_old = $this->gettagid($tid, $tag_info);
		$row['description'] = $desc;
		$row['utime'] = $utime;
		$row[0] = EVENT_TAG_UPDATE;
		//$row['uid'] = $uid;
		$row['tid'] = $tid;
		$tablename = 'tag';
		//$sql = $this->mysqldb_obj->prepare_update_sql($tablename, $row);
		//$sql .= '  WHERE  tid = '.$tid; 
		//$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);        
		$res = true;
		if($res) {
			if($nodiff == 1){ // nodiff  为1表示不比较
				$con = $desc;
			}else{
				$c_res = $this->compare_obj->textdiff($desc,$tag_info['desc'],$con);
			}
			//$queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid); 
			$url = QDOMAIN."/send_queue.php";
			$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
			if(!$nolog && $desc !== $tag_info['desc']){
				$l_res = $this->logs_obj->add_logs($tid,$uid,$row[0],$con,$utime,$logids);  
			}
			if($queue){
				return true;
			}else{
				return false;
			}
		}else{
			$rs['error_num'] = 2503;
			$rs['error'] = '添加话题失败';
			echo json_encode($rs);exit;  
		}     
	}

	/**
	 * 修改话题名称 后台操作
	**/
	public function uptag_tname($tid,$tagname,$utime,$uid,$delname){
		$res_old = $this->gettagid($tid, $tag_info);
		$row['name'] = $tagname;
		//$row['utime'] = $utime;
		$row['tid'] = $tid;
		//update mysql
		$tablename = 'tag';
		$sql = $this->mysqldb_obj->prepare_update_sql($tablename, $row);
		$sql .= '  WHERE  tid = '.$tid; 
		$res = $this->rpcdb_obj->update("question", $sql, $data);        
		if(!$res) {
			return false;
		}
		$row['uid'] = $uid;
		$row[0] = EVENT_TAG_UPDATE;
		$url = QDOMAIN."/send_queue.php";
		$bdb_result = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
		//同时删除话题修改事件
		unset($row[0]);
		$row[0] = EVENT_TAG_UPDATE_NAME;
		unset($row['name']);
		$row['name'] = $delname; 
		unset($row['tid']);
		$row['tid'] = "";
		$url = QDOMAIN."/send_queue.php";
		$bdb_result = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);

			/*
			if(!$nolog && $tagname !== $tag_info['tname']){
				$l_res = $this->logs_obj->add_logs($tid,$uid,$row[0],$content,$utime,$logids);  
			}*/
		if($bdb_result){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * 修改话题图片
	 * @param $tid the id of tag
	 * @param $image the tag image
	 * ***for the logs     
	 * @param $uid who update the tag  
	 * @param $utime the time of added tag  
	 * @return  true/false
	 */
	public function uptag_image($tid,$image,$utime,$uid,&$img_logid,$nolog){
		$res_old = $this->gettagid($tid, $tag_info);

		$row['image'] = $image;
		$row['utime'] = $utime;
		$tablename = 'tag';
		$sql = $this->mysqldb_obj->prepare_update_sql($tablename, $row);
		$sql .= '  WHERE tid = '.$tid; 
		$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
		if($res){
			$row[0] = EVENT_TAG_UPDATE_LOGO;
			//$row['uid'] = $uid;
			$row['tid'] = $tid;
			// 获取新老图片url
			#if(preg_match('~^[0-9]+$~is',$tag_info['imageid'])){
			#	$oldimage = $this->image_obj->getlogo($tag_info['imageid'], "tb");	
			#}else{
				$oldimage = $this->wbv4_obj->get_image_url($tag_info['imageid'] , 'thumb50'); // old 
			#}
			$newimage = $this->wbv4_obj->get_image_url($image , 'thumb50');	// new 

			$content = $oldimage.'|'.$newimage;            
			# $queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);            
			$url = QDOMAIN."/send_queue.php";
			$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
			if(!$nolog){
				$l_res = $this->logs_obj->add_logs($tid, $uid, $row[0], $content, $utime,$img_logid);
			}
			if($queue){
				return $newimage;
			}else{
				return false;
			}
		}else{
			return false;
		}    
	}

	/**
	 * 修改话题显示状态---删除话题
	 * @param $tid the id of tag
	 * @param $showflag 显示状态， 1为显示，0为不显示，默认为1
	 * ***for the logs     
	 * @param $uid who update the tag  
	 * @param $utime the time of added tag  
	 * @return  true/false
	 */
	public function uptag_showflag($tid,$showflag,$utime,$uid,$nolog){
		$row['showflag'] = $showflag;
		$row['utime'] = $utime;
		$tablename = 'tag';
		$sql = $this->mysqldb_obj->prepare_update_sql($tablename, $row);
		$sql .= '  WHERE tid = '.$tid; 
		$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
		if($res){
			$row[0] = $showflag == 1 ? EVENT_TAG_DEL : EVENT_TAG_REST;
			if($showflag == 0) {
				$this->gettagid($tid , $tinfo);
				$row['title'] = $tinfo['tname'];
			}
			//$row['uid'] = $uid;
			$row['tid'] = $tid;
			$content = '';

			# $queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);            
			$url = QDOMAIN."/send_queue.php";
			$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
			if(!$nolog){
				$l_res = $this->logs_obj->add_logs($tid, $uid, $row[0], $content, $utime);
			}
			if($queue){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}    
	}


	/**
	 * 修改话题锁定状态---锁定话题
	 * @param $tid the id of tag
	 * @param $status  话题锁定状态， 1为锁定，0为不锁定，默认为0
	 * ***for the logs     
	 * @param $uid who update the tag  
	 * @param $utime the time of added tag  
	 * @return  true/false
	 */
	public function uptag_status($tid,$status,$utime,$uid){
		$row['status'] = $status;
		$row['utime'] = $utime;
		$tablename = 'tag';
		$sql = $this->mysqldb_obj->prepare_update_sql($tablename, $row);
		$sql .= ' WHERE tid = '.$tid; 
		$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
		if($res){
			$row[0] = EVENT_TAG_LOCK;
			//$row['uid'] = $uid;
			$row['tid'] = $tid;
			# $queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);
			$url = QDOMAIN."/send_queue.php";
			$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
			if($queue){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}    
	}



	/**
	 * 添加话题经验
	 * @param $tid the id of tag
	 * @param $uid the id of user
	 * @param $content the exprestion of the tag
	 * @param $ctime the add time 
	 * @return true/fasle
	 */
	public function addexp($tid,$uid,$content,$ctime){
		$row['tid'] = $tid;
		$row['uid'] = $uid;
		$row['content'] = $content;
		$row['ctime'] = $ctime;        
		$tablename = 'tagexp';
		$sql = $this->mysqldb_obj->prepare_insert_sql($tablename, $row);
		$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
		if($res){
			$row[0] = EVENT_TAG_EXP_UPDATE;
			/************added  by 20111124**************/
			$res_old = $this->gettagid($tid, $tag_info);
			$row['tname'] = $tag_info['tname'];
			# $queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);
			$url = QDOMAIN."/send_queue.php";
			$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
			return $queue;
		}else{
			return false;
		}
	}

	/**
	 * 修改话题经验
	 * @param $tid
	 * @param $uid
	 * @param $content
	 * @param $utime
	 * @return true/fasle
	 */
	public function upexp($tid,$uid,$content,$utime){
		$tablename = 'tagexp';
		$row['content'] = $content;
		$row['ctime'] = $utime;
		$sql = $this->mysqldb_obj->prepare_update_sql($tablename, $row);
		$sql .= ' WHERE tid ='.$tid.' AND uid = '.$uid;
		$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
		if($res){
			$row[0] = EVENT_TAG_EXP_UPDATE;
			$row['tid'] = $tid;
			$row['uid'] = $uid;
			/************added  by 20111124**************/
			$res_old = $this->gettagid($tid, $tag_info);
			$row['tname'] = $tag_info['tname'];
			# $queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);
			$url = QDOMAIN."/send_queue.php";
			$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
			return $queue;
		}else{
			return false;
		}        
	}  

	/**
	 * 删除话题经验(删除mysql中content为''的字段，为了和bdb保持一致)
	 * $tid
	 * $uid
	 * $content
	 */ 
	public function delexp($tid,$uid,$content,$utime){
		if($content == ''){
			$sql = 'DELETE  FROM tagexp WHERE tid = '.$tid.'  AND uid = '.$uid;
			$res = $this->rpcdb_obj->update($this->dbname, $sql, $data);
			if($res){
				$row[0] = EVENT_TAG_EXP_UPDATE;
				$row['tid'] = $tid;
				$row['uid'] = $uid;
				$row['content'] = $content;
				$row['ctime'] = $utime;
				# $queue = $this->queue_obj->AddToLocalQueue($this->filename, $row,$this->cmdid);
				$url = QDOMAIN."/send_queue.php";
				$queue = $this->tools_obj->curl_set($url , 'POST' , array('data' => serialize($row)) , $queue);
				return $queue;
			}else{
				return false;
			}             
		}else{
			$this->upexp($tid, $uid, $content, $utime);
		}
	}

	/**
	 *获取数据库中是否有对应的话题经验
	 * $tid
	 * $uid
	 */
	public function getexpdb($uid,$tid){
		$sql = 'SELECT * FROM tagexp WHERE tid = '.$tid.' AND uid = '.$uid;
		$res = $this->rpcdb_obj->read($this->dbname,$sql,$data);
		if(!empty($data) && !isset($data['error'])){
			$ishave = 1;
		}else{
			$ishave = 0;
		}
		return $ishave;
	}

	/**
	 * 获取话题id(知道话题名称)
	 * @param $tname the name of tag
	 * @return $tid 
	 */
	public function gettag($tname,&$tid){
		$res = $this->getbdb_obj->gets("tag",$tname,$tid);
		return $res;        
	}

	/**
	 * 获取话题信息(以话题id)
	 * @param $tid  按话题id
	 * @return true/fasle
	 */
	public function gettagid($tid,&$tag_info){

		$res = $this->getbdb_obj->gets("tagid",$tid,$data);
		if($res && !empty($data)){
			$tag_info['tid'] = $tid;
			$tag_info['tname'] = $data['name'];  //注意id
			$tag_info['uid'] = $data['uid'];
			$tag_info['desc'] = isset($data['description'])?$data['description']:'';
			$tag_info['ctime'] = $data['ctime'];
			$tag_info['imageid'] = isset($data['image'])?$data['image']:0;        
			#$tag_info['image'] = $this->image_obj->getlogo($tag_info['imageid'], "tc");
			#$tag_info['image_b'] = $this->image_obj->getlogo($tag_info['imageid'], "tb");
			#$tag_info['image_a'] = $this->image_obj->getlogo($tag_info['imageid'], "ta");            
$tag_info['image'] = ($tag_info['imageid']!==0) ? $this->wbv4_obj->get_image_url($tag_info['imageid'] , 'thumb50') : DEFAULT_TAG_LOGO; // new 
$tag_info['image_a'] = ($tag_info['imageid']!==0) ? $this->wbv4_obj->get_image_url($tag_info['imageid'] , 'thumb50') : DEFAULT_TAG_LOGO; // new 
$tag_info['image_b'] = ($tag_info['imageid']!==0) ? $this->wbv4_obj->get_image_url($tag_info['imageid'] , 'thumb120') : DEFAULT_TAG_LOGO; // new 
			
			$tag_info['showflag'] = isset($data['showflag'])?$data['showflag']:1; //默认显示
			$tag_info['status'] = isset($data['status'])?$data['status']:0; //默认不锁定
			$tag_info['app'] = isset($data['app'])?$data['app']:1;    
			$tag_info['utime'] = isset($data['utime'])&&!empty($data['utime'])?$data['utime']:'0000-00-00 00:00:00'; 
			return true;
		}else if($res && empty($data)){
			$tag_info = $data;
		}else{
			$rs['error_num'] = 2502;
			$rs['error'] = '获取话题信息失败';
			echo json_encode($rs);exit;                  
			//$this->error_num(2502);
		}        
	}

	/**
	 * 批量获取话题信息(以话题id) 不包括话题图片
	 * @param $tid  按话题id
	 */
	public function get_batch_tagid($tid_arr,&$tag_info){
		$res = $this->getbdb_obj->gets("tagid",$tid_arr,$data);
		if($res && !empty($data)){
			$tag_info = $data;
			return true;
		}else{
			$tag_info = array();
			return true;
		}        
	}

	/**
	 * 获取话题经验（跟获取用户信息合并）
	 * @param $uid
	 * @param $tid 取某一话题对应的exp当tid为0时取用户对应的话题列表
	 * @param $start  开始
	 * @param $num    跨度
	 * @param $data exp of somebody tag
	 * @return true/fasle
	 */
	public function getexp($uid,$tid=0,$start=0,$num=20,&$taginfo){
		if(empty($tid)){//$tid 不存在调用bdblist接口
			$res = $this->getbdb_obj->lists("ut", $uid,$start,$num,$data);
			if(!empty($data) && is_array($data)){
				foreach($data as $k => $v){
					if(is_numeric($k)){
						$tid = $v['keys'][2];
						$taginfo['exp']["$tid"]['exp'] = $v["data"]['content']; 
						$taginfo['exp']["$tid"]['tname'] = $v["data"]['tname']; 
					}else{
						$taginfo["$k"] = $v;                    
					}
				}//foreach end
			}else{
				$taginfo = '';
			}
		}else{//tid存在取调用getlistkey的false接口
			$res = $this->getbdb_obj->getlistkey("ut", $uid, $tid, $data,false);
			$taginfo["$tid"]['exp'] = $data['content'];
			$taginfo["$tid"]['tname'] = $data['tname'];
		}
		return $res;        
	}


	/**
	 * 获取话题日志
	 * @param $tid 话题id
	 * @param $start 开始位置
	 * @param $num 跨度
	 * @return $logs 
	 */
	public function gettaglog($tid,$start,$num){
		$res = $this->getbdb_obj->lists("te",$tid,$start,$num,$data);
		return $data;
	}


	/**
	 * 获取话题列表全部问题或者已采纳问题
	 * @param $type (tk  话题下已解决问题,tq  话题下所有问题)
	 * @param $tid 话题id
	 * @param $start 开始位置
	 * @param $num 跨度
	 * @return $list 问题列表
	 */
	public function gettaglist($type,$tid,$start=0,$num=20){
		$list = $this->getbdb_obj->lists($type, $tid, $start, $num, $data);
		return $data;
	}

	/**
	 * 获取话题列表已采纳问题(已解决问题)
	 * @param $tid 话题id
	 * @param $status 状态
	 * @param $start 开始位置
	 * @param $num 跨度
	 * @return $list  返回已采纳问题列表
	 */
	public function gettaglist_adoption($tid,$start=0,$num=20){
		$list = $this->getbdb_obj->lists("tk", $tid, $start, $num, $data);
		return $data;

	}



	/**
	 * 为了区分bdb信息，需要给用过的time加n秒（默认n=1）
	 * @param $ltime 默认$data = date("Y-m-d H:i:s");
	 * @param $n 默认n=1
	 * @return $newtime 加n秒后的时间
	 */
	function log_addns($ltime,$n=1){
		$time = explode(" ",$ltime);
		$ymd = explode("-",$time[0]);
		$his = explode(":",$time[1]);
		$miao = mktime($his[0],$his[1],$his[2],$ymd[1],$ymd[2],$ymd[0]);
		$newtime = $n+$miao;
		$newdata = date("Y-m-d H:i:s",$newtime);
		return $newdata;
	}




}

?>
