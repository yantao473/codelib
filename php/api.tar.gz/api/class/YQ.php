<?php                                                
require_once 'upbdb.php';                            
require_once 'bdbdb.php';
require_once 'bdbclient.php';
require_once  'apiconf.php';
                                                
$u = new UpBdb();   

$tarray = unserialize('a:8:{s:4:"type";s:1:"t";s:5:"ltype";s:3:"key";s:3:"app";s:4:"keyv";s:5:"table";s:2:"kv";s:4:"flag";s:3:"int";s:4:"lkey";a:2:{i:0;a:2:{i:0;i:4;i:1;s:3:"int";}i:1;a:2:{i:0;s:0:"";i:1;s:4:"char";}}s:1:"t";s:10:"keyvisitor";s:1:"v";a:3:{i:0;i:8;i:1;i:4;i:2;i:4;}}');
$keys   = unserialize('a:2:{i:0;i:6;i:1;s:11:"1_11111111_";}');
$info   = unserialize('a:3:{i:0;s:4:"4141";i:1;s:3:"214";i:2;s:5:"81234";}');

$r = $u->updata($tarray['t'], $keys, $info);

var_dump($r);
