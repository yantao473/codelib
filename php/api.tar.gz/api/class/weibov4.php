<?php
//获取weibo信息接口 v4版

class weibov4
{
	private $ch;
	
	function __construct()
	{
	}

	function __destruct()
	{
		if ($this->ch)
			curl_close($this->ch);
	}
	
	//请求
	function get($url, $params=array(), $method='GET')
	{
		$params['source'] = WEIBO_APP_KEY;
		if (!$this->ch)
			$this->ch = curl_init();
		if ($method == 'POST'){
			curl_setopt($this->ch, CURLOPT_URL, WEIBO_DOMAIN.$url);
			curl_setopt($this->ch, CURLOPT_POST, 1);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($params));
			if (empty($_COOKIE['SUE'])){
				if(!isset($params["access_token"])||empty($params["access_token"])){
					return '';
				}	
			}else{
				curl_setopt($this->ch, CURLOPT_COOKIE, 'SUE='.urlencode($_COOKIE['SUE']).'; SUP='.urlencode($_COOKIE['SUP']));
			}
		}else{
			curl_setopt($this->ch, CURLOPT_URL, WEIBO_DOMAIN.$url.'?'.http_build_query($params));
			curl_setopt($this->ch, CURLOPT_USERPWD, WEIBO_USER_PASSWD);
		}
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 2);
		curl_setopt($this->ch, CURLOPT_HEADER, 0);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		$h = curl_exec($this->ch);
		curl_close($this->ch);
		unset($this->ch);
		return $h;
	}

        function curl_get($url, $params=array(), $method='GET')                                            
        {                                                                                                  
                $params['source'] = WEIBO_APP_KEY;                                                         
                if (!$this->ch)                                                                            
                        $this->ch = curl_init();                                                           
     		curl_setopt($this->ch, CURLOPT_COOKIE, 'SUE='.urlencode($_COOKIE['SUE']).'; SUP='.urlencode($_COOKIE['SUP']));
                curl_setopt($this->ch, CURLOPT_URL, WEIBO_DOMAIN.$url.'?'.http_build_query($params));      
                curl_setopt($this->ch, CURLOPT_TIMEOUT, 2);                                                
                curl_setopt($this->ch, CURLOPT_HEADER, 0);                                                 
                curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);                                         
                $h = curl_exec($this->ch);
                curl_close($this->ch);                                                                     
                unset($this->ch);                                                                          
                return $h;                                                                                 
        }

	function post($url , $params=array(), $method='POST') {
		$params['source'] = WEIBO_APP_KEY;
		if (!$this->ch)
                        $this->ch = curl_init();
		if ($method == 'POST') {
                        curl_setopt($this->ch, CURLOPT_URL, WEIBO_DOMAIN.$url);
                        curl_setopt($this->ch, CURLOPT_POST, 1);
                        curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($params));
			curl_setopt($this->ch, CURLOPT_USERPWD, WEIBO_USER_PASSWD);
                }
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 2);
                curl_setopt($this->ch, CURLOPT_HEADER, 0);
                curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
                $h = curl_exec($this->ch);
                curl_close($this->ch);
                unset($this->ch);
                return $h;
	}
	
	//获取用户信息，可以是id或者昵称
	function showuser($uid)
	{
		$params = array();
		if (is_numeric($uid))
			$params['uid'] = $uid;
		else
			$params['screen_name'] = $uid; 
		return self::get('/2/users/show.json', $params);
	}
	
	//批量获取用户信息，必须是数组形式 
	function showusers($uids)
	{
		if (!is_array($uids))
			return '';
		$params = array();
		if (is_numeric($uids[0]))
			$params['uids'] = implode(',', $uids);
		else
			$params['screen_name'] = implode(',', $uids);
		return self::get('/2/users/show_batch.json', $params);
	}
	
	//获取关注列表
	function showfriend($uid, $count=20)
	{
		$params = array();
		$params['count'] = $count;
		if (is_numeric($uid))
			$params['uid'] = $uid;
		else
			$params['screen_name'] = $uid; 
		return self::get('/2/friendships/friends.json', $params);
	}
	//获取粉丝列表详细
	function showfollow($uid, $count=20)
	{
		$params = array();
		$params['count'] = $count;
		if (is_numeric($uid))
			$params['uid'] = $uid;
		else
			$params['screen_name'] = $uid; 
		return self::get('/2/friendships/followers.json', $params);
	}
	
	//获取粉丝uids
	function showfollowid($uid, $count=20)
	{
		$params = array();
		$params['count'] = $count;
		if (is_numeric($uid))
			$params['uid'] = $uid;
		else
			$params['screen_name'] = $uid; 
		return self::get('/2/friendships/followers/ids.json', $params);
	}
	//检查$fromuid 与数组$uids的关注关系
	function showfriendships($fromuid, $uids)
	{
		if (!is_array($uids))
			return '';
		$params = array();
		$params['uids'] = implode(',', $uids);
		$params['uid'] = $fromuid;
		return self::get('/2/friendships/exists_batch_internal.json', $params);
	}
	//检查两个用户之间的关注关系
	function showfriendship($uid, $touid)
	{
//var_dump($uid);
//var_dump($touid);
		$params = array();
		if (is_numeric($uid))
			$params['source_id'] = $uid;
		else
			$params['source_screen_name'] = $uid; 
		if (is_numeric($touid))
			$params['target_id'] = $touid;
		else
			$params['target_screen_name'] = $touid; 
		return self::get('/2/friendships/show.json', $params);
	}
	//添加关注
	function upfriendship($uid)
	{
		$params = array();
		if (is_numeric($uid))
			$params['uid'] = $uid;
		else
			$params['screen_name'] = $uid; 
		return self::get('/2/friendships/create.json', $params, 'POST');
	}
	//取消关注
	function delfriendship($uid)
	{
		$params = array();
		if (is_numeric($uid))
			$params['uid'] = $uid;
		else
			$params['screen_name'] = $uid; 
		return self::get('/2/friendships/destroy.json', $params, 'POST');
	}
	//发布一条微博
	function update($content)
	{
		$params = array();
		$params['status'] = $content;
		return self::get('/2/statuses/update.json', $params, 'POST');
	}
        //发布一条微博 并 发图片
        function update_text_img($content,$imgurl,$token="")
        {
                $params = array();
                $params['status'] = $content;
                $params['url'] = $imgurl;
                if(!empty($token)){
                	 $params['access_token'] = $token;
                }
                return self::get('/2/statuses/upload_url_text.json', $params, 'POST');
        }
	//发私信，微博暂未开通 
	function sendmessage($uid, $content)
	{
		$params = array();
		$params['text'] = $content;
		if (is_numeric($uid))
			$params['uid'] = $uid;
		else
			$params['screen_name'] = $uid; 
		return self::get('/2/direct_messages/new.json', $params, 'POST');
	}

	// 获取动态平台图片地址
	function get_image_url($pid, $type)
	{
		if ($pid[9] == 'w') return self::_weibo_image_url($pid, $type);
			return self::_generic_image_url($pid, $type);
	}
			  
	function _generic_image_url($pid, $type)
	{
		$zone = (hexdec(substr($pid, -2)) % 16)+1;
		return "http://ss{$zone}.sinaimg.cn/{$type}/{$pid}&690";
	}
						  
	function _weibo_image_url($pid, $type)
	{
		$hv = crc32($pid);
	    $zone = ($hv & 3) + 1;
	    $ext = ($pid[21] == 'g' ? 'gif' : 'jpg');
	    return "http://ww{$zone}.sinaimg.cn/{$type}/{$pid}.{$ext}";
	}
        function get_short_url($long_url){
                $params = array();
                $params['url_long'] = $long_url;
                $res = self::curl_get('/2/short_url/shorten.json',$params,"GET");
                return $res;
        }

}

?>
