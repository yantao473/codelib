<?php
/*
 * 功能: 生成FEED图片 
 * @date 2012/11/20
 * @author guoxianghui
 */
class createfeedpic {
	public $tools_obj;

	function __construct(){
		$this->_init_params();
		$this->_init_class();
	}
	
	function _init_params(){
		$this->url = QDOMAIN . '/mshare.php';
	}

	function _init_class(){
		$this->tools_obj = new Tools();
	}

	function run(){
		$result = false;
		if($row[0] ==  EVENT_QUESTION_UPDATE || $row[0] == EVENT_QUESTION_TITLE_UPDATE ||$row[0] == EVENT_QUESTION_DESC_UPDATE ||$row[0] ==  EVENT_QUESTION_TAG_DEL ||$row[0] == EVENT_QUESTION_TAG_ADD ){
			//创建FEED图片
			$result = $this->create_pic( $row['questionid'] );
			if(!$result){
				//当第一次创建失败后，再执行一次
				$result = $this->create_pic( $row['questionid'] );
			}
		}
		return $result;
	}
	function create_pic($qid){
                $post_data = array(
                        'qid'   => $qid,
                        'create_pic_only' => 1,
                );
		echo "post data \n" ;
		var_dump($post_data);
		$flag = $this->tools_obj->send_curl($this->url , 'post' , $post_data , $result);
		return $flag;
	}

}
?>
