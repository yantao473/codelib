<?php
/*
 * Copyright (c) 2002, 新浪网研发中心
 * All rights reserved
 *
 * 文件名称：xmlRpcClient.php
 * 文件标示：
 * 摘    要：
 *              xmlRPC的php client接口
 * 作    者：张矗
 * 创建日期：2004-11-26
 */

class XmlRpcParser
{
	function unescape(&$value)
	{
		$findstr=array("&lt;","&gt;","&amp;");//);,"&quot;"
		$replacestr=array("<",">","&");//);,"\""
		$value = str_replace($findstr, $replacestr, $value);
		//$value = str_replace("&lt;", "<", $value);
		//$value = str_replace("&gt;", ">", $value);
		//$value = str_replace("&quot;", "\"", $value);
		//$value = str_replace("&amp;", "&", $value);
	}
	
	function escape($value)
	{
		return str_replace("&", "&amp;", $value);
	}
	
	function parse($xml, &$data)
	{
		$data = array();
		
		$xmllen = strlen($xml);
		
		$step = 0;
		$name = "";
		$value = "";
		$endname = "";
		$istart = 0;
		$i=0;
		while(1)
		{
			$i=strpos($xml,"<",$i);
			if ($i===FALSE)
				break;
			$istart=++$i;

			$i=strpos($xml,">",$i);
			if ($i===FALSE)
				break;
			$name=substr( $xml, $istart, $i-$istart);
			$istart=++$i;

			$i=strpos($xml,"<",$i);
			if ($i===FALSE)
				break;
			$value = substr( $xml, $istart, $i-$istart);
			$istart=++$i;
		
			$i=strpos($xml,">",$i);
			if ($i===FALSE)
				break;
			$endname=substr( $xml, $istart, $i-$istart);
			if ("/".$name != $endname)
				break;
			xmlRpcParser::unescape($value);
			$data[$name] = $value;
		}
		return true;
	}
}

class XmlRpcClient
{
	var $xmlSend;
	
	var $data;

	var $server;
	var $port;
	var $timeout;
	
	function __construct($server, $port, $timeout)
	{
		$this->server = $server;
		$this->port = $port;
		$this->timeout = $timeout;
	}
	
	function setServer($server)
	{
		$this->server = $server;
	}
	
	function setPort($port)
	{
		$this->port = $port;
	}
	
	function setTimeout($timeout)
	{
		$this->timeout = $timeout;
	}
	
	function setFunction($name)
	{
		$this->xmlSend = $this->xmlSend."<func>".$name."</func>";
	}
	
	function setPara($name, $value)
	{
		$this->xmlSend = $this->xmlSend."<".$name.">".XmlRpcParser::escape($value)."</".$name.">";
	}
	
	function getResult($name)
	{
		if (!array_key_exists($name, $this->data))
		{
			return "";
		}
		return $this->data[$name];
	}
	
	function getResult2($name, $index)
	{
		return $this->getResult($name.$index);
	}

	function getmicrotime()
	{
		list($usec, $sec) = explode(" ",microtime()); 
		return ((float)$usec + (float)$sec); 
	} 
	
	function writeerror($error)
	{
		$handle = fopen("/tmp/xmlRpcClientError.log", "a");
		if ($handle)
		{
			fwrite($handle, date('Y-m-d H:i:s')." ".
				$this->server." ".
				$this->port." ".
				$this->timeout." ".
				$error."\n");
			fclose($handle);
		}
	}

	function callRemote()
	{
		$start_time = $this->getmicrotime();
		
		$xml = "";
		$fp = fsockopen($this->server, $this->port, &$errno, &$errstr, $this->timeout);
		if (!$fp)
		{
			for ($i=0; $i<2; $i++)
			{
				usleep(100000);
				$fp = fsockopen($this->server, $this->port, &$errno, &$errstr, $this->timeout);
				if ($fp)
				{
					break;
				}
			}
			if (!$fp)
			{
				$this->writeerror("连接失败");
				return -2;
			}
		}
		fputs($fp, $this->xmlSend."<end></end>");
		while (!feof($fp))
		{
			$ret = fgets($fp,1024);
			if (!$ret)
			{
				fclose($fp);
				$this->writeerror("获取数据失败 ".$this->xmlSend);
				return -2;
			}
			# added by lubing, 2007.2.7
                        if ($ret == "<0/>\n")
                        {
                                # end of response encountered
                                break;
                        }
                        # end
			$xml = $xml.$ret;
		}
		fclose($fp);
		
		if (!xmlRpcParser::parse($xml, $this->data))
		{
			$this->writeerror("xmlRpcParser::parse函数失败 ".$xml);
			return -2;
		}
		
		//$end_time = $this->getmicrotime();
		//$handle = fopen("/tmp/xmlRpcClientTime.log", "a");
		//if ($handle)
		//{
		//	fwrite($handle, ($end_time - $start_time)." ".$this->xmlSend."\n");
		//	fclose($handle);
		//}
		
		return 1;
	}
	
	function clearBuf()
	{
		$this->xmlSend = "";
		$this->data = array();
	}
}

?>