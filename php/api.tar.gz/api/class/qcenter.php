<?php
/*
* 数据中心其他工作队列
* 包含:
* 1、调用站内消息
* 2、调用搜索
* 3、调用微博搜索
* 4、调用事件历史记录库
* 5、调用发送站外通知
* 6、调用发送站外勋章
* 7、调用发送数据到回答排行
*/

class qcenter {

	function __construct()
	{
		$this->msgevent_obj = new msgevent;
		$this->searchevent_obj = new searchevent;
		$this->weiboevent_obj = new weiboevent;
		$this->adminevent_obj = new adminevent;
		$this->sortanswer_obj = new sortAnswer;
		$this->createfeedpic_obj = new createfeedpic;
		$this->applyexpert_obj = new applyexpert;
		$this->tools_obj = new Tools;
	}

	function run($row)
	{
		if (!isset($row[0]))
			return false;

		echo "-----------------------------".date('Y-m-d H:i:s')."----------------------------------\n";
		
		print_r($row);
		
		// 记录总时间
		list($usec, $sec) = explode(" ", microtime());
                $this->time_start = ((float)$usec + (float)$sec);

		// 调用消息
		$this->tools_obj->microtime_float_start();
		$ret = $this->msgevent_obj->run($row);
		echo 'message back : '; var_dump($ret);
		$time = $this->tools_obj->microtime_float_end();
		if($time > 0.5) {
			$overtime = '超时!';
		}
		else {
			$overtime = '';
		}
		echo "------------------------- msgevent 耗时 : {$time} -----------{$overtime}------------ \n";

		// 调用搜索
		$this->tools_obj->microtime_float_start();
		$ret = $this->searchevent_obj->run($row);
		echo 'search back : ';  var_dump($ret);
		$time = $this->tools_obj->microtime_float_end();
		if($time > 0.5) {
			$overtime = '超时!';
		}
		else {
			$overtime = '';
		}
		
		echo "------------------------- searchevent 耗时 : {$time} ------------{$overtime}----------- \n";

		// 调用微博搜索
		$this->tools_obj->microtime_float_start();
		$ret = $this->weiboevent_obj->run($row);	
		echo 'weibo search back : ';  var_dump($ret);
		$time = $this->tools_obj->microtime_float_end();
		if($time > 0.5) {
			$overtime = '超时!';
		}
		else {
			$overtime = '';
		}
		echo "------------------------- weiboevent 耗时 : {$time} ------------{$overtime}----------- \n";
		
		// 事件入库 供后台进行事件查询
		$this->tools_obj->microtime_float_start();
		$ret = $this->adminevent_obj->run($row);
		echo 'admin search event back : '; var_dump($ret);
		$time = $this->tools_obj->microtime_float_end();
		if($time > 0.5) {
			$overtime = '超时!';
		}
		else {
			$overtime = '';
		}
		echo "------------------------- adminevent 耗时 : {$time} ------------{$overtime}----------- \n";
		
		// 答案排序
		$this->tools_obj->microtime_float_start();
		$ret = $this->sortanswer_obj->run($row);
		echo 'question answer sort back : '; var_dump($ret);
		$time = $this->tools_obj->microtime_float_end();
		if($time > 0.5) {
			$overtime = '超时!';
		}
		else {
			$overtime = '';
		}
		echo "------------------------- sortanswer 耗时 : {$time} ------------{$overtime}----------- \n";

		// 生成FEED图片
		$this->tools_obj->microtime_float_start();
		$ret = $this->createfeedpic_obj->run($row);
		echo 'feedpic back : '; var_dump($ret);
		$time = $this->tools_obj->microtime_float_end();
		if($time > 0.5) {
			$overtime = '超时!';
		}
		else {
			$overtime = '';
		}
		echo "------------------------- createfeedpic 耗时 : {$time} ------------{$overtime}----------- \n";
		
		//申请专家入库
		$this->tools_obj->microtime_float_start();
		$ret = $this->applyexpert_obj->run($row);
		echo 'applyexpert back : '; var_dump($ret);
		$time = $this->tools_obj->microtime_float_end();
		if($time > 0.5) {
			$overtime = '超时!';
		}
		else {
			$overtime = '';
		}
		echo "------------------------- applyexpert 耗时 : {$time} ------------{$overtime}----------- \n";

		// 记录总时间
		
                list($usec, $sec) = explode(" ", microtime());
                $this->time_end = ((float)$usec + (float)$sec);

                $total_time = ($this->time_end - $this->time_start);
		if($total_time > 0.5) {
                        $overtime = '超时!';
                }
                else {
                        $overtime = '';
                }
		echo "------------------------- 总耗时 : {$total_time} ------------{$overtime}----------- \n";
		
		return true;
	}
}
?>
