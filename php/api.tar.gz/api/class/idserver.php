<?php
//获取自增长id

class IdServer{
	static $timeout;
	function __construct()
	{
		self::$timeout = 1;
	}
	//appid 应用，需要保证唯一性，appid 最大有效长度20字节;返回 0 失败
	function get($appid)
	{
		$server = ID_SERVER_CLIENT_CGI.'?q='.strtolower($appid);
		$ret = @file_get_contents($server, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		if (empty($ret))
			return 0;
		return $ret;
	}
	//生成中心数据， step 步长；start 开始值
	function createserver($appid, $step=10000, $start=1)
	{
		$server = ID_SERVER_CENTER_CGI.'?up=1&server=1&q='.strtolower($appid).'&per='.intval($step).'&start='.floatval($start);
		$ret = @file_get_contents($server, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		if (empty($ret))
			return 0;
		return $ret;
	}
	//从中心取数据，生成分中心
	function createclient($appid)
	{
		$server = ID_SERVER_CLIENT_CGI.'?up=1&q='.strtolower($appid);
		$ret = @file_get_contents($server, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		if (empty($ret))
			return 0;
		return $ret;
	}
	//检查分中心数据的正确性 0 错误
	function checkclient($appid)
	{
		$server = ID_SERVER_CLIENT_CGI.'?check=1&q='.strtolower($appid);
		$ret = @file_get_contents($server, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		if (empty($ret))
			return 0;
		return $ret;
	}
}

?>