<?php
class feedincluded
{
	public static function toInclude()
	{
		$rootpath = dirname(dirname(__FILE__));
		define('FEED_VERSION', '1.6');
		define('FEED_CONF_ROOT', $rootpath.'/');
		define('FEED_LIB_ROOT', FEED_CONF_ROOT.'/class/feed_v'.FEED_VERSION.'/');
		require FEED_CONF_ROOT.'/conf/feed/feed.conf.php';
		require FEED_LIB_ROOT.'/other/factory/ModelFactory.php';
		require FEED_LIB_ROOT.'/other/model/model.php';
		require FEED_LIB_ROOT.'/other/mydb/mydb.php';
		require FEED_LIB_ROOT.'/other/myhash/myhash.php';
		require FEED_LIB_ROOT.'/other/mycurl/mycurl.php';
	}
}
