<?php
// 同步微博搜索功能
// 底层的数据处理 与先发后审 先审后发无关 
// 无法区分来源项目 一并交给微博搜索
// Author : zhanghua2@staff.sina.com.cn 
// Date : 2012-02-02 20:51:00

class weiboevent {

	private static $memq_url = 'commtc.mq.weibo.com';
	private static $memq_port = 7518;
	private static $memq_name = 'search_ask';

	public static function run(&$args)
	{
		$flag = false;
		$tools = new Tools();
		switch($args[0])
		{
			case EVENT_QUESTION_ADD:	//新加问题 通过了关键词审核
				// 问题添加搜索
				$search_data = array(
					'DF'	=> 'A',
					'id'	=> $args['questionid'],
					'title'	=> $args['title'],
					'tag'	=> @implode(' ' , $args['tags']),
					'num1'	=> 0,
					'num2'	=> 0,
					'ctime'	=> strtotime($args['ctime']),
					'ntime'	=> strtotime($args['ctime']),
					'source_id'	=> '1',
					'pushtime'	=> time(),
					'uid'	=> $args['uid'],
					'desc'	=> $tools->mb_substring($args['description'] , 0, 100),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				// 发布的问题会自动归属在话题之下 如果话题已存在则问题属于话题下问题列表之一
				// 获取话题下问题列表数 更新搜索
				// 话题不会自动关注 所以话题关注数不会有变化
				// 话题也有可能不存在 虽然观察数据发现添加话题在添加问题之前 但不保证不会变动
				// 所以先检查话题是否存在 如果不存在 先往搜索添加话题
				// 此处添加话题 跟添加话题事件里添加话题效果一样 搜索会排重保留最后一次更新的
				if(!empty($args['tags'])) {
					foreach($args['tags'] as $tid => $tname) {
						// 获取话题信息 判断话题是否存在
						$api = DOMAIN . '/t/gettag.php';
						$post_data = array(
							'tid' => $tid,
							'app' => $args['app'],
						);
						$tools->curl_set($api , 'post' ,  $post_data , $json_tag);
						$tag = json_decode($json_tag , true);
						// tag 为空
						if(empty($tag))	{
							$search_data = array(
								'DF'	=> 'A',
								'id'	=> $tid,
								'title'	=> $tname,
								'desc'	=> '',
								'tag'	=> '',
								'num1'	=> 0,
								'num2'	=> 1,	// 话题的添加伴随问题添加 初始就应该是1
								'ctime'	=> strtotime($args['ctime']),
								'ntime'	=> strtotime($args['ctime']),
								'source_id'	=> '2',
								'pushtime'	=> time(),
								'uid'	=> $args['uid'],

							);
							// 同步搜索 start
							$flag = self::send_memq($search_data);
						}
						else {
							// 取话题下的问题数
							$api = DOMAIN . '/t/gettaglist.php';
							$post_data = array(
									'tid' => $tid,
									'type' => 'tq',
									'flag' => 0,
									'app' => $args['app'],
							);
							$tools->curl_set($api , 'post' ,  $post_data , $json_t_list);	
							$t_list = json_decode($json_t_list , true);
							$search_data = array(
								'DF'	=> 'M',
								'id'	=> $tid,
								'num2'	=> $t_list['total'],
								'source_id'	=> 2,
								'pushtime'	=> time(),
							);
							// 同步搜索 start
							$flag = self::send_memq($search_data);
						}
					}
				}
				break;
			case EVENT_QUESTION_DEL:	// 用户不能在前台删除问题 所以删除就是从后台删除的事后问题
							// 删除问题时 要更新问题下所有话题的num2字段
				if($args['showflag'] != 1) {
					break;
				}
				$search_data = array(
					'DF'	=>	'D',
					'id'	=>	$args['questionid'],
					'source_id'	=> 1,
					'pushtime'	=> time(),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				// 查问题下的所有话题
				$api = DOMAIN . '/q/getquestion.php';
				$post_data = array('questionid' => $args['questionid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				if(empty($q_detail) || !empty($q_detail['error_num'])) {
					break;
				}
				if(!empty($q_detail['tags'])) {
					foreach($q_detail['tags'] as $tid => $tname) {
						// 取话题下的问题数
						$api = DOMAIN . '/t/gettaglist.php';
						$post_data = array(
								'tid' => $tid,
								'type' => 'tq',
								'flag' => 0,
								'app' => $args['app'],
						);
						$tools->curl_set($api , 'post' ,  $post_data , $json_t_list);	
						$t_list = json_decode($json_t_list , true);
						$search_data = array(
							'DF'	=> 'M',
							'id'	=> $tid,
							'num2'	=> $t_list['total'],
							'source_id'	=> 2,
							'pushtime'	=> time(),
						);
						// 同步搜索 start
						$flag = self::send_memq($search_data);
					}
				}
				break;
			case EVENT_QUESTION_UPDATE:	// eid 3 实际没有操作调用此事件
				$api = DOMAIN . '/q/getquestion.php';
				$post_data = array('questionid' => $args['questionid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				// 更新问题也涉及话题的删除 所以要将原
				$search_data = array(
					'DF'	=> 'U',
					'id'	=> $args['questionid'],
					'title'	=> $args['title'],
					'tag'	=> @implode(' ' , $args['tags']),
					'num1'	=> 0,
					'num2'	=> 0,
					'ctime'	=> strtotime($args['ctime']),
					'ntime'	=> strtotime($args['ctime']),
					'source_id'	=> '1',
					'pushtime'	=> time(),
					//'uid'	=> $args['uid'],
					'uid'	=> $q_detail['uid'],
					'desc'	=> $tools->mb_substring($args['description'] , 0, 100),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				if(!empty($args['tags'])) {
					foreach($args['tags'] as $tid => $tname) {
						// 获取话题信息 判断话题是否存在
						$api = DOMAIN . '/t/gettag.php';
						$post_data = array(
							'tid' => $tid,
							'app' => $args['app'],
						);
						$tools->curl_set($api , 'post' ,  $post_data , $json_tag);
						$tag = json_decode($json_tag , true);
						// tag 为空
						if(empty($tag))	{
							$search_data = array(
								'DF'	=> 'A',
								'id'	=> $tid,
								'title'	=> $tname,
								'desc'	=> '',
								'tag'	=> '',
								'num1'	=> 0,
								'num2'	=> 1,
								'ctime'	=> strtotime($args['ctime']),
								'ntime'	=> strtotime($args['ctime']),
								'source_id'	=> '2',
								'pushtime'	=> time(),
								'uid'	=> $args['uid'],
							);
							// 同步搜索 start
							$flag = self::send_memq($search_data);
						}
						else {
							// 取话题下的问题数
							$api = DOMAIN . '/t/gettaglist.php';
							$post_data = array(
									'tid' => $tid,
									'type' => 'tq',
									'flag' => 0,
									'app' => $args['app'],
							);
							$tools->curl_set($api , 'post' ,  $post_data , $json_t_list);	
							$t_list = json_decode($json_t_list , true);
								$search_data = array(
								'DF'	=> 'M',
								'id'	=> $tid,
								'num2'	=> $t_list['total'],
								'source_id'	=> 2,
								'pushtime'	=> time(),
							);
							// 同步搜索 start
							$flag = self::send_memq($search_data);
						}
					}
				}
				break;
			case EVENT_QUESTION_TITLE_UPDATE:	// 问题标题更新
				$api = DOMAIN . '/q/getdetail.php';
				$post_data = array('questionid' => $args['questionid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				if(empty($q_detail) || !empty($q_detail['error_num'])) {
					break;
				}
				$search_data = array(
					'DF'	=> 'U',
					'id'	=> $args['questionid'],
					'title'	=> $args['title'],
					'tag'	=> @implode(' ' , $q_detail['tags']),
					'num1'	=> 0,
					'num2'	=> 0,
					'ctime'	=> strtotime($q_detail['ctime']),
					'ntime'	=> strtotime($q_detail['last']),
					'source_id'	=> '1',
					'pushtime'	=> time(),
					//'uid'	=> $args['uid'],
					'uid'	=> $q_detail['uid'],
					'desc'	=> $tools->mb_substring($q_detail['description'] , 0, 100),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_QUESTION_DESC_UPDATE: // 问题描述更新
				$api = DOMAIN . '/q/getdetail.php';
				$post_data = array('questionid' => $args['questionid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				if(empty($q_detail) || !empty($q_detail['error_num'])) {
					break;
				}
				$search_data = array(
					'DF'	=> 'U',
					'id'	=> $args['questionid'],
					'title'	=> $q_detail['title'],
					'tag'	=> @implode(' ' , $q_detail['tags']),
					'num1'	=> 0,
					'num2'	=> 0,
					'ctime'	=> strtotime($q_detail['ctime']),
					'ntime'	=> strtotime($q_detail['last']),
					'source_id'	=> '1',
					'pushtime'	=> time(),
					//'uid'	=> $args['uid'],
					'uid'	=> $q_detail['uid'],
					'desc'	=> $tools->mb_substring($args['description'] , 0, 100),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_QUESTION_REDIRECT:
			case EVENT_QUESTION_LOCK:	// 锁定
				break;
			case EVENT_QUESTION_TAG_ADD:	//问题增加话题
				if(!empty($args['tags'])) {
					foreach($args['tags'] as $tid => $tname) {
						// 获取话题信息 判断话题是否存在
						$api = DOMAIN . '/t/gettag.php';
						$post_data = array(
							'tid' => $tid,
							'app' => $args['app'],
						);
						$tools->curl_set($api , 'post' ,  $post_data , $json_tag);
						$tag = json_decode($json_tag , true);
						// tag 为空
						if(empty($tag))	{
							$search_data = array(
								'DF'	=> 'A',
								'id'	=> $tid,
								'title'	=> $tname,
								'desc'	=> '',
								'tag'	=> '',
								'num1'	=> 0,
								'num2'	=> 1,	// 话题的添加伴随问题添加 初始就应该是1
								'ctime'	=> strtotime($args['ctime']),
								'ntime'	=> strtotime($args['ctime']),
								'source_id'	=> '2',
								'pushtime'	=> time(),
								'uid'	=> $args['uid'], //话题不存在说明话题是新加的，uid就应该是添加问题的时候的uid
							);
							// 同步搜索 start
							$flag = self::send_memq($search_data);
						}
						else {
							// 取话题下的问题数
							$api = DOMAIN . '/t/gettaglist.php';
							$post_data = array(
									'tid' => $tid,
									'type' => 'tq',
									'flag' => 0,
									'app' => $args['app'],
							);
							$tools->curl_set($api , 'post' ,  $post_data , $json_t_list);	
							$t_list = json_decode($json_t_list , true);
							$search_data = array(
								'DF'	=> 'M',
								'id'	=> $tid,
								'num2'	=> $t_list['total'],
								'source_id'	=> 2,
								'pushtime'	=> time(),
							);
							// 同步搜索 start
							$flag = self::send_memq($search_data);
						}
					}
				}
				break;
			case EVENT_QUESTION_TAG_DEL:	// 问题话题删除
				// 删除一个话题 前台暂时没有对话题是否隐藏做判断 于是这里也不删搜索 只做更新操作
				foreach($args['tags'] as $tid => $tname) {
					// 取话题下的问题数
					$api = DOMAIN . '/t/gettaglist.php';
					$post_data = array(
						'tid' => $tid,
						'type' => 'tq',
						'flag' => 0,
						'app' => $args['app'],
					);
					$tools->curl_set($api , 'post' ,  $post_data , $json_t_list);	
					$t_list = json_decode($json_t_list , true);
					$search_data = array(
						'DF'	=> 'M',
						'id'	=> $tid,
						'num2'	=> $t_list['total'],
						'source_id'	=> 2,
						'pushtime'	=> time(),
					);
					// 同步搜索 start
					$flag = self::send_memq($search_data);
				}
				break;
			case EVENT_ANSWER_ADD://添加回答 7 需要获取问题回答数，对搜索做更新问题的操作
				$api = DOMAIN . '/q/getdetail.php';
				$post_data = array('questionid' => $args['questionid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				if(empty($q_detail) || !empty($q_detail['error_num'])) {
					break;
				}
				$search_data = array(
						'DF'	=>	'M',
						'id'	=>	$args['questionid'],
						'num1'	=>	$q_detail['atotal'],	// 此处涉及到是取的快还是更新的快
											// 的问题 暂时只取能取到的值 不做
											// +1 的处理。
						'source_id'	=> '1',
						'pushtime'	=> time(),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_ANSWER_DEL:		// 删除(隐藏)一个答案时 会导致问题下的回答数-1 也要同步微博搜索
				if($args['showflag'] != 1) {
					break;
				}
				// 查问题的回答数
				$api = DOMAIN . '/q/getquestion.php';
				$post_data = array('questionid' => $args['questionid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				if(empty($q_detail) || !empty($q_detail['error_num'])) {
					break;
				}
				$search_data = array(
					'DF'	=> 'M',
					'id'	=> $args['questionid'],
					'num1'	=> isset($q_detail['atotal']) ? $q_detail['atotal'] : 0,
					'source_id' => 1,
					'pushtime' => time(),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_ANSWER_UPDATE:
			case EVENT_ANSWER_RECOVER:		// 恢复答案
				break;
			case EVENT_COMMENT_ADD:			//评论 只有问题评论需要更新微博搜索
				if($args['type'] != 1) {
					break;
				}
				// 查问题的评论数
				$api = DOMAIN . '/q/getquestion.php';
				$post_data = array('questionid' => $args['qid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				if(empty($q_detail) || !empty($q_detail['error_num'])) {
					break;
				}
				$search_data = array(
					'DF'	=> 'M',
					'id'	=> $args['qid'],
					'num2'	=> isset($q_detail['cnum']) ? $q_detail['cnum'] : 0,
					'source_id'	=> 1,
					'pushtime'	=> time(),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_COMMENT_DEL:			// 删除问题评论后 要更新微博搜索
				if($args['type'] != 1) {
					break;
				}
				// 查问题的评论数
				$api = DOMAIN . '/q/getquestion.php';
				$post_data = array('questionid' => $args['oid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_q_detail);	
				$q_detail = json_decode($json_q_detail , true);
				if(empty($q_detail) || !empty($q_detail['error_num'])) {
					break;
				}
				$search_data = array(
					'DF'	=> 'M',
					'id'	=> $args['oid'],
					'num2'	=> isset($q_detail['cnum']) ? $q_detail['cnum'] : 0,
					'source_id'	=> 1,
					'pushtime'	=> time(),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_QUESTION_INVITE:		// 邀请回答
			case EVENT_VOTE_AGREE_ADD://投票赞同
			case EVENT_QUESTION_ADOPT: // 采纳回答
			case EVENT_VOTE_AGREE_DEL:
			case EVENT_VOTE_AGAINST_ADD://反对票
			case EVENT_VOTE_AGAINST_DEL:
			case EVENT_VOTE_NOHELP:
				break;
			case EVENT_TAG_ADD://增加话题
				$search_data = array(
					'DF'	=> 'A',
					'id'	=> $args['tid'],
					'title'	=> $args['name'],
					'tag'	=> '',
					'num1'	=> 0,
					'num2'	=> 1,
					'ctime'	=> strtotime($args['ctime']),
					'ntime'	=> strtotime($args['ctime']),
					'source_id'	=> '2',
					'pushtime'	=> time(),
					'uid'	=> $args['uid'],
					'desc'	=> $tools->mb_substring($args['description'] , 0, 100),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_TAG_REST: // 恢复话题
				// 获取话题信息 判断话题是否存在
				$api = DOMAIN . '/t/gettag.php';
				$post_data = array(
					'tid' => $tid,
					'app' => $args['app'] ? $args['app'] : API_APP_ID,
				);
				$tools->curl_set($api , 'post' ,  $post_data , $json_tag);
				$tag = json_decode($json_tag , true);
				
				// 取话题下的问题数
				$api = DOMAIN . '/t/gettaglist.php';
				$post_data = array(
					'tid' => $args['tid'],
					'type' => 'tq',
					'flag' => 0,
					'app' => $args['app'] ? $args['app'] : API_APP_ID,
				);
				$tools->curl_set($api , 'post' ,  $post_data , $json_t_list);	
				$t_list = json_decode($json_t_list , true);
				
				// 取话题的被关注数
				$api = DOMAIN . '/t/get_tag_gzl.php';
				$post_data = array('tid' => $args['tid'] , 'app' => $args['app'] ? $args['app'] : API_APP_ID);
				$tools->curl_set($api , 'post' ,  $post_data , $json_t_gzl);	
				$t_gzl = json_decode($json_t_gzl , true);
				
				$search_data = array(
					'DF'	=> 'A',
					'id'	=> $args['tid'],
					'title'	=> $args['title'],
					'tag'	=> '',
					'num1'	=> $t_gzl['total'],
					'num2'	=> $t_list['total'],
					'ctime'	=> strtotime($args['ctime']),
					'ntime'	=> strtotime($args['utime']),
					'source_id'	=> '2',
					'pushtime'	=> time(),
					'uid'	=> $tag['uid'],
					'desc'	=> $tools->mb_substring($tag['description'] , 0, 100),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_TAG_FOLLOW_ADD :	// 前台添加话题关注
			case EVENT_TAG_FOLLOW_DEL :	// 前台取消话题关注
				$api = DOMAIN . '/t/get_tag_gzl.php';
				$post_data = array('tid' => $args['toid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_t_gzl);	
				$t_gzl = json_decode($json_t_gzl , true);
				$gz_total = $t_gzl['total'];
				$search_data = array(
					'DF'	=> 'M',
					'id'	=> $args['toid'],
					'num1'	=> $gz_total,
					'source_id'	=> 2,
					'pushtime'	=> time(),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_TAG_UPDATE:		// 话题更新 实际是话题描述更新 实际里面没包括图片的更新信息
			case EVENT_TAG_UPDATE_LOGO :	// 话题头像修改
				// 获取话题信息 判断话题是否存在
				$api = DOMAIN . '/t/gettag.php';
				$post_data = array(
					'tid' => $args['tid'],
					'app' => $args['app'],
				);
				$tools->curl_set($api , 'post' ,  $post_data , $json_tag);
				$tag = json_decode($json_tag , true);
				
				// 取话题下的问题数
				$api = DOMAIN . '/t/gettaglist.php';
				$post_data = array(
					'tid' => $args['tid'],
					'type' => 'tq',
					'flag' => 0,
					'app' => $args['app'],
				);
				$tools->curl_set($api , 'post' ,  $post_data , $json_t_list);	
				$t_list = json_decode($json_t_list , true);
				// 取话题下最新发布问题的时间
				$lasttime = '';
				if(!empty($t_list['list'])) {
					foreach($t_list['list'] as $qid => $info) {
						$lasttime = $info['time'];
						break;
					}
				}	
				
				// 取话题下的关注者数
				$api = DOMAIN . '/t/get_tag_gzl.php';
				$post_data = array('tid' => $args['tid'] , 'app' => $args['app']);
				$tools->curl_set($api , 'post' ,  $post_data , $json_t_gzl);	
				$t_gzl = json_decode($json_t_gzl , true);

				// tag 为空
				if(!empty($tag)) {
					$search_data = array(
						'DF'	=> 'U',
						'id'	=> $args['tid'],
						'title'	=> $tag['tname'],
						'tag'	=> '',
						'num1'	=> $t_gzl['total'],	// 话题关注次数
						'num2'	=> $t_list['total'],	// 话题中问题的数量
						'ctime'	=> strtotime($tag['ctime']),
						'ntime'	=> $lasttime,
						'source_id'	=> '2',
						'pushtime'	=> time(),
						//'uid'	=> $args['uid'],
						'uid'	=> $tag['uid'],
						'desc'	=> $args['description'] ? $tools->mb_substring($args['description'] , 0 , 100) : $tools->mb_substring($tag['desc'] , 0 , 100),
					);
					// 同步搜索 start
					$flag = self::send_memq($search_data);
				}
				break;
			case EVENT_TAG_DEL:		// 删除话题
				$search_data = array(
					'DF'	=> 'D',
					'id'	=> $args['tid'] ,
					'source_id' => 2,
					'pushtime' => time(),
				);
				// 同步搜索 start
				$flag = self::send_memq($search_data);
				break;
			case EVENT_TAG_LOCK:
			case EVENT_TAG_FATHER_ADD://增加父话题id
			case EVENT_TAG_CHILD_ADD:
			case EVENT_TAG_FATHER_DEL:
			case EVENT_TAG_CHILD_DEL:
			case EVENT_TAG_EXP_UPDATE://话题经验
			case EVENT_USER_UPDATE_LOGO://用户修改头像
			case EVENT_USER_UPDATE://用户修改
			case EVENT_USER_REGISTER:
				break;
			default:
				break;
		}
		return $flag;
	}

	private static function send_memq(&$search_data) {
		$m = new Memcached;
		# $m->connect(self::$memq_url , self::$memq_port) or exit('can not connect memcacheq!');
		$m->addServer(self::$memq_url , self::$memq_port) or exit('can not connect memcacheq!');
		$flag = $m->set(self::$memq_name , json_encode($search_data));
		echo 'send_memq : ' ; var_dump($flag);;
		print_r($search_data);
		return $flag;
	}
}
?>
