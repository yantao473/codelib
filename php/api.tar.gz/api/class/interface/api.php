<?php

/*
* 平台接口 接口类
*
*/

interface Platform_Api {

	/* 初始化参数 */
	function _init_param();

	/* 检查参数合法性 */
	function _check_param();

	/* 初始化调用类 */
	function _init_class();

	/* 初始化接口功能订制列表 */
	function _init_api_config();

	/* 执行接口订制功能 */
	function run_api_event();
}

?>
