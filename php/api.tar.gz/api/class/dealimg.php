<?php

class dealimg{
	private $dwidth;
	function __construct(){
		$this->dwidth = 403;
	}

	function answer_images(&$args){
		$preg = '~\[img_([0-9]+):([0-9]+):([a-zA-Z]+)\]~is';
		preg_match_all($preg , $args['data']['answer'] , $match);
		if(!empty($match[0])) {
			foreach($match[0] as $k => $v) {
				$file_name = $args['data']['questionid'].'_'.$match[2][$k].'.'.$match[3][$k];
				$file_path = '/'.$match[1][$k].'/'.$file_name;
				$imgurl = 'http://image.iask.sina.com.cn/vwhat'.$file_path;
				$wjj = $args['data']['questionid']%100;
				$dir = '/data0/weibo_attached/answer_pic/'.$wjj.'/';
				if(!file_exists($dir)){
					mkdir($dir,0777,true);
				}
				$fexists = @get_headers($imgurl);
				$flag = true;
				if(strpos(strtolower($fexists[0]),"ok") === false){
					$flag = false;
				}
				if($flag) {
					$img_info = getimagesize($imgurl);
					$img_width = $img_info[0];
					if($img_width > $this->dwidth){
						//等比缩小处理
						$this->deal_max_img($match[3][$k],$file_name,$imgurl,$dir);
					}
				}
				$this->rsync_imghosts($match[1][$k],$dir,$file_name);
			}
		}
	}
	function rsync_imghosts($path,$dir,$file_name){
		// 推到两个审核服务器
		$cmd = 'rsync -vzrtopg --delete '.$dir . $file_name . ' 172.16.115.104::IMAGE_VWHAT/'.$path.'/';
		echo $cmd . "\n";
		@system($cmd , $ret);
		if($ret != 0) {
			@system($cmd , $ret);
		}
		$cmd = 'rsync -vzrtopg --delete '.$dir . $file_name . ' 172.16.30.182::IMAGE_VWHAT/'.$path.'/';
		echo $cmd . "\n";
		@system($cmd , $ret);
		if($ret != 0) {
			@system($cmd , $ret);
		}

	}

	function deal_max_img($match,$file_name,$imgurl,$dir){
		$img_info = getimagesize($imgurl);
		$img_width = $img_info[0];
		$img_height = $img_info[1];
		$new_height = ($this->dwidth/$img_width)*$img_height;
		$new_width = $this->dwidth;
		echo "生成的width:";
		echo $new_width; echo "\n";
		echo "height: \n";
		echo $new_height;
		echo "=======================";
		echo "lujing\n\n";echo $dir.$file_name;
		echo "\n";
		//pic type
		if(!empty($match)){
			switch(strtolower($match)){
				case 'jpg':
				case 'jpeg':
					header('Content-Type: image/jpeg');
					$image = imagecreatefromjpeg($imgurl);
					$image_p = imagecreatetruecolor($new_width, $new_height);
					imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $img_width, $img_height);
					imagejpeg($image_p,$dir.$file_name);
					break;
				case 'gif':
					header('Content-Type: image/gif');
					$image = imagecreatefromgif($imgurl);
					$image_p = imagecreatetruecolor($new_width, $new_height);
					imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $img_width, $img_height);
					imagegif($image_p,$dir.$file_name);
					break;
				case 'png':
					header('Content-Type: image/png');
					$image = imagecreatefrompng($imgurl);
					$image_p = imagecreatetruecolor($new_width, $new_height);
					imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $img_width, $img_height);
					imagepng($image_p,$dir.$file_name);
					break;
				default:
					$image = '';
					break;
			}
			imagedestroy($image_p);
		}
	}

}
//$run = new dealimg();
//$run->dealimages($args);
?>
