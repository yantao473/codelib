<?php
if (class_exists('Notice_Relation'))
{
    return true;
}else{
	Class Notice_Relation extends Notice_BaseOperation{
		
		public function __construct($app){
			parent::__construct($app);

		}
		/**
		 * 
		 * 添加一条信息，已知信息infoid的前提下
		 * @param int64 $fromuid
		 * @param int64 $touid
		 * @param int $infoid
		 * @param int $productid
		 * @param int $type
		 * @param int $status
		 * @param string $uniq_key
		 * 
		 */
		public function add_relation($fromuid,$touid,$infoid,$productid,$type,$status,$uniq_key){
			if(!$this->check_uid($fromuid) 
				||!$this->check_type($type)||!$this->check_status($status)){
				$this->set_error(2);
				return false;
			}
			$tablename = $this->get_tablename("relation", $fromuid);
			$arr_data = array();
			$arr_data["owneruid"] = $fromuid;
			$arr_data["otheruid"] = $touid;
			$arr_data["infoid"] = $infoid;
			$arr_data["productid"] = $productid;
			$arr_data["type"] = $type;
			$arr_data["ctime"] = date("Y-m-d H:i:s");
			$arr_data["uniq_key"] = $uniq_key;
			$arr_data["status"] = $status;
			//var_dump($tablename,$arr_data);
			$sql = "insert into $tablename (owneruid,otheruid,infoid,productid,type,ctime,uniq_key,status)values
					($arr_data[owneruid],$arr_data[otheruid],$arr_data[infoid],$arr_data[productid],$arr_data[type],'$arr_data[ctime]','$arr_data[uniq_key]',$arr_data[status])";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			if(!$result){
				$this->set_error(8);
				return false;			
			}
			return true;
		}
		/**
		 * 
		 * 删除一条信息
		 * @param int64 $uid
		 * @param int $id
		 */
		public function del_relation($uid,$id){
			if(!$this->check_uid($uid)){
				$this->set_error(2);
				return false;
			}			
			$tablename = $this->get_tablename("relation", $uid);
			$sql = "delete from $tablename where owneruid='$uid' and id='$id'";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			if(!$result){				
		    	$this->set_error(8);
		    	return false;		
			}	 	
			return true;			
		}
		/**
		 * 
		 * 批量删除信息
		 * @param int64 $uid
		 * @param string|array $arr_id
		 */
		public function del_relation_more($uid,$arr_id){
			if(!$this->check_uid($uid)){
				$this->set_error(2);
				return false;
			}
			$tablename = $this->get_tablename("relation", $uid);
			if(is_array($arr_id)){
				$arr_tmp = $arr_id;
			}else{
				$arr_tmp = explode(",", $arr_id);
			}
			foreach ($arr_tmp as $key=>$val){
				if(!is_numeric($val)||floatval($val)<1){
					$this->set_error(2);
					return false;
				}
			}
			if(count($arr_tmp)<1){
				$this->set_error(2);
				return false;	
			}else{
				$ids = implode(",",$arr_tmp);
			}

			$sql = "select infoid from $tablename where id in ($ids) ";
			$result = $this->rpc->read(RPC_MESSAGE_APP, $sql, $data);
			$delids = array();
			if ($result){ 	
				$rt = $data;
				if(is_array($rt)){
					foreach ($rt as $val){
						$delids[] = "('$val[infoid]')";
					}
				}
			}			
			$sql = "delete from $tablename where owneruid='$uid' and id in ($ids)";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			if(!$result){
		    	$this->set_error(8);
		    	return false;
			}
			//insert into delinfo
			if(count($delids)>0){
				$sql = "insert into delinfoid values ".implode(",", $delids);
				$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			}
			return true;			
		}
		
		/**
		 * 
		 * 清空某用户信息
		 * @param int64 $uid
		 * @param int64 $otheruid
		 * @param int $type
		 * @param int $productid
		 */
		public function empty_relation($uid,$otheruid=0,$type=0,$productid=0){
			if(!$this->check_uid($uid)){					
				$this->set_error(2);
				return false;
			}			
			$tablename = $this->get_tablename("relation", $uid);
			$condition = " owneruid='$uid'";
			if(!empty($otheruid)){
				$condition .= " and otheruid='$otheruid' ";				
			}
			if(!empty($type)){
				$condition .= " and `type`='$type' ";				
			}			
			
			if(!empty($productid)){
				$condition .= " and productid='$productid'";
			}
			
			$sql = "delete from $tablename where $condition";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			if($result === false){
		    	$this->set_error(8);
		    	return false;
			}
			return true;			
		}
		
		/**
		 * 
		 * 修改信息（仅支持有未读状态修改）
		 * @param int64 $uid
		 * @param string|array $arr_id
		 * @param int $mtype
		 * @param array $arr_data
		 */
		public function update_realtion($uid,$arr_id,$type,$arr_data,$category=0){
			if(!$this->check_uid($uid)){
				$this->set_error(2);
				return false;
			}
			$tablename = $this->get_tablename("relation", $uid);
			if(is_array($arr_id)){
				$ids = implode(",",$arr_id);
			}else{
				$ids = $arr_id;
			}			
			$condition = " owneruid = '$uid' ";
			if($ids!=""){
				$condition .= " and id in ( $ids )";
			}
			
			$condition .= "  and status=1 ";
			if(!empty($category)){
				$condition .= " and otheruid=$category ";
			}
			if(!empty($type)){
				$condition .= " and `type` = '$type' ";	
			}
			
			$sql = "update $tablename set status=2 where $condition";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			//echo "$sql\n";var_dump($result,$data);	

			if (!$result){
		    		$this->set_error(8);
		    		return false;
			}
			return true;			
		}
		
		/**
		 * 
		 * 获取某人的某类别的信息
		 * @param int64 $uid
		 * @param int $type
		 * @param int $pagesize
		 * @param int $page
		 * @param int $lastid
		 * @param int $productid
		 */
		public function list_relation($uid,$type,$pagesize,$page,$lastid=0,$status=0,$productid=0,$category=0){
			if(!$this->check_uid($uid)||$pagesize>100){
				$this->set_error(2);
				return false;
			}
			$tablename = $this->get_tablename("relation", $uid);
			$condition = "owneruid='$uid' ";
			if(!empty($type)){
				$condition .= " and `type`= '$type'";
			}
			if(!empty($status)){
				$condition .=  " and `status`='$status'";
			}
			if(!empty($productid)){
				$condition .= " and product='$productid' ";
			}
			if(!empty($lastid)){
				$condition .= " and id < $lastid";	
			}
			if(!empty($category)){
				$condition .= " and otheruid='$category' ";
			}			
			$cursor = $pagesize * ($page -1);
			$sql = "select * from $tablename where $condition order by ctime desc  limit $cursor ,$pagesize";
			//echo $sql."\n";
			$result = $this->rpc->read(RPC_MESSAGE_APP, $sql, $data);
			
			if ($result){ 	
				$rt = $data;
				if(is_array($rt)){
					return $rt;
				}
			}
			return array();			
		}

		/**
		 * 
		 * 获取对话
		 * @param int64 $uid
		 * @param int64 $otheruid
		 * @param int $pagesize
		 * @param int $page
		 * @param int $lastid
		 * @param int $productid
		 */
		public function list_relation_talk($uid,$otheruid,$pagesize,$page,$lastid=0,$productid=0){
			if(!$this->check_uid($uid) ||$pagesize>100){
				$this->set_error(2);
				return false;
			}
			$tablename = $this->get_tablename("relation", $uid);
			$condition = "owneruid='$uid' ";
			$condition .= " and otheruid='$otheruid'";
			if(!empty($productid)){
				$condition .= " and product='$productid' ";
			}
			if(!empty($lastid)){
				$condition .= " and id> $lastid";	
			}
			$cursor = $pagesize * ($page -1);
			$sql = "select * from $tablename where $condition order by ctime desc limit $cursor ,$pagesize";
			$result = $this->rpc->read(RPC_MESSAGE_APP, $sql, $data);
			if ($result){ 	
				$rt = $data;
				if(is_array($rt)){
					return $rt;
				}
			}
			return array();									
		}
		
		
		public function get_msg_count($owneruid,$otheruid,$type,$status,$productid=0){
			if(!$this->check_uid($owneruid)||!$this->check_status($status)){
				
				$this->set_error(2);
				return false;
			}
			$tablename = $this->get_tablename("relation", $owneruid);
			$condition = "owneruid='$owneruid' ";
			if(!empty($otheruid)){
				$condition .= " and otheruid='$otheruid'";
			}
			if(!empty($type)){
				$condition .= " and `type`='$type' ";
			}
			if(!empty($status)){
				$condition .=  " and `status`='$status'";
			}
			if(!empty($productid)){
				$condition .= " and productid='$productid'";
			}
			$sql = "select count(*) as num from $tablename where {$condition}";
			$result = $this->rpc->read(RPC_MESSAGE_APP, $sql, $data);

			if ($result){
				$count = $data[0]['num'];
				return $count;
			}else{
				$this->set_error(8);
				return FALSE;
			}			
		}

		public function get_msg_count_group($owneruid,$otheruid,$type,$status,$productid=0){
			if(!$this->check_uid($owneruid)||!$this->check_status($status)){
				
				$this->set_error(2);
				return false;
			}
			$tablename = $this->get_tablename("relation", $owneruid);
			$condition = "owneruid='$owneruid' ";
			if(!empty($otheruid)){
				$condition .= " and otheruid='$otheruid'";
			}
			if(!empty($type)){
				$condition .= " and `type`='$type' ";
			}
			if(!empty($status)){
				$condition .=  " and `status`='$status'";
			}
			if(!empty($productid)){
				$condition .= " and productid='$productid'";
			}
			$sql = "select otheruid ,count(1) as num from $tablename where {$condition} group by otheruid";
			$result = $this->rpc->read(RPC_MESSAGE_APP, $sql, $data);
			$count = array(
				"question"=>0,
				"comment"=>0,
				"vote"=>0,
				"invite"=>0,

			);
			$o2c = array(
				7=>"question",11=>"comment",13=>"vote",26=>"invite",0=>"other"
			);
			if ($result){
				foreach($data as $val){
					if(!isset($o2c[$val["otheruid"]])){
						$kkey = "other";
					}else{
						$kkey = $o2c[$val["otheruid"]];
					}
					$count[$kkey] = $val["num"];

				}
				return $count;	
				
			}else{
				$this->set_error(8);
				return FALSE;
			}			
		}
		
	}
}
?>
