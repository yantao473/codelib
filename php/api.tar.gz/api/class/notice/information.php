<?php
if (class_exists('Notice_Information'))
{
    return true;
}else{
	Class Notice_Information extends Notice_BaseOperation{
		/**
		 * 构造函数
		 * 
		 * @param int $app
		 * @param int $productid
		 */
		public function __construct($app=2){
			parent::__construct($app);
			$tablename = $this->get_tablename("information");
			$this->tableName = $tablename; 	
		}
		/**
		 * 
		 * Enter description here ...
		 * @param string $content
		 * @param int $productid 
		 * @return boolean|Ambigous <boolean, string>
		 */
		public function add_info($content,$productid){
			$tablename = $this->tableName;
			$content = str_replace("'","\'",$content);
			$arr_data["content"] = $content;
			$sql = "insert into information (content)values('$content')";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			if (!$result){
				$this->set_error(8);
		    		return false;
			}
			$infoid = $data["insertid"];
			return $infoid;
		}
		
		/**
		 * 
		 * 删除一条信息
		 * @param int64 $infoid
		 */
		public function del_info($infoid){
			$tablename = $this->tableName;
			$sql = "delete from $tablename where infoid = '$infoid'";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			if (!$result){
		    	$this->set_error(8);
		    	return false;
			}
			return true;
		}
		
		/**
		 * 根据infoids 批量删除信息
		 * @param array | string $arr_infoids
		 */
		public function del_more($arr_infoids){
			$tablename = $this->tableName;
			if(is_array($arr_infoids)){
				$infoids = implode(",",$arr_infoids);
			}else{
				$infoids = $arr_infoids;
			}
			$sql = "delete from $tablename where infoid in( $infoids )";
			$result = $this->rpc->update(RPC_MESSAGE_APP, $sql, $data);
			if (!$result){
		    	$this->set_error(8);
		    	return false;
			}
			return true;
		}
		
		/**
		 * 根据infoid获取信息
		 * @param array|string $arr_infoids
		 */
		public function list_infos($arr_infoids){
			$tablename = $this->tableName;
			if(is_array($arr_infoids)){
				sort($infoids);
				$infoids = implode(",",$arr_infoids);
			}else{
				$infoids = $arr_infoids;
			}
						
			$sql = "select infoid,content from $tablename where infoid in ($infoids)";
			$result = $this->rpc->read(RPC_MESSAGE_APP, $sql, $data);
			$rt = array();
			if ($result){ 	
				$rs_array =  $data;
				foreach($rs_array as $tmp_data){
					$rt[$tmp_data["infoid"]] = $tmp_data["content"];
				}				
			}
			return $rt;
		}		
		
	}	
	
}
?>
