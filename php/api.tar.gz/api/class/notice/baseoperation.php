<?php
if (class_exists('Notice_BaseOperation'))
{
    return true;
}else{
	Class Notice_BaseOperation{
		protected  $Productid;
		protected $Application;
		protected $Pdo;
		protected $Error;
		protected $tableName;
		protected $rpc;
		
		/**
		 * @return MysqlPdo
	 	*/
		public function get_pdo() {
			return $this->Pdo;
		}
		public function get_rpc() {
			return $this->rpc;
		}

		/**
		 * @param MysqlPdo $Pdo
		 */
		public function set_pdo($Pdo) {
			$this->Pdo = $Pdo;
		}
		public function set_rpc($rpc) {
			$this->rpc = $rpc;
		}		/**
	 	* @return int
		 */
		public function get_error() {
			return $this->Error;
		}

		/**
		 * @param int $Error
	 	*/
		public function set_error($Error) {
			$this->Error = $Error;
		}
		/**
	 	* @return Int
		 */
		public function get_application() {
			return $this->Application;
		}
		
		/**

		/**
		 * @param Int $Application
		 */
		public function set_application($Application) {
			$this->Application = $Application;
		}
		
		
		public function  __construct($application=2){			
		
			$this->rpc = new RpcDb();

		}
		public function add(){}
		
		public function delete(){}
		
		public function update_realtion(){}
		
		public function list_info(){}
		
		public function get_tablename($tablename_ori,$operationid=0,$operation="fmod"){
			return $tablename_ori;/*
			$arr_fix = $GLOBALS["G_DIVIDE_ARRAY"][$tablename_ori];
			$n_table = $arr_fix["n_table"];
			if($n_table<=1 || $operationid==0 ){
				return $tablename_ori;		
			}else{
				if($operation!=""){
					$operation = $arr_fix["op"];
				}
				if($operation == "fmod"){					
					$n_fix = fmod($operationid,$n_table);
					if($n_fix == 0){
						$n_fix = $n_table;
					}
					$post_fix = "_". $n_fix;
				}else{
					$post_fix = "";
				}
			}
			return $tablename_ori.$post_fix;*/
		}
		/**
		 * 做一个最大值的检测，由于在接口最前面已经做了是否数字的检测，这里就不做检测了，只检测目前只提供到最大的uid
		 * Enter description here ...
		 * @param unknown_type $uid
		 */
		public function check_uid($uid){
			$uid = floatval($uid);
			if($uid > 4294967295){
				return false;
			}
			return true;
		}

		public function check_type($type){
			if($type<1||$type>2){
				return false;				
			}
			return true;
		}
			
		public function check_status($status){
			if($status<0||$status>2){
				return false;				
			}
			return true;
		}		
		
	}
}
?>
