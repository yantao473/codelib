<?php
if (class_exists('Notice_Operation'))
{
    return true;
}else{
	Class Notice_Operation{
		private $Aplication;
		private $Error;
		
		public function get_error() {
			return $this->Error;
		}

		/**
		 * @param int $Error
	 	*/
		private function set_error($Error) {
			if(empty($Error)){
				$Error = 8;
			}
			$this->Error = $Error;
		}
		/**
 		* 获取错误信息
		* @return int
     	*/
    	public function getErrNum (){
			return $this->Error;
    	}

    	/**
    	 * 设置错误信息
     	* @param int $errstr
     	*/
    	private function setErrNum ($errstr){
       	 	$this->Error = $errstr;
    	}				
		public function __construct($app){
			$this->Aplication = $app;
			$this->set_error(8);
		}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		// 以下添加的操作
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		private function add_one_relation($fromuid,$touid,$infoid,$productid,$type,$status,$uniq_key){
			$relation = new Notice_Relation($this->Aplication);
			$result = $relation->add_relation($fromuid,$touid,$infoid,$productid,$type,$status,$uniq_key);
			if($result){
				return true;
			}else{
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}			
		}
		
		private function add_two_relation($fromuid,$touid,$infoid,$productid){
			$relation = new Notice_Relation($this->Aplication);
			$uniq_key = "";
			//add one relation
			$type = 1;
			$status = 2;
			$result = $this->add_one_relation($fromuid,$touid,$infoid,$productid,$type,$status,$uniq_key);
			if(!$result){
				return false;
			}
			//add another
			$type = 2;
			$status = 1;//
			$result = $this->add_one_relation($touid,$fromuid,$infoid,$productid,$type,$status,$uniq_key);
			if(!$result){
				return false;
			}			
			return true;			
		}
		
		public function add_one_without_content($fromuid,$touid,$productid,$type,$status,$uniq_key){
			$relation = new Notice_Relation($this->Aplication);
			$infoid = 0;
			$result = $relation->add_relation($fromuid,$touid,$infoid,$productid,$type,$status,$uniq_key);
			if($result){
				return true;
			}else{
				return false;
			}	
		}
		
		public function add_two_without_content($fromuid,$touid,$productid=0){

			$relation = new Notice_Relation($this->Aplication);
			$infoid = 0;
			return $this->add_two_relation($fromuid, $touid, $infoid, $productid);		
		}
		
		public function add_one_with_content($fromuid,$touid,$content,$productid,$type=0,$status=0,$uniq_key=""){
			$information = new Notice_Information($this->Aplication);
			$infoid = $information->add_info($content,$productid);
			if(!$infoid){
				$error = $information->get_error();
				$this->set_error($error);
				return false;
			}
			
			$result =  $this->add_one_relation($fromuid,$touid,$infoid,$productid,$type,$status,$uniq_key);
			if(!$result){
				$error = $information->get_error();
				$this->set_error($error);
				return false;
			}
			return $result;			
		} 
				
		public function add_two_with_content($fromuid, $touid, $content, $productid=0){
						
			$information = new Notice_Information($this->Aplication);
			$infoid = $information->add_info($content,$productid);
			return $this->add_two_relation($fromuid, $touid, $infoid, $productid);
			
		}
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		// 以下删除的操作
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public function del_relation_one($uid,$id){
			//delete one from table relation by id
			$relation = new Notice_Relation($this->Aplication);
			$result = $relation->del_relation($uid,$id);
			
			if($result){
				return true;
			}else{
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}		
		}
		
		public function del_relation_more($uid,$arr_id){
			//delete info from table relation by ids
			$relation = new Notice_Relation($this->Aplication);
			$result = $relation->del_relation_more($uid,$arr_id);
			
			if($result===false){
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}else{
				return true;
			}				
		}

		public function del_relation_talk($uid,$otheruid,$productid=0){
			//delete ids from table relation by uid and otheruid
			$relation = new Notice_Relation($this->Aplication);
			$result = $relation->empty_relation($uid,$otheruid,0,$productid);
			if($result){
				return true;
			}else{
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}		
		}

		public function destroy_relation_by_uid($uid,$type,$productid=0){
			//delete infos from table realtion by uid
			$relation = new Notice_Relation($this->Aplication);
			$result =  $relation->empty_relation($uid,0,$type,$productid);
			if($result){
				return true;
			}else{
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}				
		}
				

		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		// 以下是修改的操作
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
				
		public function up_realtion_more($owneruid,$ids,$type){
			$relation = new Notice_Relation($this->Aplication);
			$arr_data = array("status"=>2);
			$result = $relation->update_realtion($owneruid,$ids,$type,$arr_data);	
			if($result){
				return true;
			}else{
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}
		}
		
		public function up_relation_batch($owneruid,$category=0,$type=0){
			$relation = new Notice_Relation($this->Aplication);
			$arr_data = array("status"=>2);
			$result = $relation->update_realtion($owneruid,"",$type,$arr_data,$category);	
			if($result){
				return true;
			}else{
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}		
		}

		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		// 以下是查找的的操作
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public function get_count_from_db($owneruid,$otheruid,$type,$status,$group=0,$productid=0){
			$relation = new Notice_Relation($this->Aplication);
			if($group){
				$count = $relation->get_msg_count_group($owneruid,$otheruid,$type,$status,$productid);
			}else{
				$count = $relation->get_msg_count($owneruid,$otheruid,$type,$status,$productid);
			}
			if(false===$count){				
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}else{
				return $count;
			}
		}
		
		

		
		public function get_list_by_type($uid,$type,$pagesize,$page,$lastid=0,$productid=0){
			//get info from table realtion by uid and type
			$information = new Notice_Information($this->Aplication);
			$relation = new Notice_Relation($this->Aplication);
			$relation_type = $relation->list_relation($uid,$type,$pagesize,$page,$lastid,$productid);
			if(false===$relation_type){				
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}			
			if(count($relation_type)<1){
				$this->set_error(18);
				return false;
			}
			foreach ($relation_type as $tmp_data){
				$infoid[] = $tmp_data['infoid'];
			}
			$infoids = implode(",",$infoid);
			$array_content = $information->list_infos($infoids);
			if(count($array_content)<1){
				//是否要不返回值，还是说给一个空的内容值
			}
			foreach ($relation_type as $key=>$val){
				if(isset($array_content[$val["infoid"]])){
					$relation_type[$key]["content"] = $array_content[$val["infoid"]];
				}else{
					$relation_type[$key]["content"] = "";
				}							
			}
			return $relation_type;
		}
		
		public function get_list_by_uid($uid,$pagesize,$page,$lastid=0,$status=0,$productid=0,$category=0){
			//get info from table realtion by uid
			$information = new Notice_Information($this->Aplication);
			$relation = new Notice_Relation($this->Aplication);
			$type = 0;
			$relation_list = $relation->list_relation($uid,$type,$pagesize,$page,$lastid,$status,$productid,$category);
			if(false===$relation_list){				
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}			
			
			if(count($relation_list)<1){
				return array();
			}
			foreach ($relation_list as $tmp_data){
				$infoid[] = $tmp_data['infoid'];
			}
			$infoids = join(",",$infoid);
			$array_content = $information->list_infos($infoids);
			if(count($array_content)<1){
				//是否要不返回值，还是说给一个空的内容值
			}
			foreach ($relation_list as $key=>$val){
				if(isset($array_content[$val["infoid"]])){
					$relation_list[$key]["content"] = $array_content[$val["infoid"]];
				}else{
					$relation_list[$key]["content"] = "";
				}							
			}
			return $relation_list;
		}
		
		public function get_list_by_uid_unread($uid,$pagesize,$page,$lastid=0,$productid=0){
			//get info from table realtion by uid
			$information = new Notice_Information($this->Aplication);
			$relation = new Notice_Relation($this->Aplication);
			$type = 0;
			$relation_list = $relation->list_relation($uid,$type,$pagesize,$page,$lastid,$productid);
			if(false===$relation_list){				
				$error = $relation->get_error();
				$this->set_error($error);
				return false;
			}			
			
			if(count($relation_list)<1){
				return array();
			}
			foreach ($relation_list as $tmp_data){
				$infoid[] = $tmp_data['infoid'];
			}
			$infoids = join(",",$infoid);
			$array_content = $information->list_infos($infoids);
			if(count($array_content)<1){
				//是否要不返回值，还是说给一个空的内容值
			}
			foreach ($relation_list as $key=>$val){
				if(isset($array_content[$val["infoid"]])){
					$relation_list[$key]["content"] = $array_content[$val["infoid"]];
				}else{
					$relation_list[$key]["content"] = "";
				}							
			}
			return $relation_list;
		}		
		
		
		
		public function get_information($uid,$infoids){
			$information = new Notice_Information($this->Aplication);
			return $information->list_infos($infoids);
		}
		
		public function is_exits_in_relation(){
			//get info from table realtion by uid and otheruid	
			//用于比如说邀请等只允许里面存在一个
			$relation = new Notice_Relation($this->Aplication);
		}
		///////////////////////////////////////////////////////////////////////////////////////////
		//end
		///////////////////////////////////////////////////////////////////////////////////////////

	}	
	
}

?>
