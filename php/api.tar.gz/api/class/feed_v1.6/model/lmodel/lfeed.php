<?php

class lfeed
{
	private $types = array('question', 'user', 'topic');

	public function __construct()
	{
		global $config;
		$this->config = $config;
	}

	public function test()
	{
		$oid = '1096093150';
		$a = sprintf('%.0f', '1096093150');
		$b = sprintf('%.0f', '1596240790');
		//$dIuser = ModelFactory::getModel('dIuser', 'd', 1);
		//$dIuser->setdbconf($config['feed']['db']['common']['master']);
		//$res = $dIuser->selIndexFeed('30d', array($a, $b));
		//print_r($res);
		//$obj = ModelFactory::getModel('dUpdatetime', 'd', 1);
		//$obj->multiSelUptime('u', array(1096093150,1780704987));
		//$obj->multiSelUptimeforMc('u', array(1096093150,1780704987));
		//$obj->multiSelUptime('u', array($a, $b));
		$myfeed = ModelFactory::getModel('dMyfeed', 'd', 1);
		$feedata = ModelFactory::getModel('dFeedata', 'd', 1);
		$timeline = time();
		$atts = array(
				'user'=>array($a, $b),
				'question'=>array('18544', '18542', '18552', '18887'),
				'topic'=>array('18944'),
				);
		/*
		$atts['10d'] = array(
				'user'=>array($a, $b),
				'question'=>array('18544', '18542', '18552'),
				//'topic'=>array('100', '101'),
				);
		*/
		//$myfeed->getMyfeedNocache($atts, 10, 20, 'up', $timeline);
		//$myfeed->getMyfeed(array('1096093150'));
		//$spanfeeds = $myfeed->getMyfeed('1096093150', $atts, 349, 5, 'up');
		//echo "lfeed.php...\n";
		//print_r($spanfeeds);
		//$res2 = $myfeed->chunkOidWithUpdatetime($atts, time());
		//$res = $myfeed->getMyfeedNeed($res2, 465, 5, 'up', array('1d', '10d', '30d'));
		//$res_1 = $myfeed->getMyfeedUp($oid, $atts, null, 30);
		//$res_1 = $myfeed->getMyfeedDown($oid, $atts, '536', 20);
		//print_r($res);
		//print_r($res_1);
		//$this->commondb['tbname'] = dFeedata::TBNAME;
		//$feedata->setdbconf($this->commondb);
		//$res_2 = $feedata->getFeedataMulti(array_values($res_1));
		//echo "这个是res_2的数据结果集\n";
		//$res_3 = $this->setPriority($res_2, $atts);
		//print_r($res_3);
		$dIusertofeed = ModelFactory::getModel('dIusertofeed', 'd', 1);
		$res = $dIusertofeed->multiGetIndex(array($a, $b, '1231231231'));
		//echo "结果集\n";
		//print_r($res);
	}

	/*
	* @prarms array(
		'uid'=>str,
		'qid'=>str,
		'tid'=>str,
		'tids'=>array(),
	);
	*/
	public function addFeedataToQueue($eid, $objs)
	{
		if(!$objs||!$eid) return false;
		if(!array_key_exists($eid, $this->config['feed_event_mapping'])) return false;
		if(!file_exists(FEED_QUEUES_LIST)||!is_writable(FEED_QUEUES_LIST)) return false;
		$objs['eid'] = $eid;
		$lqueuetool = ModelFactory::getModel('lqueuetool', 'l', 1);
		$result = $lqueuetool->AddToLocalQueue(FEED_QUEUES_LIST, $objs, FEED_QUEUES_NUM);
		return $result;
	}

	public function addFeedataToQueue_oth($eid, $objs)
	{
		$list = '/data3/qcenter/feed_v1.6/queue/data/baseevent.txt';
		$num = 6000;
		if(!$objs||!$eid) return false;
		if(!array_key_exists($eid, $this->config['feed_event_mapping'])) return false;
		if(!file_exists($list)||!is_writable($list)) return false;
		$objs['eid'] = $eid;
		$lqueuetool = ModelFactory::getModel('lqueuetool', 'l', 1);
		$result = $lqueuetool->AddToLocalQueue($list, $objs, $num);
		return $result;
	}

	public function getFeedsUp($oid, $atts, &$ifeof, &$fidtag, $upfid=null, $span=50)
	{
		$ifeof = false;
		$result = array();
		$nouseful = array();
		$fidtag = array('lfid'=>'', 'ffid'=>'');
		if($span<1||!$atts||!$oid) return $result;
		$oid = sprintf('%.0f', $oid);
		$upfid = $upfid ? sprintf('%.0f', $upfid) : $upfid;
		//为了获取关注对象时间，从而获得该对象是否更新MyFeedCache
		$atts_time = $atts;
		foreach($atts as $attobj=>$attinfo)
		{
			if(!$attinfo||!is_array($attinfo)) continue;
			$attoids = array_keys($attinfo);
			$atts[$attobj] = $attoids;
		}
		$dMyfeed = ModelFactory::getModel('dMyfeed', 'd', 1);
		$dFeedata = ModelFactory::getModel('dFeedata', 'd', 1);
		$timeline = time();
		$feeds = $dMyfeed->getMyfeedUp($oid, $atts, $atts_time, $upfid, $span);
		//print_r($feeds);
		if(!$feeds) return $result;
		$tmpfeeds = $feeds;
		$lastfid = array_pop($tmpfeeds);
		$fristfid = array_shift($tmpfeeds);
		$fidtag = array('lfid'=>$lastfid, 'ffid'=>$fristfid);
		$ifeof = (count($feeds)==$span)&&$span>0 ? true : false;
		//var_dump($ifeof);
		//error_log(var_export($ifeof, true).var_export($feeds, true), 3, '/tmp/def.log');
		//print_r($fidtag);
		$tmpconf = $dFeedata->getDbAndTbName(0);
		if(!$tmpconf) return false;
		$dbconf = $dFeedata->getDbServerInfo($tmpconf['dbname'], FEED_DB_SLVAER_ALIAS);
		$dbconf += $tmpconf;
		$dFeedata->setdbconf($dbconf);
		$feedatas = $dFeedata->getFeedataMulti(array_values($feeds));
		$result = $this->setPriority($feedatas, $atts, $oid);
		//print_r($result);
		$nouseful = array_diff(array_keys($feedatas), array_keys($result));
		if(!empty($nouseful))
		{
			//delete not mine atter.
			$dMyfeed->deleteNoUsefulMyFeed($oid, $atts, $nouseful);
		}
		return $result;
	}

	public function getFeedsDown($oid, $atts, $downfid, &$ifeof, &$fidtag, $span=50)
	{
		$ifeof = false;
		$result = array();
		$nouseful = array();
		$fidtag = array('lfid'=>'', 'ffid'=>'');
		if(!$downfid||$span<1||!$atts||!$oid) return $result;
		$oid = sprintf('%.0f', $oid);
		$downfid = sprintf('%.0f', $downfid);
		//为了获取关注对象时间，从而获得该对象是否更新MyFeedCache
		$atts_time = $atts;
		foreach($atts as $attobj=>$attinfo)
		{
			if(!$attinfo||!is_array($attinfo)) continue;
			$attoids = array_keys($attinfo);
			$atts[$attobj] = $attoids;
		}
		$dMyfeed = ModelFactory::getModel('dMyfeed', 'd', 1);
		$dFeedata = ModelFactory::getModel('dFeedata', 'd', 1);
		$timeline = time();
		$feeds = $dMyfeed->getMyfeedDown($oid, $atts, $downfid, $span);
		//print_r($feeds);
		if(!$feeds) return $result;
		$tmpfeeds = $feeds;
		$lastfid = array_pop($tmpfeeds);
		$fristfid = array_shift($tmpfeeds);
		$fidtag = array('lfid'=>$lastfid, 'ffid'=>$fristfid);
		$ifeof = (count($feeds)==$span)&&$span>0 ? true : false;
		//error_log(var_export($ifeof, true).var_export($feeds, true), 3, '/tmp/def.log');
		//print_r($fidtag);
		$tmpconf = $dFeedata->getDbAndTbName(0);
		if(!$tmpconf) return false;
		$dbconf = $dFeedata->getDbServerInfo($tmpconf['dbname'], FEED_DB_SLVAER_ALIAS);
		$dbconf += $tmpconf;
		$dFeedata->setdbconf($dbconf);
		$feedatas = $dFeedata->getFeedataMulti(array_values($feeds));
		$result = $this->setPriority($feedatas, $atts, $oid);
		$nouseful = array_diff(array_keys($feedatas), array_keys($result));
		if(!empty($nouseful))
		{
			//delete not mine atter.
			$dMyfeed->deleteNoUsefulMyFeed($oid, $atts, $nouseful);
		}
		return $result;
	}

	public function getOneUserFeeds($uid, $bfid=null, $span=20)
	{
		$result = array();
		$nouseful = array();
		if($uid&&$span)
		{
			$dMyfeed = ModelFactory::getModel('dMyfeed', 'd', 1);
			$dFeedata = ModelFactory::getModel('dFeedata', 'd', 1);
			$uid = sprintf('%.0f', $uid);
			$userfeeds = $dMyfeed->getOneUserFeeds($uid, $bfid, $span);
			if(!$userfeeds) return $result;
			$tmpconf = $dFeedata->getDbAndTbName(0);
			if(!$tmpconf) return false;
			$dbconf = $dFeedata->getDbServerInfo($tmpconf['dbname'], FEED_DB_SLVAER_ALIAS);
			$dbconf += $tmpconf;
			$dFeedata->setdbconf($dbconf);
			$feedatas = $dFeedata->getFeedataMulti(array_values($userfeeds));
			$result = $this->setPriority($feedatas, array('user'=>array($uid)));
		}
		return $result;
	}

	public function delOnemyfeed($oid, $fids) {
		$oid = sprintf('%.0f', $oid);
		if($oid&&$fids)
		{
			$dMyfeed = ModelFactory::getModel('dMyfeed', 'd', 1);
			$res0 = $dMyfeed->delRedisMyfeed($oid, $fids);
			if(!$res0) return false;
			//临时
			$atts = array('user'=>array());
			$res1 = $dMyfeed->deleteNoUsefulMyFeed($oid, $atts, $fids);
			if(!$res1)
			$res1 = $dMyfeed->deleteNoUsefulMyFeed($oid, $atts, $fids);
			if(!$res1) return false;
			$dMyfeed->reloadMc();
			$res2 = $dMyfeed->deleteNoUsefulMyFeed($oid, $atts, $fids);
			if(!$res2)
			$res2 = $dMyfeed->deleteNoUsefulMyFeed($oid, $atts, $fids);
			return $res2;
		}
		return false;
	}

	private function setPriority($fidlist, $atts, $oid='')
	{
		$priority = array();
		$nouseful = array();
		foreach($fidlist as $fid=>$onedata)
		{
			$indexs = isset($onedata['indexs']) ? $onedata['indexs'] : array();
			$uid = isset($onedata['uid']) ? $onedata['uid'] : '';
			$qid = isset($onedata['qid']) ? $onedata['qid'] : '';
			$tid = isset($onedata['tid']) ? $onedata['tid'] : '';
			$tids = isset($onedata['tids']) ? $onedata['tids'] : '';
			//过滤掉oid=uid的数据（我自己产生的动态）
			//过滤掉有问题的数据，如取到了不是我关注对象的feed数据
			if($oid&&$uid==$oid)
			{
				$nouseful[] = $fid;
				continue;
			}

			if($uid&&in_array('u', $indexs))
			{
				if(isset($atts['user'])&&in_array($uid, $atts['user']))
				{
					$onedata['priority'] = 'user';
					unset($onedata['indexs']);
					$priority[$fid] = $onedata;
					continue;
				}
			}
			if($qid&&in_array('q', $indexs))
			{
				if(isset($atts['question'])&&in_array($qid, $atts['question']))
				{
					$onedata['priority'] = 'question';
					unset($onedata['indexs']);
					$priority[$fid] = $onedata;
					continue;
				}
			}
			if($tid&&in_array('t', $indexs)&&isset($atts['topic'])&&in_array($tid, $atts['topic']))
			{
				if(isset($atts['topic'])&&in_array($tid, $atts['topic']))
				{
					$onedata['priority'] = 'topic';
					unset($onedata['indexs']);
					$priority[$fid] = $onedata;
					continue;
				}
			}
			if($tids&&in_array('t', $indexs))
			{
				if(isset($atts['topic'])&&$attopic = array_intersect($tids, $atts['topic']))
				{
					$onedata['priority'] = 'topic';
					$onedata['tids'] = $attopic;
					unset($onedata['indexs']);
					$priority[$fid] = $onedata;
					continue;
				}
			}
			//都没有符合的权重,直接删除此fid,标记为无用数据
			$nouseful[] = $fid;
			continue;
			$onedata['priority'] = 'user';
			unset($onedata['indexs']);
			$priority[$fid] = $onedata;
		}
		//print_r($priority);
		//krsort($priority);
		return $priority;
	}

	public function sendFeed($feedata)
	{
		if(is_array($feedata)&&isset($feedata['eid']))
		{
			$reldata['DATA'] = $feedata;
			QueueTool::AddToLocalQueue(QUESTION_FEED_QLIST_PATH, $reldata, QUESTION_FEED_QLIST_ID);
			return true;
		}
		return false;
	}
}
