<?php

class LMyfeed
{
	private $event_api = 'http://feed.iask.sina.com.cn/api/event.php';

	public function delMyfeed($oid, $fids) {
		if(!$oid||!$fids) return false;
		$params = array(
					
		);
	}
}
