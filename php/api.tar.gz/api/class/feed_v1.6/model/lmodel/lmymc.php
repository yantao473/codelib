<?php

class lmymc
{
	public static $NORMAL_CTIMEOUT = 1000;
	public static $NORMAL_PTIMEOUT = 500;

	/**
	 * @param $alias 缓存服务别名,详见mc.inc.php配置文件
	 **/
	public static function getNormalMc($alias)
	{
		if(!$alias) return false;
		$servers = self::getConf($alias);
		//echo $alias;
		if(!$servers) return false;
		$mc = new Memcached();
		$mc->setOption(Memcached::OPT_CONNECT_TIMEOUT, self::$NORMAL_CTIMEOUT);
		$mc->setOption(Memcached::OPT_POLL_TIMEOUT, self::$NORMAL_PTIMEOUT);
		$mc->setOption(Memcached::OPT_LIBKETAMA_COMPATIBLE, true);
		//set......
		$mc->addServers($servers);
		return $mc;
	}

	public static function getConf($alias)
	{
		global $config;
		if(isset($config['FEED_MC_ALIAS'][$alias])&&!empty($config['FEED_MC_ALIAS'][$alias]))
		{
			$mconf = $config['FEED_MC_ALIAS'][$alias];
			$rconf = array();
			foreach($mconf as $serverid)
			{
				if(isset($config['FEED_MC_SERVERS'][$serverid])&&count($config['FEED_MC_SERVERS'][$serverid])==3)
				{
					$rconf[] = $config['FEED_MC_SERVERS'][$serverid];
				}
			}
			return $rconf;
		}
		return false;
	}
}
