<?php

class lcreateid
{
	protected $dbalias;

	public function __construct()
	{
		global $config;
		$this->config = $config;
	}

	public function createDoubleID()
	{
		if(!isset($config['FEED_CREATEID_SERVERS'])||!$config['FEED_CREATEID_SERVERS']) return false;
		if(!defined('FEED_CREATEID_INFOFILE')||!defined('FEED_CREATEID_LOCKFILE')) return false;
		if(!file_exists(FEED_CREATEID_INFOFILE)||!file_exists(FEED_CREATEID_LOCKFILE)) return false;
		if(!is_writable(FEED_CREATEID_INFOFILE)) return false;
		$servers = $config['FEED_CREATEID_SERVERS'];
		$count = count($servers);
		$readres = '';
		$lockres = $this->lockRequest(FEED_CREATEID_LOCKFILE, 'readInfoFile', $readres, LOCK_SH);
		if($lockres&&$readres)
		{
			$info = explode(',', $readres);
			if($info&&count($info)==2)
			{
				$server = trim($info[0]);
				$dateinfo = trim($info[1]);
				if($server&&$dateinfo)
				{
					$idres = $this->createUinqID($dbalias, $dateinfo);
				}
			}
		}

	}

	private function lockRequest($lockfile, $fun, &$result, $locktype=LOCK_SH)
	{
		$result = false;
		$handle = fopen($lockfile, 'rb');
		if(!$handle) return $result;
		$lockres = flock($handle, $locktype);
		if($lockres)
		{
			$this->$fun();
			flock($handle, LOCK_UN);
		}
		return fclose($handle);
	}

	private function readInfoFile($infofile)
	{
		$content = @file_get_contents($infofile);
		return $content;
	}

	public function createUinqID($dbalias, $dateinfo)
	{
		if($dbalias&&array_key_exists($dbalias, $this->config['FEED_DB_SERVERS']))
		{
			$dNumberlog = modelfactory::getModel('dNumberlog', 'd', 1);
			$dbconfig = $this->config['FEED_DB_SERVERS'][$dbalias];
			$dbconfig['tbname'] = $dNumberlog->getpro('tbname');
	        $dNumberlog->setdbconf($dbconfig);
			$dNumberlog->createUniqNum($dateinfo);
		}
	}
}
