<?php
class lmyredis
{
	public static $ALIAS_CONF_TAG = 'FEED_REDIS_ALIAS';
	public static $ALIAS_CONF_SERVER_TAG = 'FEED_REDIS_SERVERS';

	/**
	 * @param $alias 缓存服务别名,详见redis.inc.php配置文件
	 **/
	public static function getNormalRedis($alias, $num=0)
	{
		if(!$alias) return false;
		$server = self::getConf($alias, $num);
		//print_r($server);
		if(!$server) return false;
		$redis = new redis();
		$connect = false;
		try{
			$connect = $redis->connect($server[0], $server[1], $server[2]);
		}catch(Exception $e) {}
		$redis->setOption(Redis::OPT_SERIALIZER, Redis::SERIALIZER_PHP);
		return $connect ? $redis : $connect;
	}

	public static function getConf($alias, $num)
	{
		global $config;
		$aliasConfTag = self::$ALIAS_CONF_TAG;
		$serverConfTag = self::$ALIAS_CONF_SERVER_TAG;
		if(isset($config[$aliasConfTag][$alias][$num]))
		{
			$serverid = $config[$aliasConfTag][$alias][$num];
			if (isset($config[$serverConfTag][$serverid])) {
				return $config[$serverConfTag][$serverid];
			}
		}
		return false;
	}
}
