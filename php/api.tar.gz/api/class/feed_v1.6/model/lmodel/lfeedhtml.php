<?php

class lfeedhtml
{
	const TMPLPRE = 'feedtmpl_';
	const TMPLDIR = 'feed';
	public $smarty;
	private $types = array('index', 'self');

	public function __construct()
	{
		$this->smarty = new smartyTmpl();
	}

	public function fetchHtml($feedata, $type='index')
	{
		$html = '';
		if(is_array($feedata)&&$feedata&&in_array($type, $this->types))
		{
			foreach($feedata as $fid=>$onefeed)
			{
				if(isset($onefeed['eid']))
				{
					$html .= $this->fetchone($fid, $onefeed, $type);
				}
				else
				{
					continue;
				}
			}
		}
		return $html;
	}

	public function fetchone($fid, $onefeed, $type='index')
	{
		$html = '';
		if(is_array($onefeed)&&$onefeed&&in_array($type, $this->types))
		{
			if(isset($onefeed['eid']))
			{
				$eid = $onefeed['eid'];
				$priority = $onefeed['priority'];
				$tmpl = self::TMPLDIR.'/'.self::TMPLPRE.$eid.'_'.$priority.'.tpl';
				//echo $tmpl;
				//var_dump($onefeed);
				//var_dump($this->smarty->template_dir);
				$this->smarty->assign('uid', $_SESSION['session_uid']);
				$this->smarty->assign('data', $onefeed);
				$this->smarty->assign('fid', $fid);
				$this->smarty->assign('feedtype', $type);
				$this->smarty->assign('lang', new V2_Lang_Zh());
				$html = $this->smarty->fetch($tmpl);
			}
		}
		return $html;
	}
}
