<?php
class lqueuetool
{
	function post($url,$query)
	{
		$info = parse_url($url);
        	$fp = fsockopen ($info["host"], 80, $errno, $errstr, 3);
		if(!$fp)
		{
			return false;
		}
		$head = "POST $info[path] HTTP/1.0\r\n";
		$head .= "Host: $info[host]\r\n";
		$head .= "Content-type: application/x-www-form-urlencoded\r\n";
		$head .= "Content-Length: ".strlen(trim($query))."\r\n";
		$head .= "\r\n";
		$head .= $query."\r\n";
		$head .= "\r\n";
		fputs( $fp, $head );
		stream_set_timeout($fp, 3);
		$result = "";
		$flag = 0;
		$i = 0;
		while (!feof($fp))
		{
			$line = fgets($fp,1024);
			if($i==0&&$flag==0)
			{
				list($protocol,$sts,$statuswork) = explode(" ",$line);
				if($sts >= 400)
				{
					fclose($fp);
					return false;
				}
			}
			$i++;
			if($line == "\n" || $line == "\r\n" )
			{
				$flag = 1;
				continue;
			}
			if($flag ==1)
				$result .= $line;
			$status = stream_get_meta_data($fp);
			if($status["timed_out"])
			{
				fclose($fp);
				return false;
			}
		}
		fclose($fp);
		return $result;
	}

	function urlencodeInt($v)
	{
		$s = sprintf("%08X", $v);
		return "%".substr($s, 6, 2)."%".substr($s, 4, 2)."%".substr($s, 2, 2)."%".substr($s, 0, 2);
	}
	
	function encode($value)
	{
		return str_replace(array("\r", "\n"), array("\\r", "\\n"), str_replace("\\", "\\\\", $value));
	}

	function AddToLocalQueue($filename,$array,$cmdid=1001)
	{
		$fp=fopen($filename,'a');
		if ($fp==NULL)
			return false;
		if (!flock($fp,LOCK_EX))
		{
			fclose($fp);
			return false;
		}
		$data=serialize($array);
		$bindata=pack("VVVV",1,$cmdid,0,strlen($data));
		$bindata.=$data;
		$qdata=pack("V",strlen($bindata));
		$qdata.=$bindata;
		$qdata.='QEND';
		fseek($fp,0,SEEK_END);
		$res = fwrite($fp,$qdata);
		fclose($fp);
		return $res ? true : false;
	}

	function forward($qname,$qconf,$data)
	{
		if (isset($qconf[$qname]) && $qconf[$qname]['type'] == 'local')
		{
			lqueuetool::AddToLocalQueue($qconf[$qname]['datafile'],$data,$qconf[$qname]['cmd']);
		}
	}

}
