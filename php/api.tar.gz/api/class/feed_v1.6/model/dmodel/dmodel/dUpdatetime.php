<?php
require_once 'common/commdb.php';

class dUpdatetime extends commdb
{
	protected $partition_pre = 'T';
	protected $filedpre = 'ut_';
	protected $filedspl = 'uid';
	protected $mc = null;
	public $tbpre = 'updatetime_';
	public $dbpre = 'feed_';
	protected $prid;
	protected $dbnum = 1;
	protected $tbnum = 16;
	protected $as;
	protected $basetable = 'updatetime';
	
	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_UPTIME);
	}	

	protected function getDbconfig($uids)
	{
		if($this->config&&$this->as)
		{
			$hashmap = myhash::gethashtable($this->dbpre, $this->tbpre.$this->as.'_', $uids, $this->dbnum, $this->tbnum);
			return $hashmap;
		}
		return false;
	}

	public function multiUptime($type, $uids, $time)
	{
		$res_return = array();
		if(!in_array($type, $this->config['feed_uptime_types'])) return array();
		$this->setpro('as', $type);
		$params = array('time'=>$time);
		$res = $this->multiRun('oneUptime', $uids, $params, FEED_DB_MASTER_ALIAS);
		if(!$res||!isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UPTIME])) return array();
		foreach($res as $uid=>$oneres)
		{
			if($oneres)
			{
				$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UPTIME], $this->as, $uid);
				//echo $key."\n";
				$count = 0;
				//echo $this->config['FEED_MC_TIMEOUT_UPTIME'][$this->as];
				do{
					$intomcres = $this->mc->set($key, $time, time()+$this->config['FEED_MC_TIMEOUT_UPTIME'][$this->as]);
					$count++;
				}
				while(!$intomcres&&$count<FEED_MC_REDO_UPTIME);
				//echo "redo {$count} ..\n";
				//var_dump($this->mc->get($key));
				$res_return[$uid] = $intomcres;
			}
		}
		return $res_return;
	}

	public function oneUptime($uids, $params)
	{
		$result = array();
		if(is_array($uids)&&$uids&&isset($params['time']))
		{
			foreach($uids as $uid)
			{
				$sql = "insert into `%s` (`%s`,`%s`) values('%.0f', '%d') ON DUPLICATE KEY UPDATE %s = '%d';";
				$filed_uid = $this->filedpre.'uid';
				$filed_time = $this->filedpre.'time';
				$sql = sprintf($sql, $this->tbname, $filed_uid, $filed_time, $uid, $params['time'], $filed_time, $params['time']);
				//echo $sql."\n";
				$res = $this->sampleQuery_noresult($sql);
				if($res) $result[$uid] = true;
			}
		}
		return $result;
	}
}
