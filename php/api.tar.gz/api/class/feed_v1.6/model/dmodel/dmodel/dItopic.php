<?php
require_once 'common/commdb.php';

class dItopic extends commdb
{
	const TBNAME = 'index_t';
	const TBNAME_PRE = 'it_';
	protected $mc = null;
	protected $filedpre = 'it_';
	public $tbpre = 'index_t';
	
	protected $pri = 'tid';
	protected $mc_timeout_conf = 'FEED_MC_TIMEOUT_INDEXT';
	protected $mc_redo_time = 'FEED_MC_REDO_INDEX_T';
	protected $index_filed_num = 3;
	protected $my_type_pre = 't';

	public function getDbConfig(){}

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_INDEXES);
	}
}
