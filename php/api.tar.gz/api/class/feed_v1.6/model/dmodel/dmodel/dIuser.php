<?php
require_once 'common/commdb.php';

class dIuser extends commdb
{
	const TBNAME = 'index_u';
	const TBNAME_PRE = 'iu_';
	protected $mc = null;
	protected $filedpre = 'iu_';
	public $tbpre = 'index_u';
	
	protected $pri = 'uid';
	protected $mc_timeout_conf = 'FEED_MC_TIMEOUT_INDEXU';
	protected $mc_redo_time = 'FEED_MC_REDO_INDEX_U';
	protected $index_filed_num = 3;
	protected $my_type_pre = 'u';

	public function getDbConfig(){}

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_INDEXES);
	}
}
