<?php
require_once 'common/commdb.php';

class dIquestion extends commdb
{
	const TBNAME = 'index_q';
	const TBNAME_PRE = 'iq_';
	protected $mc = null;
	protected $filedpre = 'iq_';
	public $tbpre = 'index_q';
	
	protected $pri = 'qid';
	protected $mc_timeout_conf = 'FEED_MC_TIMEOUT_INDEXQ';
	protected $mc_redo_time = 'FEED_MC_REDO_INDEX_Q';
	protected $index_filed_num = 3;
	protected $my_type_pre = 'q';
	
	public function getDbConfig(){}

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_INDEXES);
	}
}
