<?php

class commdb extends mydb
{	
	protected $partition_pre = 'P';

	public function addIndexFeed($type, $oid, $fid, $qid, $ctime)
	{
		if(in_array($type, $this->config['feed_index_types'])&&is_numeric($fid)&&is_numeric($qid)&&is_numeric($ctime))
		{
			$nowtime = time();
			$tbname = $this->tbpre.'_'.$type;
			$prifiled = $this->filedpre.$this->pri;
			$selsql = "select {$this->filedpre}fids as feed from {$tbname} where {$prifiled} = '{$oid}'";
			$info = array();
			$selres = $this->sampleQuery($selsql, $info);
			$qidfeed = $selres&&!empty($info['info']) ?$info['info'][0]['feed'] : '';
			$oldfeed = array();
			if($qidfeed)
			{
				$oldfeed = $this->unpackFeed($qidfeed, $this->index_filed_num);
				//echo "old feed \n";
				//print_r($oldfeed);
				if(is_array($oldfeed))
				{
					//删除过期的数据,删除重复qid数据,保留最新的qid的feed信息
					$outime = $this->config[$this->mc_timeout_conf][$type];
					$outimeline = $nowtime-$outime;
					foreach($oldfeed as $feedkey=>$oneoldfeed)
					{
						if(count($oneoldfeed)!=3) continue;
						$tmp_ctime = $oneoldfeed[1];
						$tmp_qid = $oneoldfeed[2];
						if($tmp_ctime<$outimeline)
						unset($oldfeed[$feedkey]);
						if($tmp_qid==$qid)
						unset($oldfeed[$feedkey]);
					}
				}
			}
			//echo "filte last feed \n";
			//print_r($oldfeed);
			unset($info);
			
			$thisfeed = array($fid, $ctime, $qid);
			$oldfeed[] = $thisfeed;
			//echo "into feed \n";
			//print_r($oldfeed);
			//打包feed为二进制数据
			$binfeed = $this->packFeed($oldfeed, $this->index_filed_num);
			if($qidfeed)
			{
				//更新feed数据
				$runsql = "update {$tbname} set {$this->filedpre}fids = '{$binfeed}' where {$prifiled} = '{$oid}'";
			}
			else
			{
				//插入feed数据
				$params = array(
						$this->pri=>$oid,
						'fids'=>$binfeed,
						);
				//print_r($params);
				$runsql = $this->madeInsertSql($tbname, $params, $this->filedpre);
			}
			//echo $runsql."\n";
			$updres = $this->sampleQuery_noresult($runsql);
			//var_dump($updres);
			if($updres==1)
			{
				$feedata = array();
				foreach($oldfeed as $tmpfeed)
				{
					isset($tmpfeed[0]) ? $feedata[] = $tmpfeed[0] : '';
				}
				//更新cache
				$cachefeed = array(
						'feedsum'=>count($oldfeed),
						'feedata'=>$feedata,
						);
				if(isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES]))
				{
					$mckeyformat = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES], $this->my_type_pre, $type, $oid);
					//echo $mckeyformat."\n";
					//echo $this->config[$this->mc_timeout_conf][$type]."\n";
					$count = 0;
					do{
						$resintomc = $this->mc->set($mckeyformat, $cachefeed, time()+$this->config[$this->mc_timeout_conf][$type]);
						$count++;
					}
					while(!$resintomc&&$count<$this->mc_redo_time);
					//echo "redo {$count}\n";
					//var_dump($this->mc->get($mckeyformat));
					//if(!$resintomc) error_log();
				}
				return true;
			}
			unset($qidfeed);
			return false;
		}
	
	}

	protected function unpackFeed($binaryfeed, $span)
	{
		$feed = array();
		$span = intval($span);
		if($span<1) return $feed;
		if(!$binaryfeed) return $feed;
		$feedarr = unpack('L*', $binaryfeed);
		$count = count($feedarr);
		if(!$count) return $feed;
		for($i=1; $i<=$count; $i++)
		{
			$tag = $i%$span;
			$tmparr[] = $feedarr[$i];
			if($tag==0||$i==$count)
			{
				$feed[] = $tmparr;
				$tmparr = array();
			}
		}
		return $feed;
	}

	protected function packFeed($feed, $span)
	{
		if(!is_array($feed)) return false;
		$binaryfeed = '';
		foreach($feed as $one)
		{
			if(count($one)!=3) continue;
			$tmp = '';
			for($i=0; $i<3; $i++)
			{
				$tmp .= pack('L', $one[$i]);
			}
			$binaryfeed .= $tmp;
		}
		return $binaryfeed;
	}


	public function delPartitionOneDay($thatdaytime, &$partition)
	{
		if($thatdaytime)
		{
			$YMD = date('Ymd', $thatdaytime);
			$partition = $this->partition_pre.$YMD;
			$sql = "alter table {$this->tbname} drop partition {$partition};";
			//echo $sql;
			$info = array();
			$this->query($sql, $info);
			if(isset($info['errcode'])&&$info['errcode']==1)
				return true;
			else
				return false;
		}
	}

	public function addPartitionOneDay($thatdaytime, &$partition)
	{
		if($thatdaytime)
		{
			$YMD = date('Ymd', $thatdaytime);
			$btime = strtotime($YMD);
			$etime = $btime+24*60*60;
			$partition = $this->partition_pre.$YMD;
			$sql = "alter table {$this->tbname} add partition ( partition {$partition} values less than ({$etime}));";
			//echo $sql;
			$info = array();
			$this->query($sql, $info);
			if(isset($info['errcode'])&&$info['errcode']==1)
				return true;
			else
				return false;
		}
	}

	public function delIndex($oids, $qids=array())
	{
		if(is_array($oids)&&!empty($oids))
		{
			$wqid = is_array($qids)&&!empty($qids) ? ' and '.$this->filedpre.'qid in '.$this->getInParams($qids) : '';
			$woid = $this->filedpre.$this->filedspl.' in '.$this->getInParams($oids);
			$sql = "delete from {$this->tbname} where {$woid} {$wqid}";
			//echo $sql;
			$info = array();
			$this->query($sql, $info);
			return ($info['errcode']==1) ? true : false;
		}
		return false;
	}

	protected function setIquestionCache($alias, $opre, $type, $oid, $redo, $tbname, $flagtime=false, $delfids=array())
	{
		if($this->mc&&$oid&&$type)
		{
			if(!isset($this->config['FEED_MC_KEYS_MAPPING'][$alias])) return false;
			if(!isset($this->config['FEED_MC_TIMEOUT_INDEXQ'][$type])) return false;
			$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][$alias], $opre, $type, (float)$oid);
			//echo "\n$key\n";
			$timeout = $this->config['FEED_MC_TIMEOUT_INDEXQ'][$type];
			//var_dump($timeout);
			$cas = '';
			$lastUpTime = time();
			$allnum = 0;
			$data = array();
			$new = array();
			$old = $this->mc->get($key, null, $cas);
			$times = $redo;
			//var_dump($old);
			if($this->mc->getResultCode() == Memcached::RES_NOTFOUND)
			{
				//没有cache数据
				//有flagtime,设置获取缓存的上限时间flagtime，没有则获得全部数据30d/10d/1d
				$fids = $this->getNoFlagTimeData($type, $oid, $flagtime, $tbname);
				rsort($fids);
				//更新到feedcache
				$new = array(
						'num'=>count($fids),
						'uptime'=>$flagtime,
						'data'=>$fids,
						);
				//print_r($new);
				$res = true;
				do
				{
					//echo $key.'-'.$timeout;
					$res = $this->mc->add($key, $new, time()+$timeout);
					if($this->mc->getResultCode()==Memcached::RES_NOTSTORED)
					{
						//如果其他地方添加了cache则添加cache失败，并不重试
						$times = 0;
					}
					$times--;
				}
				while (!$res&&$times!=0);
				//echo "\n$times\n";
				if(!$res) ;//log......
				return $res;
			}
			else
			{
				//有缓存数据
				//没有flagtime,不更新缓存直接返回
				if(!$flagtime) return false;
				//有flagtime查看缓存最后更新时间，时间正常则获得flagtime-oldtime之间的数据，补充缓存,其他返回false
				$oldtime = $old['uptime'];
				$olddata = is_array($old['data']) ? $old['data'] : array();
				if(!$oldtime||$oldtime>=$flagtime) return false;
				//有flagtime,设置获取缓存的上限时间flagtime
				$fids = $this->getFlagTimeData($type, $oid, $oldtime, $flagtime, $tbname);
				//合并缓存
				$olddata = array_diff($olddata, $delfids);
				$newdata = array_unique(array_merge($olddata, $fids));
				rsort($newdata);
				$new = array(
						'num'=>count($newdata),
						'uptime'=>$flagtime,
						'data'=>$newdata,
						);
				$res = true;
				do
				{
					$res = $this->mc->cas($cas, $key, $new, time()+$timeout);
					if($this->mc->getResultCode()==Memcached::RES_DATA_EXISTS)
					{
						//如果其他地方修改了cache则添加cache失败，并不重试
						$times = 0;
					}
					$times--;
				}
				while (!$res&&$times!=0);
				//echo "\n$times\n";
				if(!$res) ;//log......
				return $res;
			}
			return $res;
		}
		return false;
	}

	protected function setIndexNewUpTime($alias, $opre, $type, $oid, $time)
	{
		if($type&&$oid&&$time&&$this->mc)
		{
			//echo $type.'-'.$oid.'-'.$time;
			$key = $this->getMcNewUpTimeKey($alias, $opre, $type, $oid);
			//echo "\n".$key."\n";
			if(!$key) return false;
			$res = $this->mc->set($key, $time);
			return $res ? $time : false;
		}
	}

	protected function getMcNewUpTimeKey($alias, $opre, $type, $oid)
	{
		if(!in_array($type, $this->config['FEED_MC_INDEX_TBTYPE'])) return false;
		if(!isset($this->config['FEED_MC_KEYS_MAPPING'][$alias])) return false;
		$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][$alias], $opre, $type, (float)$oid);
		return $key ? $key : false;
	}

	protected function getDbconfig($indexs)
	{
	
	}

	protected function multiRun($fun, $indexs, $params, $type)
	{
		if(!method_exists($this, $fun)) return false;
		$res = array();
		$dbmap = $this->getDbconfig($indexs);
		if(is_array($dbmap)&&$dbmap&&$this->config)
		{
			foreach($dbmap as $onedb=>$tbmap)
			{
				if($tbmap)
				{
					foreach($tbmap as $onetb=>$oids)
					{
						if(!isset($this->config['feed_db_dblist'][$onedb][$type])) continue;
						$tmpdbconf = $this->config['feed_db_dblist'][$onedb][$type];
						$tmpdbconf['tbname'] = $onetb;
						$this->setdbconf($tmpdbconf);
						$this->createtb($onetb, $this->basetable);
						$tmpres = $this->$fun($oids, $params);
						foreach($oids as $oid)
						{
							$res[$oid] = isset($tmpres[$oid]) ? $tmpres[$oid] : false;
						}
					}
				}
			}
		}
		return $res;
	}

	protected function createtb($tb, $btb)
	{
		$sql = "create table {$tb} like {$btb}";
		$this->sampleQuery_noresult($sql);
	}
}
