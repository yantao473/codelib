<?php
require_once 'common/commdb.php';

class dFeedata extends commdb
{
	const TBNAME = 'feedata_v1';
	const TBNAME_PRE = 'fd_';
	const MY_MC_ALIAS = FEED_MC_ALIAS_FEEDATA;
	protected $partition_pre = 'F';
	private $mc = null;

	public function getDbConfig(){}

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(self::MY_MC_ALIAS);
	}

	public function addFeedata($fdata, $ctime)
	{
		if(is_array($fdata)&&!empty($fdata))
		{
			$format = serialize($fdata);
			$params = array(
					'data'=>serialize($fdata),
					'filte'=>md5($format),
					'ctime'=>$ctime,
					);
			$sql = $this->madeInsertSql($this->tbname, $params, self::TBNAME_PRE);
			echo $sql."\n";
			//return $sql ? $this->sampleInsert_noresult($sql) : false;	
			$info = array();
			$this->query($sql, $info);
			if($info['errcode']==1&&!empty($info['insertid']))
			{
				$fid = $info['insertid'];
				$this->setFeedataCache($fid, $fdata);
				return $info['insertid'];
			}
			return false;
		}
		return false;
	}

	public function selFilteFeed($fdata)
	{
		if(is_array($fdata)&&!empty($fdata))
		{
			$info = array();
			$format = md5(serialize($fdata));
			$sql = "select fd_fid as fid, fd_data as data from ".self::TBNAME." where fd_filte = '{$format}'";
			echo $sql;
			$this->query($sql, $info);
			if($info['errcode']==1&&!empty($info['info']))
			{
				return $info['info'];
			}
		}
		return false;
	}

	private function setFeedataCache($fid, $fdata)
	{
		if($this->mc&&$fid&&$fdata)
		{
			if(!isset($this->config['FEED_MC_KEYS_MAPPING'][self::MY_MC_ALIAS])) return false;
			$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][self::MY_MC_ALIAS], (float)$fid);
			$time = FEED_MC_REDO_FEEDATA;
			echo 'feedata_v1 key is '.$key."\n";
			do
			{
				$res = $this->mc->set($key, $fdata, time()+FEED_MC_TIMEOUT_FEEDATA);
				$time--;
			}
			while (!$res&&$time!=0);
			return $res;
		}
		return false;
	}

	private function delFeedataCache($fid)
	{
		if($this->mc&&$fid)
		{
			if(!isset($this->config['FEED_MC_KEYS_MAPPING'][self::MY_MC_ALIAS])) return false;
			$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][self::MY_MC_ALIAS], (float)$fid);
			$time = FEED_MC_REDO_FEEDATA;
			do
			{
				$res = $this->mc->delete($key);
				$time--;
			}
			while (!$res&&$time!=0);
			return $res;
		}
		return false;
	}
}
