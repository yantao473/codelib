<?php
require_once 'common/commdb.php';

class dIquestion extends commdb
{
	const TBNAME = 'index_q';
	const TBNAME_PRE = 'iq_';
	protected $mc = null;
	protected $filedpre = 'iq_';
	public $tbpre = 'index_q';
	
	protected $dbpre = 'feedindex_1_';
	protected $pri = 'qid';
	protected $mc_timeout_conf = 'FEED_MC_TIMEOUT_INDEXQ';
	protected $mc_redo_time = 'FEED_MC_REDO_INDEX_Q';
	protected $index_filed_num = 4;
	protected $my_type_pre = 'q';
	protected $time_post;
	protected $dbnum;
	protected $tbnum;
	protected $conftag = FEED_DB_TAG_FEEDINDEX_Q;

	public function getDbConfig($qids)
	{
		if($this->config&&$this->time_post)
		{
			$hashmap = myhash::gethashtable_aveg($this->dbpre, $this->tbpre.$this->time_post.'_', $qids, $this->dbnum, $this->tbnum);
			return $hashmap;
		}
		return false;
	}

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_INDEXES);
		//set dbmap
		$this->confInit();
	}
}
