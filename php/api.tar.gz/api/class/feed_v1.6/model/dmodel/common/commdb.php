<?php
class commdb extends mydb
{	
	protected $partition_pre = 'P';

	public function selIndexFeed($type, $oids)
	{
		if(!in_array($type, $this->config['feed_index_types'])||!is_array($oids)||!$oids) return false;
		$feed_mc = $this->selIndexFeedFromMc($type, $oids);
		//echo "mc中的索引数据\n";
		//var_dump($feed_mc);
		//$feed_mc = false;
		$oid_from_mc = $feed_mc ? array_keys($feed_mc) : array();
		$oid_from_mc_nohave = array_diff($oids, $oid_from_mc);
		//print_r($oid_from_mc_nohave);
		$feed_mysql = $oid_from_mc_nohave ? $this->selIndexFeedFromMysql($type, $oid_from_mc_nohave) : array();
		$feed_mc = $feed_mc ? $feed_mc : array();
		$feed_mysql = $feed_mysql ? $feed_mysql : array();
		$mcdata = array();
		if($feed_mysql)
		{
			foreach($feed_mysql as $oneoid=>$binaryfeed)
			{
				if(!$binaryfeed) continue;
				$newfeed = $this->unpackFeed($binaryfeed, $this->index_filed_num);
				if(!is_array($newfeed)) continue;
				$fids = array();
				foreach($newfeed as $feedkey=>$onefeed)
				{
					if(count($onefeed)!=$this->index_filed_num) continue;
					$tmpqid = strval($onefeed[1]);
					$fids[$tmpqid] = sprintf('%08s', $onefeed[2]).sprintf('%08s', $onefeed[3]);
				}
				//print_r($fids);
				//add to mc
				$addres = $this->setIndexMc($fids, $type, $oneoid, 'add');
				$mcdata[$oneoid] = array('feedsum'=>count($fids), 'feedata'=>$fids);
			}

		}
		//mysql中的uid
		$uids_mysql = array_keys($feed_mysql);
		//不在mc和mysql中的uid
		$uids_no_in_feed = array_diff($oid_from_mc_nohave, $uids_mysql);
		if($uids_no_in_feed)
		{
			foreach($uids_no_in_feed as $oneoid)
			{
				$this->setIndexMc(array(), $type, $oneoid, 'add');
			}
		}

		foreach($oids as $tmpoid)
		{
			if(isset($feed_mc[$tmpoid]))
			{
				$result[$tmpoid] = $feed_mc[$tmpoid];
			}
			if(isset($mcdata[$tmpoid]))
			{
				$result[$tmpoid] = $mcdata[$tmpoid];
			}
		}
		//print_r($result);
		//$result = array_merge($feed_mc, $mcdata);
		//print_r($feed_mc);
		//print_r($feed_mysql);
		return $result;
	}

	public function setIndexMc($feedata, $type, $oid, $addtype)
	{
		$resintomc = false;
		//更新cache
		$cachefeed = array(
				'feedsum'=>count($feedata),
				'feedata'=>$feedata,
				);
		if(isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES]))
		{
			$mckeyformat = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES], $this->my_type_pre, $type, $oid);
			//echo $mckeyformat."\n";
			//echo $this->config[$this->mc_timeout_conf][$type]."\n";
			$count = 0;
			do
			{
				if($addtype=='set')
				$resintomc = $this->mc->set($mckeyformat, $cachefeed, time()+$this->config[$this->mc_timeout_conf][$type]);
				elseif($addtype=='add')
				$resintomc = $this->mc->add($mckeyformat, $cachefeed, time()+$this->config[$this->mc_timeout_conf][$type]);
				else
				return false;
				$count++;
			}
			while(!$resintomc&&$count<$this->mc_redo_time);
			//echo "set Index mc redo {$count} ...... \n";
			//var_dump($this->mc->get($mckeyformat));
		}
		return $resintomc;
	}

	public function selIndexFeedFromMysql($type, $oids, $chunknum=1000)
	{
		if(!in_array($type, $this->config['feed_index_types'])||!is_array($oids)||!$oids) return false;
		//echo "实际的数据库连接信息\n";
		$oid_section = array_chunk($oids, $chunknum);
		if(!$oid_section) return false;
		$prifiled = $this->filedpre.$this->pri;
		$feeds = array();
		foreach($oid_section as $onesection)
		{
			$info = array();
			$wherein = $this->getInParams($onesection);
			if(!$wherein) continue;
			$selsql = "select {$this->filedpre}fids as feeds, {$this->filedpre}{$this->pri} as oid from {$this->tbname} where {$prifiled} in {$wherein}";
			//echo $selsql;
			$selres = $this->sampleQuery($selsql, $info);
			$feedres = $selres&&!empty($info['info']) ? $info['info'] : '';
			if($feedres)
			{
				foreach($feedres as $onefeed)
				{
					$oid_tmp = $onefeed['oid'];
					$feeds_tmp = $onefeed['feeds'];
					$feeds[$oid_tmp] = $feeds_tmp;
				}
			}
		}
		return $feeds;
	}

	public function selIndexFeedFromMc($type, $oids)
	{
		if(!in_array($type, $this->config['feed_index_types'])||!is_array($oids)||!$oids) return false;
		if(!$this->mc) return false;
		if(isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES]))
		{
			$mckeyformat = array();
			$selectuid = array();
			foreach($oids as $oid)
			{
				$oid = sprintf('%.0f', trim($oid));
				if($oid>0)
				{
					$tmpmckey = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES], $this->my_type_pre, $type, $oid);
					if(!$tmpmckey) continue;
					$mckeyformat[] = $tmpmckey;
					$selectuid[$tmpmckey] = $oid;
				}
			}
			if(!$selectuid) return false;
			$resintomc = array();
			$count = 0;
			$cas = '';
			//print_r($mckeyformat);
			do{
				$resintomc = $this->mc->getMulti($mckeyformat, $cas);
				$count++;
			}
			while(!$resintomc&&$count<$this->mc_redo_time);
			//if(!$resintomc)
			//echo "index mc 没有找到数据 alias is ".FEED_MC_ALIAS_INDEXES."\n";
			//echo "redo {$count}\n";
			if(!$resintomc) return false;
			$result = array();
			foreach($resintomc as $mckeyone=>$mcvalueone)
			{
				if(!in_array($mckeyone, $mckeyformat)) continue;
				$tmpoid = $selectuid[$mckeyone];
				$result[$tmpoid] = $mcvalueone;
			}
			return $result;
		}
	}

	public function addIndexFeed($type, $oid, $fid, $qid, $ctime)
	{
		if(in_array($type, $this->config['feed_index_types'])&&is_numeric($fid)&&is_numeric($qid)&&is_numeric($ctime))
		{
			$nowtime = time();
			$tbname = $this->tbpre.'_'.$type;
			$prifiled = $this->filedpre.$this->pri;
			$selsql = "select {$this->filedpre}fids as feed from {$tbname} where {$prifiled} = '{$oid}'";
			$info = array();
			$selres = $this->sampleQuery($selsql, $info);
			$qidfeed = $selres&&!empty($info['info']) ?$info['info'][0]['feed'] : '';
			$oldfeed = array();
			if($qidfeed)
			{
				$oldfeed = $this->unpackFeed($qidfeed, $this->index_filed_num);
				//echo "old feed \n";
				//print_r($oldfeed);
				if(is_array($oldfeed))
				{
					//删除过期的数据,删除重复qid数据,保留最新的qid的feed信息
					$outime = $this->config[$this->mc_timeout_conf][$type];
					$outimeline = $nowtime-$outime;
					foreach($oldfeed as $feedkey=>$oneoldfeed)
					{
						if(count($oneoldfeed)!=3) continue;
						$tmp_ctime = $oneoldfeed[1];
						$tmp_qid = $oneoldfeed[2];
						if($tmp_ctime<$outimeline)
							unset($oldfeed[$feedkey]);
						if($tmp_qid==$qid)
							unset($oldfeed[$feedkey]);
					}
				}
			}
			//echo "filte last feed \n";
			//print_r($oldfeed);
			unset($info);

			$thisfeed = array($fid, $ctime, $qid);
			$oldfeed[] = $thisfeed;
			//echo "into feed \n";
			//print_r($oldfeed);
			//打包feed为二进制数据
			$binfeed = $this->packFeed($oldfeed, $this->index_filed_num);
			if($qidfeed)
			{
				//更新feed数据
				$runsql = "update {$tbname} set {$this->filedpre}fids = '{$binfeed}' where {$prifiled} = '{$oid}'";
			}
			else
			{
				//插入feed数据
				$params = array(
						$this->pri=>$oid,
						'fids'=>$binfeed,
						);
				//print_r($params);
				$runsql = $this->madeInsertSql($tbname, $params, $this->filedpre);
			}
			//echo $runsql."\n";
			$updres = $this->sampleQuery_noresult($runsql);
			//var_dump($updres);
			if($updres==1)
			{
				$feedata = array();
				foreach($oldfeed as $tmpfeed)
				{
					isset($tmpfeed[0]) ? $feedata[] = $tmpfeed[0] : '';
				}
				//更新cache
				$cachefeed = array(
						'feedsum'=>count($feedata),
						'feedata'=>$feedata,
						);
				if(isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES]))
				{
					$mckeyformat = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_INDEXES], $this->my_type_pre, $type, $oid);
					//echo $mckeyformat."\n";
					//echo $this->config[$this->mc_timeout_conf][$type]."\n";
					$count = 0;
					do{
						$resintomc = $this->mc->set($mckeyformat, $cachefeed, time()+$this->config[$this->mc_timeout_conf][$type]);
						$count++;
					}
					while(!$resintomc&&$count<$this->mc_redo_time);
					//echo "redo {$count}\n";
					//var_dump($this->mc->get($mckeyformat));
					//if(!$resintomc) error_log();
				}
				return true;
			}
			unset($qidfeed);
			return false;
		}

	}

	protected function unpackFeed($binaryfeed, $span)
	{
		$feed = array();
		$span = intval($span);
		if($span<1) return $feed;
		if(!$binaryfeed) return $feed;
		$feedarr = unpack('L*', $binaryfeed);
		$count = count($feedarr);
		if(!$count) return $feed;
		for($i=1; $i<=$count; $i++)
		{
			$tag = $i%$span;
			$tmparr[] = $feedarr[$i];
			if($tag==0||$i==$count)
			{
				$feed[] = $tmparr;
				$tmparr = array();
			}
		}
		return $feed;
	}

	protected function packFeed($feed, $span)
	{
		if(!is_array($feed)) return false;
		$binaryfeed = '';
		foreach($feed as $one)
		{
			if(count($one)!=$span) continue;
			$tmp = '';
			for($i=0; $i<$span; $i++)
			{
				$tmp .= pack('L', $one[$i]);
			}
			$binaryfeed .= $tmp;
		}
		return $binaryfeed;
	}
	//废弃，采用分表方式替代分区方式
	public function delPartitionOneDay($thatdaytime, &$partition)
	{
		if($thatdaytime)
		{
			$YMD = date('Ymd', $thatdaytime);
			$partition = $this->partition_pre.$YMD;
			$sql = "alter table {$this->tbname} drop partition {$partition};";
			//echo $sql;
			$info = array();
			$this->query($sql, $info);
			if(isset($info['errcode'])&&$info['errcode']==1)
				return true;
			else
				return false;
		}
	}
	//废弃，采用分表方式替代分区方式
	public function addPartitionOneDay($thatdaytime, &$partition)
	{
		if($thatdaytime)
		{
			$YMD = date('Ymd', $thatdaytime);
			$btime = strtotime($YMD);
			$etime = $btime+24*60*60;
			$partition = $this->partition_pre.$YMD;
			$sql = "alter table {$this->tbname} add partition ( partition {$partition} values less than ({$etime}));";
			//echo $sql;
			$info = array();
			$this->query($sql, $info);
			if(isset($info['errcode'])&&$info['errcode']==1)
				return true;
			else
				return false;
		}
	}
	//废弃，老版的index删除方式
	public function delIndex($oids, $qids=array())
	{
		if(is_array($oids)&&!empty($oids))
		{
			$wqid = is_array($qids)&&!empty($qids) ? ' and '.$this->filedpre.'qid in '.$this->getInParams($qids) : '';
			$woid = $this->filedpre.$this->filedspl.' in '.$this->getInParams($oids);
			$sql = "delete from {$this->tbname} where {$woid} {$wqid}";
			//echo $sql;
			$info = array();
			$this->query($sql, $info);
			return ($info['errcode']==1) ? true : false;
		}
		return false;
	}
	//废弃，老版的index缓存更新
	protected function setIquestionCache($alias, $opre, $type, $oid, $redo, $tbname, $flagtime=false, $delfids=array())
	{
		if($this->mc&&$oid&&$type)
		{
			if(!isset($this->config['FEED_MC_KEYS_MAPPING'][$alias])) return false;
			if(!isset($this->config['FEED_MC_TIMEOUT_INDEXQ'][$type])) return false;
			$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][$alias], $opre, $type, (float)$oid);
			//echo "\n$key\n";
			$timeout = $this->config['FEED_MC_TIMEOUT_INDEXQ'][$type];
			//var_dump($timeout);
			$cas = '';
			$lastUpTime = time();
			$allnum = 0;
			$data = array();
			$new = array();
			$old = $this->mc->get($key, null, $cas);
			$times = $redo;
			//var_dump($old);
			if($this->mc->getResultCode() == Memcached::RES_NOTFOUND)
			{
				//没有cache数据
				//有flagtime,设置获取缓存的上限时间flagtime，没有则获得全部数据30d/10d/1d
				$fids = $this->getNoFlagTimeData($type, $oid, $flagtime, $tbname);
				rsort($fids);
				//更新到feedcache
				$new = array(
						'num'=>count($fids),
						'uptime'=>$flagtime,
						'data'=>$fids,
						);
				//print_r($new);
				$res = true;
				do
				{
					//echo $key.'-'.$timeout;
					$res = $this->mc->add($key, $new, time()+$timeout);
					if($this->mc->getResultCode()==Memcached::RES_NOTSTORED)
					{
						//如果其他地方添加了cache则添加cache失败，并不重试
						$times = 0;
					}
					$times--;
				}
				while (!$res&&$times!=0);
				//echo "\n$times\n";
				if(!$res) ;//log......
				return $res;
			}
			else
			{
				//有缓存数据
				//没有flagtime,不更新缓存直接返回
				if(!$flagtime) return false;
				//有flagtime查看缓存最后更新时间，时间正常则获得flagtime-oldtime之间的数据，补充缓存,其他返回false
				$oldtime = $old['uptime'];
				$olddata = is_array($old['data']) ? $old['data'] : array();
				if(!$oldtime||$oldtime>=$flagtime) return false;
				//有flagtime,设置获取缓存的上限时间flagtime
				$fids = $this->getFlagTimeData($type, $oid, $oldtime, $flagtime, $tbname);
				//合并缓存
				$olddata = array_diff($olddata, $delfids);
				$newdata = array_unique(array_merge($olddata, $fids));
				rsort($newdata);
				$new = array(
						'num'=>count($newdata),
						'uptime'=>$flagtime,
						'data'=>$newdata,
						);
				$res = true;
				do
				{
					$res = $this->mc->cas($cas, $key, $new, time()+$timeout);
					if($this->mc->getResultCode()==Memcached::RES_DATA_EXISTS)
					{
						//如果其他地方修改了cache则添加cache失败，并不重试
						$times = 0;
					}
					$times--;
				}
				while (!$res&&$times!=0);
				//echo "\n$times\n";
				if(!$res) ;//log......
				return $res;
			}
			return $res;
		}
		return false;
	}

	protected function setIndexNewUpTime($alias, $opre, $type, $oid, $time)
	{
		if($type&&$oid&&$time&&$this->mc)
		{
			//echo $type.'-'.$oid.'-'.$time;
			$key = $this->getMcNewUpTimeKey($alias, $opre, $type, $oid);
			//echo "\n".$key."\n";
			if(!$key) return false;
			$res = $this->mc->set($key, $time);
			return $res ? $time : false;
		}
	}

	protected function getMcNewUpTimeKey($alias, $opre, $type, $oid)
	{
		if(!in_array($type, $this->config['FEED_MC_INDEX_TBTYPE'])) return false;
		if(!isset($this->config['FEED_MC_KEYS_MAPPING'][$alias])) return false;
		$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][$alias], $opre, $type, (float)$oid);
		return $key ? $key : false;
	}

	protected function getDbconfig($indexs)
	{

	}

	protected function multiRun($fun, $indexs, $params, $type)
	{
		if(!method_exists($this, $fun)) return false;
		$res = array();
		$dbmap = $this->getDbconfig($indexs);
		//print_r($dbmap);
		if(is_array($dbmap)&&$dbmap&&$this->config)
		{
			foreach($dbmap as $onedb=>$tbmap)
			{
				if($tbmap)
				{
					$dbconf = $this->getDbServerInfo($onedb, $type);
					if(!$dbconf) continue;
					$dbconf['dbname'] = $onedb;

					foreach($tbmap as $onetb=>$oids)
					{
						$dbconf['tbname'] = $onetb;
						//echo $fun."\n";
						$this->setdbconf($dbconf);
						//$this->createtb($onetb, $this->basetable);
						$tmpres = $this->$fun($oids, $params);
						foreach($oids as $oid)
						{
							$res[$oid] = isset($tmpres[$oid]) ? $tmpres[$oid] : false;
						}
					}
				}
			}
		}
		return $res;
	}

	public function confInit()
	{
		if(!$this->config||!isset($this->config['feed_db_app_mapping'][$this->conftag])) return false;
		$myconfig = $this->config['feed_db_app_mapping'][$this->conftag];
		//init
		isset($myconfig['dbnum']) ? $this->dbnum = $myconfig['dbnum'] : '';
		isset($myconfig['tbnum']) ? $this->tbnum = $myconfig['tbnum'] : '';
		isset($myconfig['dbmap']) ? $this->dbmap = $myconfig['dbmap'] : '';
	}

	protected function createtb($tb, $btb)
	{
		$sql = "create table {$tb} like {$btb}";
		$this->sampleQuery_noresult($sql);
	}

	public function getDbServerInfo($dbname, $type)
	{
		if(!isset($this->dbmap[$dbname])) return false;
		$app = $this->dbmap[$dbname];
		if(!isset($this->config['feed_db_app_list'][$app][$type])) return false;
		$serverid = $this->config['feed_db_app_list'][$app][$type];
		//print_r($serverid);
		$dbconf = false;
		if($type==FEED_DB_MASTER_ALIAS&&isset($this->config['feed_db_servers'][$serverid]))
		{
			$dbconf = $this->config['feed_db_servers'][$serverid];
		}
		else
		if($type==FEED_DB_SLVAER_ALIAS&&is_array($serverid)&&$serverid)
		{
			$whatidkey = array_rand($serverid);
			$whatid = $serverid[$whatidkey];
			//echo $whatid."\n";
			if(isset($this->config['feed_db_servers'][$whatid]))
			$dbconf = $this->config['feed_db_servers'][$whatid];
		}
		return $dbconf;
	}
}
