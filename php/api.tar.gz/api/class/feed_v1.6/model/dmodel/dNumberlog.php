<?php
require_once 'common/commdb.php';

class dNumberlog extends commdb
{
	protected $filedpre = 'nb_';
	protected $mc = null;
	protected $pri = 'id';
	protected $tbname = 'numberlog';

	public function init()
	{
		//..
	}	

	public function createUniqNum($dateinfo)
	{
		if(!$dateinfo) return false;
		$dateinfo = intval($dateinfo);
		$params = array(
				'dateinfo'=>$dateinfo,
				);
		$sql = $this->madeInsertSql($this->tbname, $params, $this->filedpre);
		if(!$sql) return false;
		$insertid = $this->sampleInsert_noresult($sql);
		return $insertid ? $insertid : false;
	}
}
