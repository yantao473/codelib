<?php
require_once 'common/commdb.php';

class dFeedata extends commdb
{
	const TBNAME = 'feedata_v1';
	const TBNAME_PRE = 'fd_';
	const MY_MC_ALIAS = FEED_MC_ALIAS_FEEDATA;
	protected $partition_pre = 'F';
	private $mc = null;
	private $maxin = 100;

	protected $tbpre = 'feedata_v1_';
	protected $dbpre = 'feedata_1_';
	protected $pri = 'fid';
	protected $dbnum = 1;
	protected $tbnum = 1;
	protected $basetable = 'feedata_v1';
	protected $conftag = FEED_DB_TAG_FEEDATA;

	public function getDbConfig(){}

	public function getDbAndTbName($timetag)
	{
		if(!$this->dbmap||!$this->tbpre||!$this->dbpre) return false;
		$tbname = $this->tbpre.$timetag;
		$dbname = $this->dbpre.'00';
		return array('tbname'=>$tbname, 'dbname'=>$dbname);
	}

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(self::MY_MC_ALIAS);
		//set dbmap
		$this->confInit();
	}

	public function addFeedata($fid, $fdata, $ctime)
	{
		if(strlen($fid)==16&&is_array($fdata)&&!empty($fdata))
		{
			$format = serialize($fdata);
			$params = array(
					'fid'=>$fid,
					'data'=>serialize($fdata),
					'filte'=>md5($format),
					'ctime'=>$ctime,
					);
			$sql = $this->madeInsertSql($this->tbname, $params, self::TBNAME_PRE);
			//echo $sql."\n";
			//return $sql ? $this->sampleInsert_noresult($sql) : false;	
			$info = array();
			$info = $this->sampleQuery_noresult($sql);
			if($info!==false)
			{
				$this->setFeedataCache($fid, $fdata);
				return true;
			}
			return false;
		}
		return false;
	}

	public function getFeedataMulti($fids)
	{
		$result = array();
		if(is_array($fids)&&!empty($fids))
		{
			$cachedata = $this->getFeedataCache($fids);
			$cachedata = $cachedata==false ? array() : $cachedata;
			//print_r($cachedata);
			$needselmysqlfid = !$cachedata ? $fids : array_diff($fids, array_keys($cachedata));
			if($needselmysqlfid)
			{
				//echo "需要从mysql中查的数据\n";
				//print_r($needselmysqlfid);
				//print_r($this->dbconf);
				$mysqldata = $this->selFeedata($needselmysqlfid);
				//print_r($mysqldata);
				$mysqldata = $mysqldata==false ? array() : $mysqldata;
				foreach($mysqldata as $fid=>$fdata)
				$this->setFeedataCache($fid, $fdata);
				//echo "mysql中查的数据\n";
				//print_r($mysqldata);
				$result = $mysqldata + $cachedata;
			}
			else
			{
				$result = $cachedata;
			}
		}
		if($result) krsort($result);
		return $result;
	}

	public function selFilteFeed($fdata)
	{
		if(is_array($fdata)&&!empty($fdata))
		{
			$info = array();
			$format = md5(serialize($fdata));
			$sql = "select fd_fid as fid, fd_data as data from ".self::TBNAME." where fd_filte = '{$format}'";
			//echo $sql;
			$this->query($sql, $info);
			if($info['errcode']==1&&!empty($info['info']))
			{
				return $info['info'];
			}
		}
		return false;
	}

	public function selFeedata($fids)
	{
		if(is_array($fids)&&!empty($fids))
		{
			$result = array();
			$groupfids = array();
			foreach($fids as $onefid)
			{
				if(strlen($onefid)!=16) continue;
				$grouptag = substr($onefid, 0, 6);
				$groupfids[$grouptag][] = $onefid;
			}
			if(!$groupfids) return $result;
			$sql = '';
			$countnum = 1;
			$countit = count($groupfids);
			foreach($groupfids as $gk=>$gfids)
			{
				$onefids_str = $this->getInParams($gfids);
				$sql .= "select fd_fid as fid, fd_data as data from ".$this->tbpre.$gk." where fd_fid in {$onefids_str} ";
				if($countnum<$countit)
				$sql .= 'UNION ALL ';
				$countnum++;
			}
			$info = array();
			$this->sampleQuery($sql, $info);
			if(!empty($info['info']))
			{
				foreach($info['info'] as $onedata)
				{
					$fid = $onedata['fid'];
					$result[$fid] = unserialize(htmlspecialchars_decode($onedata['data']));
				}
			}
			//print_r($result);
			//echo $sql;
			/*
			$inres = array_chunk($fids, $this->maxin);
			foreach($inres as $onefids)
			{
				$onefids_str = $this->getInParams($onefids);
				//$this->query($sql, $info);
				//print_r($info);
			}
			*/
			return $result;
		}
		return false;
	}

	private function getFeedataCache($fids)
	{
		if($this->mc&&is_array($fids)&&!empty($fids))
		{
			$result = array();
			$mckeys = array();
			foreach($fids as $arrkey=>$fid)
			{
				$tmpkey= $this->getMcKey($fid);
				if(!$tmpkey) continue;
				$mckeys[$arrkey] = $tmpkey;
			}
			//$abc = $this->mc->get('mc_feedata_1751');
			if($mckeys)
			{
				$time = FEED_MC_REDO_FEEDATA;
				do
				{
					$res = $this->mc->getMulti($mckeys, $cas);
					$time--;
				}
				while (!$res&&$time!=0);
				//if(!$res)
				//echo "feedata mc 中没有数据, alias is ".self::MY_MC_ALIAS."\n";
				//echo "从feedata中拿到的数据\n";
				//var_dump($res);
				if(!$res) return false;
				foreach($res as $tmpmckey=>$tmpdata)
				{
					$tmpindex = array_search($tmpmckey, $mckeys);
					if($tmpindex===false) continue;
					$fid = $fids[$tmpindex];
					if(!$fid) continue;
					$result[$fid] = $tmpdata;
				}
			}
			return $result;
		}
		return false;
	}

	private function setFeedataCache($fid, $fdata)
	{
		if($this->mc&&$fid&&$fdata)
		{
			$key = $this->getMcKey($fid);
			if(!$key) return false;
			$time = FEED_MC_REDO_FEEDATA;
			//echo 'feedata_v1 key is '.$key."\n";
			do
			{
				$res = $this->mc->set($key, $fdata, time()+FEED_MC_TIMEOUT_FEEDATA);
				$time--;
			}
			while (!$res&&$time!=0);
			return $res;
		}
		return false;
	}

	private function delFeedataCache($fid)
	{
		if($this->mc&&$fid)
		{
			$key = $this->getMcKey($fid);
			if(!$key) return false;
			$time = FEED_MC_REDO_FEEDATA;
			do
			{
				$res = $this->mc->delete($key);
				$time--;
			}
			while (!$res&&$time!=0);
			return $res;
		}
		return false;
	}

	private function getMcKey($fid)
	{
		if($fid)
		{
			if(!isset($this->config['FEED_MC_KEYS_MAPPING'][self::MY_MC_ALIAS])) return false;
			$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][self::MY_MC_ALIAS], (float)$fid);
			return $key ? $key : false;
		}
		return false;
	}
}
