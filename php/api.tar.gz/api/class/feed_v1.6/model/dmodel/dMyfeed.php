<?php
require_once 'common/commdb.php';

class dMyfeed extends commdb
{
	protected $mc = null;
	public $tbpre = 'updatetime_';
	public $dbpre = 'feed_';
	protected $pri = 'oid';
	protected $basetable = 'updatetime';
	protected $chunknum = 1000;
	protected $minnum = 20;
	protected $mcalias = FEED_MC_ALIAS_MYFEED;
	protected $mcalias_oth = FEED_MC_ALIAS_MYFEED_OTH;
	protected $redisalias = FEED_REDIS_ALIAS_MYFEED;
	protected $redotimes = FEED_MC_REDO_MYFEED_SEL;
	protected $timeout = FEED_MC_TIMEOUT_MYFEED;
	protected $mcmaxlen;
	protected $mctype;
	protected $timeInterval = 6;//second
	protected $feedapi = 'http://feed.iask.sina.com.cn/api/event.php';

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		ModelFactory::getModel('lmyredis','l',1);
		$this->mc = lmymc::getNormalMc($this->mcalias);
		$this->dUpdatetime = ModelFactory::getModel('dUpdatetime', 'd', 1);
		$this->dIusertofeed = ModelFactory::getModel('dIusertofeed', 'd', 1);
		$this->mcmaxlen = isset($config['FEED_MC_ARR_MAXLEN'][$this->mcalias]) ? $config['FEED_MC_ARR_MAXLEN'][$this->mcalias] : 2000;
	}

	public function reloadMc() {
		$this->mc = lmymc::getNormalMc($this->mcalias_oth);
	}

	public function getMyfeedUp($oid, $atts, $atts_time, $fid=null, $span=20)
	{
		$mctypealias = count($atts)==1 ? array_pop(array_keys($atts)): 'max';
		//var_dump($this->config);
		$mctype = isset($this->config['FEED_MC_MYFEED_TYPE'][$mctypealias]) ? $this->config['FEED_MC_MYFEED_TYPE'][$mctypealias] : null;
		if(is_null($mctype)) return false;
		$oid = strval($oid);
		$mcfeeds = $this->multiSelMyfeedFromMc(array($oid), $mctype);
		//print_r($mcfeeds);
		//mc检索失败则redis中取,mcres=array() or false, 或者为临时数据版本A
		$needup = true;
		//$mcfeeds['feedata']['v'] = 'A';
		//$mcfeeds = array();
		$oid_mc_key = $this->getMckey(array($oid), $mctype);
		$mymckey = array_pop(array_keys($oid_mc_key));
		if(!$mcfeeds||(isset($mcfeeds['feedata'][$mymckey]['v'])&&$mcfeeds['feedata'][$mymckey]['v']=='A')) {
			$myfeed_redis = $this->getMyfeedredis($oid, $mymckey);
			//var_dump($myfeed_redis);
			$needup = $myfeed_redis['needup'];
			//如果redis中的数据不为空，则以此为准，否则以mc为准，无论mc中是否有数据
			$mcfeeds = empty($myfeed_redis['mcfeeds']) ? ($needup ? array() : $mcfeeds) : $myfeed_redis['mcfeeds'];
		}
		//print_r($mcfeeds);
		//var_dump($needup);
		//print_r($mcfeeds);
		//对象oid所产生的feed,需要去重
		$fidFromMe = $this->dIusertofeed->multiGetIndex(array($oid));
		$fidFromMe = isset($fidFromMe[$oid]) ? $fidFromMe[$oid] : array();
		//缓存中不存在feed数据则取一下所有人的1day数据，放在mc中;
		//若存在，则根据lastimeline查询到有更新的对象
		$timeline = time();
		$cachefeed = array();
		$spanmyfeed = array();
		//print_r($mcfeeds);
		if(empty($mcfeeds))
		{
			//echo "数据库去读取\n";
			//print_r($atts);
			$whichmc = '';
			$chunkedres = $this->chunkOidWithUpdatetime($atts, $timeline);
			//print_r($chunkedres);
			$minnum = $span>$this->minnum ? $span : $this->minnum;
			$thismyfeed = $this->getMyfeedNeed($chunkedres, $minnum, array('1d', '10d', '30d'), $whichmc);
			//filte feed create by me
			$thismyfeed = $fidFromMe&&$thismyfeed ? array_diff($thismyfeed, $fidFromMe) : $thismyfeed;
			//根据参数取定量的数据,同时完成数据的排序
			$fristimeline = abs( $timeline-$this->config['feed_index_types_sec'][$whichmc] );
			//add to mc
			//$thismyfeed = array();
			$cachefeed = $this->getMyfeedCacheDataStatus($thismyfeed, $timeline, $fristimeline);
			//print_r($cachefeed);
			if($cachefeed) {
				//看数据库是否可靠,不可靠数据标记为A,不可靠数据不更新redis
				if(!$needup) {
					$cachefeed['v'] = 'A';
					//set
				}
				if($needup) {
					//更新redis
					$upredis = $this->updateRedisMyfeed($oid, $cachefeed);
				}
				//print_r($cachefeed);
				$addres = $this->addMyfeedToMc($oid, $mctype, $cachefeed);
			}
		}
		else
		{
			$mymckey = array_pop(array_keys($mcfeeds['oidsmap']));
			if($mymckey)
			{
				$mymcas = $mcfeeds['mcases'][$mymckey];
				$oldmcfeed = $mcfeeds['feedata'][$mymckey];
				$oldlastime = $oldmcfeed['lastimeline'];
				$oldfristime = $oldmcfeed['fristimeline'];
				$oldfeednums = $oldmcfeed['nums'];
				$oldfeeds = $oldmcfeed['feeds'];
				if($timeline>$oldlastime&&($timeline-$oldlastime)>$this->timeInterval)
				{
				//大于timeInterval则去获得新的数据，防刷，同时防止遗漏动态
				//echo "*********old mc feed data********\n";
				//print_r($oldmcfeed);
				//获得新关注的对象，必须更新的对象Oid
				$must_update_oid = $this->getOidNewAtt($atts_time, $oldlastime);
				//处理一下atts
				$have_update_oid = $this->getOidHaveNewUpdate($atts, $oldlastime, $must_update_oid);
				//echo "if have update oid ?\n";
				//print_r($have_update_oid);
				$newmyfeed = array();
				//print_r($have_update_oid);
				if($have_update_oid)
				{
					$whichmc = '';
					$wheremc = $this->getWheremc($timeline, $oldlastime);
					$wheremc = !$wheremc ? '30d' : $wheremc;
					//echo $wheremc.'--'.$oldlastime.'--'."$timeline\n";
					$chunkedres[$wheremc] = $have_update_oid;
					$newmyfeed = $this->getMyfeedNeed($chunkedres, 0, array($wheremc), $whichmc);
					//print_r($newmyfeed);
					//print_r($fidFromMe);
					//filte feed create by me
					$newmyfeed = $fidFromMe&&$newmyfeed ? array_diff($newmyfeed, $fidFromMe) : $newmyfeed;
				}
				$thismyfeed = $newmyfeed ? $this->mergeFeeds_qid_fid($newmyfeed, $oldfeeds) : $oldfeeds;
				$cachefeed = $this->getMyfeedCacheDataStatus($thismyfeed, $timeline, $oldfristime);
				if($cachefeed)
					//看数据库是否可靠,不可靠数据标记为A,不可靠数据不更新redis
					if(!$needup) {
						$cachefeed['v'] = 'A';
					}
					if($needup) {
						//更新redis
						$upredis = $this->updateRedisMyfeed($oid, $cachefeed);
					}
					$casres = $this->updateMyfeedToMc($oid, $mctype, $cachefeed, $mymcas);
				}
				else
				{
					//echo "time not get new feed...";
					$thismyfeed = $oldfeeds;
				}
			}
			else
			{
				//error_log
			}
		}
		//echo "我的数据库数据123\n";
		//print_r($thismyfeed);
		$spanmyfeed = $this->fetchFeeds($fid, $span, 'up', $thismyfeed, false);
		//print_r($spanmyfeed);
		return $spanmyfeed;
	}

	public function getMyfeedDown($oid, $atts, $fid, $span=20)
	{
		$mctypealias = count($atts)==1 ? array_pop(array_keys($atts)): 'max';
		$mctype = isset($this->config['FEED_MC_MYFEED_TYPE'][$mctypealias]) ? $this->config['FEED_MC_MYFEED_TYPE'][$mctypealias] : null;
		if(is_null($mctype)||!$fid) return false;
		$mcfeeds = $this->multiSelMyfeedFromMc(array($oid), $mctype);
		//对象oid所产生的feed,需要去重
		$fidFromMe = $this->dIusertofeed->multiGetIndex(array($oid));
		$fidFromMe = isset($fidFromMe[$oid]) ? $fidFromMe[$oid] : array();
		$timeline = time();
		$cachefeed = array();
		$spanmyfeed = array();
		$selfrommc = array('1d', '10d', '30d');
		//print_r($mcfeeds);
		//mc检索失败则redis中取,mcres=array() or false, 或者为临时数据版本A
		$needup = true;
		//$mcfeeds = array();
		//echo '下面...';
		//print_r($mcfeeds);
		$oid_mc_key = $this->getMckey(array($oid), $mctype);
		$mymckey = array_pop(array_keys($oid_mc_key));
		if(!$mcfeeds||(isset($mcfeeds['feedata'][$mymckey]['v'])&&$mcfeeds['feedata'][$mymckey]['v']=='A')) {
			$myfeed_redis = $this->getMyfeedredis($oid, $mymckey);
			$needup = $myfeed_redis['needup'];
			$mcfeeds = empty($myfeed_redis['mcfeeds']) ? ($needup ? array() : $mcfeeds) : $myfeed_redis['mcfeeds'];
		}
		//echo '以后...';
		//print_r($mcfeeds);
		//var_dump($myfeed_redis);
		if(empty($mcfeeds))
		{
			$isbreak = false;
			$whichmc = '';
			$thismyfeed = array();
			$chunkedres = $this->chunkOidWithUpdatetime($atts, $timeline);
			foreach($selfrommc as $wheremc)
			{
				$tmpmyfeed = $this->getMyfeedNeed($chunkedres, 0, array($wheremc), $whichmc);
				if(empty($tmpmyfeed)) continue;
				//filte feed create by me
				$tmpmyfeed = $fidFromMe&&$tmpmyfeed ? array_diff($tmpmyfeed, $fidFromMe) : $tmpmyfeed;
				$thismyfeed = $this->mergeFeeds_qid_fid($tmpmyfeed, $thismyfeed);
				if(count($thismyfeed)>=$this->mcmaxlen)
				$isbreak = true;
				//***效率***
				$spanmyfeed = $this->fetchFeeds($fid, $span, 'down', $thismyfeed, true);
				$spanmyfeednum = count($spanmyfeed);
				if($spanmyfeednum>=$span||$isbreak)
				break;
			}
			//根据参数取定量的数据,同时完成数据的排序
			$fristimeline = abs( $timeline-$this->config['feed_index_types_sec'][$whichmc] );
			$cachefeed = $this->getMyfeedCacheDataStatus($thismyfeed, $timeline, $fristimeline);
			if($cachefeed) {
				//看数据库是否可靠,不可靠数据标记为A,不可靠数据不更新redis
				if(!$needup) {
					$cachefeed['v'] = 'A';
				}
				if($needup) {
					//更新redis
					$upredis = $this->updateRedisMyfeed($oid, $cachefeed);
				}
				//echo '真的？...';
				//print_r($cachefeed);
				$addres = $this->addMyfeedToMc($oid, $mctype, $cachefeed);
			}
		}
		else
		{
			$mymckey = array_pop(array_keys($mcfeeds['oidsmap']));
			if($mymckey)
			{
				$mymcas = $mcfeeds['mcases'][$mymckey];
				$oldmcfeed = $mcfeeds['feedata'][$mymckey];
				$oldlastime = $oldmcfeed['lastimeline'];
				$oldfristime = $oldmcfeed['fristimeline'];
				$oldfeednums = $oldmcfeed['nums'];
				$oldfeeds = $oldmcfeed['feeds'];
				$fristimeline = $oldfristime;
				//echo "*********old mc feed data********\n";
				//print_r($oldmcfeed);
				$spanmyfeed = $this->fetchFeeds($fid, $span, 'down', $oldfeeds, false);
				$spanmyfeedcount = count($spanmyfeed);
				//判断数据最早时间,如果超过存储的最大时间30天，则不拉数据
				$wheremc = $this->getWheremc($timeline, $oldfristime);
				//var_dump($wheremc);
				//var_dump($spanmyfeedcount);
				//如果mc数据量已经为最大量，不拉新数据
				if($spanmyfeedcount<$span&&$oldfeednums<$this->mcmaxlen&&$wheremc)
				{
					$isbreak = false;
					$fortag = false;
					$tmpspanmyfeed = array();
					$chunkedres = $this->chunkOidWithUpdatetime($atts, $timeline);
					//echo "不够了，要再去其他mc, 1d/10d/30d 中取数据\n";
					//print_r($chunkedres);
					//print_r($selfrommc);
					//初始化whichmc,最坏的情况为30d
					$whichmc = '30d';
					foreach($selfrommc as $tmpwheremc)
					{
						if($tmpwheremc==$wheremc) $fortag = true;
						if(!$fortag) continue;
						$tmpmyfeed = $this->getMyfeedNeed($chunkedres, 0, array($tmpwheremc), $whichmc);
						if(empty($tmpmyfeed)) continue;
						//filte feed create by me
						$tmpmyfeed = $fidFromMe&&$tmpmyfeed ? array_diff($tmpmyfeed, $fidFromMe) : $tmpmyfeed;
						//echo "先来{$tmpwheremc}的数据\n";
						//print_r($tmpmyfeed);
						$oldfeeds = $this->mergeFeeds_qid_fid_ext($tmpmyfeed, $oldfeeds, $fid);
						//echo "和老数据整合后的数据\n";
						//print_r($oldfeeds);
						if(count($oldfeeds)>=$this->mcmaxlen)
						$isbreak = true;
						//***效率问题***
						//var_dump($isbreak);
						$spanmyfeed = $this->fetchFeeds($fid, $span, 'down', $oldfeeds, true);
						//echo "这个是整合后，在去{$span}个后的数据集果 \n";
						//print_r($spanmyfeed);
						$spanmyfeednum = count($spanmyfeed);
						//var_dump($spanmyfeednum);
						//var_dump($span);
						if($spanmyfeednum>=$span||$isbreak)
						break;
					}
					$fristimeline = abs( $timeline-$this->config['feed_index_types_sec'][$whichmc] );
				}
				//echo $whichmc."\n";
				//向下找数据直到找到span数量的数据或者找到缓存底部
				$cachefeed = $this->getMyfeedCacheDataStatus($oldfeeds, $oldlastime, $fristimeline);
				if($cachefeed) {
					//看数据库是否可靠,不可靠数据标记为A,不可靠数据不更新redis
					if(!$needup) {
						$cachefeed['v'] = 'A';
					}
					if($needup) {
						//更新redis
						$upredis = $this->updateRedisMyfeed($oid, $cachefeed);
					}
					//print_r('来这里...');
					$casres = $this->updateMyfeedToMc($oid, $mctype, $cachefeed, $mymcas);
				}
			}
			else
			{
				//error_log
			}
		}
		return $spanmyfeed;
	}

	public function getOneUserFeeds($uid, $bfid=null, $span=20)
	{
		$userfeeds = array();
		if($uid&&$span)
		{
			$uid = sprintf('%.0f', $uid);
			$dIobj = ModelFactory::getModel('dIuser', 'd', 1);
			$dIobj->setpro('time_post', '_30d');
			$partinfo = $dIobj->getDbConfig(array($uid));
			if(!$partinfo) continue;
			$feedsres = array();
			foreach($partinfo as $dbname=>$tbinfo)
			{
				if(!$tbinfo) continue;
				$dbconf = $dIobj->getDbServerInfo($dbname, FEED_DB_SLVAER_ALIAS);
				$dbconf['dbname'] = $dbname;
				foreach($tbinfo as $tbname=>$tmpoids)
				{
					$dbconf['tbname'] = $tbname;
					//print_r($dbconf);
					$dIobj->setdbconf($dbconf);
					$feedindexres = $dIobj->selIndexFeed('30d', $tmpoids);
					$feedsres = $this->mergeFeeds($feedindexres, $feedsres);
				}
			}
			$userfeeds = $this->fetchFeeds($bfid, $span, 'down', $feedsres, true);
		}
		return $userfeeds;
	}

	private function getMyfeedCacheDataStatus(&$thismyfeed, $timeline, $fristimeline)
	{
		if(!is_array($thismyfeed)) return false;
		arsort($thismyfeed);
		$myfeedcount = count($thismyfeed);
		$thismyfeed = $myfeedcount>$this->mcmaxlen ? array_shift(array_chunk($thismyfeed, $this->mcmaxlen, true)) : $thismyfeed;
		$cachefeed['lastimeline'] = $timeline;
		$cachefeed['fristimeline'] = $fristimeline;
		$cachefeed['nums'] = $myfeedcount>$this->mcmaxlen ? $this->mcmaxlen : $myfeedcount;
		$cachefeed['feeds'] = $thismyfeed;
		return $cachefeed;
	}

	public function getWheremc($timeline, $lastimeline)
	{
		$result = false;
		if(($timeline-$lastimeline)<1*FEED_ONEDAY_SECES)
		{
			$result = '1d';
		}
		elseif(($timeline-$lastimeline)<10*FEED_ONEDAY_SECES)
		{
			$result = '10d';
		}
		elseif(($timeline-$lastimeline)<30*FEED_ONEDAY_SECES)
		{
			$result = '30d';
		}
		return $result;
	}

	public function getMyfeedNeed($atts, $maxsize, $indextag=array('1d'), &$wheremc)
	{
		$feedsres = array();
		$spanfeeds = array();
		$whichmc = '';
		if(is_array($atts)&&$atts&&is_array($indextag)&&$indextag)
		{
			$feed_att_obj = $this->config['feed_att_obj'];
			foreach($indextag as $itype)
			{
				if(!in_array($itype, $this->config['feed_index_types'])) continue;
				if(!array_key_exists($itype, $atts)) continue;
				foreach($atts[$itype] as $attobj=>$oids)
				{
					$dIobj = ModelFactory::getModel('dI'.$attobj, 'd', 1);
					$dIobj->setpro('time_post', '_'.$itype);
					//print_r($oids);
					$partinfo = $dIobj->getDbConfig($oids);
					//echo $attobj."partinfo......\n";
					//print_r($partinfo);
					if(!$partinfo) continue;
					foreach($partinfo as $dbname=>$tbinfo)
					{
						if(!$tbinfo) continue;
						$dbconf = $dIobj->getDbServerInfo($dbname, FEED_DB_SLVAER_ALIAS);
						$dbconf['dbname'] = $dbname;
						foreach($tbinfo as $tbname=>$tmpoids)
						{
							$dbconf['tbname'] = $tbname;
							//print_r($dbconf);
							$dIobj->setdbconf($dbconf);
							$feedindexres = $dIobj->selIndexFeed($itype, $tmpoids);
							//print_r($feedindexres);
							$feedsres = $this->mergeFeeds($feedindexres, $feedsres);
						}
					}
					//echo '['.$attobj.'---'.$itype."] **** index data is ::\n";
					//print_r($feedindexres);
				}
				//print_r($feedsres);
				if(count($feedsres)>=$maxsize)
					break;
			}
			$wheremc = $itype;
			//echo "最终的数据\n";
			//print_r($feedsres);
		}
		return $feedsres;
	}

	private function fetchFeeds($fid=null, $span, $type='up', &$feeds, $issort=true)
	{
		$result = array();
		if($span<=0||empty($feeds)||!is_array($feeds)) return $result;
		$feeds = array_unique($feeds);
		if($issort)
		{
			if(!arsort($feeds)) return $result;
		}
		$tag = 0;
		if($type=='up')
		{
			foreach($feeds as $qid=>$onefid)
			{
				if($fid)
				{
					if($onefid>$fid)
					{
						$result[$qid] = $onefid;
						$tag++;
					}
					else
					{
						break;
					}
					if($tag>=$span)
						break;
				}
				else
				{
					$result[$qid] = $onefid;
					$tag++;
					if($tag>=$span)
						break;
				}
			}
		}
		else
		{
			foreach($feeds as $qid=>$onefid)
			{
				if($fid)
				{
					if($onefid<$fid)
					{
						$result[$qid] = $onefid;
						$tag++;
					}
					if($tag>=$span)
						break;
				}
				else
				{
					$result[$qid] = $onefid;
					$tag++;
					if($tag>=$span)
						break;
				}
			}
		}
		return $result;
	}

	private function mergeFeeds($feedindexs, $result)
	{
		if(!is_array($feedindexs)||empty($feedindexs)) return $result;
		foreach($feedindexs as $oid=>$feedinfo)
		{
			if(isset($feedinfo['feedata'])&&!empty($feedinfo['feedata']))
			{
				$result = $this->mergeFeeds_qid_fid($feedinfo['feedata'], $result);
			}
		}
		return $result;
	}

	private function mergeFeeds_qid_fid($newdata, $result=array())
	{
		if(is_array($newdata))
		{
			foreach($newdata as $qid=>$fid)
			{
				if(!isset($result[$qid])||(isset($result[$qid])&&$result[$qid]<$fid))
				$result[$qid] = $fid;
			}
		}
		return $result;
	}

	private function mergeFeeds_qid_fid_ext($newdata, $result=array(), $bfid)
	{
		if(is_array($newdata))
		{
			foreach($newdata as $qid=>$fid)
			{
				if((!isset($result[$qid])&&$fid<$bfid)||(isset($result[$qid])&&$result[$qid]<$fid))
				$result[$qid] = $fid;
			}
		}
		return $result;
	}

	protected function getUpdateObjWithTimeLine($uptimetype ,$attids, $cachetime=0)
	{
		if(!in_array($uptimetype, $this->config['feed_uptime_types'])) return false;
		$alltimes = $this->dUpdatetime->multiSelUptime($uptimetype, $attids);
		if($cachetime!=0)
		{
			foreach($alltimes as $oneoid=>$onetime)
			{
				if($onetime<$cachetime)
				{
					unset($alltimes[$oneoid]);
				}
			}
		}
		return $alltimes ? $alltimes : array();
	}

	public function getOidHaveNewUpdate($atts, $lastimeline, $atts_time=array())
	{
		$return = array();
		if($atts)
		{
			foreach($atts as $attobj=>$attids)
			{
				if(!isset($this->config['feed_uptime_types'][$attobj])) continue;
				$attpre = $this->config['feed_uptime_types'][$attobj];
				//是否存在默认必须更新的对象
				if(isset($atts_time[$attobj])&&$atts_time[$attobj])
				$attids = array_diff($attids, $atts_time[$attobj]);
				$uptimes = $this->dUpdatetime->multiSelUptime($attpre, $attids);
				if($uptimes)
				{
					foreach($uptimes as $oneoid=>$onetime)
					{
						if($onetime<=0) continue;
						if($onetime>=$lastimeline)
						$return[$attobj][] = $oneoid;
					}
				}
				//var_dump($lastimeline);
				//print_r($return);
				if(isset($atts_time[$attobj])&&$atts_time[$attobj])
				$return[$attobj] = isset($return[$attobj]) ? array_merge($return[$attobj], $atts_time[$attobj]) : $atts_time[$attobj];
			}
		}
		return $return;
	}

	public function getOidNewAtt($atts_time, $lastimeline)
	{
		$return = array();
		if(!$atts_time) return $return;
		foreach($atts_time as $attobj=>$attids)
		{
			if(!isset($this->config['feed_uptime_types'][$attobj])) continue;
			if(!is_array($attids)||!$attids) continue;
			foreach($attids as $oneoid=>$onetime)
			{
				if($onetime<=0) continue;
				if($onetime>=$lastimeline)
				$return[$attobj][] = $oneoid;
			}
		}
		return $return;
	}

	public function chunkOidWithUpdatetime($atts, $nowtime)
	{
		$return = array();
		if($atts)
		{
			foreach($atts as $attobj=>$attids)
			{
				if(!isset($this->config['feed_uptime_types'][$attobj])) continue;
				$attpre = $this->config['feed_uptime_types'][$attobj];
				$uptimes = $this->dUpdatetime->multiSelUptime($attpre, $attids);
				if(!$uptimes) continue;
				foreach($uptimes as $oneoid=>$onetime)
				{
					if($onetime<=0) continue;
					if(abs($onetime-$nowtime)<1*FEED_ONEDAY_SECES)
					{
						$return['1d'][$attobj][] = $oneoid;
					}
					if(abs($onetime-$nowtime)<10*FEED_ONEDAY_SECES)
					{
						$return['10d'][$attobj][] = $oneoid;
					}
					if(abs($onetime-$nowtime)<30*FEED_ONEDAY_SECES)
					{
						$return['30d'][$attobj][] = $oneoid;
					}
				}
			}
		}
		return $return;
	}
	//public function 
	public function getOidEveryTimeline($uptimetype, $attids, $timeline, $cachetime=0)
	{
		//echo "*************MyFeed.php************\n";
		$alltimes = $this->getUpdateObjWithTimeLine($uptimetype, $attids, $cachetime);
		//print_r($alltimes);exit();
		if(!$alltimes) return false;
		$return = array('1d'=>array(), '10d'=>array(), '30d'=>array());
		foreach($alltimes as $oneid=>$onetime)
		{
			if($onetime<=0) continue;
			if(abs($onetime-$timeline)<1*FEED_ONEDAY_SECES)
			{
				$return['1d'][] = $oneid;
			}
			else
				if(abs($onetime-$timeline)<10*FEED_ONEDAY_SECES)
				{
					$return['10d'][] = $oneid;
				}
				else
					if(abs($onetime-$timeline)<30*FEED_ONEDAY_SECES)
					{
						$return['30d'][] = $oneid;
					}
		}
		return $return;
	}

	private function getMckey($oids, $mctype)
	{
		if(!is_array($oids)||!$oids||!$mctype) return false;
		if(!isset($this->config['FEED_MC_KEYS_MAPPING'][$this->mcalias])) return false;
		$result = array();
		$oid_mc_key = array();
		foreach($oids as $oid)
		{
			$tmp_mc_key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][$this->mcalias], $mctype, trim($oid));
			if($tmp_mc_key)
				$oid_mc_key[$tmp_mc_key] = $oid;
		}
		return $oid_mc_key;
	}

	public function multiSelMyfeedFromMc($oids, $mctype)
	{
		$oid_mc_key = $this->getMckey($oids, $mctype);
		if($oid_mc_key===false) return false;
		$mckeys = array_keys($oid_mc_key);
		//print_r($mckeys);
		$count = 0;
		$rescas = array();
		$return = array();
		do
		{
			$mcres = $this->mc->getMulti($mckeys, $rescas);
			$count++;
		}
		while($mcres===false&&$count<$this->redotimes);
		//if(!$mcres)
		//echo "myfeed mc 中没有数据, alias is ".$this->mcalias."\n";
		//echo "++++++[myfeed cache]sel mc redo {$count}++++++\n";
		//print_r($this->mc->getServerList());
		if($mcres)
		{
			$return['oidsmap'] = $oid_mc_key;
			$return['feedata'] = $mcres;
			$return['mcases'] = $rescas;
		}
		return $return;
	}

	public function addMyfeedToMc($oid, $mctype, $feedata)
	{
		$oid_mc_key = $this->getMckey(array($oid), $mctype);
		if($oid_mc_key===false) return false;
		$mckey = array_pop(array_keys($oid_mc_key));
		$count = 0;
		do
		{
			$mcres = $this->mc->set($mckey, $feedata, time()+$this->timeout);
			//$mcres = $this->mc->add($mckey, $feedata, time()+$this->timeout);
			$count++;
		}
		while($mcres===false&&$this->mc->getResultCode()!=Memcached::RES_NOTSTORED&&$count<$this->redotimes);
		//echo "++++++[myfeed cache]add mc redo {$count}++++++\n";
		return $mcres;
	}

	public function updateMyfeedToMc($oid, $mctype, $feedata, $cas)
	{
		$oid_mc_key = $this->getMckey(array($oid), $mctype);
		if($oid_mc_key===false) return false;
		$mckey = array_pop(array_keys($oid_mc_key));
		$count = 0;
		do
		{
			//扩展，如果cas值为0则进行set操作
			if($cas===0) {
				$mcres = $this->mc->set($mckey, $feedata, time()+$this->timeout);
			}else {
				$mcres = $this->mc->cas($cas, $mckey, $feedata, time()+$this->timeout);
			}
			$count++;
		}
		while($mcres===false&&$this->mc->getResultCode()!=Memcached::RES_DATA_EXISTS&&$count<$this->redotimes);
		//echo "++++++[myfeed cache]add mc redo {$count}++++++\n";
		//echo '更新server is..............';
		//print_r($this->mc->get($mckey));
		return !$mcres||($this->mc->getResultCode()==Memcached::RES_DATA_EXISTS) ? false : true;
	}

	public function deleteNoUsefulMyFeed($oid, $atts, $nouseful)
	{
		if(!$nouseful) return true;
		$mctypealias = count($atts)==1 ? array_pop(array_keys($atts)): 'max';
		//var_dump($this->config);
		$mctype = isset($this->config['FEED_MC_MYFEED_TYPE'][$mctypealias]) ? $this->config['FEED_MC_MYFEED_TYPE'][$mctypealias] : null;
		if(is_null($mctype)) return false;
		$oid = strval($oid);
		$mcfeeds = $this->multiSelMyfeedFromMc(array($oid), $mctype);
		//echo '两次的mc内容';
		//print_r($mcfeeds);
		if(!$mcfeeds) return true;
		$mymckey = array_pop(array_keys($mcfeeds['oidsmap']));
		if($mymckey)
		{
			$mymcas = $mcfeeds['mcases'][$mymckey];
			$oldmcfeed = $mcfeeds['feedata'][$mymckey];
			if($oldmcfeed['nums']==0) return true;
			foreach($oldmcfeed['feeds'] as $oneqid=>$onefid)
			{
				if(in_array($onefid, $nouseful))
				{
					unset($oldmcfeed['feeds'][$oneqid]);
				}
			}
			$nownum = count($oldmcfeed['feeds']);
			//echo "需要更新吗? $nownum---{$oldmcfeed['nums']}\n";
			if($nownum!=$oldmcfeed['nums'])
			{
				$oldmcfeed['nums'] = $nownum;
				$casres = $this->updateMyfeedToMc($oid, $mctype, $oldmcfeed, $mymcas);
				return $casres;
			}
		}
		return true;
	}

	public function updateRedisMyfeed($oid, $myfeed) {
		$datas = array(
				'eid'=>MYFEED_EVENT_UP,
				'uid'=>$oid,
				'value'=>json_encode($myfeed),
				);
		$params = array(
				'url'=>$this->feedapi,
				'datas'=>$datas,
				);
		$mycurl = new mycurl($params);
		$res = $mycurl->run('post');
		if($res) {
			$res = json_decode($res, true);
			return $res['code']=='1000' ? true : false;
		}
		return false;
		/*
		   $lqueuetool = ModelFactory::getModel('lqueuetool', 'l', 1);
		   return $lqueuetool->AddToLocalQueue(FEED_UPMYFEED_LIST, $params, FEED_UPMYFEED_NUM);
		*/
	}

	public function delRedisMyfeed($oid, $fids) {
		$datas = array(
				'eid'=>MYFEED_EVENT_DEL,
				'uid'=>$oid,
				'fids'=>implode(',', $fids),
				);
		$params = array(
				'url'=>$this->feedapi,
				'datas'=>$datas,
				);
		$mycurl = new mycurl($params);
		$res = $mycurl->run('post');
		if($res) {
			$res = json_decode($res, true);
			return $res['code']=='1000' ? true : false;
		}   
		return false;
		//redis持久化删除操作
		/*
		$lqueuetool = ModelFactory::getModel('lqueuetool', 'l', 1);
		return $lqueuetool->AddToLocalQueue(FEED_UPMYFEED_LIST, $params, FEED_UPMYFEED_NUM);
		*/
	}

	protected function getMyfeedredis($oid, $mymckey) {
		//redis读取失败则不更新标记,并更新mc为临时版本A
		$needup = true;
		if(isset($this->config['FEED_REDIS_ALIAS'][$this->redisalias])) {
			$mcfeeds = array();
			$acount = count($this->config['FEED_REDIS_ALIAS'][$this->redisalias]);
			$redisnum = abs(crc32(substr($oid, 0, 6)))%$acount;
			$redis = lmyredis::getNormalRedis($this->redisalias, $redisnum);
			//$redis = false;
			if($redis) {
				$redisdata = $redis->get($mymckey);
				$mcfeeds = $redisdata ? array('oidsmap'=>array($mymckey=>$oid), 'feedata'=>array($mymckey=>$redisdata), 'mcases'=>array($mymckey=>0)) : array();
			}else {
				$needup = false;
			}
		}
		return array('mcfeeds'=>$mcfeeds, 'needup'=>$needup);
	}
}
