<?php
require_once 'common/commdb.php';

class dIusertofeed extends commdb
{
	protected $partition_pre = 'T';
	protected $filedpre = 'iuf_';
	protected $filedspl = 'uid';
	protected $mc = null;
	public $tbpre = 'index_u_f_';
	public $dbpre = 'feedata_1_';
	protected $pri = 'uid';
	protected $dbnum = 1;
	protected $tbnum = 64;
	protected $as;
	protected $basetable = 'index_u_f';
	protected $index_filed_num = 3;
	protected $mc_redo_time = FEED_MC_REDO_UIDFIDINDEX;
	protected $conftag = FEED_DB_TAG_USERTOFEED;

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_UIDFIDINDEX);
		//set dbmap 
		$this->confInit();
	}	

	protected function getDbconfig($uids)
	{
		if($this->config)
		{
			$hashmap = myhash::gethashtable_aveg($this->dbpre, $this->tbpre, $uids, $this->dbnum, $this->tbnum);
			//print_r($hashmap);
			return $hashmap;
		}
		return false;
	}

	public function multiGetIndex($uids)
	{
		$res_return = array();                                              
		if(!$uids||!$this->mc) $res_return;
		$cas = array();
		//mc中查找数据
		$relMcData = array();
		$keysdata = $this->getMcKeys($uids);
		$keysrel = array_keys($keysdata);
		$mcdata = $this->mc->getMulti($keysrel, $cas);
		//echo "mc的数据\n";
		//var_dump($mcdata);
		$foundFromMcUid = array();
		if($mcdata)
		{
			foreach($mcdata as $tmpmckey=>$tmpmcdata)
			{
				if(isset($keysdata[$tmpmckey]))
				{
					$tmpuid = strval($keysdata[$tmpmckey]);
					$relMcData[$tmpuid] = $tmpmcdata;
				}
			}
			$foundFromMcUid = array_keys($relMcData);
		}
		$notFoundUid = $foundFromMcUid ? array_diff($uids, $foundFromMcUid) : $uids;
		if(!$notFoundUid) return $relMcData;
		$mysqlFoundData = $this->multiRun('oneGetIndex', $notFoundUid, array(), FEED_DB_SLVAER_ALIAS);
		foreach($notFoundUid as $notuid)
		{
			if(!isset($mysqlFoundData[$notuid])||!$mysqlFoundData[$notuid])
				$mysqlFoundData[$notuid] = 0;
		}
		//echo "mc中没有的数据\n";
		//print_r($mysqlFoundData);
		$this->setMcUidFids($mysqlFoundData, 'add');
		return (array)$mysqlFoundData + (array)$relMcData;
	}

	public function oneGetIndex($uids, $params)
	{
		if(!$uids) return array();
		$fidresult = array();
		$in = $this->getInParams($uids);
		$info = array();
		$tmpsql = "select %suid as uid, %sfids as fids from %s where %s in %s";
		$selsql = sprintf($tmpsql, $this->filedpre, $this->filedpre, $this->tbname, $this->filedpre.$this->pri, $in);
		//echo $selsql."\n";
		$selres = $this->sampleQuery($selsql, $info);
		$fids = $selres&&!empty($info['info']) ? $info['info'] : '';
		if($fids)
		{
			foreach($fids as $onedata)
			{
				$tmpfids = array();
				$tmpuid = strval($onedata['uid']);
				$binaryfids = $onedata['fids'];
				$oldfids = $this->unpackFeed($binaryfids, $this->index_filed_num);
				$oldfids = is_array($oldfids) ? $oldfids : array();
				if($oldfids)
				{
					foreach($oldfids as $tmpkey=>$oneoldfid)
					{
						if(count($oneoldfid)!=$this->index_filed_num) continue;
						$tmp_ctime = $oneoldfid[0];
						$tmp_fid_pre = $oneoldfid[1];
						$tmp_fid_post = $oneoldfid[2];
						$tmpfids[] = sprintf('%08s', $tmp_fid_pre).sprintf('%08s', $tmp_fid_post);
					}
				}
				if(!empty($tmpfids))
					$fidresult[$tmpuid] = $tmpfids;
			}
		}
		return $fidresult;
	}

	private function getMcKeys($uids)
	{
		$result = array();
		if(!$uids) return $result;
		if(isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UIDFIDINDEX]))
		{
			foreach($uids as $uid)
			{
				$mckeyformat = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UIDFIDINDEX], $uid);
				$result[$mckeyformat] = $uid;
			}
		}
		return $result;
	}

	private function setMcUidFids($uidfids, $fun)
	{
		$result = array();
		if(!$uidfids) return $result;
		if(!in_array($fun, array('set', 'add'))) return $result;
		foreach($uidfids as $uid=>$fids)
		{
			$count = 0;
			$resintomc = false;
			$mckeyformat = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UIDFIDINDEX], $uid);
			do{
				$resintomc = $this->mc->$fun($mckeyformat, $fids, time()+FEED_MC_TIMEOUT_UIDFIDINDEX);
				$count++;
			}
			while(!$resintomc&&$count<$this->mc_redo_time);
			//echo 'index mc key is : '.$mckeyformat."\n";
			//echo "redo {$count}\n";
			//print_r($this->mc->get($mckeyformat));
			if($resintomc) $result[$uid] = $resintomc;
		}
		return $result;
	}

	public function multiAddIndex($uidandfid)
	{
		$res_return = array();
		$uids = array_keys($uidandfid);
		$params = array('ufindex'=>$uidandfid);
		$res = $this->multiRun('oneAddIndex', $uids, $params, FEED_DB_MASTER_ALIAS);
		if(!$res||!isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UIDFIDINDEX])) return array();
		//echo "这是写入数据库的数据，将要写入mc\n";
		//print_r($res);
		foreach($res as $uid=>$oneres)
		{
			if($oneres)
			{
				$mckeyformat = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UIDFIDINDEX], $uid);
				$count = 0;
				do{
					$resintomc = $this->mc->set($mckeyformat, $oneres, time()+FEED_MC_TIMEOUT_UIDFIDINDEX);
					$count++;
				}
				while(!$resintomc&&$count<$this->mc_redo_time);
				//if(!$resintomc)
				//echo "index_u_f mc 没有数据 alias is ".FEED_MC_ALIAS_UIDFIDINDEX."\n";
				//echo "redo {$count}\n";
				//var_dump($this->mc->get($mckeyformat));
				//echo 'index mc key is : '.$mckeyformat."\n";
				//******************************************************************
				if($resintomc) $res_return[$uid] = $resintomc;
			}
		}
		return $res_return;
	}

	public function oneAddIndex($uids, $params)
	{
		if(!$uids) return false;
		$nowtime = time();
		$fidata = $params['ufindex'];
		$uidAndCacheData = array();
		foreach($uids as $uid)
		{
			$tmpfidata = isset($fidata[$uid]) ? $fidata[$uid] : array();
			$newfid = $tmpfidata['fid'];
			if(!$tmpfidata||strlen($newfid)!=16) continue;
			$oldfids = array();
			$info = array();
			$tmpsql = "select %sfids as fids from %s where %s = '%.0f'";
			$selsql = sprintf($tmpsql, $this->filedpre, $this->tbname, $this->filedpre.$this->pri, $uid);
			$selres = $this->sampleQuery($selsql, $info);
			//echo $selsql."\n";
			$fids = $selres&&!empty($info['info']) ?$info['info'][0]['fids'] : '';
			//echo "fids\n";
			//var_dump($fids);
			if($fids)
			{
				$oldfids = $this->unpackFeed($fids, $this->index_filed_num);
				if(is_array($oldfids))
				{
					//删除过期的数据,删除重复qid数据,保留最新的qid的feed信息
					$outime = FEED_MC_TIMEOUT_UIDFIDINDEX;
					$outimeline = $nowtime-$outime;
					foreach($oldfids as $feedkey=>$oneoldfid)
					{
						if(count($oneoldfid)!=$this->index_filed_num) continue;
						$tmp_ctime = $oneoldfid[0];
						if($tmp_ctime<$outimeline)
							unset($oldfids[$feedkey]);
					}
				}
			}
			unset($info);
			//inset now fid
			$newfid_pre = substr($tmpfidata['fid'], 0, 8);
			$newfid_post = substr($tmpfidata['fid'], 8, 8);
			$oldfids[] = array($tmpfidata['time'], $newfid_pre, $newfid_post);
			//打包feed为二进制数据
			//echo "oldfids+newfids\n";
			//print_r($oldfids);
			$binfeed = $this->packFeed($oldfids, $this->index_filed_num);
			//$oldfids = $this->unpackFeed($binfeed, $this->index_filed_num);
			//echo "sfsdfs\n";
			//print_r($oldfids);
			//var_dump($binfeed);
			$binfeed = bin2hex($binfeed);
			if($fids)
			{
				//更新feed数据
				$tmprunsql = "update %s set %sfids = 0x{$binfeed} where %s = '%.0f'";
				$runsql = sprintf($tmprunsql, $this->tbname, $this->filedpre, $this->filedpre.$this->pri, $uid);
			}
			else
			{
				//插入feed数据
				$tmprunsql = "insert into %s (`iuf_uid`,`iuf_fids`) values ('%.0f',0x{$binfeed})";
				$runsql = sprintf($tmprunsql, $this->tbname, $uid);
			}
			//echo $runsql;
			$updres = $this->sampleQuery_noresult($runsql);
			if($updres==1)
			{
				//拿出fids存入mc
				$cachedata = array();
				foreach($oldfids as $tmpfid)
				{
					$cachedata[] = sprintf('%08s', $tmpfid[1]).sprintf('%08s', $tmpfid[2]);
				}
				$uidAndCacheData[$uid] = $cachedata;
			}
		}
		return $uidAndCacheData;
	}
}
