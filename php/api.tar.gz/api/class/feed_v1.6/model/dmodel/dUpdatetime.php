<?php
require_once 'common/commdb.php';

class dUpdatetime extends commdb
{
	protected $partition_pre = 'T';
	protected $filedpre = 'ot_';
	protected $mc = null;
	public $tbpre = 'updatetime_';
	public $dbpre = 'feedata_1_';
	protected $pri = 'oid';
	//protected $prid;
	protected $dbnum = 1;
	protected $tbnum = 64;
	protected $as;
	protected $basetable = 'updatetime';
	protected $conftag = FEED_DB_TAG_UPDATETIME;
	protected $chunknum = 1000;

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_UPTIME);
		//set dbmap
		$this->confInit();
	}	

	protected function getDbconfig($uids)
	{
		if($this->config&&$this->as)
		{
			$hashmap = myhash::gethashtable_aveg($this->dbpre, $this->tbpre.$this->as.'_', $uids, $this->dbnum, $this->tbnum);
			return $hashmap;
		}
		return false;
	}

	public function multiUptime($type, $uids, $time)
	{
		$res_return = array();
		if(!in_array($type, $this->config['feed_uptime_types'])) return array();
		$this->setpro('as', $type);
		$params = array('time'=>$time);
		$res = $this->multiRun('oneUptime', $uids, $params, FEED_DB_MASTER_ALIAS);
		if(!$res||!isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UPTIME])) return array();
		foreach($res as $uid=>$oneres)
		{
			if($oneres)
			{
				$key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UPTIME], $this->as, $uid);
				$count = 0;
				do{
					$intomcres = $this->mc->set($key, $time, time()+$this->config['FEED_MC_TIMEOUT_UPTIME'][$this->as]);
					$count++;
				}
				while(!$intomcres&&$count<FEED_MC_REDO_UPTIME);
				$res_return[$uid] = $intomcres;
			}
		}
		return $res_return;
	}

	public function oneUptime($uids, $params)
	{
		$result = array();
		if(is_array($uids)&&$uids&&isset($params['time']))
		{
			foreach($uids as $uid)
			{
				$sql = "insert into `%s` (`%s`,`%s`) values('%.0f', '%d') ON DUPLICATE KEY UPDATE %s = '%d';";
				$filed_uid = $this->filedpre.'uid';
				$filed_time = $this->filedpre.'time';
				$sql = sprintf($sql, $this->tbname, $filed_uid, $filed_time, $uid, $params['time'], $filed_time, $params['time']);
				$res = $this->sampleQuery_noresult($sql);
				if($res) $result[$uid] = true;
			}
		}
		return $result;
	}

	public function multiSelUptime($type, $oids)
	{
		$mcres = array();//mc读出的数据
		$mysqloids = array();//mysql读出的数据
		$alltime = array();
		$this->setpro('as', $type);
		$mcres = $this->multiSelUptimeforMc($type, $oids);
		//echo $type;
		//var_dump($mcres);
		if($mcres===false) return false;
		//$mcres = array();
		$mcoids = array_keys($mcres);
		$noseloids_mc = array_diff($oids, $mcoids);
		if($noseloids_mc)
		{
			$mysqloids = $this->multiRun('oneSelUptimeFromMysql', $noseloids_mc, array(), FEED_DB_SLVAER_ALIAS);
			foreach($mysqloids as $k_oid=>$v_time)
			{
				if(!$v_time)
				unset($mysqloids[$k_oid]);
			}
			$noseloids_mysql = array_diff($noseloids_mc, $mysqloids);
		}
		else
		{
			$noseloids_mysql = array();
		}
		if($noseloids_mysql)
		{
			//echo "now set null mc to keys ...... \n";
			//假如mc,mysql都没有则写mc为空，以备其他请求重复读库
			$oidtime = array();
			foreach($noseloids_mysql as $oid)
			{
				$oidtime[$oid] = 0;
			}
			$sucoids = $this->multiSetUptimeforMc($type, $oidtime, 'add');
		}
		foreach($oids as $tmpoid)
		{
			if(isset($mcres[$tmpoid]))
			{
				$alltime[$tmpoid] = $mcres[$tmpoid];
			}
			if(isset($mysqloids[$tmpoid]))
			{
				$alltime[$tmpoid] = $mysqloids[$tmpoid];
			}
		}
		//echo "[update time] mysql data echo ...... \n";
		//print_r($mysqloids);
		//echo "[update time] alltime data echo ...... \n";
		//print_r($alltime);
		return $alltime;
	}

	public function multiSetUptimeforMc($type, $oidtime, $con='add')
	{
		$this->setpro('as', $type);
		if(!is_array($oidtime)||!$oidtime) return false;
		$oids = array_keys($oidtime);
		$oid_mc_key = $this->getMckey($type, $oids);
		$mc_keys = array_keys($oid_mc_key);
		if($oid_mc_key===false) return false;
		$count = 0;
		do
		{
			if($con=='add')
			{
				foreach($oid_mc_key as $mckey=>$oid)
				{
					//$this->mc->delete($mckey);
					$tmptime = $oidtime[$oid];
					$addres = $this->mc->add($mckey, $tmptime, time()+$this->config['FEED_MC_TIMEOUT_UPTIME'][$this->as]);
					if((!$addres&&$this->mc->getResultCode() == Memcached::RES_NOTSTORED)||$addres)
						unset($oid_mc_key[$mckey]);
				}
				$intomcres = (count($oid_mc_key)==0) ? true : false;

			}
			else
				if($con=='set')
				{
					$setparams = array();
					foreach($oid_mc_key as $mckey=>$oid)
					{
						$setparams[$mckey] = $oidtime[$oid];
					}
					$intomcres = $this->mc->setMulti($setparams, time()+$this->config['FEED_MC_TIMEOUT_UPTIME'][$this->as]);
				}
				else
				{
					return false;
				}
			$count++;
		}
		while(!$intomcres&&$count<FEED_MC_REDO_UPTIME);
		//echo "add new time redo {$count} ..\n";
		//echo "mc中的数据 ...... \n";
		//print_r($this->mc->getMulti($mc_keys));
		if($con=='add')
		{
			$res_return = $oid_mc_key ? array_diff($oids, array_values($oid_mc_key)) : $oids;
		}
		else
			if($con=='set')
			{
				$res_return = $intomcres ? $oids : array();
			}
		return $res_return;
	}

	private function getMckey($type, $oids)
	{
		if(!is_array($oids)||!$oids) return false;
		if(!in_array($type, $this->config['feed_uptime_types'])) return false;
		if(!isset($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UPTIME])) return false;
		$result = array();
		$oid_mc_key = array();
		foreach($oids as $oid)
		{
			$tmp_mc_key = sprintf($this->config['FEED_MC_KEYS_MAPPING'][FEED_MC_ALIAS_UPTIME], $type, sprintf('%.0f', trim($oid)));
			if($tmp_mc_key)
				$oid_mc_key[$tmp_mc_key] = $oid;
		}
		return $oid_mc_key;
	}

	public function multiSelUptimeforMc($type, $oids)
	{
		$result = array();
		$this->setpro('as', $type);
		$oid_mc_key = $this->getMckey($type, $oids);
		if($oid_mc_key===false) return false;
		$mckeys = array_keys($oid_mc_key);
		$count = 0;
		do
		{
			$mcres = $this->mc->getMulti($mckeys);
			$count++;
		}
		while($mcres===false&&$count<FEED_MC_REDO_UPTIME_SEL);
		//if(!$mcres)
		//echo "updatetime mc 中没有数据, alias is ".FEED_MC_ALIAS_UPTIME."\n";
		//echo "sel mc redo {$count} ..\n";
		if($mcres)
		{
			foreach($mcres as $mckey=>$mcvalue)
			{
				if(isset($oid_mc_key[$mckey]))
				{
					$tmp_oid = $oid_mc_key[$mckey];
					$result[$tmp_oid] = $mcvalue;
				}
			}
		}
		//echo '********[update time] mc data*********'."\n";
		//print_r($result);
		return $result;
	}

	public function oneSelUptimeFromMysql($oids, $params)
	{
		if(!is_array($oids)||!$oids) return array();
		$result = array();
		$oid_section = array_chunk($oids, $this->chunknum);
		foreach($oid_section as $onesection)
		{
			$info = array();
			$wherein = $this->getInParams($onesection);
			if(!$wherein) continue;
			$filed_uid = $this->filedpre.$this->pri;
			$filed_time = $this->filedpre.'time';
			$sql = 'select %s as oid, %s as time from %s where %s in %s;';
			$selsql = sprintf($sql, $filed_uid, $filed_time, $this->tbname, $filed_uid, $wherein);
			//echo $selsql."\n";
			$selres = $this->sampleQuery($selsql, $info);
			$timeres = $selres&&!empty($info['info']) ? $info['info'] : '';
			if($timeres)
			{
				foreach($timeres as $onetime)
				{
					$oid_tmp = $onetime['oid'];
					$time_tmp = $onetime['time'];
					$result[$oid_tmp] = $time_tmp;
				}
			}
		}
		return $result;
	}
}
