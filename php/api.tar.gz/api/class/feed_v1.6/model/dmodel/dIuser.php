<?php
require_once 'common/commdb.php';

class dIuser extends commdb
{
	const TBNAME = 'index_u';
	const TBNAME_PRE = 'iu_';
	protected $mc = null;
	protected $filedpre = 'iu_';
	public $tbpre = 'index_u';
	
	protected $dbpre = 'feedindex_1_';
	protected $pri = 'uid';
	protected $mc_timeout_conf = 'FEED_MC_TIMEOUT_INDEXU';
	protected $mc_redo_time = 'FEED_MC_REDO_INDEX_U';
	protected $index_filed_num = 4;
	protected $my_type_pre = 'u';
	protected $time_post;
	protected $dbnum;
	protected $tbnum;
	protected $conftag = FEED_DB_TAG_FEEDINDEX_U;

	public function getDbConfig($uids)
	{
		if($this->config&&$this->time_post)
		{
			$hashmap = myhash::gethashtable_aveg($this->dbpre, $this->tbpre.$this->time_post.'_', $uids, $this->dbnum, $this->tbnum);
			return $hashmap;
		}
		return false;
	}

	public function init()
	{
		ModelFactory::getModel('lmymc','l',1);
		$this->mc = lmymc::getNormalMc(FEED_MC_ALIAS_INDEXES);
		//set dbmap
		$this->confInit();
	}
}
