<?php 
interface itask
{
	/**
	 * 统一提供服务方法
	 */
	public function service($args);
}
