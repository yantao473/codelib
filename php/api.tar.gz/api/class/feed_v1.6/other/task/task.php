<?php

require('interface/task.interface.php');

class task implements itask
{
	protected $config;
	protected $eid;
	protected $task;
	
	public function __construct()
	{
		global $config;
		$this->config = $config;
		//...
	}
	
	//任务调度
	public function service($args)
	{
		//extension
	}
	
	protected function filteInput($fun, $args)
	{
		if(isset($args['eid'])&&array_key_exists($args['eid'], $this->config['feed_event_mapping']))
		{
			$this->eid = $args['eid'];
			$this->task = $this->config['feed_event_mapping'][$this->eid];
			if(!$this->task) return false;
			return $this->extFilteInput($fun, $args);
		}
		return false;
	}
	
	protected function extFilteInput($fun, $args)
	{
		$extfun = $fun.'_Ext';
		return $this->$extfun($args);
	}
}
