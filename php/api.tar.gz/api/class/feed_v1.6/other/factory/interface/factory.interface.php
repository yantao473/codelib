<?php 
interface ifactory
{
	/**
	 * 获得模型对象
	 */
	public static function getModel($model, $type='d', $new=0, $params='nouse');
}
