<?php
class ModelfactoryException extends Exception{}