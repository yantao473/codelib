<?php
require 'interface/factory.interface.php';
require 'exception/ModelfactoryException.php';
class ModelFactory implements ifactory
{
	private static $modeltype  = array('d','i','l');
	
	private static $factorys = array();
	
	public static function getModel($model, $type='d', $new=0, $params='nouse')
	{
		if(!in_array($type, self::$modeltype))
		{
			throw new ModelfactoryException("ModelFactory create [{$model}] obj is error. type not defined.");
		}
		
		if(!array_key_exists($model, self::$factorys))
		{
			require FEED_LIB_ROOT.'model/'.$type.'model/'.$model.'.php';
		}
		
		if(!$new&&array_key_exists($model, self::$factorys))
		{
			$obj = self::$factorys[$model];
		}
		else
		{
			if($params!=='nouse')
			{
				$obj = new $model($params);
			}
			else
			{
				$obj = new $model();
			}
			
			self::$factorys[$model] = $obj;
		}
		
		return $obj;
	}
}
