<?php

class mylog
{
	function set_error_log($errormsg, $errordata, $errorfile)
	{
		$msg = '';
		$msg .= '['.date('Y-m-d H:i:s').'] ';
		$msg .= 'error:'.$errormsg.' ';
		$msg .= 'data:'.$errordata.' ';
		$msg .= "\n";
		return error_log($msg, 3, $errorfile);
	}
}
