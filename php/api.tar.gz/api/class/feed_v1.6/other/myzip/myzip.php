<?php
require 'exception/MyzipException.php';

class myzip
{
	protected $zip;
	protected $type = array('rar', 'zip');
	
	public function __construct()
	{
                require_once 'lib/otherlib/string/stringcon.php';
		$this->zip = new ZipArchive();
	}
	public function extract_all($files, $exts, &$filelist, &$rnamelist, &$all_list)
	{
		if(!empty($files))
		{
			foreach ($files as $path=>$file)
			{
			    if(file_exists($file))
			    {
				//解析文件类型
				$file_ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

				$paths = array();
				
				if(in_array($file_ext,$this->type))
				{
					if($file_ext=='rar')
					{
						$execs = $this->extract_rar($file, $path, $exts, $paths, 1);
						$need = $execs[0];
						$rname = $execs[1];
						$alls = $execs[2];
					}
					else
					if($file_ext=='zip')
					{
						$execs = $this->extract_zip($file, $path, $exts, $paths, 1);
						$need = $execs[0];
						$rname = $execs[1];
						$alls = $execs[2];
					}

					if($execs)
					{
						$filelist = array_merge($filelist, $need);
						$rnamelist = array_merge($rnamelist, $rname);
						$all_list = array_merge($all_list, $alls);
					}

					if(!empty($paths))
					{
						$this->extract_all($paths, $exts, $filelist, $rnamelist, $all_list);
					}
				}
			    }
			}
		}
		
		return true;
	}

	public function extract_rar($file, $path, $exts, &$paths, $tag=0)
	{
		$rar_file = rar_open($file);

		$res = false;
		$extract_arr = array();
		$return_arr = array();
        	$allpaths = array();
		$changename_arr = array();

		if($rar_file)
		{
			$file_list = rar_list($rar_file);

			if($file_list)
			{
				foreach($file_list as $infile)
				{
					$paths_arr = array('zip_path'=> '', 'rel_path'=> '', 'need_path'=> '');

					$entry = $infile->getName();
					$fileinfo = pathinfo($entry);
					$file_ext = isset($fileinfo['extension']) ? $fileinfo['extension'] : '';
					$dirname = isset($fileinfo['dirname']) ? $fileinfo['dirname'] : '';
					$filename = isset($fileinfo['filename']) ? $fileinfo['filename'] : '';
					
					//压缩包内地址
					$path_absolute = $path.'/'.$entry;

					//实际解压地址
					$rel_extract_path = $this->file_path_to_md5($path_absolute);

					if(in_array($file_ext, $exts))
					{
						$res = $infile->extract(false, $rel_extract_path);

						array_push($return_arr, $path_absolute);
						array_push($changename_arr, $rel_extract_path);
                                                $paths_arr['need_path'] = $rel_extract_path;
                                                //$paths_arr['need_path'] = 'base.txt';
					}
					
					if($tag&&in_array($file_ext, $this->type))
					{
						$rel_filename = basename($rel_extract_path, '.'.$file_ext);

						$path_relative = dirname($rel_extract_path).'/'.$rel_filename.'('.$file_ext.')'.'/';

						$paths[$path_relative] = $rel_extract_path;
						
						$res = $infile->extract(false, $rel_extract_path);
					}
                                        $paths_arr['zip_path'] = $path_absolute;
                                        $paths_arr['rel_path'] = $rel_extract_path;
					$allpaths[] = $paths_arr;
				}
			}
		}

		return $res ? array($return_arr,$changename_arr, $allpaths) : $res;
	}

	public function extract_zip($file, $path, $exts, &$paths, $tag=0)
	{
		$zip_res = $this->zip->open($file);

		$res = false;
		$extract_arr = array();
		$return_arr = array();
		$allpaths = array();
		$changename_arr = array();

		if($zip_res===true)
		{	
			for($i = 0; $i < $this->zip->numFiles; $i++)
			{
				$paths_arr = array('zip_path'=> '', 'rel_path'=> '', 'need_path'=> '');

				$entry = $this->zip->getNameIndex($i);
				$fileinfo = pathinfo($entry);
				$file_ext = isset($fileinfo['extension']) ? $fileinfo['extension'] : '';
				$dirname = isset($fileinfo['dirname']) ? $fileinfo['dirname'] : '';
				$filename = isset($fileinfo['filename']) ? $fileinfo['filename'] : '';
				
				//压缩包内地址
				$path_absolute = $path.'/'.$entry;
				//实际解压地址
				$rel_extract_path = $this->file_path_to_md5($path);
				$rel_extract_entry = $this->file_path_to_md5($entry);
				$rel_path_absolute = $rel_extract_path.'/'.$rel_extract_entry;	

				if(in_array($file_ext, $exts))
				{
					$rename_res = $this->zip->renameName($entry, $rel_extract_entry);

					if($rename_res)
					{
						$res = $this->zip->extractTo($rel_extract_path, $rel_extract_entry);

						array_push($return_arr, $path_absolute);
						array_push($changename_arr, $rel_path_absolute);
                                                $paths_arr['need_path'] = $rel_path_absolute;
                                                //$paths_arr['need_path'] = 'base.txt';
					}
				}
				
				if($tag&&in_array($file_ext, $this->type))
				{
					$rename_res = $this->zip->renameName($entry, $rel_extract_entry);
					
					if($rename_res)
					{
						$rel_filename = basename($rel_path_absolute, '.'.$file_ext);
						$path_relative = dirname($rel_path_absolute).'/'.$rel_filename.'('.$file_ext.')'.'/';
					
						$paths[$path_relative] = $rel_path_absolute;

						$res = $this->zip->extractTo($rel_extract_path, $rel_extract_entry);
					}
				}
                                
                                $paths_arr['zip_path'] = $path_absolute;
                                $paths_arr['rel_path'] = $rel_path_absolute;
				$allpaths[] = $paths_arr;
			}
			
			$this->zip->unchangeAll();
			$this->zip->close();
		}
		
		return $res ? array($return_arr, $changename_arr, $allpaths) : $res;
	}

	public function file_path_to_md5($path)
	{
		if($path)
		{
			$path = preg_replace('/\/+/','/', rtrim($path, '/'));
			
			$path_arr = explode('/', $path);

			$path_rel = '';
			
			foreach($path_arr as $name)
			{
				$ext = pathinfo($name, PATHINFO_EXTENSION);
				$name = stringcon::txt_convert_encoding($name);
				if($name&&!preg_match('/^[0-9a-z%()]+(\.\w+)*$/i', $name))
				{
					//echo $name."\n";
					if($ext)
							$path_rel .= urlencode(basename($name, '.'.$ext)).'.'.$ext.'/';
					else
							$path_rel .= urlencode($name).'/';
				}
				else
				{
						$path_rel .= $name.'/';
				}

			}

			return rtrim($path_rel, '/');
		}

		return false;
	}
}

/*
$obj = new myzip();

$filelist = array();
$rnamelist = array();
$all_list = array();
$obj->extract_all(array('test/final'=>'final.rar'), array('txt','pdf','doc','php','bak','524'), $filelist, $rnamelist, $all_list);
print_r($filelist);
print_r($rnamelist);
print_r($all_list);

foreach($filelist as $filename)
{
	echo urldecode(stringcon::txt_convert_encoding($filename))."\n";
}

foreach($filelist as $filepath)
{
    echo stringcon::txt_convert_encoding($filepath)."\n";
}
*/ 
