<?php
class MyzipException extends Exception{}