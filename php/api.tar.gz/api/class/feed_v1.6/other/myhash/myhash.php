<?php

class myhash
{
	public static function gethashtable($db_pre, $tb_pre, $indexs, $dbnum=1, $tbnum=4)
	{
		if(empty($indexs) || !is_array($indexs)) return false;
		$result = array();
		foreach($indexs as $index)
		{
			if(empty($index)) continue;

			$index_key = sprintf('%u', abs(crc32($index)));
			$index_db = $index_key % $dbnum;
			$index_tb = $index_key % $tbnum;
			$dbname = $db_pre.sprintf("%02s", dechex($index_db));
			$tbname = $tb_pre.sprintf("%02s", dechex($index_tb));
			$result[$dbname][$tbname][] = sprintf('%s', $index);
		}
		return $result;
	}

	public static function gethashtable_aveg($db_pre, $tb_pre, $indexs, $dbnum=1, $tbnum=4)
	{
		if(empty($indexs) || !is_array($indexs)) return false;
		$result = array();
		$alltbnum = $dbnum*$tbnum;
		foreach($indexs as $index)
		{
			if(empty($index)) continue;

			$index_key = sprintf('%u', abs(crc32($index)));
			$index_tb = $index_key % $alltbnum;
			$index_db = $index_tb % $dbnum;
			$dbname = $db_pre.sprintf("%02s", dechex($index_db));
			$tbname = $tb_pre.sprintf("%02s", dechex($index_tb));
			$result[$dbname][$tbname][] = $index;
		}
		return $result;
	}
}
