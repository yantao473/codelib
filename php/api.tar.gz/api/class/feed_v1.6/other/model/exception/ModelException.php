<?php
class ModelException extends Exception{}