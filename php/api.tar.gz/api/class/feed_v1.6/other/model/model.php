<?php
require 'exception/ModelException.php';

class model
{
	var $params = array();
	var $ModelFactory;
	var $config;
	
	public function __construct()
	{
		global $config;
		$this->config = $config;
		$this->ModelFactory = new ModelFactory();
		$this->init();
	}
	
	public function setpro($name, $value)
	{
		if(property_exists($this, $name))
		{
			$this->$name = $value;
			return $this;
		}
		else
		{
			throw new ModelException("rsyncer property [{$name}] not exists.");
		}
	}
	
	public function getpro($name)
	{
		if(property_exists($this, $name))
		{
			return $this->$name;
		}
		else
		{
			throw new ModelException("rsyncer property [{$name}] not exists.");
		}
	}
	
	public function init(){}
}