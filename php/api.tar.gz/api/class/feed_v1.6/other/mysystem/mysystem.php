<?php



class mysystem
{

	public static function check_pid_exists($pid)
        {
                $pid = intval($pid);

                if($pid>0)
                {
                        $command = "ps -p {$pid}";
                        $select_pid = trim(exec($command));
                        return (strpos($select_pid, (string)$pid)!==false) ? true : false;
                }

                return false;
        }

	public static function get_ppid_with_pid($pid)
	{
	
	}

	public static function get_ppid_with_name($name)
	{
		$lines = array();
		exec("ps jx | grep {$name}", $lines);

		if(!empty($lines))
		{
			$ppids = array();
			$pids  = array();

			foreach($lines as $line)
			{
		        	$info = explode(' ',trim($line));
				$key = 1;

				foreach($info as $v)
				{
					if($key>2) break;

					if($v)
					{
						if($key==1) $ppid = $v;
						if($key==2) $pid  = $v;
						$key++;
					}
				}

				$ppids[] = $ppid;
				$pids[]  = $pid;
			}

			return array('ppid'=>$ppids, 'pid'=>$pids);
		}

		return false;
	}

	public static function chk_ppids_exists($name)
	{
		$ppids = self::get_ppid_with_name($name);

		if($ppids['ppid'])
		{
			foreach($ppids['ppid'] as $key=>$ppid)
			{
				$chk_res = self::check_pid_exists($ppid);

				if(!$chk_res||$ppid=='1')
				{
					if($ppids['pid'][$key]!='1')
					exec("kill -9 {$ppids['pid'][$key]}");
				}
			}
		}
	}
}
