<?php
class mycurl
{
	protected $url;
	protected $datas;
	protected $fields;
	protected $curl_handle;
	protected $timeout = 20;
	protected $types = array('post', 'get');
	protected $plist = array();
	protected $headers;
	protected $body;
	protected $allcontents;

	public function __construct($params)
	{
		$this->url = isset($params['url']) ? $params['url'] : '';
		$this->datas = isset($params['datas']) ? $params['datas'] : array();

		$this->init();
		$this->fields = $this->create_fields();
	}

	public function run($type='post')
	{
		if(in_array($type, $this->types))
		{
			$fun = 'goto_'.$type;
			$execres = $this->$fun();
			if($execres!==false)
			{
				$this->allcontents = $execres;
				$this->getheaders();
			}
			return $execres;
		}
		return false;
	}

	public function setparams($key, $name)
	{
		$this->plist[$key] = $name;
		return $this;
	}

	public function delparams($key)
	{
		if(array_key_exists($key, $this->plist))
		{
			unset($this->plist[$key]);
		}
		return $this;
	}

	public function parse_run_res()
	{
		$response_code = curl_getinfo($this->curl_handle, CURLINFO_HTTP_CODE);
		return $response_code=='200' ? true : false;
	}	

	private function goto_post()
	{
		$this->setparams(CURLOPT_POST, 1)
			->setparams(CURLOPT_POSTFIELDS, $this->fields);
		return $this->goto_run();
	}

	private function goto_get()
	{
		$this->url = ltrim($this->url, '?').'?'.$this->fields;
		$this->setparams(CURLOPT_HTTPGET, 1)
			->setparams(CURLOPT_URL, $this->url);
		return $this->goto_run();
	}

	public function init()
	{
		$this->curl_handle = curl_init();
		$this->setparams(CURLOPT_URL, $this->url)
			->setparams(CURLOPT_HEADER, 0)
			->setparams(CURLOPT_TIMEOUT, $this->timeout)
			->setparams(CURLOPT_NOBODY, 1)
			->setparams(CURLOPT_RETURNTRANSFER, 1);
	}

	private function goto_run()
	{
		curl_setopt_array($this->curl_handle, $this->plist);
		return curl_exec($this->curl_handle);
	}

	private function create_fields()
	{
		if($this->datas&&is_array($this->datas))
		{
			$field_str = '';
			foreach ($this->datas as $key=>$value)
			{
				$field_str .= $key.'='.$value.'&';
			}
			return rtrim($field_str, '&');
		}
	}

	private function getheaders()
	{
		if(isset($this->plist[CURLOPT_HEADER])&&$this->plist[CURLOPT_HEADER]==1)
		{
			$pos = strpos($this->allcontents, "\r\n\r\n");
			if($pos)
			{
				$headers_str = substr($this->allcontents, 0, $pos);
				$headers_arr = explode("\r\n", $headers_str);
				if(is_array($headers_arr))
				{
					$j = 0;
					$this->headers = array();
					foreach ($headers_arr as $one)
					{
						$one = trim($one);
						$tmparr = array();
						$pres = preg_match('/^(.+)?\: (.+)$/i', $one, $tmparr);
						if(!$pres)
						{
							$this->headers[$j] = $one;
							$j++;
						}
						else
						{
							$tmpkey = strtolower(trim($tmparr[1]));
							$tmpvalue = trim($tmparr[2]);
							$this->headers[$tmpkey] = $tmpvalue;
						}
					}
				}
				//分离body部分，刨除\r\n\r\n
				$this->body = substr($this->allcontents, $pos+4);
			}
		}
	}
	public function forequest($type, &$times, $count=5)
	{
		$this->setparams(CURLOPT_HEADER, 1);
		$times = 1;
		do
		{
			$iscontinue = false;
			$str = $this->run($type);
			$headers = $this->headers;
			$body = $this->body;
			if($str)
			{
				$result = array();
				if(preg_match('/^HTTP\/1\.[01] (\d{3,6})? .*$/i', $headers[0], $result))
				{
					if($result[1]=='200'||$result[1]=='206')
					{
						return $body;
					}
					else
						if($result[1]=='302')
						{
							$this->url = $headers['location'];
							$iscontinue = true;
						}
				}
			}
			$times++;
		}
		while ($times<=$count&&$iscontinue);
	}
}

/*
$obj = new mycurl(array('url'=>'http://127.0.0.1/tc/test/f.php', 'datas'=>array('a'=>1, 'b'=>2, 'c'=>3)));
//$obj->setparams($key, $name);
echo $obj->run('post');
*/
