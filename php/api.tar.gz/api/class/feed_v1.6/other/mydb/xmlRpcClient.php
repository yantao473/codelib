<?php
/*
 * Copyright (c) 2002, �������з�����
 * All rights reserved
 *
 * �ļ����ƣ�xmlRpcClient.php
 * �ļ���ʾ��
 * ժ    Ҫ��
 *              xmlRPC��php client�ӿ�
 * ��    �ߣ��Ŵ�
 * �������ڣ�2004-11-26
 */

class xmlRpcParser_oth
{
	function unescape(&$value)
	{
		$value = str_replace("&lt;", "<", $value);
		$value = str_replace("&gt;", ">", $value);
		$value = str_replace("&quot;", "\"", $value);
		$value = str_replace("&amp;", "&", $value);
	}
	
	function parse($xml, &$data)
	{
		$data = array();
		
		$xmllen = strlen($xml);
		
		$step = 0;
		$name = "";
		$value = "";
		$endname = "";
		for ($i=0; $i<$xmllen; $i++)
		{
			if ($xml[$i] == "<")
			{
				if ($step == 0)
				{
					$step = 1;
					$name = "";
				}
				else if ($step == 1)
				{
					$data = "1";
					return false;
				}
				else if ($step == 2)
				{
					$step = 3;
					$endname = "";
				}
				else if ($step == 3)
				{
					$data = "2";
					return false;
				}
				else
				{
					$data = "3";
					return false;
				}
			}
			else if ($xml[$i] == ">")
			{
				if ($step == 0)
				{
					$data = "4";
					return false;
				}
				else if ($step == 1)
				{
					$step = 2;
					$value = "";
				}
				else if ($step == 2)
				{
					$data = "5";
					return false;
				}
				else if ($step == 3)
				{
					$step = 0;
					if ("/".$name != $endname)
					{
						$data = "6";
						return false;
					}
					xmlRpcParser_oth::unescape($value);
					$data[$name] = $value;
				}
				else
				{
					$data = "7";
					return false;
				}
			}
			else
			{
				if ($step == 0)
				{
					# added by lubing, 2007.2.7
					if ($xml[$i] == "\n") {
						# skip LF charater between '>' & '<'
						continue;
					}
					#end
					$data = "8";
					return false;
				}
				else if ($step == 1)
				{
					$name .= $xml[$i];
				}
				else if ($step == 2)
				{
					$value .= $xml[$i];
				}
				else if ($step == 3)
				{
					$endname .= $xml[$i];
				}
				else
				{
					$data = "9";
					return false;
				}
			}
		}
		return true;
	}
}

class xmlRpcClient_oth
{
	var $xmlSend;
	
	var $data;

	var $server;
	var $port;
	var $timeout;
	
	function xmlRpcClient_oth($server, $port, $timeout)
	{
		$this->server = $server;
		$this->port = $port;
		$this->timeout = $timeout;
	}
	
	function setServer($server)
	{
		$this->server = $server;
	}
	
	function setPort($port)
	{
		$this->port = $port;
	}
	
	function setTimeout($timeout)
	{
		$this->timeout = $timeout;
	}
	
	function setFunction($name)
	{
		$this->xmlSend = $this->xmlSend."<func>".$name."</func>";
	}
	
	function setPara($name, $value)
	{
		$this->xmlSend = $this->xmlSend."<".$name.">".htmlspecialchars($value)."</".$name.">";
	}
	
	function getResult($name)
	{
		if (!array_key_exists($name, $this->data))
		{
			return "";
		}
		return $this->data[$name];
	}
	
	function getResult2($name, $index)
	{
		return $this->getResult($name.$index);
	}

	function getmicrotime()
	{
		list($usec, $sec) = explode(" ",microtime()); 
		return ((float)$usec + (float)$sec); 
	} 
	
	function writeerror($error)
	{
		$handle = fopen("/tmp/xmlRpcClientError.log", "a");
		if ($handle)
		{
			fwrite($handle, date('Y-m-d H:i:s')." ".
				$this->server." ".
				$this->port." ".
				$this->timeout." ".
				$error."\n");
			fclose($handle);
		}
	}

	function callRemote()
	{
		$start_time = $this->getmicrotime();
		
		$xml = "";
		$fp = fsockopen($this->server, $this->port, &$errno, &$errstr, $this->timeout);
		if (!$fp)
		{
			for ($i=0; $i<2; $i++)
			{
				usleep(100000);
				$fp = fsockopen($this->server, $this->port, &$errno, &$errstr, $this->timeout);
				if ($fp)
				{
					break;
				}
			}
			if (!$fp)
			{
				$this->writeerror("����ʧ��");
				return -2;
			}
		}
		fputs($fp, $this->xmlSend."<end></end>");
		while (!feof($fp))
		{
			$ret = fgets($fp,1024);
			if (!$ret)
			{
				fclose($fp);
				$this->writeerror("��ȡ����ʧ�� ".$this->xmlSend);
				return -2;
			}
			# added by lubing, 2007.2.7
			if ($ret == "<0/>\n")
			{
				# end of response encountered
				break;
			}
			# end
			$xml = $xml.$ret;
		}
		fclose($fp);
		
		if (!xmlRpcParser_oth::parse($xml, $this->data))
		{
			$this->writeerror("xmlRpcParser_oth::parse����ʧ�� ".$xml);
			return -2;
		}
		return 1;	
		$end_time = $this->getmicrotime();
		$handle = fopen("/tmp/xmlRpcClientTime.log", "a");
		if ($handle)
		{
			fwrite($handle, ($end_time - $start_time)." ".$this->xmlSend."\n");
			fclose($handle);
		}
		
		return 1;
	}
	
	function clearBuf()
	{
		$this->xmlSend = "";
		$this->data = array();
	}
}

class CXmlRpcTool_oth
{
	function getstat($server, $port, $timeout)
	{
		echo "=========================== start ========================\n";
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("getstat");
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{		//ִ�гɹ�
				echo "pid: ".$client->getResult("pid")."\n";
			}
			else
			{		//�߼�����
				echo "getResult: ".$ret."\n";
			}
		}
		else
		{			//�������
			echo "callRemote: ".$ret."\n";
		}
		echo "============================ end =========================\n";
	}
	
	function safeclose($server, $port, $timeout)
	{
		echo "=========================== start ========================\n";
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("safeclose");
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			echo "getResult: ".$ret."\n";
		}
		else
		{			//�������
			echo "callRemote: ".$ret."\n";
		}
		echo "============================ end =========================\n";
	}
	
	function execute($server, $port, $timeout, $path, $app, $sql, &$data)
	{
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("execute");
		$client->setPara("path", $path);
		$client->setPara("app", $app);
		$client->setPara("sql", $sql);
	
		$data = array();
		$data["errcode"] = $client->callRemote();
		if (0 < $data["errcode"])
		{
			$data["errcode"] = $client->getResult("re");
			if (0 < $data["errcode"])
			{		//ִ�гɹ�
				$data["colnum"] = $client->getResult("colnum");
				$data["rownum"] = $client->getResult("rownum");
				$data["insertid"] = $client->getResult("insertid");
				$data["totalchange"] = $client->getResult("totalchange");
				$data["info"] = array();
				for ($i=0; $i<$client->getResult("rownum"); $i++)
				{
					$data["info"][$i] = array();
					for ($j=0; $j<$client->getResult("colnum"); $j++)
					{
						$data["info"][$i][$client->getResult("col_".$j)] = $client->getResult2($client->getResult("col_".$j)."_", $i);
					}
				}
			}
			else
			{		//�߼�����
				$data["errinfo"] = $client->getResult("errinfo");
			}
		}
		else
		{			//�������
			$data["errinfo"] = "Զ�̵���ʧ��";
		}
	}
	
	function sqlite_now()
	{
		return date("Y-m-d H:i:s");
	}
	
	function sqlite_escape($src)
	{
		return str_replace("'", "''", $src);
	}
	
	function mysql_exec($server, $port, $timeout, $app, $sql, &$data)
	{
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("mysql_exec");
		$client->setPara("app", $app);
		$client->setPara("sql", $sql);
	
		$data = array();
		$data["errcode"] = $client->callRemote();
		if (0 < $data["errcode"])
		{
			$data["errcode"] = $client->getResult("re");
			if (0 < $data["errcode"])
			{		//ִ�гɹ�
				$data["colnum"] = $client->getResult("colnum");
				$data["rownum"] = $client->getResult("rownum");
				$data["insertid"] = $client->getResult("insertid");
				$data["totalchange"] = $client->getResult("totalchange");
				$data["info"] = array();
				for ($i=0; $i<$client->getResult("rownum"); $i++)
				{
					$data["info"][$i] = array();
					for ($j=0; $j<$client->getResult("colnum"); $j++)
					{
						$data["info"][$i][$client->getResult("col_".$j)] = $client->getResult2($client->getResult("col_".$j)."_", $i);
					}
				}
			}
			else
			{		//�߼�����
				$data["errinfo"] = $client->getResult("errinfo");
			}
		}
		else
		{			//�������
			$data["errinfo"] = "Զ�̵���ʧ��";
		}
	}
	
	function setCache($server, $port, $timeout, $app, $key, $value, &$data)
	{
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("setCache");
		$client->setPara("app", $app);
		$client->setPara("key", $key);
		$client->setPara("value", $value);
	
		$data = array();
		$data["errcode"] = $client->callRemote();
		if (0 < $data["errcode"])
		{
			$data["errcode"] = $client->getResult("re");
			if (0 < $data["errcode"])
			{		//ִ�гɹ�
			}
			else
			{		//�߼�����
				$data["errinfo"] = $client->getResult("errinfo");
			}
		}
		else
		{			//�������
			$data["errinfo"] = "Զ�̵���ʧ��";
		}
	}
	
	function getCache($server, $port, $timeout, $app, &$data)
	{
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$num = count($data["key"]);
		$client->clearBuf();
		$client->setFunction("getCache");
		$client->setPara("app", $app);
		$client->setPara("num", $num);
		for($i=0; $i<$num; $i++)
		{
			$client->setPara("key_".$i, $data["key"][$i]);
		}
	
		$data = array();
		$data["errcode"] = $client->callRemote();
		if (0 < $data["errcode"])
		{
			$data["errcode"] = $client->getResult("re");
			if (0 < $data["errcode"])
			{		//ִ�гɹ�
				$data["value"] = array();
				for($i=0; $i<$num; $i++)
				{
					$data["value"][$i] = $client->getResult("value_".$i);
				}
			}
			else
			{		//�߼�����
				$data["errinfo"] = $client->getResult("errinfo");
			}
		}
		else
		{			//�������
			$data["errinfo"] = "Զ�̵���ʧ��";
		}
	}
	
	function CacheStat($server, $port, $timeout)
	{
		echo "=========================== start ========================\n";
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("CacheStat");
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{		//ִ�гɹ�
				echo "app num: ".$client->getResult("num")."\n";
				for ($i=0; $i<$client->getResult("num"); $i++)
				{
					echo $client->getResult("app_".$i)." count: "
						.$client->getResult("count_".$i)."\n";
				}
			}
			else
			{		//�߼�����
				echo "getResult: ".$ret."\n";
			}
		}
		else
		{			//�������
			echo "callRemote: ".$ret."\n";
		}
		echo "============================ end =========================\n";
	}
	
	function delApp($server, $port, $timeout, $app, &$data)
	{
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("delApp");
		$client->setPara("app", $app);
	
		$data = array();
		$data["errcode"] = $client->callRemote();
		if (0 < $data["errcode"])
		{
			$data["errcode"] = $client->getResult("re");
			if (0 < $data["errcode"])
			{		//ִ�гɹ�
			}
			else
			{		//�߼�����
				$data["errinfo"] = $client->getResult("errinfo");
			}
		}
		else
		{			//�������
			$data["errinfo"] = "Զ�̵���ʧ��";
		}
	}
	
	function delKey($server, $port, $timeout, $app, $key, &$data)
	{
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		
		$client->clearBuf();
		$client->setFunction("delKey");
		$client->setPara("app", $app);
		$client->setPara("key", $key);
	
		$data = array();
		$data["errcode"] = $client->callRemote();
		if (0 < $data["errcode"])
		{
			$data["errcode"] = $client->getResult("re");
			if (0 < $data["errcode"])
			{		//ִ�гɹ�
			}
			else
			{		//�߼�����
				$data["errinfo"] = $client->getResult("errinfo");
			}
		}
		else
		{			//�������
			$data["errinfo"] = "Զ�̵���ʧ��";
		}
	}
}

?>
