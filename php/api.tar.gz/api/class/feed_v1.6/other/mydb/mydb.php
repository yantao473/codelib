<?php

require 'xmlRpcClient.php';
require 'sampleConMysql.php';

class mydb extends model
{
	var $dbconf = array();
	var $host;
	var $user;
	var $pass;
	var $port;
	var $dbname;
	var $tbname;

	function query($sql, &$info)
	{
		if (empty($sql)&&empty($this->dbconf)) return false;
		CXmlRpcTool_oth::mysql_exec($this->host,$this->port, $this->timeout, $this->app, $sql, $info);
		return ($info["errcode"] > 0);
	}

	function sampleQuery($sql, &$info)
	{
		if (empty($sql)&&empty($this->dbconf)) return false;
		$conobj = sampleConMysql::getInstance($this->host, $this->user, $this->pass, $this->dbname, $this->port);
		$info = $conobj->myselect($sql);
		if($info['error']=='')
		{
			return true;
		}
		return false;
	}

	function sampleQuery_noresult($sql)
	{
		if (empty($sql)&&empty($this->dbconf)) return false;
		$conobj = sampleConMysql::getInstance($this->host, $this->user, $this->pass, $this->dbname, $this->port);
		return $conobj->query($sql);
	}

	function sampleInsert_noresult($sql)
	{
		if (empty($sql)&&empty($this->dbconf)) return false;
		$conobj = sampleConMysql::getInstance($this->host, $this->user, $this->pass, $this->dbname, $this->port);
		return $conobj->myinsert($sql);
	}

	function setdbconf($conf)
	{
		$this->dbconf = array_merge($this->dbconf, $conf);
		$this->host = $this->dbconf['host'];
		$this->user = $this->dbconf['user'];
		$this->pass = $this->dbconf['pass'];
		$this->port = $this->dbconf['port'];
		$this->dbname = $this->dbconf['dbname'];
		isset($this->dbconf['tbname']) ? $this->tbname = $this->dbconf['tbname'] : '';
		return $this;
	}

	function settbconf($tbname)
	{
		$this->dbconf['tbname'] = $tbname;
		return $this;
	}

	function insert()
	{
		//.....
	}

	function madeInsertSql($tbname, $params, $tbpre='')
	{
		if($tbname&&is_array($params)&&!empty($params))
		{
			$sql = 'insert into '.$tbname.' ';
			$fileds = '';
			$values = '';

			foreach ($params as $filed=>$value)
			{
				$fileds .= '`'.$tbpre.$filed.'`,';
				$values .= '\''.mysql_escape_string($value).'\',';
			}
			$fileds = '('.rtrim($fileds, ',').')';
			$values = ' values ('.rtrim($values, ',').')';
					$sql .= $fileds.$values;
					return $sql;
					}
					return false;
					}

					function makdInsertSqlMulti($tbname, $keys, $vales, $tbpre='')
					{
					if($tbname&&is_array($keys)&&!empty($keys)&&is_array($vales)&&!empty($vales))
					{
					$sql = 'insert into '.$tbname.' ';
					$fileds = '';
					$values = '';
					foreach ($keys as $filed)
					{
					$fileds .= '`'.$tbpre.$filed.'`,';
					}
					$fileds = '('.rtrim($fileds, ',').')';
					$onev = '';
					foreach ($vales as $value)
					{
						foreach($value as $k=>$v)
							$value[$k] = mysql_escape_string($v);
						$onev .= '(\''.implode('\',\'', $value).'\'),';
					}
					$values = ' values '.rtrim($onev, ',');
					$sql .= $fileds.$values;
					return $sql;
					}
			return false;
					}

			function getInParams($params)
			{
				if($params&&is_array($params))
				{
					$str = '';
					foreach($params as $p)
					{
						$str .= '\''.mysql_escape_string($p).'\',';
					}

					return $str ? '('.rtrim($str, ',').')' : false;
				}
				return false;
			}

			function sampleLockTab($type='read')
			{
				$sql = "lock table {$this->dbconf['tbname']} {$type};";
				return $this->sampleQuery_noresult($sql);
			}

			function sampleUnLockTabs()
			{
				$sql = "unlock tables;";
				return $this->sampleQuery_noresult($sql);
			}
}

