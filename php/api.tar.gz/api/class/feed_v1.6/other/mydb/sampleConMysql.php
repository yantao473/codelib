<?php

class sampleConMysql
{
	var $conn;
	var $host;
	var $user;
	var $pass;
	var $port;

	function sampleConMysql($host, $user, $pass, $port, $pcon)
	{
		$this->host = $host;
		$this->user = $user;
		$this->pass = $pass;
		$this->port = $port;
		$this->connect($pcon);

	}

	function connect($pcon)
	{
		$conn = false;
		if($pcon)
		{
			$conn = mysql_pconnect($this->host.':'.$this->port, $this->user, $this->pass);
		}
		else
		{
			$conn = mysql_connect($this->host.':'.$this->port, $this->user, $this->pass);
		}
		if($conn)
		{
			$this->conn = $conn;
		}
		else
		{
			exit('mysql connect is error!');
		}
	}

	function getInstance($host, $user, $pass, $dbname='', $port='3306', $pcon=0)
	{
		$connectIndex = $host.':'.$port.' -u '.$user.' -p '.$pass;
		if(!isset($GLOBALS['DB_OBJ_INDEXS'][$connectIndex])||!is_object($GLOBALS['DB_OBJ_INDEXS'][$connectIndex]))
		{
			$GLOBALS['DB_OBJ_INDEXS'][$connectIndex] = new sampleConMysql($host, $user, $pass, $port, $pcon);
		}
		$mysqlObj = $GLOBALS['DB_OBJ_INDEXS'][$connectIndex];
		if($dbname)
		{
			if(!$mysqlObj->selectDb($dbname))
				return false;
		}
		return $mysqlObj;
	}

	function query($sql)
	{
		if($this->conn&&$sql)
		{
			return mysql_query($sql, $this->conn);
		}
		else
		{
			return false;
		}
	}

	function myinsert($sql)
	{
		if($this->conn&&$sql&&$this->query($sql))
		{
			return mysql_insert_id($this->conn);
		}
		return false;
	}

	function mydelete($sql)
	{
		if($this->conn&&$sql&&$this->query($sql))
		{
			return mysql_affected_rows($this->conn);
		}
		return false;
	}

	function myselect($sql)
	{
		if($this->conn&&$sql)
		{
			$result = $this->query($sql);	
			if($result)
			{
				$infos = array();
				$error = mysql_error($this->conn);
				$errno = mysql_errno($this->conn);
				$insertid = mysql_insert_id($this->conn);
				$totalchange = mysql_affected_rows($this->conn);
				while($row = mysql_fetch_assoc($result))
				{
					$infos[] = $row;
				}
				return array(
						'error'=>$error,
						'errno'=>$errno,
						'insertid'=>$insertid,
						'totalchange'=>$totalchange,
						'info'=>$infos,
					    );
			}
		}
		return false;
	}

	function selectDb($dbname)
	{
		if($this->conn&&$dbname)
		{
			return mysql_select_db($dbname, $this->conn);
		}
		return false;
	}
}
