<?php
/*
* Copyright (c) 2009, �������з�����
* All rights reserved
*
* �ļ����ƣ�CBDB.php
* ժ    Ҫ��BDB���ݿ�rpc�ӿ�
* ��    �ߣ��ź���
* ʱ    �䣺2009-3-13
*/
include_once("xmlRpcClient.php");

class dbcon 
{
	/**
	 * ����һ����¼
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $key keyֵ
	 * @param $value valueֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @return true/false
	 */
	function insert($app, $dbname, $key, $value, $server, $port, $timeout=3)
	{
		if (empty($server) || empty($port) || $dbname == '' || $key == '')
			return false;
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("insert");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		if (is_array($key))
		{
			if (is_array($key[0]))
			{
				$client->setPara("key", $key[0][0]);
				$client->setPara("tag", "1");
			}
			else
			$client->setPara("key", $key[0]);
			$client->setPara("timeid", $key[1]);
			if (isset($key[2]))
				$client->setPara("id", $key[2]);
		}
		else
		{
			$client->setPara("key", $key);
		}
		$client->setPara("data", $value);
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ɾ��һ����¼
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $key keyֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @return true/false
	 */
	function del($app, $dbname, $key, $server, $port, $timeout=3)
	{
		if (empty($server) || empty($port) || $dbname == '' || $key == '')
			return false;
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("del");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		if (is_array($key))
		{
			if (is_array($key[0]))
			{
				$client->setPara("key", $key[0][0]);
				$client->setPara("tag", "1");
			}
			else
				$client->setPara("key", $key[0]);
			$client->setPara("timeid", $key[1]);
			if (isset($key[2]))
				$client->setPara("id", $key[2]);
		}
		else
		{
			$client->setPara("key", $key);
		}
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ����һ����¼
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $key keyֵ
	 * @param $value valueֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @return true/false
	 */
	function update($app, $dbname, $key, $value, $server, $port, $timeout=3)
	{
		if (empty($server) || empty($port) || $dbname == '' || $key == '')
			return false;
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("update");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		if (is_array($key))
		{
			if (is_array($key[0]))
			{
				$client->setPara("key", $key[0][0]);
				$client->setPara("tag", "1");
			}
			else
				$client->setPara("key", $key[0]);
			$client->setPara("timeid", $key[1]);
			if (isset($key[2]))
				$client->setPara("id", $key[2]);
		}
		else
		{
			$client->setPara("key", $key);
		}
		$client->setPara("data", $value);
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ��ȡһ����¼
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $key keyֵ
	 * @param $data ����dataֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @return true/false
	 */
	function getdata($app, $dbname, $key, &$data, $server, $port, $timeout=3)
	{
		if (empty($server) || empty($port) || $dbname == '' || $key == '')
			return false;
		$data = '';
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("getdata");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		if (is_array($key))
		{
			$client->setPara("key", $key[0]);
			$client->setPara("timeid", $key[1]);
			if (isset($key[2]))
				$client->setPara("id", $key[2]);
		}
		else
		{
			$client->setPara("key", $key);
		}
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				if (1 == $client->getResult("total"))//find
					$data = $client->getResult("data");
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ��ȡ������¼
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $keys keyֵ���������� keys=array('0'=>'111','1'=>''...)
	 * @param $data ����dataֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @return true/false
	 */
	function getdatas($app, $dbname, $keys, &$data, $server, $port, $timeout=3)
	{
		if (empty($server) || empty($port) || $dbname == '')
			return false;
		if (!is_array($keys) || empty($keys))
			return false;
		if (!is_array($data))
			$data = array();
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("getdatas");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		foreach ($keys as $k => $v)
		{
			if (is_array($v))
			{
				$client->setPara("key".$k, $v[0]);
				$client->setPara("timeid".$k, $v[1]);
				if (!empty($v[2]))
					$client->setPara("id".$k, $v[2]);
			}
			else
			{
				$client->setPara("key".$k, $v);
			}
		}
		$num = count($keys);
		$client->setPara("num", $num);
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				//not find = ""
				for($i=0; $i < $num; $i++)
				{
					$data[$keys[$i]] = $client->getResult("data".$i);
				}
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ��ȡ��¼������BTREE����Ч��
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $key keyֵ
	 * @param $data ����dataֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @return true/false
	 */
	function getcount($app, $dbname, &$total, $server, $port, $timeout=3)
	{
		if (empty($server) || empty($port) || $dbname == '')
			return false;
		$total = 0;
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("getcount");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				if (0 < $client->getResult("total"))//find
					$total = $client->getResult("total");
			}
			else
			{//�߼�����
				return false;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ������־
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @return true/false
	 */
	function checkpoint($server, $port, $timeout=3)
	{
		if (empty($server) || empty($port))
			return false;
		$total = 0;
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("checkpoint");
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ��ȡ�б���¼ --  ������
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $start ��ʼλ��
	 * @param $num   ��ȡ����
	 * @param $data ����dataֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @param $order ���� 0 ����,1����
	 * @return true/false
	 */
	function get1list($app, $dbname, $start, $num, &$data, $server, $port, $timeout=3, $order=0)
	{
		if (empty($server) || empty($port) || $dbname == '')
			return false;
		$data = array();
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("get1list");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		$client->setPara("start", $start);
		$client->setPara("num", $num);
		$client->setPara("order", $order);
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				$data['total'] = $client->getResult("total");
				$data['num'] = intval($client->getResult("num"));
				for($i=0; $i < $data['num']; $i++)
				{
					$data[$i]['key'] = $client->getResult("key".$i);
					$data[$i]['id'] = $client->getResult("id".$i);
					$data[$i]['data'] = $client->getResult("data".$i);
				}
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	/**
	 * ��ȡ�б���¼
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $keys keyֵ��ǰ�벿��
	 * @param $start ��ʼλ��
	 * @param $num   ��ȡ����
	 * @param $data ����dataֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @param $order ���� 0 ����,1����
	 * @return true/false
	 */
	function getlist($app, $dbname, $key, $start, $num, &$data, $server, $port, $timeout=3,$order=0)
	{
		/*
		echo 'app==='.$app;
                echo '<br/>';	
		echo 'dbname==='.$dbname;
                echo '<br/>';	
		echo 'key==='.$key;
                echo '<br/>';	
		echo 'start==='.$start;
                echo '<br/>';	
		echo 'num==='.$num;
                echo '<br/>';	
		echo 'data===';var_dump($data);
                echo '<br/>';	
		echo 'server==='.$server;
                echo '<br/>';	
		echo 'port ==='.$port;
                echo '<br/>';	
		echo 'order ==='.$order;
                echo '<br/>';	
		echo '---------------------------------';
                echo '<br/>';	
		*/
		if (empty($server) || empty($port) || $dbname == '' || $key === '')
			return false;
		$data = array();
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("getlist");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		if (is_array($key))
		{
			if (!isset($key[0]))
				return false;
			if (isset($key[0]))
			{
				$client->setPara("key", $key[0]);
				$client->setPara("tag", "1");
			}
			else
			{
				$client->setPara("key", $key[0]);
				$client->setPara("dupkey", "1");
			}
		}
		else
		{
			$client->setPara("key", $key);
		}
		$client->setPara("start", $start);
		$client->setPara("num", $num);
		$client->setPara("order", $order);
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				$data['total'] = $client->getResult("total");
				$data['num'] = intval($client->getResult("num"));
				for($i=0; $i < $data['num']; $i++)
				{
					$data[$i]['key'] = $client->getResult("key".$i);
					$data[$i]['id'] = $client->getResult("id".$i);
					$data[$i]['data'] = $client->getResult("data".$i);
				}
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
	
	/**
	 * ����ɾ���б���¼������key�µ��б�
	 * @param $app Ӧ������
	 * @param $dbname ���ݿ��ļ���
	 * @param $keys keyֵ��ǰ�벿��
	 * @param $start ��ʼλ��
	 * @param $num   ��ȡ����
	 * @param $data ����dataֵ
	 * @param $server ip
	 * @param $port   �˿�
	 * @param $timeout ��ʱ��
	 * @param $order ���� 0 ����,1����
	 * @return true/false
	 */
	function dellist($app, $dbname, $key, &$data, $server, $port, $timeout=3)
	{
		if (empty($server) || empty($port) || $dbname == '' || $key === '')
			return false;
		$data = array();
		$client = new xmlRpcClient_oth($server, $port, $timeout);
		$client->clearBuf();
		$client->setFunction("dellist");
		$client->setPara("path", $app);
		$client->setPara("dbname", $dbname);
		if (is_array($key))
		{
			if (!isset($key[0]))
				return false;
			if (isset($key[0]))
			{
				$client->setPara("key", $key[0]);
				$client->setPara("tag", "1");
			}
			else
			{
				$client->setPara("key", $key[0]);
				$client->setPara("dupkey", "1");
			}
		}
		else
		{
			$client->setPara("key", $key);
		}
		$ret = $client->callRemote();
		if (0 < $ret)
		{
			$ret = $client->getResult("re");
			if (0 < $ret)
			{
				$data['total'] = $client->getResult("total");
			}
			else
			{//�߼�����
				return true;
			}
		}
		else
		{//�������
			return false;
		}
		return true;
	}
}
?>
