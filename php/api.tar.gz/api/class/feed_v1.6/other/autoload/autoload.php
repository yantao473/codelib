<?php

class autoload
{
	const LIBPRE = 'lib/otherlib/';
	private $regclass = array(
						'myhash',
						'mylog',
						);
	
	public function __construct()
	{
		spl_autoload_register(array($this, 'run'));
	}

	private function run($classname)
	{
		$classname = strtolower($classname);
		if(in_array($classname, $this->regclass))
		{
			$path = self::LIBPRE.$classname.'/'.$classname.'.php';
			require $path;
		}
	}
}
