<?php
require 'exception/StringconException.php';
/**
 * 字符串处理对象
 * @author matong
 * @version 1.0
 */
class stringcon
{
	/**
	 * 把字符串切割，末尾添加end字符
	 * @param string $string
	 * @param int $length
	 * @param string $end
	 */
	public static function chunk_split_chinese($string, $length, $end='')
	{
		$strlen = strlen($string);
		$start = 0;
		$strtmp = '';
		
        while ( true )
        {
        		if($strlen < $length)
        		{
        			$strtmp .= substr($string, $start);
        			break;
        		}
        		
        		$len = $length;
        		
                for($i=$start; $i<$start+$length; $i++)
                {
                        if (ord($string[$i]) > 127)
                        {
                                $i += 2;
                        }
                }

				if($i > $start+$length)
				{
					$len = $i - 3 - $start;
				}
				
                $strtmp .= substr($string, $start, $len).$end;
                
                $strlen -= $len;
				$start += $len;
        }

        return $strtmp;
	}
        
        public static function str_split_chinese_utf8($string, $length)
        {
            $split_tag = str_repeat(chr(0), 10);

            $length = intval($length);

            $split_str = self::chunk_split_chinese($string, $length, $split_tag);

            if($split_str&&$length>0)
            {
                return @explode($split_tag, trim($split_str, $split_tag));
            }

            return false;
        }
	
	public static function txt_convert_encoding($str,$to='UTF-8')
	{
		$from_types = array("ASCII", "Unicode", "UTF-8", "GBK", "GB2312");
		$this_type  = mb_detect_encoding($str, $from_types);

		if($this_type)
		{
			if(strtolower($this_type)==strtolower($to))
			{
				return $str;
			}
			else
			{
				return @mb_convert_encoding($str, $to, $this_type);
			}
		}
		else
		{
			return false;
		}
	}
        
        public static function chkunicode($str)
        {
            $bom_1 = ord(substr($str, 0, 1));
            $bom_2 = ord(substr($str, 1, 1));

            if($bom_1=='254'&&$bom_2='255')
            {
                return 'lit';
            }
    
            if($bom_1=='255'&&$bom_2='254')
            {
                return 'big';
            }
            
            return false;
        }

        public static function uni2utf8($str, $type='big')
        {
            $str = preg_replace('/^(\xFF\xFE|\xFE\xFF)/', '', $str);
            $tmp = array();
            $return = '';
            $strlen = strlen($str);

            for ($i=0;$i<$strlen;$i=$i+2)
            {
                if($type!='big')
                {
                    $f = ord(substr($str, $i, 1))<<8;
                    $s = ord(substr($str, $i+1, 1));
                }
                else
                {
                    $f = ord(substr($str, $i+1, 1))<<8;
                    $s = ord(substr($str, $i, 1));
                }
    
                $ord = $f + $s; 

                if(!array_key_exists($ord, $tmp))
                {
                    if($ord<128)
                        $tmp[$ord] = chr($ord);
                    else
                    if($ord<2048)
                        $tmp[$ord] = chr(192 + (($ord - ($ord % 64)) / 64)) . chr(128 + ($ord % 64));
                    else
                        $tmp[$ord] = chr(224 + (($ord - ($ord % 4096)) / 4096)) . chr(128 + ((($ord % 4096) - ($ord % 64)) / 64)) . chr(128 + ($ord % 64));
                }
                
                $return .= $tmp[$ord];
            }
            
            return $return;
        }
        
	public static function chunk_split_chinese_gb2312($string, $length, $end='')
	{
		$strlen = strlen($string);
		$start = 0;
		$strtmp = '';
		
                while ( true )
                {
        		if($strlen < $length)
        		{
        			$strtmp .= substr($string, $start);
        			break;
        		}
        		
        		$len = $length;
        		
                        for($i=$start; $i<$start+$length; $i++)
                        {
                            if (ord($string[$i]) > 0x80)
                            {
                                $i++; 
                            }
                        }

			if($i > $start+$length)
			{
	    		    $len = $i - 2 - $start;
			}
				
                        $strtmp .= substr($string, $start, $len).$end;
                
                        $strlen -= $len;
			$start += $len;
                }

                return $strtmp;
	}

        public static function get_context($search, $contents, $len, $encode='UTF-8')
        {
            $begin_address = 0;
            $search_result = '';
            $search_length = mb_strlen($search, $encode); 

            while(($search_address = mb_strpos($contents, $search, $begin_address, $encode))!==false)
            {
                $pre_address = $search_address - $len;
                $pre_address = $pre_address > 0 ? $pre_address : 0; 
                
                $search_result .= mb_substr($contents, $$pre_address, ($search_length + (2 * $len)), $encode);
                $begin_address = $search_address + $search_length;
            }
            
            return $search_result;
        }
}
