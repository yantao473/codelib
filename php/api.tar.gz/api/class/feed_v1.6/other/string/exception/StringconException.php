<?php
class StringException extends Exception{}