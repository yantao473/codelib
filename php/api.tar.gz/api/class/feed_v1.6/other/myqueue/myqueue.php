<?php

class myqueue
{	
	public function run()
	{
		$stdin_handle = fopen('php://stdin', 'r');

		while (true)
		{
			$len = fread($stdin_handle, 4);
			$funret = 0;			
			if(trim(strlen($len))<4)
			{
				echo pack("C", $funret);
				continue;
			}
			$len = unpack('V', $len);
			if(isset($len[1])&&$len[1])
			{
				$data = '';
				while (strlen($data) < $len[1])
				{
					$data .= fread($stdin_handle, $len[1]-strlen($data));
				}
				//解析参数
				$version = unpack("V", substr($data, 0, 4));
				$cmd = unpack("V", substr($data, 4, 4));
				$reverse = unpack("V", substr($data, 8, 4));
				$len = unpack("V", substr($data, 12, 4));
				$args = unserialize( substr($data, 16) );
				//调用任务
				ob_start();
				$this->serivice($args);
				$str = ob_get_contents();
				ob_end_clean();
				error_log($str, 3, '/tmp/matong.txt');
			}
			echo pack("C", $funret);
		}
		fclose($stdin_handle);
	}

	protected function serivice($args)
	{
		//具体服务逻辑......
	}
}
