<?php
//����ҳ

class ErrorTmpl {
	function __construct()
	{
		
	}
	
	function show($message='')
	{
		
		
	}
	
	

}

?>