<?php
//message 事件处理

class msgevent
{
	function __construct()
	{
		global $notice_code;
                $this->notice_code = $notice_code;
		$this->notice_obj = new Notice();
		$this->bdb_obj = new GetBdb();
		$this->tools_obj = new Tools();
		$this->wbv4_obj = new weibov4();
		$this->rpc_obj = new RpcDb();
		$this->notice_words = array(
                        '与朋友一起分享你的经验与知识！',
                        '与朋友一起分享你的经验与知识吧！',
                        '与朋友们一起分享你的经验与知识！',
                        '与你的朋友分享你的经验与知识！',
                        '与你的朋友分享你的经验与知识吧！',
                        '与你的朋友一起互动问答吧！',
                        '与你的朋友一起互动问答！',
                        '与朋友们一起互动问答！',
                        '与朋友们一起互动问答吧！',
                        '解惑答疑，就在微什么！',
                        '精彩问答，尽在微什么！',
                        '解惑答疑，尽在微什么！',
                        '精彩问答，就在微什么！',
                        '乐享知识，尽在微什么！',
                        '乐享知识，就在微什么！',
                        '让知识展现你的价值！',
                        '让知识展现价值！',
                        '让知识展现价值吧！',
                        '了解十万个微什么！',
                        '享受问答的乐趣！',
                        '享受问答的乐趣吧！',
                        '贡献知识，感受分享的快乐！',
                        '贡献知识，感受分享的快乐吧！',
                        '微什么，汇集大家的智慧！',
                        '一起共建大家的知识社区！',
                        '发现无限知识！',
                        '答疑解惑，分享知识！',
                        '分享经验，收获精彩！',
                        '分享知识与经历！',
                        '让思考更有意义，每天问个微什么！',
                        '微什么，让思考更有意义！',
                        '你的经验，别人的微什么！',
                        '无微不至，有问必答！',
                        '倾听他人智慧！',
                        '倾听他人的智慧！',
                 );
	}
	function run($row)
	{
		if (!isset($row[0]))
		{
			return false;
		}
		else
		{
			$this->row = $row;
		}
		$type = $this->row[0];
		$info = array();
		
		switch($type)
		{
			case EVENT_QUESTION_ADD://新加问题
			case EVENT_QUESTION_DEL:
				break;
			case EVENT_QUESTION_UPDATE:
			case EVENT_QUESTION_TITLE_UPDATE:
			case EVENT_QUESTION_REDIRECT:
				break;
			case EVENT_QUESTION_DESC_UPDATE: // 问题描述更新
				break;
			case EVENT_QUESTION_LOCK:	// 锁定
				break;
			case EVENT_QUESTION_TAG_ADD://问题增加话题
				break;
			case EVENT_QUESTION_TAG_DEL:
				break;
			case EVENT_ANSWER_ADD://添加回答 7
				$msg_ask_user = false;
				// 找到问题的提问者
				$url = DOMAIN . '/q/getquestion.php';
				$param = array('questionid' => $this->row['questionid'] , 'app' => API_APP_ID);
				$this->tools_obj->curl_set($url,'post',$param,$res);
				$res = json_decode($res,true);	
				$ask_uid = $res['uid'];
				
				// 获取问题提问者的设置
				$url = DOMAIN . '/u/getuser.php';
				$param = array('uid' => $ask_uid , 'app' => API_APP_ID);
				$this->tools_obj->curl_set($url,'post',$param,$res);
				$uinfos = json_decode($res,true);	
				$this->tools_obj->read_app($uinfos[$ask_uid]['notice_set'] , $notice_code);

				// 判断提问者是否设置了给自己发消息
				if(!empty($notice_code)) {
					foreach($notice_code as $k => $code) {
                        			$notice_app_name = array_search($code , $this->notice_code);
                				if($notice_app_name == 'notice_ans') {	// 勾选了"我的问题有新的回答"
							$msg_ask_user = true;
							break;
						}
					}
				}
				// 获取关注此问题的所有用户
				$url = DOMAIN . '/f/getfollowlist.php';
				$param = array(
						'type'	=> 'gqo',
						'qid'	=> $this->row['questionid'],
						'app' => API_APP_ID,
						);
				$this->tools_obj->curl_set($url,'post',$param,$res);
				$res = json_decode($res,true);	
				if($res['total'] > 0)
				{
					$arr_fansid = array();
					foreach($res['follow'] as $k => $gzinfo)
					{
						// 需要检查此用户的通知设置

						// 发通知
						// 提问者没有勾选 "我的问题有新的回答" 或 关注者是回答者本身 都不发消息
						if(($msg_ask_user == false && $gzinfo[2] == $ask_uid) || $gzinfo[2] == $this->row['uid']) {
							continue;
						}
						echo 'message to fansid : ' .$gzinfo[2] ."\n";
						//防止重复发消息
						if(!@array_key_exists($gzinfo[2],$arr_fansid)){
							//雷平解析回答字符串有问题
							$this->row['answer'] = '';
							$res = $this->notice_obj->add_notice($gzinfo[2], serialize($this->row));// 添加通知
							$arr_fansid[$gzinfo[2]] = $gzinfo[2];

							// 发送微博通知
							$this->send_weibo_notice($gzinfo[2]);

						}
						if($res['err_code'] != 0) {
							$res['touid'] = $gzinfo[2] ;
							$this->write_err_log($res,EVENT_ANSWER_ADD);
						}
					}
				}
				break;
			case EVENT_ANSWER_DEL:
				break;
			case EVENT_ANSWER_UPDATE:
			case EVENT_ANSWER_RECOVER:		// 恢复答案
				break;
			case EVENT_COMMENT_ADD://评论
				$msg_ask_user = false;
				$filter_user = array();
				// 获取某个回答的所有评论人
				if($this->row['type'] == 2) // 2 回答评论 1 问题评论	
				{
					// 取回答者uid
					$url = DOMAIN . '/q/getans.php';
					$param = array('answerid' => $this->row['targetid'] , 'app' => API_APP_ID);
					$this->tools_obj->curl_set($url,'post',$param,$res);
					$ansinfo = json_decode($res,true);	
					$ans_uid = $ansinfo['uid'];
					$this->row['auid'] = $ans_uid;			// 2012-06-18 雷平说要在发评论消息时加上回答者的uid

					// 评论者与回答者一致时 不给本人发消息
					if($this->row['uid'] != $ans_uid)
					{
						// 获取问题提问者的设置
						$url = DOMAIN . '/u/getuser.php';
						$param = array('uid' => $ans_uid , 'app' => API_APP_ID);
						$this->tools_obj->curl_set($url,'post',$param,$res);
						$uinfos = json_decode($res,true);	
						$this->tools_obj->read_app($uinfos[$ans_uid]['notice_set'] , $notice_code);
		
						// 判断提问者是否设置了给自己发消息
						if(!empty($notice_code)) {
							foreach($notice_code as $k => $code) {
	        	                			$notice_app_name = array_search($code , $this->notice_code);
	                					if($notice_app_name == 'notice_cmt') {	// 勾选了"有人评论我的回答"
									$msg_ask_user = true;
									break;
								}
							}
						}
						// 是否给回答者发消息
						if($msg_ask_user == true) {
							echo 'to uid : ' . $ans_uid . "\n";
							$filter_user[] = $ans_uid;
							$res = $this->notice_obj->add_notice($ans_uid, serialize($this->row));// 添加通知

							// 发送微博通知
							$this->send_weibo_notice($ans_uid);
						}
					}

					$url = DOMAIN . '/q/getcommentlist.php';
					$param = array(
							'type'  => 'tac',
							'oid'   => $this->row['targetid'],
							'app' => API_APP_ID,
							);
					echo $url . "\n\n";
					print_r($param);
					$this->tools_obj->curl_set($url,'post',$param,$res);
					$res = json_decode($res,true);	
					var_Dump($res);
					
					if(!empty($res))
					{
						foreach($res as $k => $clist)
						{
							if(empty($clist['data'])) {
								continue;
							}
							$cinfo = $clist['data'];
							if(!in_array($cinfo['uid'],$filter_user)&&$cinfo['uid']!=$this->row['uid'])
							{
								echo 'to uid : ' . $cinfo['uid'] . "\n";
								$filter_user[] = $cinfo['uid'];
								//$cinfo[0] = $this->row[0];
								$res = $this->notice_obj->add_notice($cinfo['uid'], serialize($this->row));// 添加通知
								
								// 发送微博通知
								$this->send_weibo_notice($cinfo['uid']);

								if($res['err_code'] != 0) {
									$res['touid'] = $cinfo['uid'];
									$this->write_err_log($res,EVENT_COMMENT_ADD);
								}
							}
						}
					}
				}
				if($this->row['type'] == 1) // 2 回答评论 1 问题评论   
				{
					$filter_user = array();
/*
					$url = DOMAIN . '/q/getcommentlist.php';
					$param = array(
							'type'  => 'tqc',
							'oid'   => $this->row['targetid'],
							'app' => API_APP_ID,
							);
					$this->tools_obj->curl_set($url,'post',$param,$res);
					$res = json_decode($res,true);	
*/

                                        $url = DOMAIN . '/q/getquestion.php';
                                        $param = array(
                                                        'questionid'   => $this->row['targetid'],
							'app' => API_APP_ID,
                                                        );
                                        $this->tools_obj->curl_set($url,'post',$param,$res);
                                        $res = json_decode($res,true);  

					if(!empty($res))
					{
						//foreach($res as $k => $clist)
						//{
							//if(empty($clist['data'])) {
							//	continue;
							//}
							//$cinfo = $clist['data'];
							//if(!in_array($cinfo['uid'],$filter_user)&&$cinfo['uid']!=$this->row['uid'])
							if(!in_array($res['uid'],$filter_user)&&$res['uid']!=$this->row['uid'])
							{
								echo 'to uid : ' . $res['uid'] . "\n";
								$filter_user[] = $res['uid'];
								
								$result = $this->notice_obj->add_notice($res['uid'], serialize($this->row));// 添加通知
								
								// 发送微博通知
								$this->send_weibo_notice($res['uid']);

								if($result['err_code'] != 0) {
									$res['touid'] = $res['uid'];
									$this->write_err_log($res,EVENT_COMMENT_ADD);
								}
							}
						//}
					}	
				}
				break;
			case EVENT_COMMENT_DEL:
				break;
			case EVENT_QUESTION_INVITE:		// 邀请回答
				echo 'touid : ' . $this->row['inviter'] . "\n";
				$res = $this->notice_obj->add_notice($this->row['inviter'], serialize($this->row));// 添加通知
				if($res['err_code'] != 0) {
					$res['touid'] = $this->row['inviter'];
					$this->write_err_log($res,EVENT_QUESTION_INVITE);
				}
				else {
					// 找到问题的提问者
                                	$url = DOMAIN . '/q/getquestion.php';
                                	$param = array('questionid' => $this->row['questionid'] , 'app' => API_APP_ID);
                                	$this->tools_obj->curl_set($url , 'post' , $param , $res);
                                	$res = json_decode($res,true);
                                	$title = $res['title'];

                                	// 获取问题提问者的设置
                                	$url = DOMAIN . '/u/getuser.php';
                                	$param = array('uid' => $this->row['uid'] , 'app' => API_APP_ID);
                                	$this->tools_obj->curl_set($url , 'post' , $param , $res);
                                	$uinfos = json_decode($res,true);
						
					$params = array(
        					'uids' => $this->row['inviter'],
        					'tpl_id' => '3480113259496163',
        					'objects1' => '@'.urldecode($uinfos[$this->row['uid']]['nick']) . ' ',	// 结尾的空格不能删除 注意
						'objects2' => $title,
        					'action_url' => 'http://ask.weibo.com/q/' . $this->row['questionid'],
					);
					print_r($param);
					$url = '/2/notification/send.json';
					$json = $this->wbv4_obj->post($url , $params , 'POST');
					$res = json_decode($json , true);
					var_dump($res);
				}
				break;
			case EVENT_VOTE_AGREE_ADD://投票赞同
				$msg_ask_user = false;
				// $row['uid'] 是谁投票的，不是被投票回答的uid
				$url = DOMAIN . '/q/getans.php';
				$param = array(
						'answerid'   => $this->row['answerid'],
						'app' => API_APP_ID,
						);
				$this->tools_obj->curl_set($url,'post',$param,$res);
				$res = json_decode($res,true);	
				$ans_uid = $res['uid'];
				$ans_vnum = $res['vnum'];
				
				// 发布勋章逻辑，如果用户回答了至少1个问题，并且回答的被赞次数超过6次 那么就发一个勋章
				if($ans_vnum >= 6) {
					// 发勋章接口
					$url = '/badges/app/issue.json';
					$params = array(
        					'badge_id' => 'dtXwdG2v',
        					'uids' => $ans_uid,
						);
					$json = $this->send_weibo_medal($params);
					$res = json_decode($json , true);
					echo 'send medal : ';var_dump($res);
				
					// 入数据库记录
                                        $this->weibo_medal_mysql($params);
				}


				// 获取问题提问者的设置
				$url = DOMAIN . '/u/getuser.php';
				$param = array('uid' => $ans_uid , 'app' => API_APP_ID);
				$this->tools_obj->curl_set($url,'post',$param,$res);
				$uinfos = json_decode($res,true);	
				$this->tools_obj->read_app($uinfos[$ans_uid]['notice_set'] , $notice_code);

				// 判断提问者是否设置了给自己发消息
				if(!empty($notice_code)) {
					foreach($notice_code as $k => $code) {
                        			$notice_app_name = array_search($code , $this->notice_code);
                				if($notice_app_name == 'notice_ag') {	// 勾选了"我的问题有新的回答"
							$msg_ask_user = true;
							break;
						}
					}
				}

				if($this->row['uid'] != $ans_uid && $msg_ask_user) {
					echo 'touid : '. $ans_uid;
					$res = $this->notice_obj->add_notice($ans_uid, serialize($this->row));// 添加通知
					
					// 发送微博通知
					$this->send_weibo_notice($ans_uid);

					if($res['err_code'] != 0) {
						$res['touid'] = $ans_uid;
						$this->write_err_log($res,EVENT_VOTE_AGREE_ADD);
					}
				}
				break;
			case EVENT_QUESTION_ADOPT: // 采纳回答
				$msg_ask_user = false;
				$url = DOMAIN . '/q/getans.php';
				$param = array(
						'answerid'   => $this->row['answerid'],
						'app' => API_APP_ID,
						);
				echo 'touid : ' . $this->row['uid'];
				$this->tools_obj->curl_set($url,'post',$param,$res);
				$res = json_decode($res,true);	
				$ans_uid = $res['uid'];
				//回答UID
				//$this->row['uid'] = $ans_uid;
	
				// 获取问题提问者的设置
				$url = DOMAIN . '/u/getuser.php';
				$param = array('uid' => $ans_uid , 'app' => API_APP_ID);
				$this->tools_obj->curl_set($url,'post',$param,$res);
				$uinfos = json_decode($res,true);	
				$this->tools_obj->read_app($uinfos[$ans_uid]['notice_set'] , $notice_code);

				// 判断提问者是否设置了给自己发消息
				if(!empty($notice_code)) {
					foreach($notice_code as $k => $code) {
                        			$notice_app_name = array_search($code , $this->notice_code);
                				if($notice_app_name == 'notice_ac') {	// 勾选了"我的问题有新的回答"
							$msg_ask_user = true;
							break;
						}
					}
				}
				
				if($msg_ask_user) {
					$res = $this->notice_obj->add_notice($ans_uid, serialize($this->row));// 添加通知
					
					// 发送微博通知
					$this->send_weibo_notice($ans_uid);

					if($res['err_code'] != 0) {
						$res['touid'] = $res['uid'];
						$this->write_err_log($res,EVENT_VOTE_AGREE_ADD);
					}
				}
				break;
			case EVENT_VOTE_AGREE_DEL:
				break;
			case EVENT_VOTE_AGAINST_ADD://反对票
				break;
			case EVENT_VOTE_AGAINST_DEL:
				break;
			case EVENT_VOTE_NOHELP:
				break;
			case EVENT_TAG_ADD://增加话题
				break;
			case EVENT_TAG_UPDATE:
				break;
			case EVENT_TAG_DEL:
				break;
			case EVENT_TAG_LOCK:
				break;
			case EVENT_TAG_FATHER_ADD://增加父话题id
			case EVENT_TAG_CHILD_ADD:
				break;
			case EVENT_TAG_FATHER_DEL:
			case EVENT_TAG_CHILD_DEL:
				break;
			case EVENT_TAG_EXP_UPDATE://话题经验
				break;
			case EVENT_USER_UPDATE_LOGO://用户修改头像
			case EVENT_USER_UPDATE://用户修改
				break;
			case EVENT_USER_REGISTER:
				break;
			default:
				return false;
		}


		return true;
	}

	// 发微博站内消息
	private function send_weibo_notice($uid) {
		$res = $this->notice_obj->get_notice_count_unread($uid);
		echo 'send_weibo_notice : uid : '.$uid.' unread_notice :' . intval($res['result']['num']) . "\n";
		// 如果用户的未读消息数大于1 不发消息
		if(intval($res['result']['num']) <= 1) {
                	$params = array(
                        	'uids' => $uid,
                		#'tpl_id' => '126358560892190601',
				'tpl_id' => '126984114156229228',
                        	'objects1_count' => $res['result']['num'],
                		'action_url' => 'http://ask.weibo.com/?d_url=notice',
				'objects2' => $this->notice_words[mt_rand(0 , count($this->notice_words) -1)],
                       	);
                        print_r($params);
                        $url = '/2/notification/send.json';
                       	$json = $this->wbv4_obj->post($url , $params , 'POST');
                        $res = json_decode($json , true);
                	echo "res : \n";print_r($res);	
		}
	}

	private function send_weibo_medal($params) {

                $params['source'] = WEIBO_APP_KEY;
                $ch = curl_init();
                #curl_setopt($ch, CURLOPT_URL, 'http://api.t.sina.com.cn/badges/app/issue.json');
                curl_setopt($ch, CURLOPT_URL, 'http://i2.api.weibo.com/2/proxy/badges/issue.json');
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
                curl_setopt($ch, CURLOPT_USERPWD, WEIBO_USER_PASSWD);
                curl_setopt($ch, CURLOPT_TIMEOUT, 2);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                $h = curl_exec($ch);
                curl_close($ch);
                unset($ch);
                return $h;

	}

	private function weibo_medal_mysql($params) {
                $row = array(
                        'uid' => $params['uids'],
                        'badge_id' => 705,	// dtXwdG2v
                        'ctime' => date('Y-m-d H:i:s'),
                );
                $sql = $this->rpc_obj->prepare_insert_sql('user_badge' , $row);
                $this->rpc_obj->update('stat' , $sql ,  $data);
                echo 'weibo medal mysql : ';var_dump($data);
        }

	private function getqweight($rdata)
	{
		$total = 0;
		foreach ($rdata['a'] as $aid => $v)
		{
			if ($v['weight'] > 0)
				$total += 2*$v['weight'] - self::$userweight;
		}
		return $total;
	}

	private function write_err_log($err_info,$eventid) 
	{
		$fp = @fopen('message_err_log.log','a');
		if(!$fp)
		{
			echo "write err_log false! \n";
			return ;
		}
		$slog = date('Y-m-d H:i:s') . "\t" . 'eventid : ' . $eventid . "\n" . var_export($this->row,true);
		$slog .= "\n";
		$slog .= "touid : " . $err_info['touid'] . "\n";
		$slog .= 'err_code : ' . $err_info['err_code'] . "\t" . 'err_msg : ' . $err_info['err_msg'] . "\n";
		$slog .= "---------------------------------------------------- \n\n";
		@fwrite($fp , $slog);
		@fclose($fp);
		return true;
	}
}

?>
