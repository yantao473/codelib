<?php
/**
 * @fn              添加回答类
 * @author          zhanghua2@staff.sina.com.cn
 * @copyright       v1 
 * @date            2012-06-12
 */

include_once("apiconf.php");

class Answer {

	public $g_para;
	public $g_result;

	function  __construct(&$g_para , &$g_result) {
		$this->g_para	= &$g_para;
		$this->g_result = &$g_result;
		$this->wbv      = new weibov4();
		$this->rpc_obj  = new RpcDb();
		$this->bdb_obj  = new GetBdb();
		$this->logs_obj = new Logs;
		$this->feed_obj = new feed();
		$this->mysql_obj = new MysqlDb();
		$this->tools_obj = new Tools();
		$this->follow_obj = new Follow($g_para , $g_result);
		$this->compare_obj = new Compare;
	}

	/**
	 * 回答时是否被邀请
	 *
	 **/
	public function is_invited($qid){
		$rusutl = $this->bdb_obj->lists('tin', $qid, 0, 1000, $data);
		return $data;
	}
	/**
	 * @微什么 之 检查是否已经回答过
	 * @date 2012-05-03
	 **/
	function check_if_answered(){
		$result = $this->bdb_obj->gets("detail" , $this->g_para['questionid'] , $data);
		if(!empty($data['a'])) {
			foreach($data['a'] as $aid => $ainfo) {
				if( $ainfo['uid'] == $this->g_para['uid'] ) {
					return false;
				}
			}
		}
		// 注册一个问题标题变量 为了发微博所使用
		$this->g_result['title'] = $data['title'];
		return true;
	}

	/**
	 * @微什么 之 写问题日志
	 * @date 2012-05-03
	 **/
	function add_log_list() {
		if($this->g_para['nolog'] == 1) {
			return ;
		}
		$uid = $this->get_logs_uid();
		switch($this->g_para['api_name']) {
			case 'addans' :
				$arr = array(
						'oid'	=> $this->g_para['questionid'],
						'uid'	=> $uid,
						'type'	=> EVENT_ANSWER_ADD,
						'ctime'	=> $this->g_para['time'],
						'content' => $this->g_para['answer'],
					    );
				break;
			case 'upans':
				$this->compare_answer();
				$arr = array(
						'oid'   => $this->g_para['questionid'],
						'uid'   => $uid,
						'type'  => $this->g_result['eid'],
						'ctime' => $this->g_para['time'],
						'content' => $this->g_result['compare_result'],
					    );
		}
		$this->logs_obj->create_logs($arr , $logid_ans);
		$this->g_result['logids_array'][] = $logid_ans;
	}

	/**
	 * @公共 之 发送BDB
	 * @date 2012-05-03
	 **/
	function send_bdb($arr , &$queue_result) {
		$ser_array = array('data' => serialize($arr));
		$url = QDOMAIN . "/send_queue.php";
		$this->tools_obj->curl_set($url , "POST" , $ser_array , $queue_result);
	}

	/**
	 * @公共 之 写MYSQL
	 * @date 2012-05-03
	 **/	
	function send_mysql($arr , &$rpcdb_result) {
		// 取表名
		$this->g_result['table_name'] = $this->mysql_obj->get_table('answer' , $this->g_para['questionid']);
		switch($this->g_para['api_name']) {
			case 'addans' :
				//select is exist
				//以后通过UID和QID查询
				/*
				   $tablename = $this->g_result['table_name'];
				   $aid =  $arr['answerid'];
				   $issql = "select count(answerid) as num from  $tablename  where answerid= '$aid'";
				   $this->rpc_obj->read('question',$issql,$idata);
				   if($idata[0]['num'] == 0){
				   $sql = $this->rpc_obj->prepare_insert_sql($this->g_result['table_name'] , $arr );
				   }
				 */
				$sql = $this->rpc_obj->prepare_insert_sql($this->g_result['table_name'] , $arr );
				break;
			case 'upans':
				$sql = $this->rpc_obj->prepare_update_sql($this->g_result['table_name'] , $arr);
				$sql.= "  where questionid = '".$this->g_para['questionid']."' and answerid = '".$this->g_para['answerid']."' ";
				break;
		}
		$rpcdb_result = $this->rpc_obj->update('question' , $sql , $data);
		return true;
	}

	/**
	 * @微什么 之 添加问题feed
	 * @date 2012-05-03
	 **/
	function add_feed() {
		$result = $this->bdb_obj->gets("question" , $this->g_para['questionid'] , $data);
		if(!empty($data['tags'])) {
			foreach($data['tags'] as $k => $v) {
				$tids_array[] = $k;
			}
		} else {
			$tids_array = array();
		}
		$eid = EVENT_ANSWER_ADD;
		$objs = array(
				'uid'	=> $this->g_para['uid'],
				'qid'	=> $this->g_para['questionid'],
				'aid'	=> $this->g_para['answerid'],
				'tids'	=> $tids_array,
			     );
		$res = $this->feed_obj->addFeedataToQueue($eid,$objs);
		return $res;
	}

	/**
	 * @微什么 之 自动关注
	 * @date 2012-05-03
	 **/
	function add_follow() {
		$this->g_para['type'] = 'question';
		$this->follow_obj->addfollow();
	}

	/**
	 * @微什么 之 是否匿名
	 * @date 2012-05-22
	 **/
	function get_logs_uid(){
		if($this->g_para['owner'] == 1){
			$uid = 0;
		}else if ($this->g_para['owner'] == 0){
			$uid = $this->g_para['uid'];
		}
		return $uid;
	}

	/*
	 * @文本比对
	 *
	 */
	function compare_answer() {
		$deal_answer = $this->compare_obj->textdiff(strip_tags($this->g_para['answer']) , strip_tags($this->g_result['answer_info']['answer']) , $diff);
		if(!empty($diff)) {
			$this->g_result['compare_result'] = $diff;
		} else {
			$this->g_result['compare_result'] = $this->g_para['answer'];
		}
	}

	/*
	 * 获取回答的详细信息
	 *
	 */
	function get_answer_detail() {
		$result = $this->bdb_obj->gets("answer" , $this->g_para['answerid'] , $data);
		$this->g_result['answer_info'] = $data;
		return $result;
	}

	/**
	 * @fn 问题置为解决
	 * @date 05-03
	 **/
	function question_resolved() {

		$uid = $this->get_logs_uid();

		// mysql
		$arr =  array(
				'questionid'	=> $this->g_para['questionid'],
				'status'	=> 1,
				'uid'		=> $uid,
				'utime'		=> $this->g_para['time'],
			     );
		$sql  = $this->rpc_obj->prepare_update_sql('question' , $arr);
		$sql .= "  where questionid = '{$this->g_para[questionid]}' ";
		$result = $this->rpc_obj->update('question' , $sql , $data);

		// bdb 由采纳事件对问题信息进行修改

		return $result;
	}



	function send_to_weibo(){
		$res = false;
		if($this->g_para['sharewb']  == 1){
			if(empty($this->g_para['wbinfo'])){
				$result = $this->bdb_obj->gets("question" , $this->g_para['questionid'] , $data);
				$title = $data['title'];
				$get_answer = $this->g_para['answer'];
				$preg = array(
						'~(<br[^>]+>)~is',
						'~<(/?)p[^>]*>~is',
						'~\[a_(\w+)\]~is',
						'~\[img_[^\]]+\]~is',
						'~([ ])+|(&nbsp;)+~is',
						'~\[(/?)paragraph\]~is',
					     );
				$replace = array(                                                                                 
						'',                                                                                        
						'',                                                                                       
						'',                                                  
						'',
						'',
						''                                                                                              
						);                                                                                                
				$get_answer = preg_replace($preg, $replace, $get_answer);  
				$title = preg_replace('~(&nbsp;)+~is',' ',$title);
				$len_title = $this->tools_obj->mb_stringlen($title);
				$str_ans = $this->tools_obj->mb_stringlen($get_answer);
				$answer_true_length = (110 - $len_title);
				if($str_ans > $answer_true_length ){
					$ans_wb = $this->tools_obj->htmlSubString($get_answer,$answer_true_length);
					$ans_wb = preg_replace('~...$~is' , ' ...' , $ans_wb);
				}else{
					$ans_wb = $get_answer;
				}


				$send_info = '我在@微什么 回答了问题【'.$title.'】 '.$ans_wb;
			}else{
				$send_info = $this->g_para['wbinfo'];
			}
			$mshare_data = array (
					'qid'   => $this->g_para['questionid'],                                   
					'm'     => $this->tools_obj->add_pwd($send_info),                         
					'c1'    => $this->g_para['c1'],                                           
					'c2'    => $this->g_para['c2'],   
					'token'    => $this->g_para['token'],
					'create_pic_only' =>0,     //发微薄又创建图片                             
					);                                                                        
			$url = QDOMAIN . '/mshare.php'; 
			$this->tools_obj->send_curl($url , 'post' , $mshare_data , $res);                         

		}                                                                                                 
		return $res;                                                                                      

	} 

}
?>
