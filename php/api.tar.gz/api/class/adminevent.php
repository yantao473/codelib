<?php
/*
 * 事件搜索功能 for 后台
 * @time 20120306
 *
 **/

class adminevent {

	private $server_info;

	function __construct() {
		$this->rpcdb_obj = new RpcDb();
		$this->rpcdb_obj->getdbinfo('stat',$this->server_info);
                $this->mysqldb_obj = new MysqlDb();
	}

	function run(&$args)
	{
		$row = array();
		switch($args[0])
		{
			case EVENT_TAG_ADD: // 话题添加
			case EVENT_ANSWER_ADD://添加答案
			case EVENT_QUESTION_ADD:// 问题添加
				$this->insertdata($args[0],serialize($args),$args['ctime']);
				break;
			// about question
			case EVENT_QUESTION_TITLE_UPDATE:// 问题标题编辑
			case EVENT_QUESTION_DESC_UPDATE:// 问题描述编辑
			case EVENT_QUESTION_TAG_ADD:// 问题话题添加
			case EVENT_QUESTION_TAG_DEL://问题话题删除
						// about answer
			case EVENT_ANSWER_UPDATE://更新答案
						// about topic
			case EVENT_TAG_UPDATE: // 话题描述修改
			case EVENT_TAG_UPDATE_LOGO: // 话题头像修改
				$this->insertdata($args[0],serialize($args),$args['utime']);
				break;
			default:
				break;
		}
		return true;
	}

	function insertdata($eventid,$content,$createtime){
		$tablename  = 'event_search';
		$dbname = 'stat';
		$row['eventid'] = $eventid;
		$row['content'] = $content;
		$row['createtime'] = $createtime;
		$sql = $this->mysqldb_obj->prepare_insert_sql($tablename,$row);
		$res = $this->rpcdb_obj->update($dbname, $sql, $data);
	}
}
?>
