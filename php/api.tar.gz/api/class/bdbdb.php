<?php
//bdb公共接口

class BdbDb{
	static private $client;
	static private $bdbapp;
	static private $dbname2tableid;
	static private $tableinfo;
	static public  $confid;
	static public  $confauto;
	public $conf;
	function __construct($auto=false)
	{
		global $g_bdb_app;
		self::$client = new bdbClient();
		self::$bdbapp =  $g_bdb_app;
		self::$confid = 0;
		self::$confauto = $auto;
		self::$dbname2tableid = array();
		$this->conf = array();
		self::$tableinfo = array();
	}
	//读恢复配置id
	public function getconfid($id=0)
	{
		if (intval($id) == 0){
			$id = intval(file_get_contents(DATA_PATH.'/conf/cur.conf'));
		}
		if ($id == self::$confid)
			return true;
		if ($id == 0){
			self::$bdbapp =  $g_bdb_app;
			self::$confid = $id;
			return true;
		}
		$filename = DATA_PATH .'/conf/'.fmod($id, 256).'/'.$id.'.conf';
		if (!file_exists($filename))
			return false;
		$data = unserialize(file_get_contents($filename));
		if (!empty($data))
		foreach ($data as $k => $v)
		{
			foreach ($v as $k1 => $v1)
			{
				foreach ($v1 as $k2 => $v2)
				{
					self::$bdbapp["$k"]["$k1"]["$k2"]['ip'] = $_SERVER["BDB_SERVER_BAK_T{$v2}"];
					self::$confid = $id;
				}
			}
		}
		return true;
	}
	public function setconfid($id=0, $data='')
	{
		$id = intval($id);
		if (false === file_put_contents(DATA_PATH.'/conf/cur.conf', $id))
			return false;
		if ($id == 0)
			return true;
		$path = DATA_PATH .'/conf/'.fmod($id, 256);
		if (!file_exists($path)){
			if (mkdir($path) === false)
				return false;
		}
		if (false === file_put_contents($path.'/'.$id.'.conf', $data))
			return false;
		return true;
	}
	private function parsedbname($app, $dbname, $type='w')
	{
		global $g_bdb_table;
		$realname = $dbname;
		$p = strpos($realname, '_');
		$g_k = false;
		if ($p !== false){
			$realname = substr($realname, 0, $p);
		}
		if (strpos($realname, 'k.') !== false){
			$realname = substr($realname, 2);
			if ($type == 'r')
				$g_k = true;
		}
		$realname = $app.'.'.$realname;
		if (empty(self::$dbname2tableid))
			self::$dbname2tableid = array('file.f'=>array(1,1), 'info.i'=>array(1,2), 'info.f'=>array(1,3),'detail.d'=>array(1,4),'question.q'=>array(1,5),'question.a'=>array(1,6),'tag.id'=>array(1,7),'tag.rtv'=>array(1,8),'tag.rta'=>array(1,9),'tag.hot'=>array(1,10),
		 'user.u'=>array(2,1),'tag.cu'=>array(2,2),'tag.same'=>array(2,3),'user.u1'=>array(2,4),'ask.q'=>array(1,11),'qinfo.l'=>array(1,12),
		 'tag.p'=>array(3,1),'user.nick'=>array(3,2),'tag.t'=>array(3,3),
		 'ilist.CF'=>array(4,1),'ilist.CP'=>array(4,7),'ilist.CS'=>array(4,2),'ilist.id'=>array(4,3),
			'zlist.UIF'=>array(4,4),'zlist.UFF'=>array(4,5), 'ilist.F1'=>array(4,6),'clist.cr'=>array(4,8),'clist.cv'=>array(4,9),'clist.cn'=>array(4,10),'clist.ck'=>array(4,11),'clist.ch'=>array(4,12),'clist.ce'=>array(4,13),'clist.cc'=>array(4,14),'clist.cs'=>array(4,15),
			'clist.cm'=>array(4,16),'clist.cz'=>array(4,17),'tlist.tzr'=>array(4,18),'tlist.tzv'=>array(4,19),'tlist.tzh'=>array(4,20),'tlist.tzk'=>array(4,21),'tlist.tze'=>array(4,22),'tlist.tzc'=>array(4,23),'tlist.tza'=>array(4,24),'clist.ca'=>array(4,25),
			'zlist.UI'=>array(5,1),'zlist.UF'=>array(5,2),'ilist.F0'=>array(5,3), 'ilist.F2'=>array(5,4),'ulist.um'=>array(5,5),'ulist.uq'=>array(5,6),'ulist.ua'=>array(5,7),'ulist.ut'=>array(5,8),'ulist.uze'=>array(5,9),'ulist.uzq'=>array(5,10),
			'ulist.uzn'=>array(5,11),'ulist.uza'=>array(5,12),'ulist.uzv'=>array(5,13),'ulist.uzt'=>array(5,14),'ulist.uzy'=>array(5,15),'ulist.uzc'=>array(5,16),'clist.cga'=>array(5,17),'clist.cgb'=>array(5,18),'clist.cgn'=>array(5,19),'clist.cgt'=>array(5,20),
			'v.v'=>array(6),'r.r'=>array(7),'ulist.uqv'=>array(8,1),'tag.rq'=>array(9,1),
			'list.lq'=>array(10,1),'list.lzq'=>array(10,514),'list.lzr'=>array(10,1027),'list.lzv'=>array(10,1540),'list.lzn'=>array(10,2053),'list.lzk'=>array(10,2566),'list.lzh'=>array(10,3079),'list.lze'=>array(10,3592),'list.lzc'=>array(10,4105),'list.lzs'=>array(10,4618),'list.lzm'=>array(10,5131),
			'tlist.tq'=>array(11,1),'tlist.tk'=>array(11,2),
			'glist.gtm'=>array(12,1),'glist.gqm'=>array(12,2),'glist.gsm'=>array(12,3),
			'glist.gpm'=>array(13,1),'glist.gpo'=>array(13,2),'glist.gpd'=>array(13,3),
			'glist.gto'=>array(14,1),'glist.gqo'=>array(14,2),'glist.gso'=>array(14,3),'tlist.tin'=>array(14,4),
			'tlist.te'=>array(15,1),'tlist.tqe'=>array(15,2),'tlist.tqc'=>array(15,3),'tlist.tac'=>array(15,4),
			'ulist.ue'=>array(16,1),
			);
		if (!array_key_exists($realname, self::$dbname2tableid))
			return false;
		self::$tableinfo['tableid'] = self::$dbname2tableid["$realname"][0];
		self::$tableinfo['secondid'] = (array_key_exists(1, self::$dbname2tableid["$realname"])?self::$dbname2tableid["$realname"][1]:'');
		self::$tableinfo['prekey'] = self::i2b(self::$tableinfo['tableid']).(self::$tableinfo['secondid']===''?'':self::i2b(self::$tableinfo['secondid']));
		self::$tableinfo['prelen'] = (self::$tableinfo['secondid']===''?4:8);
		if (!self::gettableconf(self::$tableinfo['tableid'], $tarray))
			return false;
		if (!$g_bdb_table["$tarray[t]"])
			return false;
		if ($g_bdb_table["$tarray[t]"]['type'] != 't')
			return false;
		self::$tableinfo['table'] = ($g_k?'k.':'').$g_bdb_table["$tarray[t]"]['table'];
		self::$tableinfo['app'] = $tarray['app'];
		return true;
	}
	//解析端口等分配
	private function server($app, $dbname, $mkey, &$out, $type='r',$realkey='')
	{
		if (self::$confauto){
			self::getconfid();
		}
		$out = array();
		$out['table'] = $dbname;
		$out['database'] = $app;
		$out['key'] = ($realkey==''? $mkey:$realkey);
		$out['prelen'] = 0;
		if (self::parsedbname($app, $dbname, $type)){//需要转为通用接口的
			$out['database'] = self::$tableinfo['app'];
			if ($out['key'] == '' || in_array($out['database'], array('list','alist'), true)){//getalist
				$mkey = self::$tableinfo['secondid'];
			}
			$out['table'] = self::$tableinfo['table'];
			$out['key'] = self::$tableinfo['prekey'].$out['key'];
			$out['prelen'] = self::$tableinfo['prelen'];
			$app = $out['database'];
			$dbname = $out['table'];
		}
		if (!isset(self::$bdbapp["$app"]))
			return false;
		$out['seg'] = 0;
		$num = 0;
		if (!isset(self::$bdbapp["$app"]["$type"]) && isset(self::$bdbapp["$app"]['w'])){
			$type = 'w';
		}
		switch(isset(self::$bdbapp["$app"]['segtype'])?self::$bdbapp["$app"]['segtype']:'')
		{
			case BDB_SEG_PERNUM://按key大小范围
			$num = abs((int)((float)$mkey/self::$bdbapp["$app"]['segnum']));
			$out['table'] = $dbname.'_'.$num;
			$pernum = count(self::$bdbapp["$app"]['w']);
			if ($pernum > 1){
				$s = (int)fmod($num, $pernum);
			}else{
				$s = 0;
			}
			$out['seg'] = $s;
			$out['ip'] =      self::$bdbapp["$app"]["$type"]["$s"]['ip'];
			$out['port'] =    self::$bdbapp["$app"]["$type"]["$s"]['port'];
			break;
			case BDB_SEG_MD5://按key的md5值后两位分配固定文件个数
			sscanf(substr(md5($mkey), -2), '%x', $num);
			$num = (int)fmod($num, self::$bdbapp["$app"]['segnum']);
			$out['table'] = $dbname.'_'.$num;
			$s = (int)fmod($num, count(self::$bdbapp["$app"]['w']));
			$out['seg'] = $s;
			$out['ip'] =      self::$bdbapp["$app"]["$type"]["$s"]['ip'];
			$out['port'] =    self::$bdbapp["$app"]["$type"]["$s"]['port'];
			break;
			case BDB_SEG_MD5_BIG://按key的md5值后4位分配固定文件个数
			sscanf(substr(md5($mkey), -4), '%x', $num);
			$num = (int)fmod($num, self::$bdbapp["$app"]['segnum']);
			$out['table'] = $dbname.'_'.$num;
			$s = (int)($num/(int)(self::$bdbapp["$app"]['segnum']/count(self::$bdbapp["$app"]['w'])));
			$out['seg'] = $s;
			$out['ip'] =      self::$bdbapp["$app"]["$type"]["$s"]['ip'];
			$out['port'] =    self::$bdbapp["$app"]["$type"]["$s"]['port'];
			break;
			case BDB_SEG_INT_BIG://按key余数分配固定文件个数
			$num = (int)fmod((float)$mkey, self::$bdbapp["$app"]['segnum']);
			$out['table'] = $dbname.'_'.$num;
			$s = (int)($num/(int)(self::$bdbapp["$app"]['segnum']/count(self::$bdbapp["$app"]['w'])));
			$out['seg'] = $s;
			$out['ip'] =      self::$bdbapp["$app"]["$type"]["$s"]['ip'];
			$out['port'] =    self::$bdbapp["$app"]["$type"]["$s"]['port'];
			break;
			case BDB_SEG_INT://按key余数分配固定文件个数
			$num = (int)fmod((float)$mkey, self::$bdbapp["$app"]['segnum']);
			$out['table'] = $dbname.'_'.$num;
			$s = (int)fmod($num, count(self::$bdbapp["$app"]['w']));
			$out['seg'] = $s;
			$out['ip'] =      self::$bdbapp["$app"]["$type"]["$s"]['ip'];
			$out['port'] =    self::$bdbapp["$app"]["$type"]["$s"]['port'];
			break;
			default:
			$out['ip'] =      self::$bdbapp["$app"]["$type"][0]['ip'];
			$out['port'] =    self::$bdbapp["$app"]["$type"][0]['port'];
			break;
		}
		return true;
	}
	//获取 $binkey=0 不需要转为二进制key；1 需要转为二进制key,int 长度,此时的key是数字字符串形式;$nokey 返回值的key 命名方式， 0 使用sepkey值;1使用key值
	public function get($app, $table, $key, &$data, $sepkey='',$binkey=1,$nokey=0)
	{
		$data = array();
		if (is_array($key))
		{
			$from = array();
			$keys = 0;
			if (count($key) > 1)
				$keys = 1;
			$j = 0;
			foreach ($key as $k0 => $k)
			{
				self::server($app, $table, ($sepkey==''?$k:(is_array($sepkey)?$sepkey["$k0"]:$sepkey)), $out,'r',($binkey==1?self::i2b((float)$k):$k));
				$nk = $out['seg'];
				$from["$nk"]['dbname'][] = $out['table'];
				$from["$nk"]['key'][] = $out['key'];
				$from["$nk"]['sort'][] = $j++;
				$from["$nk"]['ip'] = $out['ip'];
				$from["$nk"]['port'] = $out['port'];
				$from["$nk"]['keys'] = $keys;
				$from["$nk"]['database'] = $out['database'];
			}
			$j = 0;
			$multi = array();
			$sort = array();
			foreach ($from as $k => $v)
			{
				$v['type'] = 'GET';
				if (count($v['dbname']) == 1 || count(array_unique($v['dbname'])) == 1)
					$v['table'] = $v['dbname'][0];
				else
					$v['table'] = $v['dbname'];
				if (count($v['key']) == 1)
					$from["$k"]['key'] = $v['key'][0];
				foreach ($v['sort'] as $s)
				{
					$sort[] = $s;
				}
				$multi[] = $v;
			}
			$rkey = $sepkey;
			if ($nokey == 1)
				$rkey = $key;
			if (count($multi) == 1){
				if (!self::$client->run($multi[0], $read))
					return false;
				foreach ($read as $j => $v)
				{
					$k = $j;
					if (@array_key_exists($j,$rkey))
						$k = $rkey["$j"];
					$data["$rkey[$j]"] = $v;
					$j++;
				}
			}else{
				if (!self::$client->runmulti($multi, $read))
					return false;
				$idata = array();
				foreach ($read as $v)
				{
					foreach ($v as $v1)
					{
						$k = $j;
						if (@array_key_exists($sort["$j"],$rkey))
							$k = $rkey["$sort[$j]"];
						$idata[$sort["$j"]]["$k"] = $v1;
						$j++;
					}
				}
				//以下保证出去的数据按原序
				ksort($idata);
				foreach ($idata as $v)
				{
					foreach ($v as $k1 => $v1)
						$data["$k1"] = $v1;
				}
			}
			return true;
		}
		self::server($app, $table, ($sepkey==''?$key:$sepkey), $out,'r',($binkey==1?self::i2b((float)$key):$key));
		$out['type'] = 'GET';
		if (!self::$client->run($out, $data))
			return false;
		return true;
	}
	//更新 sepkey 分隔表用的关键字；key 真实的;$offset 从偏移位置开始更新--尚未生效
	public function update($app, $table, $key, $data, $sepkey='', $offset=0)
	{
		self::server($app, $table, ($sepkey==''? $key:$sepkey), $out, 'w', $key);
		$out['type'] = 'PUT';
		$out['data'] = $data;
		$out['start'] = intval($offset);
		return self::$client->run($out, $data);
	}
	//批量更新
	public function multiupdate($app, $table, $key, $data, $sepkey, &$rdata, $type='PUT')
	{
		$rdata = array();
		if (is_array($key))
		{
			$from = array();
			$keys = 0;
			if (count($key) > 1)
				$keys = 5;
			$j = 0;
			foreach ($key as $k0 => $k)
			{
				self::server($app, $table, ($sepkey==''?$k:(is_array($sepkey)?$sepkey["$k0"]:$sepkey)), $out,'w',$k);
				$nk = $out['seg'];
				$from["$nk"]['dbname'][] = $out['table'];
				$from["$nk"]['key'][] = $out['key'];
				$from["$nk"]['data'][] = $data["$k0"];
				$from["$nk"]['sort'][] = $j++;
				$from["$nk"]['ip'] = $out['ip'];
				$from["$nk"]['port'] = $out['port'];
				$from["$nk"]['keys'] = $keys;
				$from["$nk"]['database'] = $out['database'];
			}
			$j = 0;
			$multi = array();
			$sort = array();
			foreach ($from as $k => $v)
			{
				$v['type'] = $type;
				if (count($v['dbname']) == 1 || count(array_unique($v['dbname'])) == 1)
					$v['table'] = $v['dbname'][0];
				else
					$v['table'] = $v['dbname'];
				if (count($v['key']) == 1)
					$from["$k"]['key'] = $v['key'][0];
				if (count($v['data']) == 1)
					$from["$k"]['data'] = $v['data'][0];
				foreach ($v['sort'] as $s)
				{
					$sort[] = $s;
				}
				$multi[] = $v;
			}
			$rkey = $sepkey;
			if ($rkey == '')
				$rkey = $key;
			if (count($multi) == 1){
				if (!self::$client->run($multi[0], $read))
					return false;
				foreach ($read as $j => $v)
				{
					$k = $j;
					if (@array_key_exists($j,$rkey))
						$k = $rkey["$j"];
					$rdata["$rkey[$j]"] = $v;
					$j++;
				}
			}else{
				if (!self::$client->runmulti($multi, $read))
					return false;
				$idata = array();
				foreach ($read as $v)
				{
					foreach ($v as $v1)
					{
						$k = $j;
						if (@array_key_exists($sort["$j"],$rkey))
							$k = $rkey["$sort[$j]"];
						$idata[$sort["$j"]]["$k"] = $v1;
						$j++;
					}
				}
				//以下保证出去的数据按原序
				ksort($idata);
				foreach ($idata as $v)
				{
					foreach ($v as $k1 => $v1)
						$rdata["$k1"] = $v1;
				}
			}
			return true;
		}
		self::server($app, $table, ($sepkey==''? $key:$sepkey), $out, 'w', $key);
		$out['type'] = $type;
		$out['keys'] = 0;
		$out['data'] = $data;
		$out['start'] = intval($offset);
		return self::$client->run($out, $rdata);
	}
	//删除
	public function multidel($app, $table, $key, $sepkey, &$rdata)
	{
		return self::multiupdate($app, $table, $key, '', $sepkey, $rdata, 'DELETE');
	}
	//删除
	public function del($app, $table, $key, $sepkey='', $data='')
	{
		self::server($app, $table, ($sepkey==''? $key:$sepkey), $out,'w',$key);
		$out['type'] = 'DELETE';
		$out['data'] = $data;
		return self::$client->run($out, $data);
	}
	//删除列表
	public function dellist($app, $table, $key,$sepkey='')
	{
		self::server($app, $table, ($sepkey==''? $key:$sepkey), $out,'w',$key);
		$out['type'] = 'DELETE';
		$out['keys'] = 1;
		return self::$client->run($out, $data);
	}
	//获取访客列表，取key的部分内容，暂未使用
	/*function getvlist($app, $table, $key, $start, $num, &$data, $order=0,$sepkey='')
	{
		self::server($app, $table, ($sepkey==''? $key:$sepkey), $out,'r',$key);
		$out['type'] = 'GET';
		$out['num'] = intval($num);
		$out['start'] = intval($start);
		$out['order'] = $order;
		return self::$client->run($out, $data);
	}*/
	//获取列表
	public function getlist($app, $table, $key, $start, $num, &$data, $order=0,$sepkey='')
	{
		self::server($app, $table, ($sepkey==''? $key:$sepkey), $out,'r',$key);
		$out['type'] = 'GET';
		$out['keys'] = 2;
		$out['num'] = intval($num);
		$out['start'] = intval($start);
		$out['order'] = $order;
		return self::$client->run($out, $data);
	}
	//获取全部列表
	public function getalist($app, $table, $start, $num, &$data, $order=0)
	{
		self::server($app, $table, '', $out,'r');
		if ($out['database'] != $app){//通用转到getlist
			return self::getlist($app, $table, '', $start, $num, $data, $order);
		}
		$out['type'] = 'GET';
		$out['keys'] = 3;
		$out['key'] = 0;
		$out['num'] = intval($num);
		$out['start'] = intval($start);
		$out['order'] = $order;
		return self::$client->run($out, $data);
	}
	/* 创建表信息
		$data['type'] = 1;//索引类型，1 btree, 2 hash
		$data['islist'] = 0;//是否列表类型， 0 非列表， 1 列表， 2 计数器类型(按int来设计)
		$data['universal'] = 0;//是否通用类型 0 普通（默认）， 1 通用表
		$data['listindextable'] = 0;//是否key创建辅助索引表 0 无 1 辅助表  2 主表（重复更新）3 主表（重复不更新）
		$data['pagesize'] = 4096;//页大小
		$data['tableid'] = 0;//应用id 普通表值为0，通用表有值
		$data['listindexaddr'] = 0;//key不进入排序值偏移
		$data['listindexsize'] = 0;//key不进入排序值长度
		$data['keysize'] = 0;//key大小，不固定大小的为0
		$data['datasize'] = 0;//value长度，不固定大小为0
		$data['datablocksize'] = 0;//value块大小，不固定块大小为0
		$data['datablockuniquesize'] = 0;//value块无重复关键字大小，从头开始计算(访客) 0 无限制
		$data['datablockuindexsize'] = 0;//块排序大小，按字典顺序
		$data['other'] = 0;//留着扩展用
		*/
	private function createtable($app, $table, $data)
	{
		if (empty(self::$bdbapp["$app"]['w']))
			return false;
		$out['table'] = $table.(in_array($app, array('list'), true)?'':'_');
		$out['database'] = $app;
		$out['key'] = 0;
		$out['seg'] = 0;
		//头信息
		$mdata  = pack("v", empty($data['type'])?1:$data['type']);
		$mdata .= pack("v", (empty($data['islist'])||$data['islist']==2)?0:$data['islist']);
		$mdata .= pack("v", empty($data['universal'])?0:$data['universal']);
		$mdata .= pack("v", empty($data['listindextable'])?0:$data['listindextable']);
		$mdata .= pack("V", empty($data['pagesize'])?0:$data['pagesize']);
		//tableid信息
		$mdata .= pack("V", empty($data['tableid'])?0:$data['tableid']);
		$mdata .= pack("v", empty($data['islist'])?0:$data['islist']);
		$mdata .= pack("v", empty($data['listindextable'])?0:$data['listindextable']);
		$mdata .= pack("v", empty($data['listindexaddr'])?0:$data['listindexaddr']);
		$mdata .= pack("v", empty($data['listindexsize'])?0:$data['listindexsize']);
		$mdata .= pack("v", empty($data['keysize'])?0:$data['keysize']);
		$mdata .= pack("v", empty($data['datasize'])?0:$data['datasize']);
		$mdata .= pack("v", empty($data['datablocksize'])?0:$data['datablocksize']);
		$mdata .= pack("v", empty($data['datablockuniquesize'])?0:$data['datablockuniquesize']);
		$mdata .= pack("v", empty($data['datablockuindexsize'])?0:$data['datablockuindexsize']);
		$mdata .= pack("v", empty($data['other'])?0:$data['other']);
		$out['type'] = 'PUT';
		$out['keys'] = 3;
		$out['data'] = $mdata;
		foreach (self::$bdbapp["$app"]['w'] as $server)
		{
			$out['ip'] = $server['ip'];
			$out['port'] = $server['port'];
			if (!self::$client->run($out, $rdata))
				return false;
		}
		return true;
	}
	//以tableid方式生产库
	public function createtableid($tableid, $data)
	{
		global $g_bdb_table;
		if (!self::gettableconf($tableid, $tarray))
			return false;
		if (!$g_bdb_table["$tarray[t]"])
			return false;
		if ($g_bdb_table["$tarray[t]"]['type'] != 't')
			return false;
		$data['tableid'] = $tableid;
		return self::createtable($g_bdb_table["$tarray[t]"]['app'], $g_bdb_table["$tarray[t]"]['table'], $data);
	}
	//清空tableid数据，全部删除
	public function cleartableid($tableid, $secondid=0)
	{
		global $g_bdb_table;
		if (empty($tableid))
			return false;
		if (!self::gettableconf($tableid, $tarray))
			return false;
		if (!$g_bdb_table["$tarray[t]"])
			return false;
		if ($g_bdb_table["$tarray[t]"]['type'] != 't')
			return false;
		$key = self::i2b($tableid);
		for($i=1;$i<count($tarray['lkey']);$i++)
		{
			if ($tarray['lkey'][$i][1] != 'int')
				break;
			if ($i == 1 && $secondid != 0){
				$key .= self::i2b($secondid, $tarray['lkey'][$i][0]);
			}else{
				$key .= self::i2b(0, $tarray['lkey'][$i][0]);
			}
		}
		if (empty(self::$bdbapp["$tarray[app]"]['w']))
			return false;
		$out['table'] = $tarray['table'].(in_array($tarray['app'], array('list'), true)?'':'_');
		$out['database'] = $tarray['app'];
		$out['key'] = $key;
		$out['seg'] = 0;
		$out['type'] = 'DELETE';
		$out['keys'] = 4;
		$out['data'] = '';
		foreach (self::$bdbapp["$tarray[app]"]['w'] as $server)
		{
			$out['ip'] = $server['ip'];
			$out['port'] = $server['port'];
			if (!self::$client->run($out, $rdata))
				return false;
		}
		return true;
	}
	//dump数据
	public function dump($app, $num)
	{
		global $g_bdb_table;
		if (empty(self::$bdbapp["$app"]['w']))
			return false;
		$out['table'] = '.';
		$out['database'] = $g_bdb_table["$app"]['app'];
		$out['key'] = 1;
		$out['seg'] = 0;
		$out['type'] = 'DELETE';
		$out['keys'] = 6;
		$out['data'] = '';
		$anum = $num;
		if (!is_array($num))
			$anum = array($num);
		foreach (self::$bdbapp["$tarray[app]"]['w'] as $k => $server)
		{
			if (!array_key_exists($k, $anum))
				continue;
			$out['ip'] = $server['ip'];
			$out['port'] = $server['port'];
			if (!self::$client->run($out, $rdata))
				return false;
		}
		return true;
	}
	//删除表
	public function droptable($app, $table, $key='')
	{
		self::server($app, $table, $key, $out,'w');
		$out['type'] = 'DELETE';
		$out['keys'] = 2;
		return self::$client->run($out, $data);
	}
	//情况表
	public function truncatetable($app, $table, $key='')
	{
		self::server($app, $table, $key, $out,'w');
		$out['type'] = 'DELETE';
		$out['keys'] = 3;
		return self::$client->run($out, $data);
	}
	//将整型转为二进制形式
	public function i2b($id, $len=4)
	{
		switch($len)
		{
			case 2:
				return ($id===''?'':pack("v", $id));
			case 4:
				return ($id===''?'':pack("V", $id));
			case 8:
				return pack("VV", $id&0xFFFFFFFF, $id >>32);
		}
		return '';
	}
	//将二进制转为整型形式
	public function b2i($id, $len=4)
	{
		if ($id == '') return '';
		switch($len)
		{
			case 2:
				$m = unpack("v", $id);
				return sprintf("%u", $m[1]);
			case 4:
				$m = unpack("V", $id);
				return sprintf("%u", $m[1]);
			case 8:
				list($l, $h) = array_values(unpack("V*V*", $id));
				if ($h < 0)
					$h += (1 << 32);
				if ($l < 0)
					$l += (1 << 32);
				return (($h << 32) + $l);
			default:
			break;
		}
		return '';
	}
	//获取key相关的信息，分别用于：分区，key存储
	private function _getkey($conf, $key, &$karray, $dkey='')
	{
		$karray = array();
		$this->conf = $conf;
		if ($conf['type'] == 't'){//通用类型的$key，必须是数组，并且第一个是tableid
			if (!is_array($key))
				return false;
			if (!self::gettableconf($key[0], $this->conf))
				return false;
			$ipart = (isset($this->conf['ikey'])?$this->conf['ikey']:(isset($conf['ikey'])?$conf['ikey']:1));
			if (!@array_key_exists($ipart, $key))
				return false;
			$karray['part'] = $key["$ipart"];
			if (!isset($this->conf['lkey']))
				return false;
			$i = 0;
			$dkeyv = '';
			foreach ($key as $k => $v){
				if ($dkey == 'del' && isset($this->conf['dkey']) && $this->conf['dkey'] == $i){
					$dkeyv .= self::getrealkey($this->conf['lkey']["$k"], $v);
				}else{
					$karray['real'] .= self::getrealkey($this->conf['lkey']["$k"], $v);
				}
				$i++;
			}
			$karray['real'] .= $dkeyv;
		}else if (is_array($key)){
			$ipart = (isset($conf['ikey'])?$conf['ikey']:0);
			$karray['part'] = $key["$ipart"];
			$i = 0;
			$dkeyv = '';
			foreach ($key as $k => $v){
				if ($dkey == 'del' && isset($conf['dkey']) && $conf['dkey'] == $i){
					$dkeyv .= self::getrealkey($conf['lkey']["$k"], $v);
				}else{
					$karray['real'] .= self::getrealkey($conf['lkey']["$k"], $v);
				}
				$i++;
			}
			$karray['real'] .= $dkeyv;
		}else{
			$karray['part'] = $key;
			$karray['real'] = self::getrealkey($conf['lkey'][0], $key);
		}
		$karray['flag'] = $this->conf['flag'];
		$karray['max'] = (array_key_exists('max', $this->conf)?$this->conf['max']:0);
		return true;
	}
	//批量获取key
	public function getkey($conf, $key, &$karray, $dkey='')
	{
		$multi = 0;
		if ($conf['type'] == 't'){
			if (is_array($key[0]))
				$multi = 1;
		}else if (@array_key_exists(0, $key)){
			if (count($conf['lkey']) !== 1){
				if (@array_key_exists(0, $key[0]))
					$multi = 1;
			}else{
				$multi = 1;
			}
		}
		if ($multi == 1){
			$karray = array();
			foreach ($key as $k => $v)
			{
				if (!self::_getkey($conf, $v, $varray, $dkey))
					return false;
				$karray['real']["$k"] = $varray['real'];
				$karray['part']["$k"] = $varray['part'];
				$karray['flag'] = $varray['flag'];
				$karray['max'] = $varray['max'];
			}
		}else{//单个情况
			return self::_getkey($conf, $key, $karray, $dkey);
		}
		return true;
	}
	//获取通用tableid配置
	public function gettableconf($tableid, &$tarray)
	{
		global $g_bdb_tableid,$g_bdb_table;
		if (!array_key_exists($tableid, $g_bdb_tableid)){//从缓存取
			$filename = DATA_PATH.'/table/';
			if (!file_exists($filename))
				mkdir($filename);
			$filename .= fmod($tableid, 256);
			if (!file_exists($filename))
				mkdir($filename);
			$filename .= '/'.$tableid.'.data';
			$table = unserialize(file_get_contents($filename));
			$g_bdb_tableid["$tableid"] = $table;
			
			if (empty($table)){
				//读bdb
				//if (!self::get('keyb', 'kb', self::getrealkey($g_bdb_tableid[BDB_INFO_TABLEID]['lkey'], array(BDB_INFO_TABLEID, $tableid)), $data, $tableid))
				//change by liuchang5
				if(!self::_getkey($g_bdb_table['keybtree'], array(BDB_INFO_TABLEID, $tableid), $karray,''))
					return false;
				if (!self::get('keyb', 'kb', $karray['real'], $rdata, $karray['part'],0))
					return false;
				$v1 = @gzuncompress($rdata[0]);
				$data = $v1?$v1:$rdata[0];
				$g_bdb_tableid["$tableid"] = unserialize($data);
				if (empty($g_bdb_tableid["$tableid"]))
					return false;
				if (file_put_contents($filename, $data) === 0)
					return false;
			}
			//return false;
		}
		$table = $g_bdb_tableid["$tableid"]['t'];
		$tarray = array();
		$tarray = array_merge($g_bdb_table["$table"], $g_bdb_tableid["$tableid"]);
		return true;
	}
	public function getrealkey($lkey, $value)
	{
		if (!is_array($lkey))
			return '';
		if ($lkey[1] === 'char'){
			return ($lkey[0] === ''?$value:substr($value, 0, $lkey[0]));
		}
		return self::i2b((float)$value, $lkey[0]);
	}
	public function getoutkey($lkey, $value)
	{
		if (!is_array($lkey))
			return '';
		if ($lkey[1] === 'char'){
			return ($lkey[0] === ''?$value:substr($value, 0, $lkey[0]));
		}
		return self::b2i($value, $lkey[0]);
	}
}

?>
