<?php
/*
 * 功能: 申请专家类 
 * @date 2012/12/05
 * @author guoxianghui
 */
class applyexpert {
	public $tools_obj;
	function __construct(){
		$this->_init_params();
		$this->_init_class();
	}

	function _init_params(){
		$this->url = ADMIN_URL."/interface/applyexpert_db.php";
	}

	function _init_class(){
		$this->tools_obj = new Tools();
	}

	function run($row){
		$result = false;
		if($row[0] ==  EVENT_USER_UPDATE){
			//json格式
			if(!empty($row['data_append'])){
				$data_append = json_decode($row['data_append'],true);
				if(!empty($data_append['be_good_at'])){
var_dump($data_append['be_good_at']);
					//获取话题tid 和 用户昵称                                                                         
					$send = array();                                                                                  
					$send[] = array(                                                                                  
							'url' => DOMAIN . '/t/get_batch_tags.php',                                        
							'params' => array(                                                                
								'app'   => 1 ,
								'tag_str'  => @implode(",",$data_append['be_good_at']) ,
								),                                                                        
							'method' => 'post',                                                               
						       );                                                                                 
					$send[] = array(                                                                                  
							'url' => DOMAIN . '/u/getuser.php',                                               
							'params' => array(                                                                
								'app'   => 1,                                                             
								'uid'   => $row['uid'] ,                                         
								),                                                                        

							'method' => 'post',                                                               

						       );                                                                                 
					$datares = $this->tools_obj->multi_curl_set($send);                                               
					$tdata = json_decode($datares[0],true);                                                           
					$udata = json_decode($datares[1],true);
					if(!empty($tdata)){                                                                               
						foreach($tdata as $k=>$v){                                                                
							if($v['showflag'] == 0){                                                          
								$tmp_tag["$k"] = $v;                                                      
							}                                                                                 
						}                                                                                         
					}                                                                                                 
					$post_data = array('uid'=>$row['uid'],'nick'=>$udata[$row['uid']]['nick'],'tag'=>$tmp_tag, 'ctime'=> $row['etime']);
					var_dump($post_data);
					$result= $this->tools_obj->curl_set($this->url , 'post' , $post_data , $json);    
					if(!$result){
						$result = $this->tools_obj->curl_set($this->url , 'post' , $post_data , $json);    
					}
				}
			}
		}
		return $result;
	}

}
?>
