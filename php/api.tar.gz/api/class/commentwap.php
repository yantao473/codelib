<?php
/**
 * @fn              添加评论接口
 * @author          zhanghua2@staff.sina.com.cn
 * @copyright       v1
 * @date            2012-06-15
 */

include_once("apiconf.php");

class Commentwap {

	public $g_para;
        public $g_result;

	public function __construct(&$g_para , &$g_result) {
		$this->g_para   = &$g_para;
                $this->g_result = &$g_result;
		$this->rpc_obj = new RpcDb();
		$this->dbname = 'question';
		$this->tools_obj = new Tools();
		$this->mysql_obj = new MysqlDb();
		$this->bdb_obj  = new GetBdb();
	}
	
	/**
	 * 获取评论列表 getcommentlist.php调用 
	 *
	 * @param array
	 * @return bool
	*/
	public function get_comment_bdb(&$data) {
		$flag = $this->bdb_obj->lists($this->g_para['type'], $this->g_para['oid'], $this->g_para['start'], $this->g_para['num'], $data); // 问题1 回答2 收藏3
        	if(!$flag) {
			return false;
		}
		foreach($data as $k => $v) {
                        unset($data[$k]['keys']);
                        $this->bdb_obj->gets('user' , $v['data']['uid'] , $uinfo);
                        if(!empty($v['data'])) {
                                $data[$k]['data']['nick'] = $uinfo['nick'];
                                $data[$k]['data']['comment'] = urlencode($v['data']['comment']);
                        }
                }
		return true;
	}

	/**
	* 获取评论详细信息 delcomment.php调用
	*
	* @param array
	* @return bool
	*/
	public function get_comment_detail($table,$arr , &$data) {
        	$query = '';
        	if(!empty($arr)) {
		        foreach($arr as $col => $val) {
		            $query .= !empty($query) ? " AND `{$col}`='{$val}' " : " `{$col}`='{$val}' ";
		        }
		        $sql = "SELECT * FROM `".$table."` WHERE {$query}";
			if($this->rpc_obj->read($this->dbname,$sql,$data)) {
				return true;
			}
			else {
				return false;
			}
	    	}
		return true;
	}

	/**
	* 删除评论  delcomment.php调用
	*
	* @param array
	* @return bool
	*/
	public function del_comment($table_name,$cid,&$err_msg) {
        	if(!empty($cid)) {
			$sql = 'delete from `'.$table_name.'` where `commentid` = '.$cid;
			if($this->rpc_obj->update($this->dbname,$sql,$data)) {
				return true;
			}
			else {
				return false;
			}
            		return true;
		}
	}

	/**
         * @公共 之 写MYSQL
         * @date 2012-05-03
         **/
        function send_mysql($arr , &$rpcdb_result) {
		if($this->g_para['type'] == 1) {                                // question
			$table = 'question_comment';
		}
		elseif($this->g_para['type'] == 2) {                            // answer
			$table = 'answer_comment';
		}
		$get_sql  = $this->rpc_obj->prepare_insert_sql($table , $arr);
                $rpcdb_result = $this->rpc_obj->update("question",$get_sql,$data);
                return true;
        }

	/**
         * @公共 之 发送BDB
         * @date 2012-05-03
         **/
        function send_bdb($arr , &$queue_result) {
                $ser_array = array('data' => serialize($arr));
                $url = QDOMAIN . "/send_queue.php";
                $res = $this->tools_obj->curl_set($url , 'POST' , $ser_array , $queue_result);
                return $res;
        }
	
        /**
         * @微什么 之 发微博
         * @date 2012-05-03
         **/
        function send_to_weibo(){
        }
	
        /**
         * @微什么 之 写问题日志
         * @date 2012-05-03
         **/
        function add_log_list(){
	}

        /**
         * @微什么 之 添加问题feed
         * @date 2012-05-03
         **/
        function add_feed(){
	}

	/**
         * @微什么 之 添加关注
         * @date 2012-05-03
         **/
        function add_follow() {
	}
 
}
?>
