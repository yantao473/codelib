<?php
include_once("apiconf.php");
class feed
{

	public static function addFeedataToQueue($eid, $objs)
	{
		global $config;
		$tools_obj = new Tools();
		if(!$objs||!$eid) return false;
		if(!array_key_exists($eid, $config['feed_event_mapping'])) return false;
		#if(!file_exists(FEED_QUEUES_FILE)||!is_writable(FEED_QUEUES_FILE)) return false;
		$objs['eid'] = $eid;
		//add feed flag
		$objs['feedflag'] = true;
		//$result = QueueTool::AddToLocalQueue(FEED_QUEUES_LIST, $objs, FEED_QUEUES_NUM);
		$ser_array = array('data'=>serialize($objs));  
		$url = QDOMAIN."/send_queue.php";                                                  
		$tools_obj->curl_set($url,"POST",$ser_array,$result);
		return $result;
	}
}
