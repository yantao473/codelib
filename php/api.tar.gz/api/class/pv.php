<?php
//获取问题pv

class pv{
	static $timeout;
	function __construct()
	{
		self::$timeout = 1;
	}
	
	//ids 问题id，多个用数组形式;$isadd =1 自动增加1
	function get($ids, &$data, $isadd = 0)
	{
		$idlist = $ids;
		if (is_array($ids)){
			$idlist = implode(',', $ids);
		}
		$url = QUESTION_PV_CGI."?ids=".$idlist.($isadd == 0?'':'&add=1');
		$m = @file_get_contents($url, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		if (empty($m) && $isadd != 0)
			return false;
		if (is_array($ids)){
			$data = explode(',', $m);
		}
		else{
			$data = $m;
		}
		return true;
	}
	
	//自增长值
	function up($ids, &$data)
	{
		$data = 0;
		$url = QUESTION_PV_CGI."?ids=".$ids.'&add=1';
		$m = @file_get_contents($url, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		if (empty($m))
			return false;
		$data = $m;
		return true;
	}
	//##################################################
	//特殊id使用，v供数据库自增长id使用; $isadd 自增长步长
	function getid($id, $isadd=1)
	{
		$url = QUESTION_PV_CGI.'?t=1&ids='.$id.'&add='.$isadd;
		$m = @file_get_contents($url, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		return floatval($m);
	}
	//重置自增长id值，返回设置后的值
	function setid($id, $setnum)
	{
		$url = QUESTION_PV_CGI.'?t=1&ids='.$id.'&set=1&add='.$setnum;
		$m = @file_get_contents($url, false, stream_context_create(array('http'=>array('method'=>'GET','timeout'=>self::$timeout))));
		return floatval($m);
	}
}

?>