#!/usr/local/bin/php
<?php
require_once '/data0/api/class/feedincluded.php';
feedincluded::toInclude();
require FEED_LIB_ROOT.'/other/myqueue/myqueue.php';
require FEED_LIB_ROOT.'/other/mycurl/mycurl.php';

class Myfeed extends myqueue
{
	private $event_api = 'http://feed.iask.sina.com.cn/api/event.php';
	public $config;

	public function __construct()
	{
	}

	function serivice($args)
	{
		if($args) {
			$params = array(
				'url'=>$this->event_api,
				'datas'=>$args,
			);
			$obj = new mycurl($params);
			$res = $obj->run('post');
			if(!$res) exit();
			$res = json_decode($res);
			return true;
		}
	}
}
global $config;
$obj = new Myfeed();
$obj->config = $config;
$obj->run();
//$obj->serivice(array('eid'=>2, 'uid'=>'2746617127', 'fids'=>'1212211000000541'));
