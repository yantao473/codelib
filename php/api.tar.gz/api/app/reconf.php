<?php
//监控bdb个端口服务状态，异常时发送配置
include_once('apiconf.php');

class apiconf extends webApp{
	static $apiserver;
	function __construct()
	{
		$api = @parse_ini_file(DATA_PATH.'/conf/api.conf');// apiserver[] = "10.39.32.24" 只有本api关联的server
		if (is_array($api) && array_key_exists('apiserver', $api))
			self::$apiserver = $api['apiserver'];
		//self::$apiserver = array('10.39.32.24', '10.39.32.25', '10.39.32.26', '10.39.32.29','10.39.32.28','10.83.0.28','10.83.0.24','10.83.0.25','10.83.0.26');
	}
	//一主，一从监控
	function main()
	{
		$input = getopt('', array('type::'));
		if (!array_key_exists('type', $input)){
			exit;
		}
		switch($input['type'])
		{
			case 'server':
				self::server();
				break;
			case 'client':
				self::client();
				break;
			default:
				break;
		}
	}
	function client()
	{
		$connect = self::checklink();
		//客户端只存储结果
		$filename = DATA_PATH.'/conf/client.conf';
		if (false === @file_put_contents($filename, serialize($connect)))
			return false;
		return self::rsyncserver();
	}
	//一主，一从监控
	function server()
	{
		$connect = self::checklink();
		$bdb = new bdbdb();
		$cdata = serialize($connect);
		$clientdata = @file_get_contents(DATA_PATH.'/conf/client.conf');
		if ($cdata !== $clientdata){//一致的数据，认定为问题数据
			$clientarray = unserialize($clientdata);
			$connect1 = array();
			foreach ($connect as $k1 => $v1)
			{
				if (is_array($v2))
				foreach ($v1 as $k2 => $v2)
				{
					if (is_array($v2))
					foreach ($v2 as $k3 => $v3)
					{
						if (array_key_exists($k1, $clientarray) && array_key_exists($k2, $clientarray["$k1"]) &&array_key_exists($k3, $clientarray["$k1"]["$k2"])){
							$connect1["$k1"]["$k2"]["$k3"] = $v3;
						}
					}
				}
			}
			$connect = $connect1;
			if (empty($connect))
				return true;
			$cdata = serialize($connect);
		}
		if (empty($connect)){
			$curid = intval(@file_get_contents(DATA_PATH.'/conf/cur.conf'));
			if ($curid != 0){
				$bdb->setconf();
				return self::rsyncid();
			}
			return true;
		}
		if (time() - filectime(DATA_PATH.'/conf/cur.conf') < 300){//5分钟内只能更新一次
			return true;
		}
		if (($id = IdServer::get('confid')) === 0)
			return false;
		$bdb->setconfid($id, $cdata);
		self::bdbqueue($id, $cdata);//主要用于备份服务的信息传递
		return self::rsyncid($id);
	}
	private function bdbqueue($key, $data)
	{
		$tool = new tools();
		$url = QDOMAIN_BAK."/send_queue.php";
		$post_data = array();
		$post_data['unitebdb'] = 4;
		$post_data['key'] = $key;
		$post_data['data'] = $data;
		$str = serialize($post_data);
		return $tool->curl_set($url , 'post', array('data'=>$str), $res);
	}
	//将信息传给中心点
	private function rsyncserver()
	{
		$filename = DATA_PATH.'/conf/client.conf';
		if (false === system("/usr/bin/rsync -a --timeout=3 {$filename} {$_SERVER[ID_SERVER_CLIENT]}::API_ASK/data/conf/")){
			if (false === system("/usr/bin/rsync -a --timeout=3 {$filename} {$_SERVER[ID_SERVER_CLIENT]}::API_ASK/data/conf/"))
				echo "/usr/bin/rsync -a --timeout=3 {$filename} {$_SERVER[ID_SERVER_CLIENT]}::API_ASK/data/conf/ error\n";
		}
		return true;
	}
	//传给api备份队列服务器
	private function rsyncid($id=0)
	{
		$filename = DATA_PATH.'/conf/cur.conf';
		foreach (self::$apiserver as $server)
		{
			if (false === system("/usr/bin/rsync -a --timeout=3 {$filename} {$server}::API_ASK/data/conf/")){
				if (false === system("/usr/bin/rsync -a --timeout=3 {$filename} {$server}::API_ASK/data/conf/")){
					echo "/usr/bin/rsync -a --timeout=3 {$filename} {$server}::API_ASK/data/conf/ error\n";
				}
			}
		}
		if ($id == 0)
			return true;
		$filename = DATA_PATH .'/conf/'.fmod($id, 256).'/'.$id.'.conf';
		foreach (self::$apiserver as $server)
		{
			if (false === system("/usr/bin/rsync -a --timeout=3 {$filename} $server::API_ASK/data/conf/".fmod($id, 256).'/')){
				if (false === system("/usr/bin/rsync -a --timeout=3 {$filename} $server::API_ASK/data/conf/".fmod($id, 256).'/')){
					echo "/usr/bin/rsync -a --timeout=3 {$filename} $server::API_ASK/data/conf/".fmod($id, 256).'/'." error\n";
				}
			}
		}
		return true;
	}
	//确认故障端口
	private function checklink()
	{
		global $g_bdb_app;
		$connect = array();
		foreach ($g_bdb_app as $k1 => $v)
		{
			if (!empty($g_bdb_app["$k1"]))
			foreach ($g_bdb_app["$k1"] as $k2 => $v2)
			{
				if ($k2 === 'w' || $k2 === 'r'){
					foreach ($v2 as $k3 => $v3)
					{
						if (false === ($fd = @fsockopen($v3['ip'], $v3['port'], $errno, $err, BDB_DEFAULT_TIMEOUT)) || $errno != 0){
						 	$connect["$k1"]["$k2"]["$k3"] = array($v3[0], $v3['ip'], $v3['port']);
						}else{
							fclose($fd);
						}
					}
				}
			}
		}
		if (!empty($connect)){
			sleep(3);
			foreach ($connect as $k1 => $v1)
			{
				foreach ($v1 as $k2 => $v2)
				{
					foreach ($v2 as $k3 => $v3)
					{
						if (false === ($fd = @fsockopen($v3[1], $v3[2], $errno, $err, BDB_DEFAULT_TIMEOUT)) || $errno != 0){
							 	//$connect["$v1"]["$k2"]["$k3"] = array($v3[0], $v3['ip'], $v3['port']);
						}else{
							fclose($fd);
						}
					}
				}
			}
		}
		$connect1 = array();
		if (!empty($connect)){
			sleep(10);
			foreach ($connect as $k1 => $v1)
			{
				foreach ($v1 as $k2 => $v2)
				{
					foreach ($v2 as $k3 => $v3)
					{
						if (false === ($fd = @fsockopen($v3[1], $v3[2], $errno, $err, BDB_DEFAULT_TIMEOUT)) || $errno != 0){
							 	$connect1["$k1"]["$k2"]["$k3"] = $v3[0];
						}else{
							fclose($fd);
						}
					}
				}
			}
		}
		return $connect1;
	}
}

$app = new apiconf();
$app->run();
?>