<?php
//初始化分布式数据库id值
include_once('apiconf.php');

$id = new IdServer();

$key = array('question','answer0','answer1','answer2','answer3','answer4','answer5','answer6','answer7','answer8','answer9',
'user0','user2','user3','user4','user5','user6','user7','user8','user9',
'question_comment','answer_comment','vote','invite','user_logs','tag_logs','question_logs','tag',
);

//检查client节点数据是否正确
echo "check client\n";
foreach ($key as $appid){
	$ret = $id->checkclient($appid);
	echo "$appid $ret";
}


?>