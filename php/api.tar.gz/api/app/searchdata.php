<?php
//搜索数据处理
include_once('conf.php');

$s = new searchevent;
$s->rsyncdata();
if (date('Hi') == "0000"){
	$s->deldata();
}

?>