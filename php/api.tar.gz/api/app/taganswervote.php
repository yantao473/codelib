<?php
/**
 * 话题最佳回答----增量统计  以前一天的数据投票数据为依据以此为准，
 * 
 * @by tingting 18
 * 20111204
 * 思路投票库-->aid-->qid-->tid
 */
ini_set ('display_errors', 1);
require_once('apiconf.php');
class Taganswervote{
    public $rpcdb_obj,$getbdb_obj,$stat_obj;
    function __construct() {
        $this->rpcdb_obj = new RpcDb;
        $this->mysqldb_obj = new MysqlDb; 
        $this->getbdb_obj = new GetBdb;         
        $this->stat_obj = new Stat;       
    }
    function main(){
  //    $day = date("Y-m-d");
        $day = date('Y-m-d',strtotime("-1 day"));
/*
        $tid = 17166;
        $bdb_data = $this->stat_obj->get_tag_ask($tid);
var_dump($bdb_data);exit;
*/
        $votes = $this->stat_obj->get_vote($day);
		if(!empty($votes) && is_array($votes)){
      	// 更新统计库
			foreach($votes as $k=>$v){
			    $num = $this->stat_obj->get_data($v);
                if($num >=1){//update
                    $v['num'] = $num+$v['num'];
                    $u_res = $this->stat_obj->up_data($v);                    
                }else if($num == 0){// insert
                    $u_res = $this->stat_obj->insert_data($v);
                }
			}//foreach end 
            $stat_data = $this->stat_obj->get_gt_stat(1);
//组合后的数据
			if(!empty($stat_data)){
				foreach($stat_data as $qid=>$v){
					$tids["$qid"] = $this->stat_obj->gettid_from_question($qid);
					$data_t_a["$qid"] = $this->stat_obj->get_tid_aid($tids["$qid"],$v);	
				}//foreach end
			}else{
				$data_t_a = 0;
			}
			//处理数据，为写bdb做准备
			if(!empty($data_t_a) && is_array($data_t_a)){
				$st_data = $this->stat_obj->sort_data(60,$data_t_a);	
			}else{
				$st_data = 0;
			}
			if(!empty($st_data)){	
				$res = $this->stat_obj->add_bdb($st_data,$day);
			}else{
			}
var_dump($st_data);
		}else{ //不更新bdb
		}
    }
}
$app = new Taganswervote;
$app->main();
?>
