<?php
/**
 * 话题最佳回答
 * @by tingting 18
 * 20111129
 * 思路:tids->qids->aids-->num
 * modify guoxianghui  获取MC数据，通过questionid 获取对应的tid 不使用数据库存储，直接存BDB 
 */
require_once('apiconf.php');
class Tagbestanswer{
	public $rpcdb_obj,$tag_obj,$getbdb_obj,$queue_obj,$tools_obj;
	public $mem_host,$mem_port;
	function __construct() {
		$this->rpcdb_obj = new RpcDb;
		$this->mysqldb_obj = new MysqlDb;
		$this->tag_obj = new Tag;   
		$this->getbdb_obj = new GetBdb;         
		$this->queue_obj = new QueueTool;
		$this->tools_obj = new Tools();
#$this->mem_host  = $_SERVER['MEMCACHE_SERVER'];
#$this->mem_port  = $_SERVER['MEMCACHE_PORT'];
		$this->mem_host_1  = "10.83.0.27";
		$this->mem_port_2  = "10.39.32.27";
		$this->mem_port  = "10000";
	}
	function main(){
		$info_arr = array();
		$qids = array();
		//get memcache 
		$i = 0 ;
		$result = $this->connetc_memcache_1($memcache);
		if($result){
			while($i < 10){
				$get_value = $memcache->get(MC_VOTE.$i);
				if(!empty($get_value)){
					foreach($get_value as $val){
						if(!empty($val)){
							$qids_arr1[] = $val;
							$memcache->set(MC_VOTE.$i,'');
						}
					}
				}
				$i++;
			}
		}
#echo "server 10.83.0.27 : \n";
#print_r($qids_arr1);
		$result = $this->connetc_memcache_2($memcache);
		if($result){
			while($i < 10){
				$get_value = $memcache->get(MC_VOTE.$i);
				if(!empty($get_value)){
					foreach($get_value as $val){
						if(!empty($val)){
							$qids_arr2[] = $val;
							$memcache->set(MC_VOTE.$i,'');
						}
					}
				}
				$i++;
			}
		}
#echo "server 10.39.32.27 : \n";
#print_r($qids_arr2);
		if(!empty($qids_arr2) && !empty($qids_arr1)){
			$qids_arr = array_unique(array_merge($qids_arr1,$qids_arr2));
		}else if ( !empty($qids_arr2) && empty($qids_arr1) ){
			$qids_arr = $qids_arr2;
		}else if ( empty($qids_arr2) && !empty($qids_arr1) ){

			$qids_arr = $qids_arr1;
		}
#echo "2  server : \n";
#print_r($qids_arr);
		//根据qid获取对应tid
		if(!empty($qids_arr)){
			$api = DOMAIN . '/q/getdetail.php';
			$post_data = array( 'questionids' => implode(",",$qids_arr) );
			$flag = $this->tools_obj->curl_set($api , 'post' , $post_data , $q_data);
			$q_info = json_decode($q_data,true);    
		} 
#var_export($q_info);	
		if(!empty($q_info)){

			foreach($q_info as $qid=>$val){
				if($val['showflag'] != 1){
					$vote = array();
					foreach ($val['a'] as $aid=>$v){
						if($v['showflag'] != 1){
							if(!empty($v['2'])){
								$vote[] = $v['2'];
								array_multisort($vote, SORT_DESC , $ar[$qid]['a']);
							}
						}
					}
				}
			}

#var_export($q_info);	
			$info_array = array();
			foreach($q_info as $qid=>$val){
				if($val['showflag'] != 1){
					$answer = $val['a'];
					if(!empty($answer)){
						foreach ($answer as $aid=>$aval){
							if($aval['showflag'] != 1){
								$num = count($aval[2]);
								if($num >= 0){
									if(isset($val['tags']) && !empty($val['tags'])  ){
										foreach($val['tags'] as $tid=>$value){
											if(empty($tid)){
												continue;
											}
											$info_array[] = array('aid'=>$aid,'tid'=>$tid,'qid'=>$qid,'vnum'=>$num,);         
										}
									}
#$aids[] = $aid;	
								}	
							}
						}

					}
				}       
			}           
		}
#print_r($info_array);exit;	
		//guoxianghui add 20120223 start
		$ainfo= array();	
		//print_r($info);exit;
		if(!empty($info_array)){
			$arr_unique = array();
			foreach($info_array as $k => $val) {
				if(!array_key_exists($val['qid'],$arr_unique) ){
					$data[$val['tid']][]= array('aid' => $val['aid'] ,'qid'=>$val['qid'],'vnum'=>$val['vnum']);
					$arr_unique[$val['qid']] = $val['vnum'];
				}
				//use clear start
				/*
				   $data[$val['tid']][0]= array('aid' => "" , 'num' => "",'qid'=> "");
				//$array =  array('tid'=>$val['tid'],'aid' => "", 'num' => "",'ctime'=>"",);	
				$arr_data = array('0'=>EVENT_TAG_ANSWER_VOTE,'data'=>$data);
				$queue = $this->queue_obj->AddToLocalQueue($this->filename, $arr_data,$this->cmdid);
				 */
				//use clear end
			}
		}
#print_r($data);
		$i = 0;
		if(!empty($data)){
			foreach($data as $tid => $tinfo) {
				$tinfo['tid'] = $tid;
				$arr_data = array('0'=>EVENT_TAG_ANSWER_VOTE,'data'=>$tinfo);
				$ser_array = array('data'=>serialize($arr_data));                                 
				$url = "qcenter.sina.com.cn/send_queue.php";                                                  
				$this->tools_obj->curl_set($url,"POST",$ser_array,$queue_result);
#echo "result : ".$i++  ;var_dump($queue_result); 
			}
		}
#foreach($info as $val){
#$this->insert_data($val);
#}
		//guoxianghui add  end
	}
	/**
	 *获取MC值函数
	 **/
	public function connetc_memcache_1(&$memcache){
		$memcache = new Memcached();
		$result = $memcache->addServer($this->mem_host_1 , $this->mem_port ) or exit('can not connect memcache!');
		return $result;
	} 
	public function connetc_memcache_2(&$memcache){
		$memcache = new Memcached();
		$result = $memcache->addServer($this->mem_host_2 , $this->mem_port ) or exit('can not connect memcache!');
		return $result;
	} 
	/***
	 * 插入数据库，写bdb函数
	 * $row = 数据库参数   ('tid'=>$tid,'aid'=>$aid,'num'=>$num)
	 * @return true/false
	 */
	function insert_data($row){
		$dbname = 'stat';
		$tablename = 'best_answer';
		$row['ctime'] = date("Y-m-d H:i:s");
		$sql = $this->mysqldb_obj->prepare_insert_sql($tablename, $row);
		//echo $sql;
		$s_res = $this->rpcdb_obj->update($dbname,$sql,$data);
	}

	/**
	 * 更新数据库，更新bdb函数
	 * $row = 数据库参数   ('tid'=>$tid,'aid'=>$aid,'num'=>$num)
	 * @return true/false
	 */
	function up_data($row){
		$dbname = 'stat';
		$tablename = 'best_answer';        
		$row['ctime'] = date("Y-m-d H:i:s");
		$updata['ctime'] = $row['ctime'];
		$updata['num'] = $row['num'];   
		$sql = $this->mysqldb_obj->prepare_update_sql($tablename, $updata); 
		$sql .= ' WHERE tid = '.$row['tid'].' AND '.' aid = '.$row['aid'];   
		$s_res = $this->rpcdb_obj->update($dbname, $sql, $data);
	}//function end

	//add by guoxianghui start
	function delete_data(){
		$sql = "delete from best_answer;";
		$s_res = $this->rpcdb_obj->update('stat', $sql, $data);

	}
	//add by guoxianghui end
}
$app = new Tagbestanswer;
$app->main();
?>
