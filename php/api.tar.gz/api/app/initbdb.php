<?php
//初始化bdb库 通用

error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);
require_once 'apiconf.php';

$bdb = new BdbDb;
$data['universal'] = 1;//通用类型
$data['tableid'] = 0;//应用id

$data['type'] = 1;//索引类型，1 btree, 2 hash
$data['pagesize'] = 16384;//页大小
$data['keysize'] = 12;//key大小，不固定大小的为0
$data['islist'] = 0;//是否列表类型， 0 非列表， 1 列表， 2 计数器类型(按int来设计)
$data['listindextable'] = 0;//是否key创建辅助索引表 0 无 1 辅助表  2 主表（重复更新）3 主表（重复不更新）
$data['listindexaddr'] = 0;//key不进入排序值偏移
$data['listindexsize'] = 0;//key不进入排序值长度
$data['datasize'] = 0;//value长度，不固定大小为0
$data['datablocksize'] = 0;//value块大小，不固定块大小为0
$data['datablockuniquesize'] = 0;//value块无重复关键字大小，从头开始计算(访客) 0 无限制
$data['datablockuindexsize'] = 0;//块排序大小，按字典顺序
$data['tableid'] = 1;//应用id
$ret = $bdb->createtableid(1, $data);//通用共享资料，信息
var_dump($ret);
$data['keysize'] = 16;
$data['tableid'] = 2;//应用id
$ret = $bdb->createtableid(2, $data);//通用共享资料，信息
var_dump($ret);
$data['keysize'] = 0;
$data['tableid'] = 3;//应用id
$ret = $bdb->createtableid(3, $data);//通用共享资料，信息
var_dump($ret);
$data['keysize'] = 12;
$data['datasize'] = 4096;//value长度，不固定大小为0
$data['tableid'] = 7;//应用id
$ret = $bdb->createtableid(7, $data);//通用访客反向索引
var_dump($ret);
$data['datasize'] = 0;//value长度，不固定大小为0
$data['pagesize'] = 4096;//页大小
$data['islist'] = 1;//是否列表类型， 0 非列表， 1 列表， 2 计数器类型(按int来设计)
$data['keysize'] = 20;//key大小，不固定大小的为0
$data['tableid'] = 4;//应用id
$data['other'] = 8;//列表偏移
$ret = $bdb->createtableid(4, $data);//通用共享资料列表
var_dump($ret);
$data['keysize'] = 24;//key大小，不固定大小的为0
$data['tableid'] = 5;//应用id
$ret = $bdb->createtableid(5, $data);//通用共享资料列表
var_dump($ret);
$data['keysize'] = 28;//key大小，不固定大小的为0
$data['tableid'] = 8;//应用id
$ret = $bdb->createtableid(8, $data);//通用共享资料列表
var_dump($ret);
$data['keysize'] = 16;//key大小，不固定大小的为0
$data['tableid'] = 19;//应用id
$data['other'] = 4;//列表偏移
$ret = $bdb->createtableid(19, $data);//通用共享资料列表
$data['tableid'] = 20;
$ret = $bdb->createtableid(20, $data);
$ret = $bdb->createtableid(21, $data);
$ret = $bdb->createtableid(22, $data);
$ret = $bdb->createtableid(23, $data);
$ret = $bdb->createtableid(24, $data);
$data['keysize'] = 20;//key大小，不固定大小的为0
$ret = $bdb->createtableid(25, $data);
$ret = $bdb->createtableid(26, $data);
$ret = $bdb->createtableid(27, $data);
echo "20";var_dump($ret);
$data['other'] = 4;//列表偏移
$data['pagesize'] = 8192;//页大小
$data['islist'] = 0;//是否列表类型， 0 非列表， 1 列表， 2 计数器类型(按int来设计)
$data['keysize'] = 0;//key大小，不固定大小的为0
$data['datasize'] = 1600;//value长度，不固定大小为0
$data['datablocksize'] = 16;//value块大小，不固定块大小为0
$data['datablockuniquesize'] = 8;//value块无重复关键字大小，从头开始计算(访客) 0 无限制
$data['datablockuindexsize'] = 4;//块排序大小，按字典顺序
$data['tableid'] = 6;//应用id
$ret = $bdb->createtableid(6, $data);//通用共享资料列表
var_dump($ret);
$data['other'] = 8;//列表偏移
$data['keysize'] = 12;
$data['datasize'] = 128;//value长度，不固定大小为0
$data['datablocksize'] = 8;
$data['datablockuniquesize'] = 4;//value块无重复关键字大小，从头开始计算(访客) 0 无限制
$data['datablockuindexsize'] = 4;//块排序大小，按字典顺序
$data['tableid'] = 9;//应用id
$ret = $bdb->createtableid(9, $data);//通用共享资料列表
var_dump($ret);
$data['datasize'] = 0;//value长度，不固定大小为0
$data['datablocksize'] = 0;
$data['datablockuniquesize'] = 0;//value块无重复关键字大小，从头开始计算(访客) 0 无限制
$data['datablockuindexsize'] = 0;//块排序大小，按字典顺序
$data['islist'] = 1;
$data['pagesize'] = 4096;//页大小
$data['other'] = 4;//列表偏移
$data['keysize'] = 16;
$data['tableid'] = 10;//应用id
$ret = $bdb->createtableid(10, $data);
var_dump($ret);
$data['other'] = 8;//列表偏移
$data['keysize'] = 20;
$data['tableid'] = 11;//应用id
$data['listindextable'] = 2;//是否key创建辅助索引表 0 无 1 辅助表  2 主表（重复更新）3 主表（重复不更新）
$data['listindexaddr'] = 12;//key不进入排序值偏移
$data['listindexsize'] = 4;//key不进入排序值长度
$ret = $bdb->createtableid(11, $data);
var_dump($ret);
$data['keysize'] = 24;
$data['tableid'] = 12;//应用id
$data['listindextable'] = 3;//是否key创建辅助索引表 0 无 1 辅助表  2 主表（重复更新）3 主表（重复不更新）
$data['listindexaddr'] = 16;//key不进入排序值偏移
$data['listindexsize'] = 4;//key不进入排序值长度
$ret = $bdb->createtableid(12, $data);
var_dump($ret);
$data['keysize'] = 28;
$data['tableid'] = 13;//应用id
$ret = $bdb->createtableid(13, $data);
var_dump($ret);
$data['keysize'] = 24;
$data['tableid'] = 14;//应用id
$data['listindexaddr'] = 12;//key不进入排序值偏移
$ret = $bdb->createtableid(14, $data);
var_dump($ret);
$data['pagesize'] = 16384;//页大小
$data['listindextable'] = 0;//是否key创建辅助索引表 0 无 1 辅助表  2 主表（重复更新）3 主表（重复不更新）
$data['listindexaddr'] = 0;//key不进入排序值偏移
$data['listindexsize'] = 0;//key不进入排序值长度
$data['keysize'] = 20;
$data['tableid'] = 15;//应用id
$ret = $bdb->createtableid(15, $data);
var_dump($ret);
$data['keysize'] = 24;
$data['tableid'] = 16;//应用id
$ret = $bdb->createtableid(16, $data);
var_dump($ret);

$data['type'] = 1;//索引类型，1 btree, 2 hash
$data['pagesize'] = 16384;//页大小
$data['keysize'] = 12;//key大小，不固定大小的为0
$data['islist'] = 0;//是否列表类型， 0 非列表， 1 列表， 2 计数器类型(按int来设计)
$data['listindextable'] = 0;//是否key创建辅助索引表 0 无 1 辅助表  2 主表（重复更新）3 主表（重复不更新）
$data['listindexaddr'] = 0;//key不进入排序值偏移
$data['listindexsize'] = 0;//key不进入排序值长度
$data['datasize'] = 0;//value长度，不固定大小为0
$data['datablocksize'] = 0;//value块大小，不固定块大小为0
$data['datablockuniquesize'] = 0;//value块无重复关键字大小，从头开始计算(访客) 0 无限制
$data['datablockuindexsize'] = 0;//块排序大小，按字典顺序
$data['other'] = 0;//islist=3时 块排序大小，按字节顺序
$ret = $bdb->createtableid(1000, $data);
$ret = $bdb->createtableid(1012, $data);
$ret = $bdb->createtableid(1013, $data);
$data['keysize'] = 8;//key大小，不固定大小的为0
$ret = $bdb->createtableid(1011, $data);
$ret = $bdb->createtableid(17, $data);
$data['keysize'] = 20;//key大小，不固定大小的为0
$ret = $bdb->createtableid(1001, $data);
var_dump($ret);

$data['pagesize'] = 4096;//页大小
$data['islist'] = 1;//是否列表类型， 0 非列表， 1 列表， 2 计数器类型(按int来设计)
$data['datasize'] = 128;//value长度，不固定大小为0
$data['other'] = 4;//列表偏移
$ret = $bdb->createtableid(1002, $data);
$ret = $bdb->createtableid(1003, $data);
$ret = $bdb->createtableid(1004, $data);
echo "1004\n";
$ret = $bdb->createtableid(1005, $data);
$ret = $bdb->createtableid(1015, $data);
$ret = $bdb->createtableid(1016, $data);
$ret = $bdb->createtableid(1017, $data);
$ret = $bdb->createtableid(1018, $data);
echo "1005\n";var_dump($ret);
$data['keysize'] = 28;
$ret = $bdb->createtableid(1007, $data);
$ret = $bdb->createtableid(1008, $data);//共享资料，信息
$ret = $bdb->createtableid(1009, $data);//通用
$ret = $bdb->createtableid(1010, $data);

$data['keysize'] = 24;
$data['other'] = 0;
$ret = $bdb->createtableid(1006, $data);
$data['keysize'] = 16;
$ret = $bdb->createtableid(1014, $data);//通用
$ret = $bdb->createtableid(1019, $data);

echo "ok\n";
?>
