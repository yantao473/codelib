<?php
/***
 * 此话题的优秀回答者
 * @by tingting18
 * @ 2011-12-12
 */
require_once('apiconf.php');
class Tagexcellentuser{
    public $rpcdb_obj,$getbdb_obj,$stat_obj;
    function __construct() {
        $this->rpcdb_obj = new RpcDb;
        $this->mysqldb_obj = new MysqlDb; 
        $this->getbdb_obj = new GetBdb;         
        $this->stat_obj = new Stat;       
    }
    function main(){
  //    $day = date("Y-m-d");
        $day = date('Y-m-d',strtotime("-1 day"));
        //$day = '2011-12-08';
/*
        $data = $this->stat_obj->get_answer($day);
        // 把数据更新到对应的统计表中
        if(!empty($data['add']) && is_array($data['add']) && !isset($data['add']['errno'])){// add不为空，直接添加数据到数据表中；
            $dbname ='stat';
            $tablename = 'good_answer';
            foreach($data['add'] as $adv){
                $a_res = $this->stat_obj->insert_data($adv,$dbname,$tablename);
            }//foreach end
        }else if(!empty($data['del']) && is_array($data['del']) && !isset($data['del']['errno'])){//del不为空， 删除其中的数据；
            foreach($data['del'] as $dev){
                $d_res = $this->stat_obj->del_data($row);
            }//foreach end            
        }else{ //都为空时不操作；
            
        }
*/
        // 获取当前所有的统计回答
        $answer = $this->stat_obj->get_stat_user('good_answer','stat');
        foreach($answer as $av){
            $qid = $av['qid'];
            $qtid = $this->stat_obj->gettid_from_question($qid);            
        }
		foreach ($answer as $k=>$av){
        	$ta_data = $this->stat_obj->get_tid_aid($qtid,$av);
			foreach($ta_data as $tak => $tav){
				if($tav['tid'] && $tav['uid']){
					$tag_user[] = $tav['tid'].','.$tav['uid'];
				}	
			}   //foreach end
		}
       	$tag_num = array_count_values($tag_user); 
		$tag_user_data =  array_keys($tag_num) ;
		$tag_u = array_values($tag_num);
		foreach($tag_user_data as $k => $v){
			if($tag_u["$k"]>=5){
				$t_u = explode(',',$v);
				$uid = $t_u[1];
				$tag['tid'] = $t_u[0];
				$tag["$uid"]['uid'] = $t_u[1];
			//	$tag["$uid"]['num'] = $tag_u["$k"];
				$tag[0] = EVENT_TAG_ANSWER_USER;
			}
		}	
        var_dump($tag);  
		$queue = $this->stat_obj->queue_obj->AddToLocalQueue($this->stat_obj->filename, $tag,$this->stat_obj->cmdid);
		//写bdb
    }
}
$app = new Tagexcellentuser;
$app->main();
?>
