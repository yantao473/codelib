#!/usr/local/bin/php -f
<?php
function ob_callback($buffer)
{
	$fp=fopen(__FILE__.'.log',"ab");
	if ($fp)
	{
		fwrite($fp,$buffer);
		fclose($fp);
	}
}
ob_start('ob_callback');
require_once('apiconf.php');
ob_end_flush();

$ev = new bdbevent;
$ret = 0;
$fp = fopen('php://stdin', 'r');
while (1)
{
	$len = fread($fp, 4);
	$len = unpack("V", $len);
	
	$funret=0;
	if ($len[1])
	{
		$data = '';
		while (strlen($data) < $len[1])
		{
			$data .= fread($fp, $len[1]-strlen($data));
		}
		
		//$version = unpack("V", substr($data, 0, 4));
		$cmd = unpack("V", substr($data, 4, 4));
		$reverse = unpack("V", substr($data, 8, 4));
		$len = unpack("V", substr($data, 12, 4));
		$args = unserialize( substr($data, 16) );
		ob_start('ob_callback');
		//start
		$ev->run($args);
		
		ob_end_flush();
	}
	
	echo pack("C", $ret);
}
fclose($fp);


?>