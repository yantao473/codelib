#!/bin/sh

cd /data0/api/queue
{
./qr q.conf > /dev/null 2>&1 &
./qr user.conf > /dev/null 2>&1 &
}
