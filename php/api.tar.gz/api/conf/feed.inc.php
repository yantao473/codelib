<?php
global $config;
define('FEED_EVENT_ADD_QUESTION', 1);
define('FEED_EVENT_ADD_QUESTION_TOPIC', 5);
define('FEED_EVENT_ADD_ANSWER', 7);
define('FEED_EVENT_AGREE_ANSWER', 13);
define('FEED_EVENT_ATT_QUESTION', 39);
//动态队列数据文件路径
define('FEED_QUEUES_LIST', '/data3/qcenter/feed_v1/queue/data/baseevent.txt');
define('FEED_QUEUES_NUM', 32000);

$config['feed_event_mapping'] = array(
		FEED_EVENT_ADD_QUESTION=>'oneManAddQuestionForSelf',
		FEED_EVENT_ADD_QUESTION_TOPIC=>'addQuestionToTopic',
		FEED_EVENT_ADD_ANSWER=>'addQuestionOneAnswer',
		FEED_EVENT_AGREE_ANSWER=>'somebodyAgreeQuestion',
		FEED_EVENT_ATT_QUESTION=>'attOneQuestion',
);
