<?php
define('BDB_SEG_PERNUM', 1); //按key的int值,每个文件固定多少个id分割文件
define('BDB_SEG_MD5', 2);    //按key的md5值,分割给定的份数
define('BDB_SEG_INT', 3);    //按key的int值,分割给定的份数
define('BDB_SEG_MD5_BIG', 4);    //按key的md5值后4位,分割给定的份数
define('BDB_DEFAULT_TIMEOUT', 0.08);    //默认超时时间 秒
define('BDB_DEFAULT_MULTI_TIMEOUT', 100000);    //默认超时时间 毫秒
define('BDB_SEG_INT_BIG', 5);    //按key的int值,分割给定的份数，按范围分
define('BDB_INFO_TABLEID', 17);//tableid存储开始值
define('BDB_SAE_START_TABLEID_INT', 65536);//sae开始tableid，按int排序，搜索key必须是4的倍数
define('BDB_SAE_START_TABLEID_CHAR', 16777216);//sae开始tableid，按字典顺序
define('BDB_SAE_MAX_KEY_LEN', 32);//sae最大key长度
define('BDB_SAE_MAX_VALUE_LEN', 32768);//sae最大value长度
define('BDB_GZ_MIN_LEN', 100);//字符串最小压缩长度

//库定义
define('BDB_USER_APP', 'user');
define('BDB_QUESTION_DETAIL_APP', 'detail');
define('BDB_QUESTION_APP', 'question');
define('BDB_TAG_APP', 'tag');

$g_bdb_app = array(
'keyb'=> array(//通用key btree
				'w' => array(
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27000'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27001'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27002'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27003'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27004'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27005'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27006'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27007'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27008'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27009'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27010'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27011'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27012'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27013'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27014'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'27015'),
				),
        'segtype' => BDB_SEG_MD5_BIG,
        'segnum' => 8096,
				),
'plist'=> array(//通用普通列表，value值很小<4096
				'w' => array(
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29000'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29001'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29002'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29003'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29004'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29005'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29006'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'29007'),
				),
        'segtype' => BDB_SEG_MD5_BIG,
        'segnum' => 4096,
				),
'vlist'=> array(//通用带value值列表
				'w' => array(
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30000'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30001'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30002'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30003'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30004'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30005'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30006'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'30007'),
				),
        'segtype' => BDB_SEG_MD5_BIG,
        'segnum' => 4096,
				),
'alist'=> array(//通用全部列表
				'w' => array(
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'35000'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'35001'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'35002'),
				array(0,'ip'=>$_SERVER['BDB_SERVER_T0'], 'port'=>'35003'),
				),
        'segtype' => BDB_SEG_INT,
        'segnum' => 2048,
				),
);
//app 库; table 表; flag 类型 array数组序列化,chardel 字符串删除（唯一性）,char 字符串 ,int 数字二进制;bigint访客;, num 计数器; key 解析读的数据格式
$g_bdb_table = array(
	/////通用/////
	'keybtree' => array('type'=>'t','ltype'=>'key','app'=>'keyb', 'table' => 'kb','flag'=>'array', 'lkey'=>array(array(4,'int'), array('','char'))),
	#'keyhash' => array('type'=>'t','ltype'=>'key','app'=>'keyh', 'table' => 'kh','flag'=>'array', 'lkey'=>array(array(4,'int'), array('','char'))),
	'plist' => array('type'=>'t','ltype'=>'list','app'=>'plist', 'table' => 'lp','lkey'=>array(array(4,'int'), array('','char')),),
	'vlist' => array('type'=>'t','ltype'=>'list','app'=>'vlist', 'table' => 'lv','lkey'=>array(array(4,'int'), array('','char')),),
	'alist' => array('type'=>'t','ltype'=>'list','app'=>'alist', 'table' => 'la','lkey'=>array(array(4,'int'), array('','char')),'ikey'=>0),//ikey 分区key位置
);
$g_bdb_tableid = array(//以后这个放到专门配置文件里
	'1' => array('t'=>'keybtree','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>2, 'flag'=>'char'),//共享资料详情 f 摘要 i 目录 f 3,detail 4,question 5,answer 6,tagid 7,vanswer 8,canswer 9,hotanswer 10,ask 11, qinfo 12
	'2' => array('t'=>'keybtree','lkey'=>array(array(4,'int'),array(4,'int'),array(8,'int')),'ikey'=>2,'flag'=>'char'),//微什么 user,interest,same 3,u 4用户
	'3' => array('t'=>'keybtree','lkey'=>array(array(4,'int'),array(4,'int'),array('','char')),'ikey'=>2,'flag'=>'chardel'),//微什么 userurl,nick,tag 3
	'4' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>2),//共享资料 CF CS id UIF UFF F1 CP 7,cr,cv,cn,ck,ch,ce,cc,cs,cm 16,cz,tzr,tzv,tzh,tzk,tze,tzc,tza 24,ca 25
	'5' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(8,'int'),array(4,'int'),array(4,'int')),'ikey'=>2),//共享资料 UI UF F0 F2 4,um 5,uq 6,ua 7,ut 8,uze,uzq,uzn,uza,uzv,uzt,uzy,uzc 16,cga,cgb,cgn,cgt 20
	'6' => array('t'=>'keyvisitor','lkey'=>array(array(4,'int'),array('','char')), 'v'=>array(8,4,4),),//访客脚印
	'7' => array('t'=>'keybtree','lkey'=>array(array(4,'int'),array(8,'int')),'max'=>100),//访客反向索引
	'8' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(8,'int'),array(4,'int'),array(8,'int')),'ikey'=>2),//uqv 1,
	'9' => array('t'=>'keyvisitor','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int')), 'v'=>array(4,4),'ikey'=>2),//相关问题 relate 1
	'10' => array('t'=>'alist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),//全部问题 lq 1,lzq 2,lzr 3,lzv,lzn,lzk,lzh,lze,lzc,lzs,lzm 11 (i*512+1)
	'11' => array('t'=>'klist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>2, 'dkey'=>3),//话题下问题 tq 1,tk 2
	'12' => array('t'=>'klist','lkey'=>array(array(4,'int'),array(4,'int'),array(8,'int'),array(4,'int'),array(4,'int')),'ikey'=>2, 'dkey'=>3),//gtm 1, gqm ,gsm 3
	'13' => array('t'=>'klist','lkey'=>array(array(4,'int'),array(4,'int'),array(8,'int'),array(4,'int'),array(8,'int')),'ikey'=>2, 'dkey'=>3),//gpm 1, gpo 2,gpd 3
	'14' => array('t'=>'klist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int'),array(8,'int')),'ikey'=>2, 'dkey'=>3),//gto 1, gqo, gso,tin 4
	'15' => array('t'=>'vlist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>2),// te 1,tqe 2,tqc 3, tac 4
	'16' => array('t'=>'vlist','lkey'=>array(array(4,'int'),array(4,'int'),array(8,'int'),array(4,'int'),array(4,'int')),'ikey'=>2),// ue 1,
	'17' => array('t'=>'keybtree', 'lkey'=>array(array(4,'int'),array(4,'int')),'flag'=>'char'),//通用id
	'18' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(8,'int'),array(4,'int')),'ikey'=>1),//feed删除问题列表
	'19' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(8,'int'),array(4,'int')),'ikey'=>1,'dkey'=>1),//微什么赞过的
	'20' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),
	'21' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),
	'22' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),
	'23' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),
	'24' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),
	'25' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(4,'int'),array(4,'int'),array(8,'int')),'ikey'=>1),//ishare f-u
	'26' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(8,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),//ishare u-f
	'27' => array('t'=>'plist','lkey'=>array(array(4,'int'),array(8,'int'),array(4,'int'),array(4,'int')),'ikey'=>1),//ishare u-c

	'1000'=>array('t'=>'keybtree', 'lkey'=>array(array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'', 'flag'=>'char'), //微盘整合
	'1001'=>array('t'=>'keybtree', 'lkey'=>array(array(4, 'int'), array(8, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'',  'flag'=>'char'),
	'1002'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1003'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1004'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1005'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1007'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1008'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1009'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1006'=>array('t'=>'alist',  'lkey'=>array(array(4, 'int'), array(4, 'int'), array(8, 'int'), array(8, 'int')), 'ikey'=>0, 'lvalue'=>'128'),
	'1010'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1011'=>array('t'=>'keybtree', 'lkey'=>array(array(4, 'int'), array(4, 'int')), 'ikey'=>1, 'lvalue'=>'', 'flag'=>'char'),
	'1012'=>array('t'=>'keybtree', 'lkey'=>array(array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'', 'flag'=>'char'),
	'1013'=>array('t'=>'keybtree', 'lkey'=>array(array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'', 'flag'=>'char'),
	'1014'=>array('t'=>'alist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>0, 'lvalue'=>'128'),
	'1015'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1016'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1017'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1018'=>array('t'=>'plist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>1, 'lvalue'=>'128'),
	'1019'=>array('t'=>'alist', 'lkey'=>array(array(4, 'int'), array(4, 'int'), array(8, 'int')), 'ikey'=>0, 'lvalue'=>'128'),
	//通用从66000开始 t 类型 列表 plist (value长度< 1024);vlist (value>1024);alist 全排序类型列表,lkey key字段信息描述；ikey 分表字段（全列表时为tableid，其它为key[0]）；dkey 排序字段描述，用于唯一索引，sae时暂时为空。
	//lvalue value的长度，''是不定长
	//'65536' => array('t'=>'plist', 'lkey'=>array(0=>array(8, 'char'), 1=>array(4,'int'),),'lvalue'=>'', 'ikey'=>1, ),
	//'16777216'=>array('t'=>'alist', 'lkey'=>array(0=>array(5,'char'), 1=>array(2,'int'), 2=>array('','char'),'ikey'=>0,),
);

?>
