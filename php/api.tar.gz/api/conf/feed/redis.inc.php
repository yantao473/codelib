<?php
global $config;

define('FEED_REDIS_ONE_MASTER', 1);
define('FEED_REDIS_TWO_MASTER', 2);
define('FEED_REDIS_11TH_MASTER', 11);
define('FEED_REDIS_12TH_MASTER', 12);
//alias
define('FEED_REDIS_ALIAS_MYFEED', 1);
//重试机制
define('FEED_REDIS_REDO_MYFEED', 2);
//超时机制
define('FEED_REDIS_TIMEOUT_MYFEED', 0);

$config['FEED_REDIS_SERVERS'] = array(
		FEED_REDIS_1TH_MASTER=>array('10.83.0.27', 6379, 1),
		FEED_REDIS_2TH_MASTER=>array('10.83.0.27', 6380, 1),

		FEED_REDIS_11TH_MASTER=>array('10.39.32.27', 6379, 1),
		FEED_REDIS_12TH_MASTER=>array('10.39.32.27', 6380, 1),
		);

$config['FEED_REDIS_ALIAS'] = array(
		FEED_REDIS_ALIAS_MYFEED=>array(
			FEED_REDIS_11TH_MASTER,
			FEED_REDIS_12TH_MASTER,
			),
		);

$config['FEED_REDIS_KEYS_MAPPING'] = array(
		FEED_REDIS_ALIAS_MYFEED=>'mc_myfeed_%s_%.0f',
		);
