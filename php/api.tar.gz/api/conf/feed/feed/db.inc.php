<?php
global $config;
define('FEED_DB_MASTER_ALIAS', 'master');
define('FEED_DB_SLVAER_ALIAS', 'slaver');

define('FEED_DB_APP_INDEX', 1);
define('FEED_DB_APP_DATA', 2);
define('FEED_DB_APP_DATA_OTH', 3);
define('FEED_DB_APP_INDEX_OTH', 4);

define('FEED_DB_TAG_FEEDATA', 1);
define('FEED_DB_TAG_FEEDINDEX_U', 2);
define('FEED_DB_TAG_FEEDINDEX_T', 3);
define('FEED_DB_TAG_FEEDINDEX_Q', 4);
define('FEED_DB_TAG_UPDATETIME', 5);
define('FEED_DB_TAG_USERTOFEED', 6);
//主库使用三位数字表示,从库用5位数字表示，100的从库只能是100xx的实例
$config['feed_db_servers'] = array(
		'100'=>array('host'=>'m4797i.eos.grid.sina.com.cn', 'user'=>'feed', 'pass'=>'f3u4w8n7b3h', 'port'=>'4797', 'app'=>'feed', 'timeout'=>20),
		'10001'=>array('host'=>'s4797i.eos.grid.sina.com.cn', 'user'=>'feed_r', 'pass'=>'DAKAdfad3k4lzx', 'port'=>'4797', 'app'=>'feed', 'timeout'=>20),
		'10002'=>array('host'=>'s4797i.eos.grid.sina.com.cn', 'user'=>'feed_r', 'pass'=>'DAKAdfad3k4lzx', 'port'=>'4797', 'app'=>'feed', 'timeout'=>20),
		'101'=>array('host'=>'m4797i.eos.grid.sina.com.cn', 'user'=>'feed', 'pass'=>'f3u4w8n7b3h', 'port'=>'4797', 'app'=>'feed', 'timeout'=>20),
		'10101'=>array('host'=>'s4797i.eos.grid.sina.com.cn', 'user'=>'feed_r', 'pass'=>'DAKAdfad3k4lzx', 'port'=>'4797', 'app'=>'feed', 'timeout'=>20),
		'10102'=>array('host'=>'s4797i.eos.grid.sina.com.cn', 'user'=>'feed_r', 'pass'=>'DAKAdfad3k4lzx', 'port'=>'4797', 'app'=>'feed', 'timeout'=>20),
		);

$config['feed_db_app_list'] = array(
		FEED_DB_APP_DATA => array(FEED_DB_MASTER_ALIAS=>100, FEED_DB_SLVAER_ALIAS=>array(10001, 10102)),
		FEED_DB_APP_DATA_OTH => array(FEED_DB_MASTER_ALIAS=>100, FEED_DB_SLVAER_ALIAS=>array(10001, 10002)),
		FEED_DB_APP_INDEX => array(FEED_DB_MASTER_ALIAS=>101, FEED_DB_SLVAER_ALIAS=>array(10101, 10102)),
		FEED_DB_APP_INDEX_OTH => array(FEED_DB_MASTER_ALIAS=>101, FEED_DB_SLVAER_ALIAS=>array(10101, 10102)),
		);

$config['feed_db_app_mapping'] = array(
		FEED_DB_TAG_FEEDATA=>array(
			'dbmap'=>array('feedata_1_00'=>FEED_DB_APP_DATA),
			),
		FEED_DB_TAG_FEEDINDEX_U=>array(
			'dbnum'=>1,
			'tbnum'=>32,
			'dbmap'=>array('feedindex_1_00'=>FEED_DB_APP_INDEX, 'feedindex_01'=>FEED_DB_APP_INDEX_OTH),
			),
		FEED_DB_TAG_FEEDINDEX_T=>array(
			'dbnum'=>1,
			'tbnum'=>32,
			'dbmap'=>array('feedindex_1_00'=>FEED_DB_APP_INDEX, 'feedindex_01'=>FEED_DB_APP_INDEX_OTH),
			),
		FEED_DB_TAG_FEEDINDEX_Q=>array(
			'dbnum'=>1,
			'tbnum'=>32,
			'dbmap'=>array('feedindex_1_00'=>FEED_DB_APP_INDEX, 'feedindex_01'=>FEED_DB_APP_INDEX_OTH),
			),
		FEED_DB_TAG_UPDATETIME=>array(
			'dbnum'=>1,
			'tbnum'=>64,
			'dbmap'=>array('feedata_1_00'=>FEED_DB_APP_DATA),
			),
		FEED_DB_TAG_USERTOFEED=>array(
			'dbnum'=>1,
			'tbnum'=>64,
			'dbmap'=>array('feedata_1_00'=>FEED_DB_APP_DATA),
			),
		);
