<?php
global $config;
define('FEED_EVENT_ADD_QUESTION', 1);
define('FEED_EVENT_ADD_QUESTION_TOPIC', 5);
define('FEED_EVENT_ADD_ANSWER', 7);
define('FEED_EVENT_AGREE_ANSWER', 13);
define('FEED_EVENT_ATT_QUESTION', 39);

$config['feed_event_mapping'] = array(
		FEED_EVENT_ADD_QUESTION=>'oneManAddQuestionForSelf',
		FEED_EVENT_ADD_QUESTION_TOPIC=>'addQuestionToTopic',
		FEED_EVENT_ADD_ANSWER=>'addQuestionOneAnswer',
		FEED_EVENT_AGREE_ANSWER=>'somebodyAgreeQuestion',
		FEED_EVENT_ATT_QUESTION=>'attOneQuestion',
);

$config['feed_event_mustfiled'] = array(
		FEED_EVENT_ADD_QUESTION=>array('uid', 'qid'),
		FEED_EVENT_ADD_QUESTION_TOPIC=>array('qid', 'tid'),
		FEED_EVENT_ADD_ANSWER=>array('uid', 'qid'),
		FEED_EVENT_AGREE_ANSWER=>array('uid', 'qid'),
		FEED_EVENT_ATT_QUESTION=>array('uid','qid'),
);

$config['feed_event_checkfiled'] = array(
		'uid',
		'qid',
		'tid',
		'tids',
);
