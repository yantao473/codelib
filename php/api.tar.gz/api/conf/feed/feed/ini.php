<?php
//error_reporting(E_ALL);

ini_set('display_errors', 1);

defined('FEED_DEFINE_FLAG') or die('define.php not be loaded.');
//ini_set($varname, $newvalue);
set_include_path(get_include_path().PATH_SEPARATOR.FEED_DOCUMENT_ROOT);

//ini_set()
ini_set('memory_limit', '800M');
