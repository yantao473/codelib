<?php
//define
require 'define.php';
require 'ini.php';
require 'db.inc.php';
require 'event.inc.php';
require 'mc.inc.php';
require 'createid.inc.php';
//config
//显示排重权重
/*
$config['feed_question_display_weights'] = array(
		EVENT_QUESTION_ADD=>5,
		EVENT_QUESTION_TAG_ADD=>4,
		EVENT_ANSWER_ADD=>1,
		);
*/
$config['feed_common_filtetypes'] = array(
		'1'=>'qid',
		'2'=>'tid',
		);

$config['feed_index_types'] = array(
		'1d',
		'10d',
		'30d',
		);

$config['feed_index_types_sec'] = array(
		'1d'=>1*FEED_ONEDAY_SECES,
		'10d'=>10*FEED_ONEDAY_SECES,
		'30d'=>30*FEED_ONEDAY_SECES,
);
$config['feed_uptime_types'] = array(
		'question'=>'q',
		'topic'=>'t',
		'user'=>'u',
		);

$config['feed_indexalias_map'] = array(
		'q'=>'question',
		't'=>'topic',
		'u'=>'user',
		);

$config['feed_tasks'] = array(
		FEED_TASK_CREATEFEED,
		FEED_TASK_INDEX_Q,
		FEED_TASK_INDEX_U,
		FEED_TASK_INDEX_T,
		);

$config['feed_task_qlist'] = array(
		FEED_TASK_CREATEFEED=>FEED_DOCUMENT_ROOT.'queue/data/createfeed.txt',
		FEED_TASK_INDEX_Q=>FEED_DOCUMENT_ROOT.'queue/data/index_q.txt',
		FEED_TASK_INDEX_U=>FEED_DOCUMENT_ROOT.'queue/data/index_u.txt',
		FEED_TASK_INDEX_T=>FEED_DOCUMENT_ROOT.'queue/data/index_t.txt',
		);

$config['feed_itask_nums'] = array(
		FEED_TASK_INDEX_Q=>2,
		FEED_TASK_INDEX_U=>2,
		FEED_TASK_INDEX_T=>2,
		);

$config['feed_att_obj'] = array(
		'question',
		'topic',
		'user',
		);
