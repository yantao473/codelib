<?php

//临时
global $config;
//define
define('FEED_CREATEID_INFOFILE', '/data0/weibo/data/createid/info.txt');
define('FEED_CREATEID_LOCKFILE', '/data0/weibo/data/createid/lock.txt');
define('FEED_DB_SERVER_001', 1);
define('FEED_DB_SERVER_002', 2);
//config
$config['FEED_DB_SERVERS'] = array(
		FEED_DB_SERVER_001=>array(
			'host'=>'10.71.13.33',
			'user'=>'feed',
			'pass'=>'123456',
			'dbname'=>'feed',
			'port'=>10073,
			'app'=>'feed',
			'timeout'=>'10'
			),
		FEED_DB_SERVER_002=>array(
			'host'=>'10.71.13.33',
			'user'=>'feed',
			'pass'=>'123456',
			'dbname'=>'feed',
			'port'=>10073,
			'app'=>'feed',
			'timeout'=>'10'
			),
		);
$config['FEED_CREATEID_SERVERS'] = array(
			FEED_DB_SERVER_001,
			FEED_DB_SERVER_002,
		);
