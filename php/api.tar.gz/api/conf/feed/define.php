<?php
//根目录
define('FEED_ONEDAY_SECES', 24*60*60);
define('FEED_DEFINE_FLAG', 1);
define('FEED_DOCUMENT_ROOT',dirname(dirname(__FILE__)).'/');

//数据库清空方式
define('FEED_DATA_DEL_1D', 2*24*60*60);
define('FEED_DATA_DEL_10D', 11*24*60*60);
define('FEED_DATA_DEL_30D', 31*24*60*60);

//数据库清空日志
define('FEED_DATA_DEL_ERRORLOG', FEED_DOCUMENT_ROOT.'log/del_mysql_data/error.log');
define('FEED_TASK_RUN_ERRORLOG', FEED_DOCUMENT_ROOT.'log/task/error.log');

define('FEED_QLIST_ID_COMMON', 8000);
//默认执行队列步骤
define('FEED_TASK_CREATEFEED', 'createfeed');
define('FEED_TASK_INDEX_Q', 'qindex');
define('FEED_TASK_INDEX_U', 'uindex');
define('FEED_TASK_INDEX_T', 'tindex');
//动态队列数据文件路径
define('FEED_QUEUES_LIST', WEIBO_QUEUES_ROOT.'/feed/data/data.txt');
define('FEED_QUEUES_NUM', 6000);
define('FEED_UPMYFEED_LIST', '/data0/qcenter/myfeed_queue/data/data.txt');
define('FEED_UPMYFEED_NUM', 6000);
