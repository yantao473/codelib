<?php
global $config;

define('FEED_MC_ONE_MASTER', 1);
define('FEED_MC_TWO_MASTER', 2);
define('FEED_MC_3TH_MASTER', 3);
define('FEED_MC_4TH_MASTER', 4);
define('FEED_MC_5TH_MASTER', 5);
define('FEED_MC_6TH_MASTER', 6);
define('FEED_MC_7TH_MASTER', 7);
define('FEED_MC_8TH_MASTER', 8);
define('FEED_MC_9TH_MASTER', 9);
define('FEED_MC_10TH_MASTER', 10);

define('FEED_MC_11TH_MASTER', 11);
define('FEED_MC_12TH_MASTER', 12);
define('FEED_MC_13TH_MASTER', 13);
define('FEED_MC_14TH_MASTER', 14);
define('FEED_MC_15TH_MASTER', 15);
define('FEED_MC_16TH_MASTER', 16);
define('FEED_MC_17TH_MASTER', 17);
define('FEED_MC_18TH_MASTER', 18);
define('FEED_MC_19TH_MASTER', 19);
define('FEED_MC_20TH_MASTER', 20);
//alias
define('FEED_MC_ALIAS_FEEDATA', 1);
define('FEED_MC_ALIAS_INDEXES', 2);
//define('FEED_MC_ALIAS_MYFEEDS', 3);
define('FEED_MC_ALIAS_UPTIME', 4);
define('FEED_MC_ALIAS_MYFEED', 5);
define('FEED_MC_ALIAS_MYFEED_OTH', 6);
define('FEED_MC_ALIAS_UIDFIDINDEX', 101);
//obj pre
define('FEED_MC_OBJ_PRE_Q', 'q');
define('FEED_MC_OBJ_PRE_T', 't');
define('FEED_MC_OBJ_PRE_U', 'u');
//重试机制
define('FEED_MC_REDO_FEEDATA', 2);
define('FEED_MC_REDO_INDEX_Q', 6);
define('FEED_MC_REDO_INDEX_T', 6);
define('FEED_MC_REDO_INDEX_U', 6);
define('FEED_MC_REDO_UPTIME', 6);
define('FEED_MC_REDO_FEEDATA_SEL', 2);
define('FEED_MC_REDO_INDEX_Q_SEL', 2);
define('FEED_MC_REDO_INDEX_T_SEL', 2);
define('FEED_MC_REDO_INDEX_U_SEL', 2);
define('FEED_MC_REDO_UPTIME_SEL', 2);
define('FEED_MC_REDO_MYFEED_SEL', 2);
define('FEED_MC_REDO_UIDFIDINDEX', 2);
//超时机制
define('FEED_MC_TIMEOUT_FEEDATA', 10*FEED_ONEDAY_SECES);
define('FEED_MC_TIMEOUT_UPTIME', 30*FEED_ONEDAY_SECES);
define('FEED_MC_TIMEOUT_MYFEED', 10*FEED_ONEDAY_SECES);
define('FEED_MC_TIMEOUT_UIDFIDINDEX', 10*FEED_ONEDAY_SECES);
//数组最大长度
$config['FEED_MC_ARR_MAXLEN'] = array(
		FEED_MC_ALIAS_MYFEED=>2000,
);

$config['FEED_MC_TIMEOUT_INDEXQ'] = array(
		'30d'=>11*FEED_ONEDAY_SECES,
		'10d'=>11*FEED_ONEDAY_SECES,
		'1d'=>2*FEED_ONEDAY_SECES,
		);

$config['FEED_MC_TIMEOUT_INDEXU'] = array(
		'30d'=>11*FEED_ONEDAY_SECES,
		'10d'=>11*FEED_ONEDAY_SECES,
		'1d'=>2*FEED_ONEDAY_SECES,
		);

$config['FEED_MC_TIMEOUT_INDEXT'] = array(
		'30d'=>11*FEED_ONEDAY_SECES,
		'10d'=>11*FEED_ONEDAY_SECES,
		'1d'=>2*FEED_ONEDAY_SECES,
		);

$config['FEED_MC_TIMEOUT_UPTIME'] = array(
		'q'=>31*FEED_ONEDAY_SECES,
		't'=>31*FEED_ONEDAY_SECES,
		'u'=>31*FEED_ONEDAY_SECES,
		);

$config['FEED_MC_INDEX_TBTYPE'] = array(
		'30d',
		'10d',
		'1d',
		);
$config['FEED_MC_MYFEED_TYPE'] = array(
		'question'=>FEED_MC_OBJ_PRE_Q,
		'topic'=>FEED_MC_OBJ_PRE_T,
		'user'=>FEED_MC_OBJ_PRE_U,
		'max'=>'m',
);

$config['FEED_MC_SERVERS'] = array(
		FEED_MC_ONE_MASTER=>array('10.83.0.28', 12001, 0),
		FEED_MC_TWO_MASTER=>array('10.83.0.28', 12002, 0),
		FEED_MC_3TH_MASTER=>array('10.83.0.28', 12003, 0),
		FEED_MC_4TH_MASTER=>array('10.83.0.28', 12004, 0),
		FEED_MC_5TH_MASTER=>array('10.83.0.28', 12005, 0),
		FEED_MC_6TH_MASTER=>array('10.83.0.28', 12006, 0),
		FEED_MC_7TH_MASTER=>array('10.83.0.28', 12007, 0),
		FEED_MC_8TH_MASTER=>array('10.83.0.28', 12008, 0),
		FEED_MC_9TH_MASTER=>array('10.83.0.28', 12009, 0),
		FEED_MC_10TH_MASTER=>array('10.83.0.28', 12010, 0),

		FEED_MC_11TH_MASTER=>array('10.39.32.28', 12001, 0),
		FEED_MC_12TH_MASTER=>array('10.39.32.28', 12002, 0),
		FEED_MC_13TH_MASTER=>array('10.39.32.28', 12003, 0),
		FEED_MC_14TH_MASTER=>array('10.39.32.28', 12004, 0),
		FEED_MC_15TH_MASTER=>array('10.39.32.28', 12005, 0),
		FEED_MC_16TH_MASTER=>array('10.39.32.28', 12006, 0),
		FEED_MC_17TH_MASTER=>array('10.39.32.28', 12007, 0),
		FEED_MC_18TH_MASTER=>array('10.39.32.28', 12008, 0),
		FEED_MC_19TH_MASTER=>array('10.39.32.28', 12009, 0),
		FEED_MC_20TH_MASTER=>array('10.39.32.28', 12010, 0),
		);

$config['FEED_MC_ALIAS'] = array(
        FEED_MC_ALIAS_FEEDATA=>array(
            FEED_MC_11TH_MASTER,
            FEED_MC_12TH_MASTER,
            ),
        FEED_MC_ALIAS_INDEXES=>array(
            FEED_MC_15TH_MASTER,
            FEED_MC_16TH_MASTER,
            ),
        FEED_MC_ALIAS_MYFEED=>array(
            FEED_MC_19TH_MASTER,
            FEED_MC_20TH_MASTER,
            ),
        FEED_MC_ALIAS_MYFEED_OTH=>array(
            FEED_MC_9TH_MASTER,
            FEED_MC_10TH_MASTER,
            ),
        FEED_MC_ALIAS_UPTIME=>array(
            FEED_MC_17TH_MASTER,
            FEED_MC_18TH_MASTER,
            ),
        FEED_MC_ALIAS_UIDFIDINDEX=>array(
            FEED_MC_13TH_MASTER,
            FEED_MC_14TH_MASTER,
            ),
        );

$config['FEED_MC_KEYS_MAPPING'] = array(
		FEED_MC_ALIAS_FEEDATA=>'mc_feedata_%.0f',
		FEED_MC_ALIAS_INDEXES=>'mc_feedindex_%s_%s_%.0f',
		FEED_MC_ALIAS_UPTIME=>'mc_uptime_%s_%.0f',
		FEED_MC_ALIAS_MYFEED=>'mc_myfeed_%s_%.0f',
		FEED_MC_ALIAS_UIDFIDINDEX=>'mc_uidfidindex_%.0f',
		);
