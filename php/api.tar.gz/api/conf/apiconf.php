<?php
//全局配置文件

//根路径
define('ROOT_DIR', '/data0/api');

function __autoload($class_name)
{
	$class_name = strtolower($class_name);
	$m = explode('_', $class_name);
	if (count($m) > 1){
		require_once(ROOT_DIR.'/class/'.implode('/', $m).'.php');
		return ;
	}
	require_once(ROOT_DIR.'/class/'.$class_name.'.php');
}
//加载配置文件
tools::loadconfig(ROOT_DIR.'/system/SINASRV_CONFIG');

include_once(ROOT_DIR.'/conf/const.php');
include_once(ROOT_DIR.'/conf/bdbconf.php');
include_once(ROOT_DIR.'/conf/queueconf.php');
include_once(ROOT_DIR.'/conf/feed.inc.php');

// 引用接口
include_once(ROOT_DIR.'/class/interface/api.php');
?>
