<?php
//memcache
define('MC_VOTE','vote_answer'); //最佳回答
//答案排序和折叠接口
define('QUESTION_ANSWER_SORT','http://172.16.68.112/VAsk/vask_sort_answer.php');
//实时推送话题数据接口
define('TAGS_UPDATE_PUSH','http://172.16.68.112/vask_filter/resys_vask_update.php');
//public
define('ADMIN_URL','http://admin.iask.sina.com.cn');
define('DOMAIN','http://i.iask.sina.com.cn');
define('QDOMAIN','http://qcenter.sina.com.cn');
define('WEIBO_DOMAIN','http://i2.api.weibo.com'); //微博api域名
// 回答表总数
define('ANSWER_TABLE_COUNT' , 10);
// 用户表总数
define('USER_TABLE_COUNT' , 10);

//rpc
define('RPC_TIMEOUT', '2');
define('WEIBO_APP_KEY','118957803');
define('WEIBO_APP_SECRET','1a0c94a3300a6197027728dd99096495');
define('WEIBO_APP_ID','257');
# define('WEIBO_USER_PASSWD','askweibo@sina.com:sinaweibo123,');
# define('WEIBO_USER_PASSWD','weiwenda@vip.sina.com:WSM@139');
define('WEIBO_USER_PASSWD','weiwenda@vip.sina.com:WSM@1390');
define('API_APP_ID', 1);//微博在问答平台的app
define('ZHISHI_APP_ID', 2);//知识人在问答平台的app
define('WAP_APP_ID', 3);//手机在问答平台的app

define('RPC_QUESTION_SERVER', $_SERVER['RPC_QUESTION_SERVER']);
define('RPC_QUESTION_PORT', $_SERVER['RPC_QUESTION_PORT']);
define('RPC_QUESTION_APP', $_SERVER['RPC_QUESTION_APP']);

// 用户库 (广州)
define('RPC_USER_SERVER', $_SERVER['RPC_USER_SERVER']);
define('RPC_USER_PORT', $_SERVER['RPC_USER_PORT']);
define('RPC_USER_APP', $_SERVER['RPC_USER_APP']);

// 消息库
define('RPC_MESSAGE_SERVER', $_SERVER['RPC_MESSAGE_SERVER']);
define('RPC_MESSAGE_PORT', $_SERVER['RPC_MESSAGE_PORT']);
define('RPC_MESSAGE_APP', $_SERVER['RPC_MESSAGE_APP']);


// 统计库
define('RPC_STAT_SERVER', $_SERVER['RPC_STAT_SERVER']);
define('RPC_STAT_PORT', $_SERVER['RPC_STAT_PORT']);
define('RPC_STAT_APP', $_SERVER['RPC_STAT_APP']);

// FEED index 库
define('RPC_FEED_INDEX_SERVER', '10.71.13.30');
define('RPC_FEED_INDEX_PORT', '10077');
define('RPC_FEED_INDEX_APP', 'feed_index');

// FEED data 库
define('RPC_FEED_DATA_SERVER', '10.71.13.30');
define('RPC_FEED_DATA_PORT', '10078');
define('RPC_FEED_DATA_APP', 'feed_data');

//connect mysql
define('MYSQL_STAT_WRITE_SERVER', '10.71.13.30');
define('MYSQL_STAT_WRITE_PORT', '3306');
define('MYSQL_STAT_READ_SERVER', '10.71.13.30');
define('MYSQL_STAT_READ_PORT', '3306');
define('MYSQL_STAT_DBNAME', 'stat');
define('MYSQL_STAT_PW', '123456');
define('MYSQL_STAT_USER', 'c_stat');

define('MYSQL_QUESTION_WRITE_SERVER', '10.71.13.30');
define('MYSQL_QUESTION_WRITE_PORT', '3306');
define('MYSQL_QUESTION_READ_SERVER', '10.71.13.30');
define('MYSQL_QUESTION_READ_PORT', '3306');
define('MYSQL_QUESTION_DBNAME', 'question');
define('MYSQL_QUESTION_PW', '123456');
define('MYSQL_QUESTION_USER', 'c_question');

define('MYSQL_FEED_WRITE_SERVER', '10.71.13.30');
define('MYSQL_REED_WRITE_PORT', '3306');
define('MYSQL_FEED_READ_SERVER', '10.71.13.30');
define('MYSQL_REED_READ_PORT', '3306');
define('MYSQL_FEED_DBNAME', 'feed');
define('MYSQL_FEED_PW', '123456');
define('MYSQL_FEED_USER', 'c_feed');

define('MYSQL_USER_WRITE_SERVER', '10.71.13.30');
define('MYSQL_USER_WRITE_PORT', '3306');
define('MYSQL_USER_READ_SERVER', '10.71.13.30');
define('MYSQL_USER_READ_PORT', '3306');
define('MYSQL_USER_DBNAME', 'user');
define('MYSQL_USER_PW', '123456');
define('MYSQL_USER_USER', 'c_user');

define('MYSQL_APP_WRITE_SERVER', '10.71.13.30');
define('MYSQL_APP_WRITE_PORT', '3306');
define('MYSQL_APP_READ_SERVER', '10.71.13.30');
define('MYSQL_APP_READ_PORT', '3306');
define('MYSQL_APP_DBNAME', 'app');
define('MYSQL_APP_PW', '123456');
define('MYSQL_APP_USER', 'c_app');

define('DATA_PATH', ROOT_DIR.'/data');

//搜索数据rsync地址
define('SEARCH_DATA_RSYNC', '172.16.136.85::MINI_SEARCH/lore/');
#define('SEARCH_CGI', 'http://172.16.136.237/lore/livequery.php');
#define('SEARCH_CGI', 'http://miniblog.match.sina.com.cn/openapi/rpcAsk2.php');

define('SEARCH_CGI', 'http://miniblog.match.sina.com.cn/openapi/rpcAsk3.php');

//id服务
define('ID_SERVER_CLIENT_CGI', 'http://'.$_SERVER['ID_SERVER_CLIENT'].'/idserver');
define('ID_SERVER_CENTER_CGI', 'http://'.$_SERVER['ID_SERVER_CENTER'].'/idserver');
define('QUESTION_PV_CGI', 'http://'.$_SERVER['PV_SERVER'].'/pv');//pv
//define('QUESTION_PV_CGI_BAK', 'http://'.$_SERVER['PV_SERVER_BAK'].'/pv');//pv

// 转发队列
define('FORWARD_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/forward_queue/q.txt');
// bdb queue
define('BDB_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/bdb_queue/q.txt');
define('BDB_QUEUE_ID', 30000);
//mail id
define('MAIL_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/mail_queue/q.txt');
define('MAIL_QUEUE_ID', 30001);
// bdb special queue
define('BDBSPECIAL_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/bdb_special_queue/q.txt');
define('BDBSPECIAL_QUEUE_ID', 30002);
// afteraudit 
define('AFTERAUDIT_QUEUES_FILE', '/data0/qcenter/DATA_FILE/afteraudit_queue/q.txt');
define('AFTERAUDIT_QUEUES_NUM_ID', 30003);
//feed 转发
define('FEED_QUEUES_FILE', '/data0/qcenter/feed_v1.5/queue/data/baseevent.txt');
define('FEED_QUEUES_NUM_ID', 6000);
// other queue
define('OTHER_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/other_queue/q.txt');
define('OTHER_QUEUE_ID', 30004);
// mysql queue
define('MYSQL_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/mysql_queue/q.txt');
define('MYSQL_QUEUE_ID', 30005);
define('BDB_UNITE_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/unite_queue/q.txt');//unite bdb
define('BDB_UNITE_DO_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/unite_queue/do_q.txt');//unite do
define('BDB_UNITE_QUEUE_ID', 30010);

define('BDB_UNITE_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/unite_queue/q.txt');
define('BDB_UNITE_QUEUE_ID', 30010);

define('BDB_UNITE_FORWARD_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/unite_queue/forward_q.txt');//unite bdb

define('BDB_RESCURE_QUEUE_DATA_FILE', '/data0/qcenter/DATA_FILE/bdb_rescure_queue/q.txt');
define('BDB_RESCURE_QUEUE_ID', 30011);

define('DEFAULT_TAG_LOGO', 'http://www.sinaimg.cn/pfp/w_ask/t1/images/ht_default5050.jpg'); // 话题默认图片

define("MSHARE_QUEUE_DATA_FILE", "/data0/qcenter/DATA_FILE/mshare_queue/data.txt");
define("MSHARE_QUEUE_ID", 50000);

//事件
define('EVENT_QUESTION_ADD', 1);//添加问题
define('EVENT_QUESTION_DEL', 2);//删除问题
define('EVENT_QUESTION_UPDATE', 3);//问题更新
define('EVENT_QUESTION_TITLE_UPDATE', 28);//问题标题更新
define('EVENT_QUESTION_DESC_UPDATE', 29);//问题描述更新
define('EVENT_QUESTION_LOCK', 4);//锁定
define('EVENT_QUESTION_REST', 49);//问题恢复
define('EVENT_QUESTION_TAG_ADD', 5);//问题话题添加
define('EVENT_QUESTION_TAG_DEL', 6);//问题话题删除
define('EVENT_QUESTION_REDIRECT', 25);//重定向
define('EVENT_QUESTION_INVITE', 26);//邀请回答
define('EVENT_ANSWER_ADD', 7);//添加答案
define('EVENT_ANSWER_DEL', 8);//删除答案
define('EVENT_ANSWER_UPDATE', 9);//更新答案
define('EVENT_ANSWER_RECOVER', 10);//恢复答案
define('EVENT_COMMENT_ADD', 11);//评论添加
define('EVENT_COMMENT_DEL', 12);
define('EVENT_VOTE_AGREE_ADD', 13);//添加赞成票
define('EVENT_VOTE_AGREE_DEL', 15);//删除赞成票
define('EVENT_VOTE_AGAINST_ADD', 14);//添加反对票
define('EVENT_VOTE_AGAINST_DEL', 16);//删除反对票
define('EVENT_VOTE_NOHELP', 17);//无帮助
define('EVENT_TAG_ADD', 32);//话题添加
define('EVENT_TAG_UPDATE', 18);//话题更新
define('EVENT_TAG_DEL', 19);//话题删除(是否显示)
define('EVENT_TAG_REST', 51);//话题恢复
define('EVENT_TAG_LOCK', 20); //话题锁定
define('EVENT_TAG_FATHER_ADD', 21);//父话题添加
define('EVENT_TAG_FATHER_DEL', 22);//父话题删除
define('EVENT_TAG_CHILD_ADD', 23);//子话题添加
define('EVENT_TAG_CHILD_DEL', 24);//子话题删除
define('EVENT_TAG_EXP_UPDATE', 27);//话题经验更新
define('EVENT_USER_UPDATE', 30);//用户修改
define('EVENT_USER_REGISTER', 31);//用户注册
define('EVENT_USER_UPDATE_LOGO', 33);//用户修改头像
define('EVENT_INDEX_INTEREST', 34);//感兴趣的人、话题
define('EVENT_USER_FOLLOW_ADD', 35);//关注用户
define('EVENT_USER_FOLLOW_DEL', 36);//取消关注用户
define('EVENT_TAG_FOLLOW_ADD', 37);//关注话题
define('EVENT_TAG_FOLLOW_DEL', 38);//取消关注话题
define('EVENT_QUESTION_FOLLOW_ADD', 39);//关注问题
define('EVENT_QUESTION_FOLLOW_DEL', 40);//取消关注问题
define('EVENT_QUESTION_ADOPT', 41);//采纳回答
define('EVENT_TAG_UPDATE_LOGO', 42);//话题修改头像
define('EVENT_LOG_ADD',43); //日志添加（用户，问题，话题）
define('EVENT_LOG_DEL',50); //日志删除（用户，问题，话题）
define('EVENT_QUESTION_INVITE_DEL', 44);//删除邀请回答
define('EVENT_TAG_ANSWER_VOTE', 45);//话题下投票最多回答排行
define('EVENT_TAG_ANSWER_USER', 46);//话题下回答数最多用户排行
define('EVENT_INDEX_HOT_ANSWER', 47);//热门回答，每日投票排行
define('EVENT_INDEX_SAME_USER', 48);//口味相同的人
define('EVENT_QUESTION_FUN_ADD', 52);//设置为编辑推荐问题
define('EVENT_QUESTION_FUN_DEL', 53);//取消编辑推荐问题
define('EVENT_QUESTION_CLASS', 54);//转移分类
define('EVENT_QUESTION_READOPT', 55);//纠错
define('EVENT_QUESTION_VOTE', 56);//设置投票状态
define('EVENT_QUESTION_PRICE', 57);//提高悬赏分
define('EVENT_QUESTION_EXPIRED', 58);//过期
define('EVENT_QUESTION_FOLLOW_ADD_ZHISHI', 59);//知识人关注问题
define('EVENT_QUESTION_FOLLOW_DEL_ZHISHI', 60);//知识人取消关注问题
define('EVENT_TAG_UPDATE_NAME', 61);//修改话题名称对应的id
define('EVENT_UID_FORBID_QID', 62);//用户禁止问题显示

define('QUESTION_CLASS_CACHE_PATH', DATA_PATH.'/zhishiclass.data');//知识人分类信息缓存
define('GETCLASSIFYINFOLINK', 'http://10.49.1.100/cgi-bin/qclassserialize.cgi');//知识人分类cgi
// SSO
define('SSO_REG_URL' , 'http://ilogin.sina.com.cn/api/regsso.php');
define('SSO_GET_URL' , 'http://ilogin.sina.com.cn/api/getsso.php');

define('QUESTION_MODEL_LIB_ROOT', ROOT_DIR.'/class/');
define('QUESTION_FEED_QLIST_PATH', ROOT_DIR.'/queue/feed/data/data.txt');
define('QUESTION_FEED_QLIST_ID', 6666);

// invate num
define('INVATE_TOTAL_NUMS', 6);

$notice_code = array(
        'notice_ans' => 0,
        'notice_ac' => 1,
        'notice_ag' => 2,
        'notice_cmt' => 3,
	'new_invat'   => 4,
);

//错误号
$g_error_app = array(
'2001'=>'用户id不能为空',
'2002'=>'用户id应为数字',
'2003'=>'对象id不能为空',
'2004'=>'对象id应为数字',
'2005'=>'应用id不能为空',
'2006'=>'应用id应为数字',
'2007'=>'类型不能为空',
'2008'=>'类型应为数字',
'2021'=>'类型应为字符串',
'2009'=>'评论内容不能为空',
'2010'=>'获取条数不能为空',
'2011'=>'获取条数应为数字',
'2012'=>'评论id不能为空',
'2013'=>'评论id应为数字',
'2303'=>'删除失败',

'2015'=>'注册邮箱不能为空',
'2016'=>'注册邮箱已存在',
'2017'=>'注册昵称不能为空',
'2018'=>'注册昵称已存在',

'2019'=>'注册组别不能为空',
'2020'=>'注册组别应为数字',
'2022'=>'注册用户失败',

'2201'=>'查询用户信息失败',
'2202'=>'查询用户行为失败',
'2203'=>'注册用户失败',
'2204'=>'修改用户信息失败',

'2301'=>'添加评论失败',
'2302'=>'获取评论失败',

'2101'=>'UID为空',
'2102'=>'更新失败',
'2103'=>'标题为空',
'2104'=>'向某人提问的UID为空',
'2111'=>'问题ID为空',
'2112'=>'UID为空',
'2113'=>'答案为空',
'2114'=>'时间为空',
'2128'=>'修改方式标志为空',
'2121'=>'问题描述为空',
'2124'=>'话题为空',
'2131'=>'回答ID为空',
'2132'=>'回答标志为空',
'2133'=>'操作答案标识为空',
'2134'=>'投票方式为空',
'2135'=>'问题或回答不存在',
'2136'=>'问题id不存在',
'2130'=>'查询失败',
'2105'=>'话题id空',
'2106'=>'邀请id空',
'2107'=>'话题空',

'2401'=>'添加关注失败',
'2402'=>'取消关注失败',
'2403'=>'添加关注失败(type类型有误)',
'2404'=>'获取关注列表失败',
'2405'=>'获取列表类型有误(不匹配)',
'2406'=>'获取双向关注列表失败(用户id为空)',
'2407'=>'传递参数的分隔符或者参数本身有误',

'2501'=>'获取话题失败(话题id或者话题名称为空)或者用名称去取的话题不存在',
'2502' =>'获取话题信息失败',
'2503'=>'添加话题失败',
'2504'=>'添加话题经验失败(话题id或用户id为空)',
'2505'=>'批量获取话题信息失败(话题id不为逗号分隔的数据或者tid为空)',
'2506'=>'一次批量获取话题信息数量不能超过20条',
'2507'=>'获取话题下问题的列表(所有问题或已解决问题)失败(type类型不匹配)',
'2508'=>'获取话题经验失败(用户uid不能为空)',
'2509'=>'获取话题日志失败(话题tid不能为空)',
'2510'=>'更新话题经验失败(话题id或用户id为空)',
'2511'=>'添加话题经验失败(已经存在对应用户及话题的话题经验，请更新话题经验)',
'2512'=>'更新话题经验失败',
'2513'=>'更新话题图片失败',
'2514'=>'删除话题失败',
'2515'=>'锁话题失败',
'2516'=>'获取话题下问题的列表失败（获取bdb失败）',
'2517'=>'获取话题下问题的列表失败(话题id为空了)',
'2518'=>'获取话题最佳回答失败(话题id为空了)',

'2601'=>'搜索类型不匹配',
'2602'=>'搜索关键字为空',
'2901'=>'可能感兴趣的人或话题类型有误',
'2902'=>'可能感兴趣的人或者话题用户id为空',

'3000'=>'应用ID为空',
'3001'=>'应用对应行为不存在',
'3002'=>'应用行为执行失败',
'3003'=>'项目应用与同步规则未定义',

'4000'=>'应用ID不存在',
'4001'=>'应用键不能为空',
'4002'=>'应用键必须为数字型',
'4003'=>'应用键类型错误',
'4004'=>'应用值必须为数组型',
'4005'=>'应用更新失败',
'4006'=>'应用一次获取条数太多',
'4007'=>'应用获取失败',
'4010'=>'应用类型错误',
'4011'=>'应用键设置与长度不匹配',
'4012'=>'创建应用失败',

);

?>
