<?php
$queue_config = array(
	'question'=> array('type'=>'local','datafile'=>DEFAULT_QUEUE_DATA_FILE,'cmd'=>DEFAULT_QUEUE_ID),
	'comment'=> array('type'=>'local','datafile'=>DEFAULT_QUEUE_DATA_FILE,'cmd'=>DEFAULT_QUEUE_ID),
	'answer'=> array('type'=>'local','datafile'=>DEFAULT_QUEUE_DATA_FILE,'cmd'=>DEFAULT_QUEUE_ID),
	'user'=> array('type'=>'local','datafile'=>DEFAULT_QUEUE_DATA_FILE,'cmd'=>DEFAULT_QUEUE_ID),
	'update_sql'=> array('type'=>'local','datafile'=>DEFAULT_QUEUE_DATA_FILE,'cmd'=>UPDATE_QUEUE_ID),
);
?>
